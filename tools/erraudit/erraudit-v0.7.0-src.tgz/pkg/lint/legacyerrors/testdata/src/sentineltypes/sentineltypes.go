// Package sentineltypes exercises the sentinel_concrete_type rule: package
// level Err*/err* vars whose declared or inferred type is a concrete error
// implementation are flagged, while interface-typed sentinels, non-error
// Err* vars, function-local vars, and suppressed declarations are not.
package sentineltypes

import "errors"

type ptrError struct{ msg string }

func (e *ptrError) Error() string { return e.msg }

func newPtrError(msg string) *ptrError { return &ptrError{msg: msg} }

type valError struct{ msg string }

func (e valError) Error() string { return e.msg }

// ErrPtrConcrete infers *ptrError from the constructor: flagged.
var ErrPtrConcrete = newPtrError("boom") // want `sentinel ErrPtrConcrete has concrete type \*sentineltypes.ptrError`

// ErrValConcrete explicitly declares the concrete value type: flagged.
var ErrValConcrete valError = valError{msg: "bad"} // want `sentinel ErrValConcrete has concrete type sentineltypes.valError`

// ErrExplicitPtr explicitly declares the pointer type: flagged.
var ErrExplicitPtr *ptrError = newPtrError("nope") // want `sentinel ErrExplicitPtr has concrete type \*sentineltypes.ptrError`

// cloneError mirrors the go-error-family clone idiom: WithContextAny exists
// only on the concrete type, so the error-interface rewrite would not compile.
type cloneError struct{ msg string }

func (e *cloneError) Error() string { return e.msg }

func (e *cloneError) WithContextAny(key string, value any) *cloneError { return e }

func newCloneError(msg string) *cloneError { return &cloneError{msg: msg} }

// errCloneBase is load-bearing: the .WithContextAny call below requires the
// concrete type, so it gets the load-bearing message and NO auto-fix.
var errCloneBase = newCloneError("base") // want `sentinel errCloneBase has concrete type \*sentineltypes\.cloneError and is load-bearing`

func cloneFromBase() error {
	return errCloneBase.WithContextAny("k", "v")
}

// useError pins the boundary: .Error() is interface-legal, so a sentinel with
// only Error selections keeps the rewrite advice (see ErrExplicitPtr).
func useError() {
	_ = ErrExplicitPtr.Error()
}

// errUnexportedConcrete follows the unexported sentinel naming convention: flagged.
var errUnexportedConcrete = newPtrError("hidden") // want `sentinel errUnexportedConcrete has concrete type`

// ErrIfaceTyped is correctly declared as the error interface: NOT flagged.
var ErrIfaceTyped error = newPtrError("fine")

// ErrFromErrorsNew infers the error interface from errors.New: NOT flagged.
var ErrFromErrorsNew = errors.New("not found")

// ErrIfaceExplicit is the textbook correct form: NOT flagged.
var ErrIfaceExplicit error = errors.New("explicit")

// ErrCode is Err-prefixed but not an error at all: NOT flagged.
var ErrCode = 42

// suppressedConcrete would be flagged, but carries a suppression comment.
//
//nolint:legacyerrors
var suppressedConcrete = newPtrError("quiet")

func localScope() error {
	// Function-local concrete Err* var: NOT flagged (package-level only).
	errLocal := newPtrError("local")
	return errLocal
}

func useSentinels(err error) {
	if errors.Is(err, ErrIfaceTyped) {
		_ = err
	}

	if errors.Is(err, ErrFromErrorsNew) {
		_ = err
	}
}
