// Package sentinelfix exercises the sentinel_concrete_type auto-fix: the
// error-interface rewrite is applied to single-name specs (inserting the type
// when inferred, replacing it when declared) and withheld for grouped
// multi-name specs, whose per-name initializer types would change semantics.
package sentinelfix

type ptrError struct{ msg string }

func (e *ptrError) Error() string { return e.msg }

func newPtrError(msg string) *ptrError { return &ptrError{msg: msg} }

// ErrUntypedFix infers *ptrError; the fix inserts the interface type after
// the name.
var ErrUntypedFix = newPtrError("untyped") // want `sentinel ErrUntypedFix has concrete type \*sentinelfix\.ptrError`

// ErrTypedFix declares the concrete type; the fix replaces the type
// expression.
var ErrTypedFix *ptrError = newPtrError("typed") // want `sentinel ErrTypedFix has concrete type \*sentinelfix\.ptrError`

// Grouped multi-name spec: advisory message only, no auto-fix.
var (
	ErrGroupedA, ErrGroupedB = newPtrError("a"), newPtrError("b") // want `sentinel ErrGroupedA has concrete type` `sentinel ErrGroupedB has concrete type`
)
