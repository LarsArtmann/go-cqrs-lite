// Package lint exposes the authoritative erraudit lint analysis for in-process
// consumers (the BuildFlow embedded provider, editor integrations, CI gates).
//
// The `erraudit lint` subcommand defines the CANONICAL verdict semantics:
// which rules run, which suppressions apply, and what exit 0 means. This
// package re-exports that exact analysis path — internal/analyzer's
// legacyerrors runner — so an embedded consumer can never drift from the CLI
// by re-implementing rule selection or suppression order on top of the AST
// analyzer (the 2026-10-07 BuildFlow divergence: the embedded detector ran
// MainAnalyzer's AST path and reported context_loss/blank-identifier findings
// the CLI lint never computes, making "which erraudit is authoritative"
// unanswerable).
//
// What this deliberately does NOT include: the suppress+explain finishing
// step (FinalizeViolations) and the output rendering. Callers that need
// //nolint suppression semantics identical to the CLI should apply
// pkg/suppression themselves with the same file set the result names.
package lint

import (
	"github.com/larsartmann/erraudit/internal/analyzer"
	"github.com/larsartmann/erraudit/pkg/types"
)

// Result carries the lint verdict for one analysis target.
type Result struct {
	// Violations are the deduplicated findings of the legacyerrors analyzer,
	// the same list the CLI lint would filter and render.
	Violations []types.ErrorViolation

	// SourceFiles lists every Go file the analysis touched (deduplicated,
	// test variants collapsed). Suppression engines and file-count telemetry
	// should build from this list.
	SourceFiles []string
}

// RunForPatterns runs the authoritative lint analysis for the given package
// patterns, resolved against the process working directory (the CLI lint
// semantics). An empty pattern list defaults to ./... .
func RunForPatterns(patterns []string) (Result, error) {
	return RunForDir("", patterns)
}

// RunForDir is RunForPatterns with the package patterns resolved relative to
// dir (empty means the process working directory). It exists so embedded
// consumers that analyze directories other than their own working directory
// stay chdir-free and safe under parallel execution.
func RunForDir(dir string, patterns []string) (Result, error) {
	legacy, err := analyzer.RunLegacyerrorsForDir(dir, patterns)
	if err != nil {
		return Result{}, err
	}

	return Result{
		Violations:  legacy.Violations,
		SourceFiles: legacy.SourceFiles,
	}, nil
}
