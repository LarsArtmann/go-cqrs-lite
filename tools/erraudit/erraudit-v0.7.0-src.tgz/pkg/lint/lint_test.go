package lint

import (
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
)

// writeFixtureModule creates a minimal Go module with a source file the
// legacyerrors analyzer flags (errors.As, the migration rule the CLI lint
// and the repairer both use).
func writeFixtureModule(t *testing.T) string {
	t.Helper()

	dir := t.TempDir()
	if err := os.MkdirAll(dir, 0o750); err != nil {
		t.Fatalf("mkdir: %v", err)
	}

	if err := os.WriteFile(
		filepath.Join(dir, "go.mod"),
		[]byte("module example.com/fixture\n\ngo 1.27\n"),
		0o600,
	); err != nil {
		t.Fatalf("go.mod: %v", err)
	}

	src := "package fixture\n\nimport (\n\t\"errors\"\n\t\"os\"\n)\n\ntype myErr struct{}\n\nfunc (*myErr) Error() string { return \"my\" }\n\nfunc IsMyErr(err error) bool {\n\tvar target *myErr\n\treturn errors.As(err, &target)\n}\n\nvar _ = os.Stat\n"
	if err := os.WriteFile(filepath.Join(dir, "fixture.go"), []byte(src), 0o600); err != nil {
		t.Fatalf("fixture.go: %v", err)
	}

	return dir
}

func TestRunForDir_MatchesCLILint(t *testing.T) {
	dir := writeFixtureModule(t)

	result, err := RunForDir(dir, []string{"./..."})
	if err != nil {
		t.Fatalf("RunForDir failed: %v", err)
	}

	if len(result.Violations) == 0 {
		t.Fatal("expected the swallowed-error fixture to produce violations")
	}

	if len(result.SourceFiles) == 0 {
		t.Fatal("expected source files to be reported")
	}
}

// TestRunForDir_CleanModuleIsEmpty pins the empty verdict on a clean module:
// the result must carry zero violations (and not error) so the exit-0
// semantics of the CLI lint are preserved in-process.
func TestRunForDir_CleanModuleIsEmpty(t *testing.T) {
	dir := t.TempDir()

	if err := os.WriteFile(
		filepath.Join(dir, "go.mod"),
		[]byte("module example.com/clean\n\ngo 1.27\n"),
		0o600,
	); err != nil {
		t.Fatalf("go.mod: %v", err)
	}

	src := "package clean\n\nimport (\n\t\"os\"\n)\n\nfunc WriteConfig() error {\n\treturn os.WriteFile(\"cfg\", nil, 0o600)\n}\n"
	if err := os.WriteFile(filepath.Join(dir, "clean.go"), []byte(src), 0o600); err != nil {
		t.Fatalf("clean.go: %v", err)
	}

	result, err := RunForDir(dir, []string{"./..."})
	if err != nil {
		t.Fatalf("RunForDir failed: %v", err)
	}

	if len(result.Violations) != 0 {
		var msgs []string
		for _, v := range result.Violations {
			msgs = append(msgs, v.Type.String()+": "+v.Message)
		}

		t.Fatalf("expected zero violations on the clean fixture, got: %s", strings.Join(msgs, "; "))
	}
}

// TestRunForDir_MissingModuleDegradesLikeCLI documents the degraded shape
// for a directory without module context: go/packages reports the load error
// on the package (printed by the runner), the result comes back empty, and
// no error is returned — the exact CLI lint behavior.
func TestRunForDir_MissingModuleDegradesLikeCLI(t *testing.T) {
	if _, err := exec.LookPath("go"); err != nil {
		t.Skip("go toolchain unavailable")
	}

	dir := t.TempDir()

	result, err := RunForDir(dir, []string{"./..."})
	if err != nil {
		t.Fatalf("RunForDir must degrade like the CLI (empty result, no error), got: %v", err)
	}

	if len(result.Violations) != 0 || len(result.SourceFiles) != 0 {
		t.Fatalf("expected an empty result without module context, got %d violation(s), %d file(s)",
			len(result.Violations), len(result.SourceFiles))
	}
}
