package errors

import (
	errorfamily "github.com/larsartmann/go-error-family"
)

// init registers user-facing message templates for all domain error codes.
// These templates provide What/Why/Fix/WayOut messages that errorfamily.HandleError
// uses to render helpful CLI error output.
//
//nolint:gochecknoinits // Package-level template registration for CLI error handling
func init() {
	templates := map[string]errorfamily.MessageTemplate{
		CodeConfigInvalid: {
			What:   "The configuration is invalid.",
			Why:    "One or more configuration values are missing, malformed, or contradictory.",
			Fix:    "Check the highlighted field and correct it to match the expected type and constraints.",
			WayOut: "Run with --help to see valid options, or remove the config file to use defaults.",
		},
		CodeFileNotGo: {
			What:   "The specified path does not point to a Go source file.",
			Why:    "The analyzer only works with .go files or directories containing .go files.",
			Fix:    "Provide a path ending in .go or a directory path.",
			WayOut: "Use 'erraudit .' to analyze the current directory.",
		},
		CodeExtensionNotFound: {
			What:   "A requested extension was not found.",
			Why:    "The extension name does not match any registered extension.",
			Fix:    "Check the extension name spelling or register the extension before use.",
			WayOut: "List available extensions with 'erraudit extension list'.",
		},
		CodeCacheItemTooLarge: {
			What:   "A cache item exceeds the maximum allowed size.",
			Why:    "The file or analysis result is too large to cache efficiently.",
			Fix:    "Increase the cache size limit or exclude large generated files.",
			WayOut: "Use --exclude to skip large generated directories.",
		},
		CodeTypeUnsupported: {
			What:   "An unsupported type was encountered.",
			Why:    "The analyzer encountered a Go type it doesn't know how to process.",
			Fix:    "Report this as a bug with the code that triggered it.",
			WayOut: "Use --exclude to skip the affected file.",
		},
		CodeOutputNoStrategy: {
			What:   "No output strategy is registered for the requested format.",
			Why:    "The format name is not recognized or the format module is not loaded.",
			Fix:    "Use a supported format name. Run with --help to see valid formats.",
			WayOut: "Use 'tree' or 'json' as a safe default format.",
		},
		CodePathEmpty: {
			What:   "The analysis path cannot be empty.",
			Why:    "No path was provided and no default path is available.",
			Fix:    "Provide a file or directory path as an argument.",
			WayOut: "Use 'erraudit .' to analyze the current directory.",
		},
		CodeFlagViolationsOnlyConflict: {
			What:   "The --violations-only flag is not compatible with this output format.",
			Why:    "This format requires full output (metrics, hierarchy, etc.) and cannot show only violations.",
			Fix:    "Remove --violations-only or switch to a compatible format (tree, json).",
			WayOut: "Use 'erraudit . --format tree --violations-only'.",
		},
		CodeFlagVerboseConflict: {
			What:   "The --verbose flag is not compatible with output to a file.",
			Why:    "Verbose output includes progress information meant for terminal display only.",
			Fix:    "Remove --verbose or output to stdout instead of a file.",
			WayOut: "Use 'erraudit . --verbose' without --output.",
		},
		CodeValueInvalid: {
			What:   "A provided value is not valid for its target type.",
			Why:    "The value does not match any of the allowed values for this setting (e.g. an unknown output format, severity, or error type).",
			Fix:    "Check the allowed values in the error message and correct the flag or config value.",
			WayOut: "Run with --help to list valid values for every flag.",
		},
		CodeExtensionNameMissing: {
			What:   "An extension command was called without an extension name.",
			Why:    "Extension enable/disable/info commands operate on a named extension, and no name argument was provided.",
			Fix:    "Add the extension name as an argument.",
			WayOut: "List available extensions with 'erraudit extension list'.",
		},
		CodeFixCancelledByHook: {
			What:   "The fix run was cancelled by a pre-fix hook.",
			Why:    "A registered extension hook vetoed the fix before any file was modified.",
			Fix:    "No files were changed. Adjust the hook if the cancellation was unintended.",
			WayOut: "Re-run without the hook (see --disable-extensions) or fix the condition the hook checks.",
		},
		CodeAnalysisCancelledByHook: {
			What:   "The analysis was cancelled by a pre-analysis hook.",
			Why:    "A registered extension hook vetoed the analysis before any file was scanned.",
			Fix:    "No results were produced. Adjust the hook if the cancellation was unintended.",
			WayOut: "Re-run without the hook (see --disable-extensions) or fix the condition the hook checks.",
		},
		CodeAnalysisToolchainMissing: {
			What:   "The go toolchain is required but was not found on PATH.",
			Why:    "Type-aware analysis resolves packages through go/packages, which shells out to the go command.",
			Fix:    "Install the Go toolchain or ensure go is on PATH.",
			WayOut: "Run without --type-aware for pure-AST analysis (no toolchain needed).",
		},
		CodeOutputEnvelopeMarshal: {
			What:   "The machine-readable error envelope could not be serialized.",
			Why:    "The error being reported contains a value the JSON encoder cannot represent.",
			Fix:    "This is an erraudit bug — report it with the command that triggered the failure.",
			WayOut: "The human-readable error on stderr still classifies the failure; the exit code is unaffected.",
		},
		CodeOutputEnvelopeWrite: {
			What:   "The machine-readable error envelope could not be written.",
			Why:    "The output stream was closed or broken before the envelope could be flushed.",
			Fix:    "Ensure stdout is not closed early when piping erraudit output.",
			WayOut: "The human-readable error on stderr still classifies the failure; the exit code is unaffected.",
		},
		CodeOutputErrorflowMarshal: {
			What:   "The errorflow export document could not be marshaled to JSON.",
			Why:    "The analyzed error hierarchy contains a value the JSON encoder cannot represent.",
			Fix:    "This is an erraudit bug — report it with the command that triggered the failure.",
			WayOut: "The analysis itself succeeded; re-run with --markdown for a text rendering.",
		},
	}

	errorfamily.DefaultRegistry.RegisterTemplates(templates)
}
