/*
Package errors provides centralized error definitions and utilities for the erraudit analyzer.

This package uses github.com/larsartmann/go-error-family as the underlying error type,
providing professional CLI error handling with proper exit codes, error classification
(Rejection, Conflict, Transient, Corruption, Infrastructure), and user-facing
message templates.

The domain errors form a hierarchy visible to erraudit's own tree subcommand:

	ErrInput                          (root: user-fixable input/config errors)
	├── ErrConfigInvalid              (config.invalid)
	├── ErrNotGoFile                  (file.not_go)
	├── ErrPathEmpty                  (path.empty)
	├── ErrViolationsOnlyIncompatible (flag.violations_only_incompatible)
	└── ErrVerboseIncompatible        (flag.verbose_incompatible)

	ErrAnalysis                       (root: analysis-time failures)
	├── ErrUnsupportedType            (type.unsupported)
	└── ErrCacheItemTooLarge          (cache.item_too_large)

	ErrOutput                         (root: output/rendering failures)
	└── ErrNoStrategyRegistered       (output.no_strategy)

	ErrExtension                      (root: extension system failures)
	├── ErrExtensionNotFound          (extension.not_found)
	└── ErrExtensionNameMissing       (extension.name_missing)

	ErrInput also covers user-input value failures:
	├── ErrValueInvalid               (value.invalid)
	└── ErrFixCancelledByHook         (fix.cancelled_by_hook)

# Usage

Creating wrapped errors:

	if err != nil {
	    return errors.Wrap(err, "failed to analyze package")
	}

Creating new errors with context:

	return errors.New("analysis failed: %s", packagePath)

Getting the proper CLI exit code for an error:

	exitCode := errors.HandleError(err)
	os.Exit(exitCode)

# Coded-error standard and the deliberately uncoded sites (T2.7 triage)

Every user-facing error must be a coded sentinel from this package, or a Wrap
of one — Wrap inherits the cause's code, so templates survive wrapping. The
opt-in --enforce-coded-errors check flags go-error-family constructor calls
whose code argument is the literal "".

A small set of internal invariant errors stays uncoded BY DESIGN. These report
programming bugs (broken invariants), never user mistakes, so they have no
taxonomy membership and no What/Why/Fix template:

  - cmd/erraudit/cmd/cli.go, "configuration not found in context": cmdguard
    wiring invariant — the config is always installed during flag parse; a
    miss is a framework bug, not user input.
  - internal/fix/applier.go (4 sites, overlapping/invalid text edits): the
    fix engine validates its own TextEdits; a violation means an analyzer
    produced malformed edits (a bug), not a user-facing failure.
  - pkg/types, ErrConfidenceOutOfRange: the Confidence type invariant
    [0.0, 1.0]; NewConfidence panics on construction, so a violation means
    the type system was bypassed.

If any of these ever becomes user-reachable through a normal workflow,
promote it to a coded sentinel at that point — not before. The same applies
to the New delegate below: its empty code is deliberate (context messages
have no taxonomy membership) and is pinned as the accepted
--enforce-coded-errors baseline (1) instead of nolinted, because nolint-audit
would flag the directive stale — the check is opt-in and never runs in its
default mode.
*/
package errors

import (
	"fmt"

	errorfamily "github.com/larsartmann/go-error-family"
)

// Error codes used as ErrorCode() values and template registration keys.
const (
	CodeConfigInvalid              = "config.invalid"
	CodeFileNotGo                  = "file.not_go"
	CodeExtensionNotFound          = "extension.not_found"
	CodeCacheItemTooLarge          = "cache.item_too_large"
	CodeTypeUnsupported            = "type.unsupported"
	CodeOutputNoStrategy           = "output.no_strategy"
	CodePathEmpty                  = "path.empty"
	CodeFlagViolationsOnlyConflict = "flag.violations_only_incompatible"
	CodeFlagVerboseConflict        = "flag.verbose_incompatible"
	CodeValueInvalid               = "value.invalid"
	CodeExtensionNameMissing       = "extension.name_missing"
	CodeFixCancelledByHook         = "fix.cancelled_by_hook"
	CodeAnalysisCancelledByHook    = "analysis.cancelled_by_hook"
	CodeAnalysisToolchainMissing   = "analysis.toolchain_missing"
	CodeOutputEnvelopeMarshal      = "output.envelope_marshal"
	CodeOutputEnvelopeWrite        = "output.envelope_write"
	CodeOutputErrorflowMarshal     = "output.errorflow_marshal"
)

// ============================================================================
// Domain Hierarchy
//
// Domain roots are standalone errorfamily errors. Leaf errors wrap their
// domain root via errorfamily.WrapRejection, creating a hierarchy visible to
// erraudit's own tree subcommand (the discoverer recognizes errorfamily.Wrap*
// calls as wrapping relationships).
// ============================================================================

// Domain roots. Declared as the error interface (stdlib sentinel convention):
// the dynamic type stays *errorfamily.Error, but declaring error lets
// errors.Is(err, ErrX) call sites pass the legacyerrors sentinel guard and
// satisfies the sentinel_concrete_type rule.
var (
	ErrInput error = errorfamily.NewRejection("input", "input error")

	ErrAnalysis error = errorfamily.NewRejection("analysis", "analysis error")

	ErrOutput error = errorfamily.NewRejection("output", "output error")

	ErrExtension error = errorfamily.NewRejection("extension", "extension error")
)

// Domain leaf errors — each wraps its domain root.
var (
	ErrConfigInvalid error = errorfamily.WrapRejection(
		ErrInput, CodeConfigInvalid, "invalid configuration",
	)
	ErrNotGoFile error = errorfamily.WrapRejection(
		ErrInput, CodeFileNotGo, "path does not point to a Go file",
	)
	ErrPathEmpty error = errorfamily.WrapRejection(
		ErrInput, CodePathEmpty, "path cannot be empty",
	)
	ErrViolationsOnlyIncompatible error = errorfamily.WrapRejection(
		ErrInput, CodeFlagViolationsOnlyConflict,
		"violations-only is not compatible with format",
	)
	ErrVerboseIncompatible error = errorfamily.WrapRejection(
		ErrInput, CodeFlagVerboseConflict,
		"verbose is not compatible with output file",
	)

	ErrUnsupportedType error = errorfamily.WrapRejection(
		ErrAnalysis, CodeTypeUnsupported, "unsupported type",
	)
	ErrCacheItemTooLarge error = errorfamily.WrapRejection(
		ErrAnalysis, CodeCacheItemTooLarge,
		"item size exceeds maximum cache size",
	)

	ErrNoStrategyRegistered error = errorfamily.WrapRejection(
		ErrOutput, CodeOutputNoStrategy,
		"no strategy registered for format",
	)

	ErrExtensionNotFound error = errorfamily.WrapRejection(
		ErrExtension, CodeExtensionNotFound, "extension not found",
	)
	ErrExtensionNameMissing error = errorfamily.WrapRejection(
		ErrExtension, CodeExtensionNameMissing, "extension name is required",
	)

	ErrValueInvalid error = errorfamily.WrapRejection(
		ErrInput, CodeValueInvalid, "invalid value",
	)
	ErrFixCancelledByHook error = errorfamily.WrapRejection(
		ErrInput, CodeFixCancelledByHook, "fix cancelled by pre-fix hook",
	)

	ErrAnalysisCancelledByHook error = errorfamily.WrapRejection(
		ErrAnalysis, CodeAnalysisCancelledByHook,
		"analysis cancelled by pre-analysis hook",
	)
	ErrAnalysisToolchainMissing error = errorfamily.WrapRejection(
		ErrAnalysis, CodeAnalysisToolchainMissing,
		"type-aware analysis requires the go toolchain",
	)

	ErrEnvelopeMarshal error = errorfamily.WrapRejection(
		ErrOutput, CodeOutputEnvelopeMarshal,
		"failed to marshal the error envelope",
	)
	ErrEnvelopeWrite error = errorfamily.WrapRejection(
		ErrOutput, CodeOutputEnvelopeWrite,
		"failed to write the error envelope",
	)
	ErrErrorflowMarshal error = errorfamily.WrapRejection(
		ErrOutput, CodeOutputErrorflowMarshal,
		"failed to marshal the errorflow export",
	)
)

// ============================================================================
// Error Constructor Functions
// ============================================================================

// New creates a new Rejection error with the given formatted message.
// Context-message delegate without taxonomy membership: user-facing failures
// must use a coded sentinel instead (Wrap inherits the cause's code). The
// deliberate empty code is pinned as the accepted --enforce-coded-errors
// baseline (1) rather than nolinted — nolint-audit would flag the directive
// stale because the check is opt-in and never runs in its default mode.
func New(format string, args ...any) error {
	return errorfamily.NewRejection("", fmt.Sprintf(format, args...))
}

// Wrap wraps an existing error as a Rejection with additional context.
// The wrapper inherits the cause's error code (outermost code wins in
// errorfamily.Code lookup), so wrapping a coded sentinel preserves its
// What/Why/Fix template and suggested fix at the CLI boundary. Wrapping an
// uncoded error leaves the code empty, exactly as before.
// Returns nil if err is nil.
func Wrap(err error, format string, args ...any) error {
	if err == nil {
		return nil
	}

	return errorfamily.WrapRejectionf(err, errorfamily.Code(err), format, args...)
}

// WrapContext wraps like Wrap and attaches structured key/value pairs that
// surface in the JSON error envelope and HandleErrorDetailed output — the
// operational context (pattern, mode, files) a debugger needs without
// re-running the command.
func WrapContext(err error, context map[string]string, format string, args ...any) error {
	if err == nil {
		return nil
	}

	return errorfamily.WrapRejectionf(err, errorfamily.Code(err), format, args...).
		WithContextMap(context)
}

// FormatWithCause formats an error message with optional underlying cause.
func FormatWithCause(message string, cause error) string {
	if cause != nil {
		return fmt.Sprintf("%s: %v", message, cause)
	}

	return message
}

// ============================================================================
// go-error-family Integration
// ============================================================================

// HandleError delegates to errorfamily.HandleError, which classifies the error,
// renders a user-friendly message to stderr, and returns the proper exit code.
func HandleError(err error) int {
	return errorfamily.HandleError(err)
}

// ExitCode returns the BSD sysexits.h exit code for the given error.
// nil → 0, Rejection → 1, Transient → 75, Corruption → 65, Infrastructure → 69.
func ExitCode(err error) int {
	return errorfamily.ExitCode(err)
}

// Classify returns the go-error-family Family for the given error.
func Classify(err error) errorfamily.Family {
	return errorfamily.Classify(err)
}

// RegisterMessageTemplate registers a user-facing message template for a
// specific error code.
func RegisterMessageTemplate(code string, template errorfamily.MessageTemplate) {
	errorfamily.DefaultRegistry.RegisterTemplate(code, template)
}
