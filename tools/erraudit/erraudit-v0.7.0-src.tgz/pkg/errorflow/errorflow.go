// Package errorflow exports the error-surface coeffects of an analyzed
// module — every named error with its kind, go-error-family code and
// family, declaration site, declared parent, inline wrap sites, errors.Is
// check sites, and a referenced/unreferenced status — as a stable,
// deterministic JSON document (and a Markdown rendering of the same).
//
// Downstream consumers (EventCatalog x-errors frontmatter, the hub's
// error-insights page, generated taxonomy docs) read the Export schema,
// NOT erraudit internals: schema changes bump SchemaVersion.
//
// Status vocabulary (mirrors the tree command's reference annotation):
//
//   - referenced: the error has inline wrap sites, errors.Is checks, or a
//     declared relationship (parent or child in var X = fmt.Errorf("%w", Y)
//     style declarations).
//   - unreferenced: zero inline references AND no declared relationships
//     AND no children — the dead-sentinel candidate signal (hedged:
//     identifier references within the analyzed scope; cross-package
//     references resolve via selector attribution).
package errorflow

import (
	"encoding/json"
	"fmt"
	"go/token"
	"sort"
	"strings"

	apierrors "github.com/larsartmann/erraudit/pkg/errors"
	"github.com/larsartmann/erraudit/pkg/types"
)

// SchemaVersion is the errorflow export schema version. Bump on any
// breaking change to the Export shape.
//
// v2 adds the template-text columns (What/Why/Fix/WayOut) per error, joined
// from go-error-family MessageTemplate registrations in the analyzed source.
const SchemaVersion = 2

// Status values for ErrorEntry.Status.
const (
	StatusReferenced   = "referenced"
	StatusUnreferenced = "unreferenced"
)

// Site is one inline reference site: the call position (file:line) plus the
// enclosing function name.
type Site struct {
	Position string `json:"position"`
	Function string `json:"function,omitempty"`
}

// CodeEntry is one go-error-family code minted anywhere in the analyzed
// scope — named sentinel or inline constructor call — with the family the
// constructor actually constructs and the first minting position. Taxonomy
// doc generators consume this as ground truth (schemaVersion 2).
type CodeEntry struct {
	Code     string `json:"code"`
	Family   string `json:"family"`
	Declared string `json:"declared,omitempty"`
}

// ErrorEntry is one named error in the export.
type ErrorEntry struct {
	Name      string `json:"name"`
	Kind      string `json:"kind"`
	Code      string `json:"code,omitempty"`
	Family    string `json:"family,omitempty"`
	Message   string `json:"message,omitempty"`
	Declared  string `json:"declared"`
	Wraps     string `json:"wraps,omitempty"`
	WrappedBy []Site `json:"wrappedBy,omitempty"`
	CheckedBy []Site `json:"checkedBy,omitempty"`
	Status    string `json:"status"`

	// What/Why/Fix/WayOut carry the registered go-error-family message
	// template texts for this error's code (schemaVersion 2). Empty when the
	// code has no registration or the error is uncoded.
	What   string `json:"what,omitempty"`
	Why    string `json:"why,omitempty"`
	Fix    string `json:"fix,omitempty"`
	WayOut string `json:"wayOut,omitempty"`
}

// Export is the complete errorflow document for one analysis.
type Export struct {
	SchemaVersion int          `json:"schemaVersion"`
	Package       string       `json:"package,omitempty"`
	FilesScanned  int          `json:"filesScanned"`
	Errors        []ErrorEntry `json:"errors"`

	// Codes carries every go-error-family code minted in the analyzed scope
	// (named or inline), sorted by code, deduplicated. Empty for modules
	// without go-error-family constructors.
	Codes []CodeEntry `json:"codes,omitempty"`
}

// FromGraph derives the errorflow export from a finalized ErrorGraph. The
// errors are sorted by name for byte-stable output (golden snapshots, dist
// diffing). A nil hierarchy yields an empty export — callers decide whether
// that is expected (the CLI warns).
func FromGraph(graph *types.ErrorGraph) Export {
	export := Export{
		SchemaVersion: SchemaVersion,
		Package:       graph.Package,
		FilesScanned:  graph.FilesScanned,
		Errors:        []ErrorEntry{},
		Codes:         nil,
	}

	if graph.Hierarchy == nil {
		return export
	}

	hierarchy := graph.Hierarchy

	namedBy := make(map[string]types.NamedError, len(hierarchy.NamedErrors))
	for _, named := range hierarchy.NamedErrors {
		namedBy[named.Name] = named
	}

	declConnected := make(map[string]bool, 2*len(hierarchy.Relationships))
	for _, rel := range hierarchy.Relationships {
		declConnected[rel.Parent] = true
		declConnected[rel.Child] = true
	}

	wrapRefs := hierarchy.Metrics.WrapSiteRefs
	checkRefs := hierarchy.Metrics.CheckSiteRefs

	for _, name := range sortedKeys(hierarchy.AllNodes) {
		node := hierarchy.AllNodes[name]
		named := namedBy[name]

		// Template texts join on the code as written (literal value or Code*
		// identifier name); a nil/absent map yields zero texts for every code.
		texts := hierarchy.MessageTemplates[named.Code]

		entry := ErrorEntry{
			Name:      name,
			Kind:      string(node.Kind),
			Code:      named.Code,
			Family:    named.Family,
			Message:   named.Message,
			Declared:  formatPosition(node.Position),
			WrappedBy: sitesFor(wrapRefs, name),
			CheckedBy: sitesFor(checkRefs, name),
			Wraps:     "",
			Status:    "",
			What:      texts.What,
			Why:       texts.Why,
			Fix:       texts.Fix,
			WayOut:    texts.WayOut,
		}

		if named.ParentName != "" {
			entry.Wraps = named.ParentName
		}

		referenced := len(entry.WrappedBy) > 0 ||
			len(entry.CheckedBy) > 0 ||
			declConnected[name] ||
			len(node.Children) > 0

		if referenced {
			entry.Status = StatusReferenced
		} else {
			entry.Status = StatusUnreferenced
		}

		export.Errors = append(export.Errors, entry)
	}

	export.Codes = codeEntries(hierarchy.InlineCodes)

	return export
}

// codeEntries projects the collected go-error-family mints into the export's
// codes array: sorted by code (then family), deduplicated per code+family
// pair — a code minted with two different families stays as two entries so
// taxonomy gates surface the conflict instead of hiding it.
func codeEntries(codes []types.InlineCode) []CodeEntry {
	if len(codes) == 0 {
		return nil
	}

	sorted := make([]types.InlineCode, 0, len(codes))
	sorted = append(sorted, codes...)
	sort.Slice(sorted, func(i, j int) bool {
		if sorted[i].Code != sorted[j].Code {
			return sorted[i].Code < sorted[j].Code
		}

		return sorted[i].Family < sorted[j].Family
	})

	entries := make([]CodeEntry, 0, len(sorted))
	for _, code := range sorted {
		if len(entries) > 0 &&
			entries[len(entries)-1].Code == code.Code &&
			entries[len(entries)-1].Family == code.Family {
			continue
		}

		entries = append(entries, CodeEntry{
			Code:     code.Code,
			Family:   code.Family,
			Declared: formatPosition(code.Position),
		})
	}

	return entries
}

// JSON renders the export as indented JSON with a trailing newline.
func (e Export) JSON() ([]byte, error) {
	data, err := json.MarshalIndent(e, "", "  ")
	if err != nil {
		return nil, apierrors.Wrap(apierrors.ErrErrorflowMarshal, "marshal export: %v", err)
	}

	return append(data, '\n'), nil
}

// Markdown renders the export as a coeffects table: one row per error with
// kind, code, family, the registered What text, wrap/check site counts, and
// status. Site details (positions, functions) and the full Why/Fix/WayOut
// texts live in the JSON export — the table stays scannable.
func (e Export) Markdown() string {
	var builder strings.Builder

	builder.WriteString("# Error Flow\n\n")

	if e.Package != "" {
		fmt.Fprintf(&builder, "Analyzed package: `%s` · files scanned: %d\n\n", e.Package, e.FilesScanned)
	}

	builder.WriteString("| Error | Kind | Code | Family | What | Wrapped by | Checked by | Status |\n")
	builder.WriteString("| --- | --- | --- | --- | --- | --- | --- | --- |\n")

	for _, entry := range e.Errors {
		fmt.Fprintf(
			&builder,
			"| `%s` | %s | %s | %s | %s | %d | %d | %s |\n",
			entry.Name,
			entry.Kind,
			cellOrDash(entry.Code),
			cellOrDash(entry.Family),
			cellOrDash(entry.What),
			len(entry.WrappedBy),
			len(entry.CheckedBy),
			entry.Status,
		)
	}

	return builder.String()
}

// sitesFor returns the reference sites for one error name, sorted by
// position for deterministic output.
func sitesFor(refs map[string][]types.ErrorSiteRef, name string) []Site {
	siteRefs, ok := refs[name]
	if !ok {
		return nil
	}

	sites := make([]Site, 0, len(siteRefs))
	for _, ref := range siteRefs {
		sites = append(sites, Site{
			Position: formatPosition(ref.Position),
			Function: ref.Function,
		})
	}

	sort.Slice(sites, func(i, j int) bool {
		if sites[i].Position != sites[j].Position {
			return sites[i].Position < sites[j].Position
		}

		return sites[i].Function < sites[j].Function
	})

	return sites
}

// formatPosition renders a token position as "file:line" with the absolute
// directory prefix trimmed to the base name (positions move between
// machines; base names are stable).
func formatPosition(pos token.Position) string {
	if pos.Filename == "" {
		return ""
	}

	file := pos.Filename
	if slash := strings.LastIndex(file, "/"); slash >= 0 {
		file = file[slash+1:]
	}

	if pos.Line > 0 {
		return fmt.Sprintf("%s:%d", file, pos.Line)
	}

	return file
}

// art-dupl:accept trivial map-keys collection idiom, 5 lines, unrelated packages (fix/applier groups by file)
func sortedKeys[V any](mapping map[string]V) []string {
	keys := make([]string, 0, len(mapping))
	for key := range mapping {
		keys = append(keys, key)
	}

	sort.Strings(keys)

	return keys
}

func cellOrDash(value string) string {
	if value == "" {
		return "-"
	}

	return "`" + value + "`"
}
