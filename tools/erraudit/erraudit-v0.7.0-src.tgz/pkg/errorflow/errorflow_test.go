package errorflow_test

import (
	"encoding/json"
	"go/token"
	"testing"

	"github.com/larsartmann/erraudit/pkg/errorflow"
	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// fixtureGraph builds a small finalized-graph shape covering every status
// path: a referenced root (inline checks), a decl-connected child, a
// wrap-site user, and an unreferenced dead sentinel.
func fixtureGraph() *types.ErrorGraph {
	root := &types.ErrorNode{Name: "ErrRoot", Kind: types.ErrorKindNew, Position: pos("errors.go", 10)}
	child := &types.ErrorNode{Name: "ErrChild", Kind: types.ErrorKindWrap, Position: pos("errors.go", 20)}
	root.Children = []*types.ErrorNode{child}

	dead := &types.ErrorNode{Name: "ErrDead", Kind: types.ErrorKindNew, Position: pos("errors.go", 30)}

	hierarchy := &types.ErrorHierarchy{
		RootErrors: []*types.ErrorNode{root, dead},
		AllNodes: map[string]*types.ErrorNode{
			"ErrRoot":  root,
			"ErrChild": child,
			"ErrDead":  dead,
		},
		Relationships: []types.ErrorRelationship{{
			Parent: "ErrRoot", Child: "ErrChild",
			RelationshipType: types.RelationshipTypeWraps, Position: pos("errors.go", 20),
		}},
		NamedErrors: []types.NamedError{
			{
				Name: "ErrRoot", Kind: types.ErrorKindNew, Message: "root",
				Position: pos("errors.go", 10), FileName: "errors.go",
			},
			{
				Name: "ErrChild", Kind: types.ErrorKindFamilyWrap, Message: "child",
				Position: pos("errors.go", 20), FileName: "errors.go",
				ParentName: "ErrRoot", Code: "root.child", Family: "rejection",
			},
			{
				Name: "ErrDead", Kind: types.ErrorKindNew, Message: "dead",
				Position: pos("errors.go", 30), FileName: "errors.go",
			},
		},
	}
	hierarchy.Metrics.WrapSiteRefs = map[string][]types.ErrorSiteRef{
		"ErrChild": {
			{Position: pos("service.go", 42), Function: "(*S).Do"},
			{Position: pos("api.go", 7), Function: "handle"},
		},
	}
	hierarchy.Metrics.CheckSiteRefs = map[string][]types.ErrorSiteRef{
		"ErrRoot": {{Position: pos("service.go", 50), Function: "(*S).Do"}},
	}

	return &types.ErrorGraph{
		Package:      "./pkg/...",
		Hierarchy:    hierarchy,
		FilesScanned: 3,
	}
}

func pos(file string, line int) token.Position {
	return token.Position{Filename: "/abs/path/to/" + file, Line: line}
}

func TestFromGraph_StatusSemantics(t *testing.T) {
	export := errorflow.FromGraph(fixtureGraph())

	byName := map[string]errorflow.ErrorEntry{}
	for _, entry := range export.Errors {
		byName[entry.Name] = entry
	}

	require.Len(t, export.Errors, 3)
	assert.Equal(t, errorflow.StatusReferenced, byName["ErrRoot"].Status,
		"inline checks make a node referenced")
	assert.Equal(t, errorflow.StatusReferenced, byName["ErrChild"].Status,
		"wrap sites AND declared relationships make a node referenced")
	assert.Equal(t, errorflow.StatusUnreferenced, byName["ErrDead"].Status,
		"no sites, no relationships, no children = dead-sentinel candidate")
}

func TestFromGraph_DeterministicOrderAndSites(t *testing.T) {
	export := errorflow.FromGraph(fixtureGraph())

	names := make([]string, 0, len(export.Errors))
	for _, entry := range export.Errors {
		names = append(names, entry.Name)
	}
	assert.Equal(t, []string{"ErrChild", "ErrDead", "ErrRoot"}, names,
		"errors are sorted by name for byte-stable output")

	child := export.Errors[0]
	require.Len(t, child.WrappedBy, 2)
	assert.Equal(t, "api.go:7", child.WrappedBy[0].Position,
		"sites are sorted by position")
	assert.Equal(t, "handle", child.WrappedBy[0].Function)
	assert.Equal(t, "root.child", child.Code)
	assert.Equal(t, "rejection", child.Family)
	assert.Equal(t, "ErrRoot", child.Wraps)
	assert.Equal(t, "errors.go:20", child.Declared,
		"positions render as basename:line, machine paths stripped")
}

func TestFromGraph_CodeEntriesSortedAndDeduped(t *testing.T) {
	graph := fixtureGraph()
	graph.Hierarchy.InlineCodes = []types.InlineCode{
		{Code: "root.child", Family: "rejection", Position: pos("errors.go", 9)},
		{Code: "a.first", Family: "rejection", Position: pos("a.go", 1)},
		{Code: "a.first", Family: "rejection", Position: pos("a.go", 5)},
		{Code: "a.second", Family: "conflict", Position: pos("a.go", 2)},
	}

	export := errorflow.FromGraph(graph)

	require.Len(t, export.Codes, 3)
	assert.Equal(t, "a.first", export.Codes[0].Code)
	assert.Equal(t, "a.go:1", export.Codes[0].Declared)
	assert.Equal(t, "a.second", export.Codes[1].Code)
	assert.Equal(t, "conflict", export.Codes[1].Family)
	assert.Equal(t, "root.child", export.Codes[2].Code)
}

func TestFromGraph_NilHierarchy(t *testing.T) {
	export := errorflow.FromGraph(&types.ErrorGraph{FilesScanned: 0})

	assert.Empty(t, export.Errors)
	assert.Equal(t, errorflow.SchemaVersion, export.SchemaVersion)
}

func TestJSON_RoundTrip(t *testing.T) {
	export := errorflow.FromGraph(fixtureGraph())

	data, err := export.JSON()
	require.NoError(t, err)

	var decoded errorflow.Export
	require.NoError(t, json.Unmarshal(data, &decoded))

	assert.Equal(t, errorflow.SchemaVersion, decoded.SchemaVersion)
	assert.Len(t, decoded.Errors, 3)
	assert.Equal(t, "ErrChild", decoded.Errors[0].Name)
}

func TestMarkdown_TableShape(t *testing.T) {
	export := errorflow.FromGraph(fixtureGraph())

	rendered := export.Markdown()

	assert.Contains(t, rendered, "# Error Flow")
	assert.Contains(t, rendered, "| Error | Kind | Code | Family | What | Wrapped by | Checked by | Status |")
	assert.Contains(t, rendered, "`ErrChild`")
	assert.Contains(t, rendered, "`root.child`")
	assert.Contains(t, rendered, "unreferenced")
	assert.Contains(t, rendered, "`./pkg/...`", "package identity is rendered")
}

func TestFromGraph_TemplateTextsJoinOnCode(t *testing.T) {
	graph := fixtureGraph()
	graph.Hierarchy.MessageTemplates = map[string]types.TemplateTexts{
		"root.child": {
			What:   "The child is invalid.",
			Why:    "Fixture reason.",
			Fix:    "Fixture fix.",
			WayOut: "Fixture way out.",
		},
	}

	export := errorflow.FromGraph(graph)

	require.Len(t, export.Errors, 3)
	child := export.Errors[0]
	assert.Equal(t, "root.child", child.Code)
	assert.Equal(t, "The child is invalid.", child.What)
	assert.Equal(t, "Fixture reason.", child.Why)
	assert.Equal(t, "Fixture fix.", child.Fix)
	assert.Equal(t, "Fixture way out.", child.WayOut)

	root := export.Errors[2]
	assert.Empty(t, root.What, "codes without a registration stay empty")
}
