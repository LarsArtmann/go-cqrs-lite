# 🔍 Erraudit

[![Version](https://img.shields.io/badge/version-0.5.0-blue.svg)](https://github.com/larsartmann/erraudit/releases)
[![GoDoc](https://godoc.org/github.com/larsartmann/erraudit?status.svg)](https://godoc.org/github.com/larsartmann/erraudit)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

A Go static analysis tool that detects, analyzes, and visualizes error handling patterns, hierarchies, and violations in your codebase.

## What is this?

This tool helps you build robust error handling in Go by:

- **Detecting error handling violations** — flags panics on errors, silent error swallowing, ignored errors, and improper wrapping
- **Discovering error hierarchies** — finds sentinel errors (`var ErrFoo = errors.New(...)`) and their wrapped relationships
- **Visualizing error relationships** — generates trees, graphs, and HTML reports showing how errors relate to each other
- **Enforcing modern patterns** — built-in `legacyerrors` linter detects old `errors.As`/`errors.Is` and suggests `errors.AsType` (Go 1.26+), with optional auto-fix

## Why error hierarchies matter

Good error handling in Go enables:

- **Precise error handling** with `errors.Is()` and `errors.As()`
- **Structured error types** with domain-specific context
- **Clear error taxonomy** that documents your API's failure modes

Without typed errors, callers must rely on string matching or give up entirely.

## Key Feature: Generic Error Return Detection

**This is the only Go linter that detects when functions return the bare `error` interface instead of specific error types.**

Enable with `--enforce-generic-return` (off by default — returning `error` is standard Go practice).

This matters because generic returns prevent callers from using `errors.As()` for type-specific handling.

```go
// ❌ BAD: Generic error return (detected as violation)
func Validate(input string) error {
    return errors.New("invalid input")
}

// ✅ GOOD: Specific error type (no violation)
type ValidationError struct{ Field, Msg string }
func (e *ValidationError) Error() string { return e.Msg }
func Validate(input string) *ValidationError {
    return &ValidationError{Field: "input", Msg: "required"}
}
```

## Features

### Error Pattern Detection

Identifies common error handling patterns:

- Error returns and wrapping
- Error checking and handling
- Silent error swallowing
- Error ignoring with `_`
- Panics on errors
- Log.Fatal on errors
- Improper error wrapping (missing `%w`)

### Error Hierarchy Discovery

Discovers all named errors in your codebase and builds relationships between them:

```go
// Sentinel errors (root errors)
var ErrNotFound = errors.New("resource not found")
var ErrInvalid = errors.New("invalid input")

// Wrapped errors (with parent-child relationships)
var ErrUserNotFound = fmt.Errorf("user not found: %w", ErrNotFound)
var ErrValidationFailed = fmt.Errorf("validation failed: %w", ErrInvalid)
```

The analyzer automatically:

- **Discovers** all named error variables (`var ErrFoo = ...`)
- **Tracks** parent-child relationships via `%w` wrapping
- **Builds** a complete hierarchy tree of error relationships
- **Detects** custom error types (implementing the `error` interface)

### Strong Type System

Uses type-safe Severity constants:

- Impossible states unrepresentable
- Better IDE support (autocomplete)
- Self-documenting code

### Violation Reporting

Categorizes issues by severity:

- HIGH: Critical issues (panic, log.Fatal, silent swallowing)
- MEDIUM: Moderate issues (improper wrapping)
- LOW: Minor issues (suggestions)

### Summary Statistics

Comprehensive breakdown of violations:

- Total violations count
- Severity breakdown (HIGH/MEDIUM/LOW)
- Type breakdown (panic/ignored/unwrapped/silent_swallow)

### Multiple Output Formats

| Format             | Description                       | Use Case                        |
| ------------------ | --------------------------------- | ------------------------------- |
| `tree`             | Human-readable tree with metrics  | CLI output, quick analysis      |
| `json`             | Machine-readable JSON             | Integration with other tools    |
| `html`             | Styled HTML report                | Team reviews, presentations     |
| `hierarchy`        | Error relationship tree           | Understanding error structure   |
| `dot`              | Graphviz DOT format               | Render professional graphs      |
| `mermaid`          | Mermaid diagram format            | Documentation, live.mermaid.app |
| `agent`            | Token-efficient output            | AI coding agents                |
| `full`             | Complete analysis report          | Detailed analysis               |
| `sarif`            | SARIF 2.1.0 with domain features  | GitHub Code Scanning            |
| `go-finding-sarif` | Standardized SARIF via go-finding | Cross-tool SARIF correlation    |
| `go-finding-json`  | Standardized JSON via go-finding  | Cross-tool JSON integration     |
| `csv`              | Comma-separated values            | Data export, spreadsheet import |
| `tsv`              | Tab-separated values              | Terminal paste, data import     |
| `markdown`         | Markdown table                    | Documentation, README embeds    |
| `table`            | Aligned table with borders        | Terminal display                |
| `yaml`             | YAML serialization                | Config-file-friendly export     |
| `xml`              | XML serialization                 | Enterprise integration          |
| `jsonl`            | JSON Lines (one object per line)  | Streaming/log processing        |
| `toml`             | TOML serialization                | Config-file-friendly export     |
| `asciidoc`         | AsciiDoc table                    | Technical documentation         |
| `d2`               | D2 diagram format                 | Structurizr-style diagrams      |
| `plantuml`         | PlantUML diagram format           | UML-style documentation         |

- **Built-in Linter**: `legacyerrors` — detects `errors.As`/`errors.Is` and suggests `errors.AsType` (Go 1.26+)

### Comparison with Other Linters

"Ignored errors" means different things to different tools. **errcheck** performs
a _reception_ check: was every error return value assigned at all? **erraudit**
classifies _discarded and mishandled_ errors: what happened to errors that were
received. **wrapcheck** enforces _propagation_: was the error wrapped before
being returned upstream? The three tools' default findings do not overlap —
they are complements, not substitutes.

| Linter       | Panic / log.Fatal | Unreceived error returns       | Blank-identifier discards | Swallow / mishandled classification | Wrapping at return | Generic Returns |
| ------------ | ----------------- | ------------------------------ | ------------------------- | ----------------------------------- | ------------------ | --------------- |
| errcheck     | ❌                | ✅ (bare, `go`, `defer` calls) | ⚠️ opt-in (`-blank`)       | ❌ (by design)                      | ❌                 | ❌              |
| staticcheck  | ⚠️ *               | ❌ (verified *)                | ❌ (verified *)           | ❌ (verified *)                     | ❌ (verified *)    | ❌ *            |
| wrapcheck    | ❌                | ❌ (verified *)                | ❌ (verified *)           | ❌ (verified *)                     | ✅ **UNIQUE**      | ❌ *            |
| go vet       | ❌                | ⚠️ *                            | ❌ *                      | ❌ *                                | ❌ *               | ❌ *            |
| **erraudit** | ✅                | ❌ (opt-in backlog)            | ✅ default (`ignored`)    | ✅ (`silent_swallow`, context loss) | ❌ (backlog)       | ✅ **UNIQUE**   |

\* Cells marked "verified" were tested against an empirical 15-pattern fixture
with staticcheck v0.8.1, wrapcheck v2.12.0, errcheck v1.20.0, and erraudit
(2026-09-11). Panic/log.Fatal and generic-return cells for external tools, and
every go vet column, are not fixture-verified (carried over or derived from
tool sources).

**Run them together.** erraudit does not replace errcheck: errcheck catches
error returns that are never received (`f()`, `go f()`, `defer f()`), erraudit
classifies errors that were received but discarded or mishandled, and wrapcheck
enforces wrapping where errors are returned upstream. With default settings
their findings are disjoint. See
[docs/linter-comparison.md](docs/linter-comparison.md) for the full verified
matrix, the deferred-`Close` deadlock resolution, and pairing guidance.

### BuildFlow / pipeline integration

erraudit registers itself as a [go-finding](https://pkg.go.dev/github.com/larsartmann/go-finding)
toolsdk tool. Any pipeline that imports
`github.com/larsartmann/erraudit/pkg/provider` gets erraudit as a first-class
DAG tool through `toolsdk.All()` — detection with type-aware analysis,
`//nolint` suppression, per-finding explanations, and a deterministic SARIF
wire format. See [docs/provider.md](docs/provider.md). Prefer plain CLI? The
`--pipeline` flag produces the same standardized go-finding JSON/SARIF.

## Installation

### From Source

```bash
GOEXPERIMENT=jsonv2 go build -o erraudit ./cmd/erraudit
```

Or install directly:

```bash
GOEXPERIMENT=jsonv2 go install github.com/larsartmann/erraudit/cmd/erraudit@latest
```

> **`GOEXPERIMENT=jsonv2` is REQUIRED** when building from source: the codebase
> imports `encoding/json/v2` (experimental on Go 1.26). Without the flag the
> build fails with "build constraints exclude all Go files". Released binaries
> and `nix build` have this baked in already.

### As a Library (SDK)

```bash
go get github.com/larsartmann/erraudit@latest
```

```go
import (
    "github.com/larsartmann/erraudit/pkg/types"
)

// Use types from the public API
var violation types.ErrorViolation
violation.Severity = types.SeverityHigh
```

### Building with Version

`erraudit --version` resolves its version in this order: an ldflags-injected
string, then the Go toolchain's VCS stamp (the git commit), then `dev`. To pin
an explicit version string at build time, inject the package-level `injected`
variable:

```bash
go build -ldflags "-X github.com/larsartmann/erraudit/pkg/version.injected=v0.5.0" -o bin/erraudit ./cmd/erraudit
```

`nix build` and GoReleaser builds inject provenance automatically.

## Configuration

The analyzer supports configuration through three mechanisms (priority order):

1. **CLI Flags** (highest priority)
2. **Environment Variables**
3. **Configuration File** (`.erraudit.yaml`)

### Quick Start

Create a configuration file in your project directory:

```bash
# Copy example configuration
cp .erraudit.yaml.example .erraudit.yaml

# Or create minimal config
cat > .erraudit.yaml << EOF
output_format: tree
verbose: true
excluded_paths:
  - "vendor/"
  - "*_test.go"
EOF
```

### Configuration File

Place `.erraudit.yaml` in your project root:

```yaml
# Output format
output_format: tree

# Output file (empty = stdout)
output: ""

# Enable verbose logging
verbose: false

# Filter by severity
severity: ""

# Exclude paths
excluded_paths:
  - "vendor/"
  - "*_test.go"
```

### Environment Variables

```bash
export ERRAUDIT_OUTPUT_FORMAT=json
export ERRAUDIT_VERBOSE=true
export ERRAUDIT_SEVERITY=high

erraudit ./...
```

### CLI Flags

```bash
erraudit ./... \
  --format json \
  --output results.json \
  --severity high \
  --violations-only
```

### Opt-in Enforcement Checks

Four advisory detectors are OFF by default (they flag standard Go practice) and
turn on per run:

```bash
erraudit ./... \
  --enforce-go-error-family \   # stdlib error constructors (errors.New/fmt.Errorf)
  --enforce-samber-oops \       # stdlib constructors + oops redundant-guard anti-pattern
  --enforce-generic-return \    # functions returning bare `error`
  --enforce-deferred-close      # `defer x.Close()` discarding the Close error
```

Individual violation types can be excluded with `--disable context_loss`
(repeatable).

### Configuration Precedence

When multiple sources set the same value, CLI flags override environment variables, which override the configuration file.

**Example:**

- Config file sets: `output_format: tree`
- Environment variable: `ERRAUDIT_OUTPUT_FORMAT=json`
- CLI flag: `--format html`
- **Result:** `html` (CLI flag wins)

### Common Configuration Patterns

**Development Mode:**

```yaml
verbose: true
output_format: tree
```

**CI/CD Pipeline:**

```yaml
output_format: json
output: "results.json"
severity: high
violations_only: true
```

**HTML Report:**

```yaml
output_format: html
output: "error-report.html"
```

### Full Configuration Documentation

For complete configuration details, see [docs/CONFIGURATION.md](docs/CONFIGURATION.md).

## Usage

### Basic Analysis

```bash
# Analyze a single file
erraudit examples/patterns.go

# Analyze a directory
erraudit ./internal/ast

# Analyze a package
erraudit ./...
```

### Output Formats

```bash
# Tree format (default) - includes metrics, summary, and violations
erraudit --format tree ./examples/

# JSON format - machine-readable
erraudit --format json ./examples/

# HTML format - styled report with CSS
erraudit --format html ./examples/ > report.html

# Full format - summary statistics only (compact)
erraudit --format full ./examples/

# Hierarchy format - error relationship tree (NEW!)
erraudit --format hierarchy ./examples/

# DOT format - Graphviz format for professional graphs
erraudit --format dot ./examples/ > graph.dot
# Render with: dot -Tpng graph.dot -o graph.png

# Mermaid format - for diagrams in documentation
erraudit --format mermaid ./examples/
# View at: https://mermaid.live/
```

### Error Tree Visualization

The `tree` subcommand renders the error hierarchy as a clean ASCII tree
(powered by `go-output/tree`). Each node shows the error name, kind, a
working-directory-relative source position, occurrence and violation counts,
and — since v0.5.0 — inline usage annotations (`· 1 inline wrap · 3 checks`)
counting the wrapping and `errors.Is` checking that lives outside
package-level declarations. The metrics footer that accompanies the tree
(and the `full`, `hierarchy`, and `agent` formats) carries the same
reference counts in aggregate: `Inline Wrap Sites`, `Sentinel Checks`
(`errors.Is`), and `Type Checks` (`errors.As`) — the `agent` format
compresses them to `wraps=N checks=N typeChecks=N` tokens. A `./...`
target renders a scale root label
(`Error Hierarchy (15 packages · 38 files)`), and a flat hierarchy prints a
notice citing the inline activity it can see instead of a bare zero.

```bash
# ASCII tree (default)
erraudit tree ./examples/

# Markdown bullet list
erraudit tree . --markdown

# Force color when piping to less
erraudit tree . --color always | less -R

# Cleaner output (omit positions and kinds)
erraudit tree . --no-position --no-kind

# Limit depth for large hierarchies
erraudit tree . --max-depth 2

# Save to file (color disabled automatically)
erraudit tree . --output error-tree.txt

# Show where each error is wrapped and checked (function-body evidence)
erraudit tree ./... --inline-wraps

# Surface the most-referenced errors first (auto when the hierarchy is flat)
erraudit tree ./... --sort wraps

# Group root errors by package directory
erraudit tree ./... --group
```

### Errorflow Export

The `errorflow` subcommand exports the same error surface as stable,
schema-versioned JSON (`schemaVersion: 2`) — the interchange format for
taxonomy tooling, not a report for humans. Every named error carries its
kind, taxonomy code, family, declaration site, wraps relationship, the
inline sites that wrap/check it, and a referenced/unreferenced status; a
`codes` array carries every go-error-family code minted anywhere in the
scope — including inline function-body constructor calls (`Newf`/`Wrapf`
forms included) that hand-rolled regex scans classically miss — with the
family each constructor actually builds. A code minted under two families
stays as two entries, so taxonomy gates surface the conflict instead of
hiding it. Coded errors also carry their registered What/Why/Fix/WayOut
template texts. Output is byte-stable (golden-snapshotted), so a committed
export can be freshness-gated in CI.

```bash
# Machine-readable export (consumed by taxonomy doc generators and hubs)
erraudit errorflow ./... --type-aware -o errorflow.json

# Human-readable coeffects table
erraudit errorflow ./... --markdown
```

### Error Hierarchy Example

```bash
$ erraudit --format hierarchy ./examples/erraudit.go
Error Hierarchy Tree
=====================

Hierarchy Metrics
-----------------
Total Named Errors: 14
Total Relationships: 10
Max Depth: 4
Sentinel Errors: 4

Named Errors
------------
  • ErrNotFound (sentinel) [wraps: parent]
  • ErrUserNotFound (fmt.Errorf) [wraps: ErrNotFound]
  • ErrProductNotFound (fmt.Errorf) [wraps: ErrNotFound]
  • ErrValidationFailed (fmt.Errorf) [wraps: ErrInvalid]

Error Relationships Tree
------------------------
└── ErrRollbackFailed (fmt.Errorf)
    └── ErrTransactionFailed (fmt.Errorf)
        └── ErrDatabaseQuery (fmt.Errorf)
            └── ErrDatabaseConnection (fmt.Errorf)
                └── ErrInternal (sentinel)

Relationships
-------------
  ErrUserNotFound --wraps--> ErrNotFound
  ErrDatabaseQuery --wraps--> ErrDatabaseConnection
```

### Filtering Violations

```bash
# Show only HIGH severity violations
erraudit --severity high ./examples/

# Show only panic violations
erraudit --type panic ./examples/

# Combine filters
erraudit --severity high --type panic ./examples/
```

### Output Options

```bash
# Save tree output to file
erraudit --output report.txt ./examples/

# Save JSON output
erraudit --format json --output report.json ./examples/

# Save HTML report
erraudit --format html --output report.html ./examples/
```

### Advanced Options

```bash
# Show only violations (no metrics/summary)
erraudit --violations-only ./examples/

# Verbose output
erraudit --verbose ./examples/

# Show version
erraudit --version
```

### Auto-fix

Automatically migrate legacy `errors.As` calls to the modern `errors.AsType` (Go 1.26+).

```bash
# Preview fixes (dry-run — default)
erraudit fix ./...

# Apply fixes to disk
erraudit fix ./... -w
```

**What it does:**

- Detects `errors.As(err, &target)` used as a standalone expression statement
- Replaces it with `target, _ = errors.AsType[TargetType](err)`
- Resolves types relative to the package and its imports
- Idempotent: running twice on already-fixed code is a no-op

**Safety features:**

- Dry-run by default; `-w` required to write changes
- Overlapping edits are detected and rejected
- Unified diff output for review before applying
- Respects `excluded_paths` from configuration

**Example:**

```go
// Before
var target *MyError
errors.As(err, &target)

// After (with erraudit fix ./... -w)
target, _ = errors.AsType[*MyError](err)
```

**Exit codes:**

- `0`: No fixes needed
- `2`: Fixes found or applied (same as `analyze` command)
- `1`: Infrastructure error

### Watch Mode

Re-run analysis automatically when files change:

```bash
# Watch current directory for changes
erraudit watch ./...

# Watch with specific format
erraudit watch --format json ./...
```

### Lint Command

Run the built-in `legacyerrors` linter via the CLI subcommand:

```bash
# Run the legacyerrors linter
erraudit lint ./...

# CI gating: only show errors.As modernizations, filter out advisories
erraudit lint ./... --severity-threshold error

# Structured output for CI artifacts
erraudit lint ./... -f sarif -o results.sarif

# Audit suppression list: show everything including //nolint-suppressed
erraudit lint ./... --no-suppress
```

The lint subcommand supports the same output flags as the main analyze command (`-f`, `-o`, `--severity`, `--severity-threshold`, `--type`, `--no-suppress`). By default it produces plain text output (`file:line:col: message`) compatible with `go vet`.

### Suppressing Findings

To suppress a finding on a specific line, use the linter name `legacyerrors`:

```go
//nolint:legacyerrors // ErrNotFound is a sentinel; errors.Is is correct here
if errors.Is(err, ErrNotFound) {
    // ...
}
```

Always include a reason. The reason helps future readers understand why the suppression exists and when it can be removed.

Bare `//nolint` (without a linter name) also works and suppresses all violation types on that line. The tool-level name `//nolint:erraudit` is also recognized.

Use `--no-suppress` to audit every potential violation — it shows all violations including those hidden by `//nolint` comments **and** bypasses all AST heuristics (signature-aware blank-identifier check, presence-flag sibling check, map-index check) so you can review every possible violation.

### Extension Management

```bash
# List registered extensions
erraudit extension list

# Show extension details
erraudit extension show <name>

# List registered hooks
erraudit extension hooks

# Disable an extension
erraudit extension disable <name>
```

## Portfolio Audits (fleet-wide)

`erraudit portfolio` audits **every Go project on your machine** in one sweep and aggregates the results into a single report — the fleet-wide counterpart to running erraudit manually in each repository.

```bash
# Fleet audit with the aggressive flag set
erraudit portfolio --type-aware --enforce-go-error-family --no-suppress \
  --enforce-samber-oops --enforce-generic-return --explain

# Audit two specific projects (bypasses discovery), sorted by critical findings
erraudit portfolio ~/projects/erraudit ~/projects/go-ndjson --sort-by critical

# Machine-readable report
erraudit portfolio -f json > portfolio.json
```

Output is one row per project (files scanned, critical/error/warning/total), a TOTAL footer, a summary block, and a failures section:

```
│ Project  │ Files │ Critical │ Error │ Warning │ Total │ Skipped │
│ erraudit │ 132   │ 3        │ 17    │ 3       │ 23    │ 0       │
```

**How it works:** projects are discovered via [project-discovery-sdk](https://github.com/LarsArtmann/project-discovery-sdk) (Go projects only, cached); each project is then analyzed by re-invoking the erraudit binary with `--format json` and exactly the audit flags you set — so a fleet run behaves identically to your manual per-project runs, with per-project crash isolation. `--modules=all` is forwarded, so monorepos with nested `go.mod` files get full coverage.

| Flag            | Default                                                         | Meaning                                                                                      |
| --------------- | --------------------------------------------------------------- | -------------------------------------------------------------------------------------------- |
| `--search-path` | `~/projects ~/GolandProjects ~/IdeaProjects ~/WebStormProjects` | Directories to discover Go projects in (repeatable)                                          |
| `--sort-by`     | `violations`                                                    | `name, violations, critical, error, warning, files` (metrics descending)                     |
| `--show-all`    | off                                                             | Include projects with zero violations (hidden by default; coverage totals always count them) |
| `--concurrency` | `8`                                                             | Parallel project analyses (1 = sequential)                                                   |
| `--format`      | `table`                                                         | Report format: `table, json, csv, tsv, markdown, yaml`                                       |

Children always run with `GOWORK=off`, `GOEXPERIMENT=jsonv2`, and `-mod` flags stripped from `GOFLAGS` — a parent `go.work` or direnv shell cannot poison foreign projects. Exit codes follow the analyze contract: `0` clean, `2` violations found, `1` error.

## Output Examples

### Tree Format

```
Error Metrics
=============

Total Errors Found: 23
Error Returns: 7
Error Wraps: 5
Silent Swallows: 1
Panics on Errors: 1
Ignored Errors: 1
Max Wrap Depth: 2

Violations Summary
==================

Total Violations: 4
  HIGH:   2
  MEDIUM: 2
  LOW:    0

By Type:
  unwrapped: 1
  panic: 1
  ignored: 1
  silent_swallow: 1

Violations Report
=================

HIGH Severity:
├── Error checked but not handled properly (error is swallowed) (./examples/error_patterns.go:38)
│   └── 💡 Return the error instead of returning nil or a different value
│
  36 func BadExample1() error {
  37 	err := someOperation()
> 38 	if err != nil {
  39 		// VIOLATION: Silent error swallowing
  40 		log.Println(err) // Error is logged but not handled
│
└── Panic on error - errors should be returned, not panic'd (./examples/error_patterns.go:59)
│   └── 💡 Return the error instead of panicking
│
```

### JSON Format

```json
{
  "package": "github.com/larsartmann/erraudit/examples",
  "metrics": {
    "total_errors": 23,
    "max_wrap_depth": 2,
    "error_returns": 7,
    "error_wraps": 5,
    "silent_swallows": 1,
    "panics_on_errors": 1,
    "ignored_errors": 1
  },
  "violations": [
    {
      "position": {
        "filename": "./examples/error_patterns.go",
        "line": 59
      },
      "type": "panic",
      "severity": "high",
      "message": "Panic on error - errors should be returned, not panic'd",
      "suggestion": "Return the error instead of panicking",
      "code_snippet": "  57\tif err != nil {\n> 58\t\t// VIOLATION: Panic on error\n  59\t\tpanic(err)\n"
    }
  ]
}
```

### HTML Format

HTML reports include:

- Summary statistics with severity breakdown
- Styled violation cards with color coding
- Code snippets with context
- Suggestion boxes
- Responsive design for mobile/tablet
- Export-ready for presentations

### Full Format (Summary Only)

```
Error Metrics
=============

Total Errors Found: 23
Error Returns: 7
Error Wraps: 5
Silent Swallows: 1
Panics on Errors: 1
Ignored Errors: 1
Max Wrap Depth: 2
```

## Violation Types

| Type                                           | Severity | Default    | Description                                                                         |
| ---------------------------------------------- | -------- | ---------- | ----------------------------------------------------------------------------------- |
| `panic`                                        | HIGH     | on         | Panicking on errors                                                                 |
| `log_fatal`                                    | HIGH     | on         | Calling log.Fatal on errors                                                         |
| `silent_swallow`                               | HIGH     | on         | Logging errors without handling                                                     |
| `ignored`                                      | HIGH     | on         | Ignoring errors with `_`                                                            |
| `context_loss`                                 | HIGH     | on         | Business context variables dropped on error paths                                   |
| `unwrapped`                                    | MEDIUM   | on         | Missing `%w` in error wrapping                                                      |
| `legacy_as`                                    | MEDIUM   | on (lint)  | Old `errors.As` pattern (use `errors.AsType`)                                       |
| `legacy_is`                                    | LOW      | on (lint)  | Old `errors.Is` pattern (advisory)                                                  |
| `check`                                        | LOW      | on         | Informational: error check found                                                    |
| `return`/`assignment`/`wrapping`/`propagation` | LOW      | on         | Informational pattern records                                                       |
| `generic_return`                               | LOW      | opt-in     | Returning bare `error` instead of a specific type                                   |
| `deferred_close_ignored`                       | LOW      | opt-in     | `defer x.Close()` discarding the Close error                                        |
| `oops_redundant_guard`                         | LOW      | opt-in     | Redundant nil guard before `oops.Wrap`/`Wrapf`                                      |
| `oops_misused_w`                               | LOW      | opt-in     | `%w` in `oops.Wrapf` (does not chain)                                               |
| `stdlib_constructor`                           | MEDIUM   | opt-in     | `errors.New`/`fmt.Errorf` under `--enforce-go-error-family`/`--enforce-samber-oops` |
| `uncoded_constructor`                          | MEDIUM   | opt-in     | go-error-family constructor called with an empty code (`--enforce-coded-errors`)    |
| `sentinel_concrete_type`                       | MEDIUM   | type-aware | Package-level sentinel var declared with a concrete error type instead of `error`   |

Opt-in types are off by default because they flag standard Go practice; enable
them with the matching `--enforce-*` flag (see [Opt-in Enforcement Checks](#opt-in-enforcement-checks)).

## CLI Flags

| Flag                | Description                               | Values                                                                                                                                                                                                                                                  |
| ------------------- | ----------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `--format`          | Output format                             | 22 values: `tree`, `json`, `html`, `full`, `hierarchy`, `dot`, `mermaid`, `agent`, `sarif`, `go-finding-sarif`, `go-finding-json`, plus table formats (`csv`, `tsv`, `markdown`, `table`, `yaml`, `xml`, `jsonl`, `toml`, `asciidoc`, `d2`, `plantuml`) |
| `--output`          | Output file path                          | Any file path                                                                                                                                                                                                                                           |
| `--severity`        | Filter by severity                        | `high`, `medium`, `low`                                                                                                                                                                                                                                 |
| `--type`            | Filter by violation type                  | Any value from the [Violation Types](#violation-types) table (19 types)                                                                                                                                                                                 |
| `--violations-only` | Show only violations (no metrics/summary) | Boolean flag                                                                                                                                                                                                                                            |
| `--verbose`         | Verbose output                            | Boolean flag                                                                                                                                                                                                                                            |
| `--version`         | Show version                              | Boolean flag                                                                                                                                                                                                                                            |

## Exit Codes

- `0`: Success, no violations found
- `2`: Success, violations found (expected behavior)
- `1`: Error occurred (bad path, toolchain missing, render error)
- `75`: Transient failure (go-error-family Transient family default, `EX_TEMPFAIL`) — retryable operational condition

## Error Contract

**Exit 2 is success.** Violations are data, not errors — scripts must treat `rc <= 2` as a successful run. Only operational failures (bad path, toolchain missing, render error) are errors.

**Machine-readable failures (json formats).** When an operational failure occurs with `--format json` or `--format jsonl`, erraudit prints an error envelope to stdout so scripts and embedders can branch programmatically instead of parsing stderr:

```json
{
  "error": {
    "code": "analysis.toolchain_missing",
    "family": "rejection",
    "exit_code": 1,
    "message": "...",
    "fix": "Install the Go toolchain or ensure go is on PATH.",
    "context": { "path": "./pkg/...", "type_aware": "true" }
  }
}
```

- `code` — stable dotted identifier (absent for uncoded context errors)
- `family` — go-error-family classification (`rejection`, `transient`, ...)
- `exit_code` — the process exit code this error maps to
- `fix` — actionable suggestion from the error's template
- `context` — operational key/values (analysis path, mode) when available

Flag-syntax and config-validation failures are rejected by the CLI framework before analysis and render on stderr only. Embedders (BuildFlow, go-finding pipelines) receive findings as data and never see exit 2 — `pkg/provider` and `pkg/finding` are the integration surface.

## Examples

### Find Critical Issues

```bash
erraudit --severity high ./your-project/
```

### Generate HTML Report for Team Review

```bash
erraudit --format html --output errors.html ./your-project/
open errors.html
```

### Filter by Specific Violation Type

```bash
erraudit --type panic ./your-project/
```

### Compact Output (Summary Only)

```bash
erraudit --format full ./your-project/
```

### Verbose Mode

```bash
erraudit --verbose ./your-project/
```

### Show Violations Only (No Metrics)

```bash
erraudit --violations-only ./your-project/
```

## Security

This tool is designed as a **local code analysis utility** and is not intended for use with untrusted inputs from external sources. However, several security measures are implemented:

### HTML Output Security

- **Automatic XSS Protection**: HTML reports use Go's `html/template` package which automatically escapes all user-provided content
- **No unsafe HTML injection**: All violation data, including filenames, error messages, and code snippets are properly escaped
- **Safe-by-default**: The template engine prevents cross-site scripting (XSS) attacks

### File Path Validation

- **Path sanitization**: File paths are cleaned using `filepath.Clean()` to normalize paths
- **Null byte protection**: Paths containing null bytes are rejected
- **OS-level protections**: The tool relies on OS-level file access controls

### Recommendations

1. **Local Use Only**: Run this tool on codebases you own or have permission to analyze
2. **Review HTML Reports**: When sharing HTML reports, ensure they contain only code you intend to share
3. **Secure Output**: Store generated reports in secure locations and restrict access as needed
4. **Dependencies**: Keep dependencies updated by running `go get -u ./...` regularly

### Security Testing

The security utilities are tested in `pkg/utils/security_test.go` to ensure proper path validation and sanitization.

## Contributing

Contributions welcome! See [CONTRIBUTING.md](CONTRIBUTING.md) for development setup, code style, and testing guidelines.

## License

MIT License - See LICENSE file for details
