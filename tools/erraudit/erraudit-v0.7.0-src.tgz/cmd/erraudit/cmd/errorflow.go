package cmd

import (
	"context"
	"fmt"
	"io"
	"os"

	v4 "github.com/larsartmann/cmdguard/v4/pkg/cmdguard/v4"
	"github.com/larsartmann/erraudit/cmd/erraudit/cmd/pipeline"
	"github.com/larsartmann/erraudit/pkg/errorflow"
	apierrors "github.com/larsartmann/erraudit/pkg/errors"
	"github.com/spf13/cobra"
)

func registerErrorflowCommand(cli *v4.CLI[AppConfig]) error {
	cmd, err := v4.NewCommand[AppConfig, ErrorflowFlags](
		"errorflow",
		ErrorflowFlags{
			Markdown: false,
		},
		runErrorflowHandler,
		v4.WithShort("Export the error surface as machine-readable JSON (or Markdown)"),
		v4.WithLong(`Export every named error with its kind, go-error-family code
and family, declaration site, declared parent, inline wrap sites,
errors.Is check sites, a referenced/unreferenced status, and the
What/Why/Fix/WayOut template texts registered for its code.

The JSON schema (schemaVersion `+"`2`"+`) is a stable contract for
downstream consumers: EventCatalog x-errors frontmatter, error-insights
pages, generated taxonomy docs. Errors are sorted by name, positions
are file-base-name:line — the output is byte-stable for a given source
tree (golden-snapshot friendly).

Use --type-aware for go/types-backed accuracy (recommended: also
resolves cross-package selector references).
Use --markdown for a human-readable coeffects table instead of JSON.

Exit code is always 0 for a successful export (visualization-shaped
command, not a linter gate); analysis errors exit non-zero.`),
		v4.WithExample(`  # Export the error surface of the current module
  erraudit errorflow ./... --type-aware

  # Markdown coeffects table
  erraudit errorflow ./... --markdown

  # Write to a file for a catalog build to consume
  erraudit errorflow ./... --type-aware --output errorflow.json`),
		v4.WithArgs(cobra.MaximumNArgs(1)),
	)

	return registerCommand(cli, "errorflow", cmd, err)
}

func runErrorflowHandler(ctx context.Context, cfg *AppConfig, flags ErrorflowFlags) error {
	path := pathFromArgs(argsFromContext(ctx))

	if cfg.Verbose {
		fmt.Fprintf(os.Stderr, "Exporting error flow: %s\n", path)
	}

	// Suppress/Explain stay false: the export carries the hierarchy, not the
	// violation pipeline. Progress stays false: exports are quiet.
	graph, _, err := pipeline.PerformAnalysisWithSpec(ctx, pipeline.AnalysisSpec{
		Path:                 path,
		ExcludedPaths:        cfg.Exclude,
		TypeAware:            cfg.TypeAware,
		EnforceErrorFamily:   cfg.EnforceErrorFamily,
		EnforceSamberOops:    cfg.EnforceSamberOops,
		EnforceGenericReturn: cfg.EnforceGenericReturn,
		EnforceDeferredClose: cfg.EnforceDeferredClose,
		EnforceCodedErrors:   cfg.EnforceCodedErrors,
		NoSuppress:           cfg.NoSuppress,
		ModulesAll:           cfg.Modules == ModulesAllMode,
		Progress:             false,
		Suppress:             false,
		Explain:              false,
	})
	if err != nil {
		return apierrors.Wrap(err, "analysis of %s failed", path)
	}

	if graph.FilesScanned == 0 {
		fmt.Fprintf(os.Stderr, "No Go source files found for %q (scanned 0 files).\n", path)
		fmt.Fprintln(os.Stderr, `Hint: use "./..." to analyze a whole module, or pass a package directory.`)

		return nil
	}

	export := errorflow.FromGraph(graph)
	if len(export.Errors) == 0 {
		fmt.Fprintln(os.Stderr, "No named errors found — the export carries an empty errors array.")
	}

	return withOutputWriter(
		func() (io.Writer, func(), error) { return newOutputWriter(cfg.Output, os.Stdout) },
		func(writer io.Writer) error {
			if flags.Markdown {
				if _, err := fmt.Fprint(writer, export.Markdown()); err != nil {
					return apierrors.Wrap(err, "write errorflow markdown")
				}

				return nil
			}

			data, err := export.JSON()
			if err != nil {
				return apierrors.Wrap(err, "render errorflow json")
			}

			if _, err := writer.Write(data); err != nil {
				return apierrors.Wrap(err, "write errorflow json")
			}

			return nil
		},
	)
}
