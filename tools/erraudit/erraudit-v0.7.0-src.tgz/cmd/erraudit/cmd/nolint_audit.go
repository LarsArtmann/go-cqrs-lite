package cmd

import (
	"context"
	"encoding/json/jsontext"
	"encoding/json/v2"
	"fmt"
	"go/parser"
	"go/token"
	"io"
	"io/fs"
	"os"
	"path/filepath"
	"sort"
	"strings"

	v4 "github.com/larsartmann/cmdguard/v4/pkg/cmdguard/v4"
	"github.com/larsartmann/erraudit/cmd/erraudit/cmd/pipeline"
	apierrors "github.com/larsartmann/erraudit/pkg/errors"
	"github.com/larsartmann/erraudit/pkg/suppression"
	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/samber/lo"
	"github.com/spf13/cobra"
)

// maxMessageLen is the truncation limit for violation messages in audit output.
const maxMessageLen = 60

// Repeated string constants for lint compliance.
const (
	linterErraudit       = "erraudit"
	linterLegacyerrors   = "legacyerrors"
	nolintPrefix         = "//nolint"
	nolintSpacedPrefix   = "// nolint"
	auditFormatJSONValue = "json"
	auditFormatTextValue = "text"
)

// validateAuditFormat ensures the --audit-format value is either "text" or "json".
func validateAuditFormat(format string) error {
	switch format {
	case auditFormatTextValue, auditFormatJSONValue:
		return nil
	default:
		return apierrors.Wrap(
			apierrors.ErrConfigInvalid,
			"invalid --audit-format %q (must be %q or %q)",
			format,
			auditFormatTextValue,
			auditFormatJSONValue,
		)
	}
}

// nolintDirective represents a single //nolint:erraudit directive found in source.
type nolintDirective struct {
	File    string
	Line    int
	Content string
	Reason  string
}

// directiveStatus is the audit result for a single directive.
type directiveStatus struct {
	Directive nolintDirective
	Needed    bool
	Violation *types.ErrorViolation
}

// auditReport is the JSON output structure for --audit-format json.
type auditReport struct {
	Summary    auditSummary     `json:"summary"`
	Directives []auditDirective `json:"directives"`
}

type auditSummary struct {
	Total   int `json:"total"`
	Needed  int `json:"needed"`
	Stale   int `json:"stale"`
	Removed int `json:"removed,omitempty"`
}

type auditDirective struct {
	File       string         `json:"file"`
	Line       int            `json:"line"`
	Status     string         `json:"status"`
	Reason     string         `json:"reason,omitempty"`
	Suppresses *auditSuppress `json:"suppresses,omitempty"`
}

type auditSuppress struct {
	Type    string `json:"type"`
	Message string `json:"message"`
}

func registerNolintAuditCommand(cli *v4.CLI[AppConfig]) error {
	cmd, err := v4.NewCommand[AppConfig, NolintAuditFlags](
		"nolint-audit [path]",
		NolintAuditFlags{Fix: false, DryRun: false, Format: "text"},
		runNolintAuditHandler,
		v4.WithShort("Audit //nolint:erraudit directives for staleness"),
		v4.WithLong(`Audit all //nolint:erraudit directives in the codebase and report
which ones are still needed vs stale (no longer suppressing anything).

Uses go/parser for accurate comment detection — string literals and
nolint-mentioning doc comments are NOT false positives. Directives in
testdata directories (analysistest fixtures) are skipped by convention.

Each directive is a detector deficiency waiting to be fixed. After
detector improvements, re-run this command to find stale directives
that can be safely removed.

Flags:
  --fix              Remove stale directives from source files
  --dry-run          Preview which directives --fix would remove (no changes)
  --audit-format     Output format: text (default) or json

Exit codes:
  0 — no stale directives found
  2 — one or more stale directives found (safe to remove)
  1 — analysis error`),
		v4.WithExample(`  # Audit entire project
  erraudit nolint-audit .

  # Audit specific package
  erraudit nolint-audit ./pkg/errors

  # Machine-readable JSON output for CI
  erraudit nolint-audit . --audit-format json

  # Auto-remove stale directives
  erraudit nolint-audit . --fix`),
		v4.WithArgs(cobra.MaximumNArgs(1)),
	)

	return registerCommand(cli, "nolint-audit", cmd, err)
}

func runNolintAuditHandler(ctx context.Context, cfg *AppConfig, flags NolintAuditFlags) error {
	if err := validateAuditFormat(flags.Format); err != nil {
		return err
	}

	path := pathFromArgs(argsFromContext(ctx))

	directives, err := collectDirectives(path)
	if err != nil {
		return apierrors.Wrap(err, "failed to collect nolint directives from %s", path)
	}

	if len(directives) == 0 {
		if flags.Format == auditFormatJSONValue {
			return printJSONOutput(os.Stdout, nil, 0)
		}

		fmt.Fprintln(os.Stdout, "No //nolint:erraudit directives found.")

		return nil
	}

	// Run analysis with noSuppress to surface ALL violations, including
	// those that would normally be suppressed by nolint directives.
	analysisPath := pipeline.EnsureRecursivePattern(path)

	// NoSuppress is the audit contract: surface ALL violations (both nolint
	// layers and the AST heuristics bypassed) so directives can be matched
	// against the full violation set. Progress stays false (quiet path);
	// Suppress/Explain stay false (the audit needs unsuppressed violations).
	_, violations, err := pipeline.PerformAnalysisWithSpec(ctx, pipeline.AnalysisSpec{
		Path:                 analysisPath,
		ExcludedPaths:        cfg.Exclude,
		TypeAware:            cfg.TypeAware,
		EnforceErrorFamily:   cfg.EnforceErrorFamily,
		EnforceSamberOops:    cfg.EnforceSamberOops,
		EnforceGenericReturn: cfg.EnforceGenericReturn,
		EnforceDeferredClose: cfg.EnforceDeferredClose,
		EnforceCodedErrors:   cfg.EnforceCodedErrors,
		NoSuppress:           true,
		ModulesAll:           cfg.Modules == ModulesAllMode,
		Progress:             false,
		Suppress:             false,
		Explain:              false,
	})
	if err != nil {
		return apierrors.Wrap(err, "analysis failed for %s", analysisPath)
	}

	statuses := auditDirectives(directives, violations)

	needed, stale := 0, 0

	for _, s := range statuses {
		if s.Needed {
			needed++
		} else {
			stale++
		}
	}

	removed := 0
	filesFixed := 0

	if flags.DryRun {
		previewFix(os.Stdout, statuses)
	} else if flags.Fix && stale > 0 {
		removed, filesFixed, err = applyFix(statuses)
		if err != nil {
			return apierrors.Wrap(err, "failed to remove stale directives")
		}
	}

	if flags.Format == auditFormatJSONValue {
		return printJSONOutput(os.Stdout, statuses, removed)
	}

	for _, s := range statuses {
		printStatus(s)
	}

	if removed > 0 {
		fmt.Fprintf(os.Stdout, "\nRemoved %d stale directive(s) from %d file(s).\n", removed, filesFixed)
	}

	fmt.Fprintf(os.Stdout, "\n%d directives: %d needed, %d stale\n", len(statuses), needed, stale)

	if stale > 0 && !flags.DryRun && !flags.Fix {
		fmt.Fprintf(
			os.Stdout,
			"hint: run `erraudit nolint-audit . --dry-run` to preview removals, or add `--fix` to remove stale directives\n",
		)
	}

	if stale > 0 {
		return ErrViolationsFound
	}

	return nil
}

// collectDirectives walks .go files under root and collects all //nolint:erraudit
// directives (and //nolint:legacyerrors, which is the legacy linter name).
// Uses go/parser for accurate comment detection — string literals and doc
// comments mentioning //nolint are NOT matched.
//
// testdata directories are skipped, matching the go toolchain and
// golangci-lint convention: analysistest fixtures carry //nolint directives
// that are consumed by the go/analysis linter's own suppression machinery,
// which the AST pipeline cannot see — auditing them reports false staleness.
func collectDirectives(root string) ([]nolintDirective, error) {
	var directives []nolintDirective

	walkErr := filepath.WalkDir(root, func(p string, d fs.DirEntry, accessErr error) error {
		if accessErr != nil {
			return nil //nolint:nilerr // best-effort walk; skip unreadable paths
		}

		if d.IsDir() {
			name := d.Name()
			if name != root && (strings.HasPrefix(name, ".") || name == "vendor" || name == "testdata") {
				return filepath.SkipDir
			}

			return nil
		}

		if !strings.HasSuffix(p, ".go") {
			return nil
		}

		content, readErr := os.ReadFile(p) //nolint:gosec // intentional path from user-provided root
		if readErr != nil {
			return nil //nolint:nilerr // best-effort; skip unreadable files
		}

		absPath, absErr := filepath.Abs(p)
		if absErr != nil {
			absPath = p
		}

		fset := token.NewFileSet()

		file, parseErr := parser.ParseFile(fset, p, content, parser.ParseComments)
		if parseErr != nil {
			return nil //nolint:nilerr // best-effort; skip unparseable files
		}

		lines := strings.Split(string(content), "\n")

		for _, cg := range file.Comments {
			for _, c := range cg.List {
				if !isNolintDirective(c.Text) {
					continue
				}

				lineNum := fset.Position(c.Pos()).Line

				lineText := ""
				if lineNum >= 1 && lineNum <= len(lines) {
					lineText = strings.TrimSpace(lines[lineNum-1])
				}

				directives = append(directives, nolintDirective{
					File:    absPath,
					Line:    lineNum,
					Content: lineText,
					Reason:  extractReason(lineText),
				})
			}
		}

		return nil
	})
	if walkErr != nil {
		return nil, apierrors.Wrap(walkErr, "walking %s for nolint directives", root)
	}

	deduped := deduplicateDirectives(directives)
	sortDirectives(deduped)

	return deduped, nil
}

// isNolintDirective checks if text is a Go line comment that is a nolint
// directive targeting the erraudit or legacyerrors linter. Bare //nolint
// (no linter spec) matches all linters and is included.
func isNolintDirective(text string) bool {
	if !strings.HasPrefix(text, "//") {
		return false
	}

	body := strings.TrimSpace(text[2:])

	if !strings.EqualFold(body[:min(len("nolint"), len(body))], "nolint") {
		return false
	}

	spec := body[len("nolint"):]

	// Bare //nolint — matches all linters
	if spec == "" {
		return true
	}

	if !strings.HasPrefix(spec, ":") {
		return false
	}

	spec = strings.TrimSpace(spec[1:])

	if beforeReason, _, hasReason := strings.Cut(spec, "//"); hasReason {
		spec = beforeReason
	}

	spec = strings.TrimSpace(spec)

	if beforeRule, _, hasRule := strings.Cut(spec, ":"); hasRule {
		spec = beforeRule
	}

	for l := range strings.SplitSeq(spec, ",") {
		l = strings.TrimSpace(l)
		if strings.EqualFold(l, linterErraudit) || strings.EqualFold(l, linterLegacyerrors) {
			return true
		}
	}

	return false
}

// deduplicateDirectives removes duplicates (same file+line from multiple passes).
func deduplicateDirectives(directives []nolintDirective) []nolintDirective {
	seen := make(map[string]bool)

	result := directives[:0]

	for _, d := range directives {
		key := fmt.Sprintf("%s:%d", d.File, d.Line)
		if seen[key] {
			continue
		}

		seen[key] = true

		result = append(result, d)
	}

	return result
}

// sortDirectives sorts by file then line for deterministic output.
func sortDirectives(directives []nolintDirective) {
	sort.Slice(directives, func(left, right int) bool {
		if directives[left].File != directives[right].File {
			return directives[left].File < directives[right].File
		}

		return directives[left].Line < directives[right].Line
	})
}

// extractReason pulls the comment text after the nolint directive.
// e.g. "//nolint:erraudit // hook errors are non-fatal" -> "hook errors are non-fatal".
func extractReason(line string) string {
	before, _, found := strings.Cut(strings.ToLower(line), nolintPrefix)
	if !found {
		return ""
	}

	afterNolint := line[len(before):]

	_, reason, reasonFound := strings.Cut(afterNolint, "// ") //nolint:erraudit // Cut returns string, not error
	if !reasonFound {
		return ""
	}

	return strings.TrimSpace(reason)
}

// auditDirectives determines for each directive whether it's needed (suppresses
// at least one violation) or stale (suppresses nothing).
func auditDirectives(
	directives []nolintDirective,
	violations []types.ErrorViolation,
) []directiveStatus {
	violationsByFile := lo.GroupBy(violations, func(v types.ErrorViolation) string { return v.Position.Filename })

	fileContentCache := make(map[string]string)
	statuses := make([]directiveStatus, 0, len(directives))

	for _, d := range directives {
		status := directiveStatus{Directive: d} //nolint:exhaustruct_v5 // Needed/Violation set conditionally below

		content, ok := fileContentCache[d.File]
		if !ok {
			data, readErr := os.ReadFile(d.File)
			if readErr != nil {
				status.Needed = true // can't verify; assume needed to be safe
				statuses = append(statuses, status)

				continue
			}

			content = string(data)
			fileContentCache[d.File] = content
		}

		effectiveLines := suppression.EffectiveDirectiveLines(content, d.Line)
		effectiveSet := make(map[int]bool, len(effectiveLines))

		for _, l := range effectiveLines {
			effectiveSet[l] = true
		}

		fileViolations := violationsByFile[d.File]
		for i := range fileViolations {
			if effectiveSet[fileViolations[i].Position.Line] {
				status.Needed = true
				status.Violation = &fileViolations[i]

				break
			}
		}

		statuses = append(statuses, status)
	}

	return statuses
}

// printStatus prints a single directive's audit result.
func printStatus(s directiveStatus) {
	status := "STALE"
	color := "\033[33m" // yellow
	reset := "\033[0m"

	if s.Needed {
		status = "NEEDED"
		color = "\033[32m" // green
	}

	if !isTerminal() {
		color = ""
		reset = ""
	}

	d := s.Directive
	displayPath := relativePath(d.File)

	fmt.Fprintf(os.Stdout, "%s%-7s%s %s:%d\n", color, status, reset, displayPath, d.Line)

	if d.Reason != "" {
		fmt.Fprintf(os.Stdout, "         reason: %s\n", d.Reason)
	}

	if s.Needed && s.Violation != nil {
		v := s.Violation
		fmt.Fprintf(os.Stdout, "         suppresses: %s — %s\n", v.Type, truncateMessage(v.Message))
	}

	if !s.Needed {
		fmt.Fprintf(os.Stdout, "         action: safe to remove\n")
	}
}

// printJSONOutput prints the audit results as machine-readable JSON.
func printJSONOutput(w io.Writer, statuses []directiveStatus, removed int) error {
	report := auditReport{
		Summary: auditSummary{
			Total:   len(statuses),
			Needed:  0,
			Stale:   0,
			Removed: removed,
		},
		Directives: make([]auditDirective, 0, len(statuses)),
	}

	for _, s := range statuses {
		d := auditDirective{ //nolint:exhaustruct_v5 // Status/Suppresses set conditionally below
			File:   relativePath(s.Directive.File),
			Line:   s.Directive.Line,
			Reason: s.Directive.Reason,
		}

		if s.Needed {
			d.Status = "needed"
			report.Summary.Needed++
		} else {
			d.Status = "stale"
			report.Summary.Stale++
		}

		if s.Needed && s.Violation != nil {
			d.Suppresses = &auditSuppress{
				Type:    string(s.Violation.Type),
				Message: truncateMessage(s.Violation.Message),
			}
		}

		report.Directives = append(report.Directives, d)
	}

	data, err := json.Marshal(report, jsontext.WithIndentPrefix(""), jsontext.WithIndent("  "))
	if err != nil {
		return apierrors.Wrap(err, "failed to marshal audit report")
	}

	fmt.Fprintln(w, string(data))

	return nil
}

// applyFix removes stale directives from source files. Only single-linter
// directives targeting exactly erraudit or legacyerrors are removed —
// multi-linter directives (e.g. //nolint:wrapcheck,erraudit) and bare
// //nolint are skipped to avoid breaking other linters' suppressions.
// Returns the total number of directives removed and files modified.
func applyFix(statuses []directiveStatus) (int, int, error) {
	// Group stale directives by file (line numbers sorted descending)
	byFile := make(map[string][]int)

	for _, s := range statuses {
		if s.Needed {
			continue
		}

		if !isRemovableDirective(s.Directive.Content) {
			continue
		}

		byFile[s.Directive.File] = append(byFile[s.Directive.File], s.Directive.Line)
	}

	totalRemoved := 0
	filesModified := 0

	for filePath, lineNums := range byFile {
		sort.Sort(sort.Reverse(sort.IntSlice(lineNums)))

		content, readErr := os.ReadFile(filePath)
		if readErr != nil {
			return totalRemoved, filesModified, apierrors.Wrap(readErr, "reading %s for fix", filePath)
		}

		lines := strings.Split(string(content), "\n")
		fileRemoved := 0

		for _, lineNum := range lineNums {
			if lineNum < 1 || lineNum > len(lines) {
				continue
			}

			newLine, removed := removeNolintFromLine(lines[lineNum-1])
			if !removed {
				continue
			}

			if newLine == "" {
				lines = append(lines[:lineNum-1], lines[lineNum:]...)
			} else {
				lines[lineNum-1] = newLine
			}

			fileRemoved++
		}

		if fileRemoved > 0 {
			writeErr := os.WriteFile(filePath, []byte(strings.Join(lines, "\n")), 0o644)
			if writeErr != nil {
				return totalRemoved, filesModified, apierrors.Wrap(writeErr, "writing %s after fix", filePath)
			}

			totalRemoved += fileRemoved
			filesModified++
		}
	}

	return totalRemoved, filesModified, nil
}

// previewFix shows what --fix would remove without modifying any files.
func previewFix(w io.Writer, statuses []directiveStatus) {
	wouldRemove := 0

	for _, s := range statuses {
		if s.Needed {
			continue
		}

		if !isRemovableDirective(s.Directive.Content) {
			continue
		}

		wouldRemove++

		fmt.Fprintf(
			w,
			"  Would remove: %s:%d %s\n",
			relativePath(s.Directive.File),
			s.Directive.Line,
			s.Directive.Content,
		)
	}

	if wouldRemove > 0 {
		fmt.Fprintf(w, "\nDry run: %d directive(s) would be removed. No files modified.\n", wouldRemove)
	} else {
		fmt.Fprintln(w, "Dry run: no removable stale directives found.")
	}
}

// isRemovableDirective checks if the directive targets ONLY erraudit or
// legacyerrors (not multi-linter, not bare //nolint).
func isRemovableDirective(lineContent string) bool {
	lower := strings.ToLower(lineContent)

	for _, prefix := range []string{nolintPrefix, nolintSpacedPrefix} {
		_, after, ok := strings.Cut(lower, prefix)
		if !ok {
			continue
		}

		if !strings.HasPrefix(after, ":") {
			return false
		}

		spec := strings.TrimSpace(after[1:])

		if beforeReason, _, hasReason := strings.Cut(spec, "//"); hasReason {
			spec = beforeReason
		}

		spec = strings.TrimSpace(spec)

		if beforeRule, _, hasRule := strings.Cut(spec, ":"); hasRule {
			spec = beforeRule
		}

		return spec == linterErraudit || spec == linterLegacyerrors
	}

	return false
}

// removeNolintFromLine strips the trailing //nolint comment from a line.
// Returns empty string if the line was only the comment (caller should
// remove the line entirely).
func removeNolintFromLine(line string) (string, bool) {
	lower := strings.ToLower(line)

	for _, prefix := range []string{nolintPrefix, nolintSpacedPrefix} {
		beforeLower, _, ok := strings.Cut(lower, prefix)
		if !ok {
			continue
		}

		before := line[:len(beforeLower)]
		if strings.TrimSpace(before) == "" {
			return "", true
		}

		return strings.TrimRight(before, " \t"), true
	}

	return line, false
}

func relativePath(p string) string {
	cwd, err := os.Getwd()
	if err != nil {
		return p
	}

	rel, err := filepath.Rel(cwd, p)
	if err != nil || strings.HasPrefix(rel, "..") {
		return p
	}

	return rel
}

func truncateMessage(msg string) string {
	if len(msg) <= maxMessageLen {
		return msg
	}

	return msg[:maxMessageLen-3] + "..."
}

// isTerminal reports whether stdout is connected to a terminal.
func isTerminal() bool {
	info, err := os.Stdout.Stat()
	if err != nil {
		return false
	}

	return info.Mode()&os.ModeCharDevice != 0
}
