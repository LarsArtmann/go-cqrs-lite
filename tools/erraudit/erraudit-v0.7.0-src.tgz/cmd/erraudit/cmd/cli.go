package cmd

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"os"

	v4 "github.com/larsartmann/cmdguard/v4/pkg/cmdguard/v4"
	apierrors "github.com/larsartmann/erraudit/pkg/errors"
	"github.com/larsartmann/erraudit/pkg/extension/builtins"
	"github.com/spf13/cobra"
)

// argsContextKey is used to store positional args in the context so that
// cmdguard handlers (which don't receive args directly) can access them.
type argsContextKey struct{}

// formatChangedKey is used to store whether the --format flag was explicitly
// set by the user (vs left at default). This lets the lint command distinguish
// "user explicitly chose tree" from "default tree" to decide between
// structured and plain-text output.
type formatChangedKey struct{}

// Execute builds the cmdguard CLI, registers all commands, and runs it.
// Exit codes: 0 = success, 2 = violations found, 1 = error (classified via go-error-family).
func Execute(version string) {
	var outputFormat string

	cli, err := buildCLI(version, &outputFormat)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error: %v\n", err)
		os.Exit(ExitError)
	}

	execErr := cli.Execute(context.Background())
	if execErr != nil {
		if errors.Is(execErr, ErrViolationsFound) {
			os.Exit(ExitViolationsFound)
		}

		// Machine-readable failure contract: json-family formats emit the
		// error envelope on stdout so scripts can branch on code/family
		// instead of parsing stderr text. Best-effort — the exit code below
		// still classifies the failure.
		if outputFormat == "json" || outputFormat == "jsonl" {
			_ = apierrors.WriteJSONErrorEnvelope(
				os.Stdout,
				execErr,
			) //nolint:erraudit // best-effort: process is exiting; envelope write failure has nowhere to go
		}

		os.Exit(apierrors.ExitCode(execErr))
	}
}

func buildCLI(version string, outputFormat *string) (*v4.CLI[AppConfig], error) {
	cli, err := v4.NewCLI[AppConfig](
		"erraudit",
		"Analyze error handling patterns in Go code",
		AppConfig{},
		v4.WithCLIVersion(version),
		v4.WithCLILong(`Erraudit is a comprehensive tool for analyzing,
visualizing, and enforcing proper hierarchical error handling in Go codebases.

It detects error patterns, identifies anti-patterns, and generates reports
in multiple formats (tree, JSON, HTML, DOT, Mermaid, agent, SARIF).`),
		v4.WithEnvPrefix("ERRAUDIT_"),
		v4.WithSignalHandling(),
		v4.WithConfigFile(".erraudit.yaml", ".erraudit.yml"),
		v4.WithConfigValidation(validateConfig),
		v4.WithPostFlagParse(func(cmd *cobra.Command, cfg *AppConfig) error {
			// Snapshot the output format for the JSON error envelope in Execute.
			if outputFormat != nil {
				*outputFormat = cfg.Format
			}
			// Store positional args in context for handlers that need them.
			args := cmd.Flags().Args()
			ctx := context.WithValue(cmd.Context(), argsContextKey{}, args)
			// Track whether --format was explicitly set (for lint plain-text detection).
			ctx = context.WithValue(ctx, formatChangedKey{}, cmd.Flags().Changed("format"))
			cmd.SetContext(ctx)

			// Initialize features unless disabled.
			if !cfg.DisableExtensions {
				// Auto-suppress extension logger for utility subcommands
				// that don't need analysis progress output on stderr.
				quiet := cfg.Quiet || isUtilitySubcommand(cmd.Name())

				var logger func(string, ...any)
				if quiet {
					logger = func(string, ...any) {} // no-op: suppress extension log output
				}

				if err := builtins.BuiltinsWithLogger(ctx, logger); err != nil {
					slog.Warn("feature initialization failed", "error", err)
				}
			}

			return nil
		}),
	)
	if err != nil {
		return nil, apierrors.Wrap(err, "failed to create CLI")
	}

	// Root command IS the analysis command — set RunE directly via cobra.
	root := cli.RootCommand()
	registerFlagCompletions(root)
	// The --type help is generated from the type registry, not the struct
	// tag, so the flag text can never drift from types.ValidErrorTypes().
	if typeFlag := root.PersistentFlags().Lookup("type"); typeFlag != nil {
		typeFlag.Usage = typeFilterHelpText()
	}

	root.Example = `  # Analyze current directory
  erraudit .

  # Analyze with JSON output
  erraudit . --format json

  # Analyze with agent-optimized output (for AI coding agents)
  erraudit . --format agent

  # Analyze with SARIF output (for CI/CD integration)
  erraudit . --format sarif

  # Show only violations
  erraudit . --violations-only

  # Visualize error hierarchy as a tree
  erraudit tree .`
	root.Args = cobra.MaximumNArgs(1)
	root.RunE = func(cmd *cobra.Command, args []string) error {
		cfg, ok := v4.ConfigFromContext[AppConfig](cmd.Context())
		if !ok {
			return apierrors.New("configuration not found in context")
		}

		analyzer := NewAnalyzer(pathFromArgs(args))

		return analyzer.Run(cmd, cfg)
	}

	if err := registerSubcommands(cli); err != nil {
		return nil, apierrors.Wrap(err, "failed to register commands")
	}

	return cli, nil
}

// isUtilitySubcommand reports whether the subcommand should auto-suppress
// extension logger output (nolint-audit, tree produce piped/parsed output).
func isUtilitySubcommand(name string) bool {
	switch name {
	case "nolint-audit", "tree", "portfolio":
		return true
	default:
		return false
	}
}

func registerSubcommands(cli *v4.CLI[AppConfig]) error {
	if err := registerFixCommand(cli); err != nil {
		return err
	}

	if err := registerLSPCommand(cli); err != nil {
		return err
	}

	if err := registerLintCommand(cli); err != nil {
		return err
	}

	if err := registerWatchCommand(cli); err != nil {
		return err
	}

	if err := registerExtensionCommand(cli); err != nil {
		return err
	}

	if err := registerTreeCommand(cli); err != nil {
		return err
	}

	if err := registerErrorflowCommand(cli); err != nil {
		return err
	}

	if err := registerNolintAuditCommand(cli); err != nil {
		return err
	}

	if err := registerPortfolioCommand(cli); err != nil {
		return err
	}

	versionCmd, err := v4.VersionCommand[AppConfig](cli)

	return registerCommand(cli, "version", versionCmd, err)
}

// registerCommand wraps the create-and-add boilerplate shared by every
// register*Command function. It wraps the creation error (createErr from
// NewCommand/VersionCommand) and the registration error (from AddCommand)
// with the command name for diagnostics.
func registerCommand[F any](
	cli *v4.CLI[AppConfig],
	name string,
	cmd v4.Command[AppConfig, F],
	createErr error,
) error {
	if createErr != nil {
		return apierrors.Wrap(createErr, "create %s command", name)
	}

	if err := v4.AddCommand(cli, cmd); err != nil {
		return apierrors.Wrap(err, "add %s command", name)
	}

	return nil
}
