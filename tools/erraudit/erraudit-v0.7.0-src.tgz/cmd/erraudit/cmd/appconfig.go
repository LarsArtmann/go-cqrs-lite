package cmd

import (
	"context"
	"slices"
	"strings"

	"github.com/larsartmann/erraudit/internal/viz"
	apierrors "github.com/larsartmann/erraudit/pkg/errors"
	"github.com/larsartmann/erraudit/pkg/types"
)

// DefaultDOTTheme is the default DOT graph theme name.
const DefaultDOTTheme = "default"

// ModulesAllMode is the only valid value for AppConfig.Modules: analyze the
// root module AND every nested go.mod module, merging the results.
const ModulesAllMode = "all"

// AppConfig holds all persistent analysis flags shared across subcommands.
// It replaces the former config.Config struct and is populated by cmdguard
// from struct tags, config files, environment variables, and CLI flags.
type AppConfig struct {
	Format               string   `default:"tree"    env:"FORMAT" flag:"format"                  help:"Output format: tree, json, html, full, hierarchy, dot, mermaid, agent, sarif, csv, tsv, markdown, yaml, xml, d2, jsonl, asciidoc, toml, plantuml, table"                       short:"f"`
	Output               string   `default:""                     flag:"output"                  help:"Output file (default: stdout)"                                                                                                                                                 short:"o"`
	Verbose              bool     `default:"false"                flag:"verbose"                 help:"Verbose output"                                                                                                                                                                short:"v"`
	ViolationsOnly       bool     `default:"false"                flag:"violations-only"         help:"Show only violations (no full tree/hierarchy output)"                                                                                                                                    local:"true"`
	Severity             string   `default:""                     flag:"severity"                help:"Filter violations by severity (critical, error, warning)"`
	Type                 string   `default:""                     flag:"type"                    help:"Filter violations by type (full list generated from the type registry at CLI startup; see --help)"`
	SeverityThreshold    string   `default:""                     flag:"severity-threshold"      help:"Only show violations at or above this severity (critical, error, warning)"`
	Exclude              []string `                               flag:"exclude"                 help:"Paths to exclude from analysis (can be repeated)"`
	DOTTheme             string   `default:"default"              flag:"dot-theme"               help:"DOT/Mermaid output theme (default, dark, minimal, colorful)"`
	DisableExtensions    bool     `default:"false"                flag:"disable-extensions"      help:"Disable built-in extensions"`
	TypeAware            bool     `default:"false"                flag:"type-aware"              help:"Enable type-aware analysis using go/types (reduces false positives, uses more memory)"`
	EnforceErrorFamily   bool     `default:"false"                flag:"enforce-go-error-family" help:"Flag stdlib error constructors (errors.New, fmt.Errorf, errors.Join) as violations — use when the project enforces go-error-family"`
	EnforceSamberOops    bool     `default:"false"                flag:"enforce-samber-oops"     help:"Flag stdlib error constructors as violations + detect oops anti-patterns (redundant nil guards) — use when the project enforces samber/oops"`
	EnforceGenericReturn bool     `default:"false"                flag:"enforce-generic-return"  help:"Flag functions returning bare error interface instead of a specific error type (off by default — returning error is standard Go practice)"`
	EnforceDeferredClose bool     `default:"false"                flag:"enforce-deferred-close"  help:"Flag defer x.Close() patterns where the Close return value is ignored (off by default — defer file.Close() is standard Go practice)"`
	EnforceCodedErrors   bool     `default:"false"                flag:"enforce-coded-errors"    help:"Flag go-error-family constructors called with an empty (\"\") error code (off by default — empty-code errors lose their What/Why/Fix template)"`
	NoSuppress           bool     `default:"false"                flag:"no-suppress"             help:"Disable all suppression (//nolint comments + AST false-positive heuristics) to audit every potential violation"`
	Modules              string   `default:""                     flag:"modules"                 help:"Multi-module handling: all = analyze the root module plus every nested go.mod module and merge the results (default: root module only, nested modules skipped with a warning)"`
	Progress             bool     `default:"false"                flag:"progress"                help:"Show analysis progress on stderr (auto-silenced when stderr is not a terminal); watch mode renders it per sweep, --pipeline honors it without touching stdout"`
	Quiet                bool     `default:"false"                flag:"quiet"                   help:"Suppress extension log output on stderr"                                                                                                                                       short:"q"`
	Disable              []string `                               flag:"disable"                 help:"Disable specific violation types (can be repeated, e.g. --disable context_loss)"`
	Pipeline             bool     `default:"false"                flag:"pipeline"                help:"Run analysis through go-finding pipeline (ecosystem-standard suppression and output)"`
	Explain              bool     `default:"false"                flag:"explain"                 help:"Show detailed explanation of why each violation was flagged"`
}

// FixFlags holds flags specific to the fix subcommand.
type FixFlags struct {
	Write    bool `default:"false" flag:"write"     help:"Write fixes to files (default: dry-run)" short:"w"`
	NoBackup bool `default:"false" flag:"no-backup" help:"Skip creating .orig backup files"`
}

// LSPFlags holds flags specific to the lsp subcommand.
type LSPFlags struct {
	Socket string `default:"" flag:"socket" help:"TCP socket address to listen on (e.g., :4389)"`
}

// NolintAuditFlags holds flags specific to the nolint-audit subcommand.
type NolintAuditFlags struct {
	Fix    bool `default:"false" flag:"fix"     help:"Remove stale directives from source files"`
	DryRun bool `default:"false" flag:"dry-run" help:"Preview which directives --fix would remove (no files modified)"`

	Format string `default:"text" flag:"audit-format" help:"Output format: text or json"`
}

// WatchFlags holds flags specific to the watch subcommand.
type WatchFlags struct {
	TraceOnError bool `default:"false" flag:"trace-on-error" help:"Keep a moving execution trace and dump a .trace file when an analysis errors" local:"true"`
}

// TreeFlags holds flags specific to the tree subcommand.
type TreeFlags struct {
	Markdown    bool   `default:"false" flag:"markdown"     help:"Render as a Markdown bullet list instead of an ASCII tree"`
	Color       string `default:""      flag:"color"        help:"Color output: always, never, or auto (default: auto, disabled when --output is set)"`
	NoPosition  bool   `default:"false" flag:"no-position"  help:"Omit source file:line from tree labels"`
	NoKind      bool   `default:"false" flag:"no-kind"      help:"Omit error kind (sentinel/custom_type) from tree labels"`
	MaxDepth    int    `default:"0"     flag:"max-depth"    help:"Maximum tree depth to render (0 = unlimited)"`
	InlineWraps bool   `default:"false" flag:"inline-wraps" help:"Render inline wrap sites and errors.Is checks as child lines under each error"`
	Sort        string `default:"auto"  flag:"sort"         help:"Sort root errors: auto (centrality when flat), wraps (most-referenced first), or name"`
	Group       bool   `default:"false" flag:"group"        help:"Group root errors by package directory"`
	MaxSites    int    `default:"8"     flag:"max-sites"    help:"Maximum inline sites rendered per error in ASCII output (0 = unlimited; Markdown is never capped)"`
}

// ErrorflowFlags holds flags specific to the errorflow subcommand.
type ErrorflowFlags struct {
	Markdown bool `default:"false" flag:"markdown" help:"Render as a Markdown coeffects table instead of JSON"`
}

// PortfolioFlags holds flags specific to the portfolio subcommand.
type PortfolioFlags struct {
	SearchPaths []string `flag:"search-path" help:"Directories to discover Go projects in (repeatable; default: ~/projects ~/GolandProjects ~/IdeaProjects ~/WebStormProjects)"`

	SortBy string `default:"violations" flag:"sort-by" help:"Sort projects by: name, violations, critical, error, warning, files"`

	ShowAll     bool `default:"false" flag:"show-all"    help:"Include projects with zero violations (hidden by default)"`
	Concurrency int  `default:"8"     flag:"concurrency" help:"Parallel project analyses (1 = sequential)"`
}

// typeFilterHelpText generates the --type flag help from the type registry
// (types.ValidErrorTypes), so a new ErrorType constant shows up in --help
// automatically instead of waiting for a hand-maintained list to catch up.
// Wired onto the root's persistent flag at CLI construction (cli.go).
func typeFilterHelpText() string {
	names := make([]string, 0, len(types.ValidErrorTypes()))
	for _, t := range types.ValidErrorTypes() {
		names = append(names, string(t))
	}

	return "Filter violations by type (" + strings.Join(names, ", ") + ")"
}

// validateConfig validates all AppConfig fields and cross-field combinations.
// It is passed to cmdguard via WithConfigValidation.
func validateConfig(cfg *AppConfig) error {
	if !types.OutputFormat(cfg.Format).IsValid() {
		return apierrors.Wrap(apierrors.ErrConfigInvalid, "%q", cfg.Format)
	}

	if cfg.Severity != "" {
		s, err := types.ParseSeverity(cfg.Severity)
		if err != nil {
			return apierrors.Wrap(
				apierrors.ErrConfigInvalid,
				"invalid severity filter %q",
				cfg.Severity,
			)
		}

		_ = s
	}

	if cfg.Type != "" {
		t, err := types.ParseErrorType(cfg.Type)
		if err != nil {
			return apierrors.Wrap(apierrors.ErrConfigInvalid, "invalid type filter %q", cfg.Type)
		}

		_ = t
	}

	if cfg.SeverityThreshold != "" {
		s, err := types.ParseSeverity(cfg.SeverityThreshold)
		if err != nil {
			return apierrors.Wrap(
				apierrors.ErrConfigInvalid,
				"invalid severity threshold %q",
				cfg.SeverityThreshold,
			)
		}

		_ = s
	}

	if cfg.DOTTheme != "" && !slices.Contains(viz.AvailableThemes(), cfg.DOTTheme) {
		return apierrors.Wrap(apierrors.ErrConfigInvalid, "invalid dot theme %q", cfg.DOTTheme)
	}

	if cfg.Modules != "" && cfg.Modules != ModulesAllMode {
		return apierrors.Wrap(
			apierrors.ErrConfigInvalid,
			"invalid --modules value %q (valid: %s)",
			cfg.Modules, ModulesAllMode,
		)
	}

	for _, d := range cfg.Disable {
		t, err := types.ParseErrorType(d)
		if err != nil {
			return apierrors.Wrap(
				apierrors.ErrConfigInvalid,
				"invalid violation type in --disable %q",
				d,
			)
		}

		_ = t
	}

	return validateCombinations(cfg)
}

func validateCombinations(cfg *AppConfig) error {
	if cfg.ViolationsOnly {
		of := types.OutputFormat(cfg.Format)
		if of == types.FormatDOT || of == types.FormatMermaid {
			return apierrors.Wrap(
				apierrors.ErrViolationsOnlyIncompatible,
				"--violations-only is not compatible with --format %s (graph formats show full structure)",
				of,
			)
		}
	}

	if cfg.Verbose && cfg.Output != "" {
		return apierrors.ErrVerboseIncompatible
	}

	return nil
}

// OutputFormatType returns the parsed types.OutputFormat from the string field.
func (cfg *AppConfig) OutputFormatType() types.OutputFormat {
	return types.OutputFormat(cfg.Format)
}

// SeverityFilterPtr returns a *types.Severity or nil if the field is empty.
func (cfg *AppConfig) SeverityFilterPtr() *types.Severity {
	if cfg.Severity == "" {
		return nil
	}

	s, _ := types.ParseSeverity(
		cfg.Severity,
	) //nolint:erraudit // validated by validateConfig before reaching here

	return &s
}

// TypeFilterPtr returns a *types.ErrorType or nil if the field is empty.
func (cfg *AppConfig) TypeFilterPtr() *types.ErrorType {
	if cfg.Type == "" {
		return nil
	}

	t, _ := types.ParseErrorType(
		cfg.Type,
	) //nolint:erraudit // validated by validateConfig before reaching here

	return &t
}

// SeverityThresholdPtr returns a *types.Severity or nil if the field is empty.
func (cfg *AppConfig) SeverityThresholdPtr() *types.Severity {
	if cfg.SeverityThreshold == "" {
		return nil
	}

	s, _ := types.ParseSeverity( //nolint:erraudit // validated by validateConfig before reaching here
		cfg.SeverityThreshold,
	)

	return &s
}

// DisabledTypesSet returns a set of disabled violation types, or nil if none.
func (cfg *AppConfig) DisabledTypesSet() map[types.ErrorType]bool {
	if len(cfg.Disable) == 0 {
		return nil
	}

	result := make(map[types.ErrorType]bool, len(cfg.Disable))
	for _, d := range cfg.Disable {
		result[types.ErrorType(d)] = true
	}

	return result
}

// pathFromArgs returns the first positional argument or "." if none provided.
func pathFromArgs(args []string) string {
	if len(args) == 0 {
		return "."
	}

	return args[0]
}

// argsFromContext retrieves positional args stored by the PostFlagParse hook.
func argsFromContext(ctx context.Context) []string {
	args, _ := ctx.Value(argsContextKey{}).([]string)

	return args
}

// formatExplicitlySet returns true if the --format flag was explicitly set
// by the user (vs left at default). Retrieved from the PostFlagParse hook.
func formatExplicitlySet(ctx context.Context) bool {
	changed, _ := ctx.Value(formatChangedKey{}).(bool)

	return changed
}
