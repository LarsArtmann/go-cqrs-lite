module github.com/larsartmann/erraudit

go 1.27.1

require (
	charm.land/log/v2 v2.0.1
	github.com/LarsArtmann/gogenfilter/v3 v3.6.1
	github.com/aymanbagabas/go-udiff v0.4.1
	github.com/dustin/go-humanize v1.1.0
	github.com/larsartmann/cmdguard/v4 v4.1.0
	github.com/larsartmann/go-error-family v0.12.0
	github.com/larsartmann/go-filewatcher/v2 v2.4.2
	github.com/larsartmann/go-finding v1.15.0
	github.com/larsartmann/go-finding/analysis v1.14.0
	github.com/larsartmann/go-finding/pipeline v1.15.0
	github.com/larsartmann/go-finding/toolsdk v1.16.0
	github.com/larsartmann/go-output v0.38.5
	github.com/larsartmann/go-output/d2 v0.38.5
	github.com/larsartmann/go-output/delimited v0.38.5
	github.com/larsartmann/go-output/graph v0.38.5
	github.com/larsartmann/go-output/markdown v0.38.5
	github.com/larsartmann/go-output/markup v0.38.5
	github.com/larsartmann/go-output/plantuml v0.38.5
	github.com/larsartmann/go-output/serialization v0.38.5
	github.com/larsartmann/go-output/table v0.38.5
	github.com/larsartmann/go-output/tree v0.38.5
	github.com/maypok86/otter/v2 v2.3.0
	github.com/onsi/ginkgo/v2 v2.33.1
	github.com/onsi/gomega v1.44.0
	github.com/samber/lo v1.53.0
	github.com/sourcegraph/go-lsp v0.0.0-20240223163137-f80c5dd31dfd
	github.com/sourcegraph/jsonrpc2 v0.2.3
	github.com/spf13/cobra v1.10.2
	github.com/stretchr/testify v1.12.1
	golang.org/x/sync v0.24.0
	golang.org/x/tools v0.52.0
	pgregory.net/rapid v1.3.0
)

require (
	charm.land/fang/v2 v2.0.1 // indirect
	charm.land/lipgloss/v2 v2.0.6 // indirect
	github.com/DmitriyVTitov/size v1.5.0 // indirect
	github.com/Masterminds/semver/v3 v3.5.0 // indirect
	github.com/a-h/templ v0.3.1070 // indirect
	github.com/beorn7/perks v1.0.1 // indirect
	github.com/bmatcuk/doublestar/v4 v4.10.3 // indirect
	github.com/cespare/xxhash/v2 v2.3.0 // indirect
	github.com/charmbracelet/colorprofile v0.4.3 // indirect
	github.com/charmbracelet/ultraviolet v0.0.0-20261008173134-6b8d4baf91b4 // indirect
	github.com/charmbracelet/x/ansi v0.11.9 // indirect
	github.com/charmbracelet/x/exp/charmtone v0.1.0 // indirect
	github.com/charmbracelet/x/term v0.2.2 // indirect
	github.com/charmbracelet/x/termios v0.1.1 // indirect
	github.com/charmbracelet/x/windows v0.2.2 // indirect
	github.com/clipperhouse/displaywidth v0.11.0 // indirect
	github.com/clipperhouse/uax29/v2 v2.7.0 // indirect
	github.com/fsnotify/fsnotify v1.10.1 // indirect
	github.com/go-enry/go-enry/v2 v2.9.6 // indirect
	github.com/go-enry/go-oniguruma v1.2.1 // indirect
	github.com/go-faster/errors v0.8.0 // indirect
	github.com/go-faster/jx v1.2.0 // indirect
	github.com/go-faster/yaml v0.4.6 // indirect
	github.com/go-logfmt/logfmt v0.6.1 // indirect
	github.com/go-logr/logr v1.4.4 // indirect
	github.com/go-task/slim-sprig/v3 v3.0.0 // indirect
	github.com/go-viper/mapstructure/v2 v2.5.0 // indirect
	github.com/gobwas/glob v1.0.0 // indirect
	github.com/gofrs/flock v0.13.1 // indirect
	github.com/google/go-cmp v0.7.0 // indirect
	github.com/google/pprof v0.0.0-20261014150452-c3b4e57cab2c // indirect
	github.com/inconshreveable/mousetrap v1.1.0 // indirect
	github.com/knadh/koanf/maps v0.1.3 // indirect
	github.com/knadh/koanf/parsers/json v1.0.1 // indirect
	github.com/knadh/koanf/parsers/toml v0.1.0 // indirect
	github.com/knadh/koanf/parsers/yaml v1.1.1 // indirect
	github.com/knadh/koanf/v2 v2.3.8 // indirect
	github.com/larsartmann/go-atomic-write v0.6.0 // indirect
	github.com/larsartmann/go-branded-id v0.7.0 // indirect
	github.com/larsartmann/go-composable-business-types v0.7.0 // indirect
	github.com/larsartmann/go-ndjson v0.0.1 // indirect
	github.com/larsartmann/go-output/daghtml v0.38.5 // indirect
	github.com/larsartmann/go-output/escape v0.38.5 // indirect
	github.com/larsartmann/samber-do-auditlog v0.11.0 // indirect
	github.com/lucasb-eyer/go-colorful v1.4.1 // indirect
	github.com/mattn/go-runewidth v0.0.31 // indirect
	github.com/mitchellh/copystructure v1.2.0 // indirect
	github.com/mitchellh/reflectwalk v1.0.2 // indirect
	github.com/muesli/cancelreader v0.2.2 // indirect
	github.com/muesli/mango v0.2.0 // indirect
	github.com/muesli/mango-cobra v1.3.0 // indirect
	github.com/muesli/mango-pflag v0.2.0 // indirect
	github.com/muesli/roff v0.1.0 // indirect
	github.com/munnerz/goautoneg v0.0.0-20191010083416-a7dc8b61c822 // indirect
	github.com/pelletier/go-toml v1.9.5 // indirect
	github.com/pelletier/go-toml/v2 v2.4.3 // indirect
	github.com/prometheus/client_golang v1.25.0 // indirect
	github.com/prometheus/client_model v0.6.3 // indirect
	github.com/prometheus/common v0.72.1 // indirect
	github.com/prometheus/procfs v0.22.0 // indirect
	github.com/rivo/uniseg v0.4.7 // indirect
	github.com/sabhiram/go-gitignore v0.0.0-20210923224102-525f6e181f06 // indirect
	github.com/samber/do/v2 v2.1.0 // indirect
	github.com/samber/go-singleflightx v1.0.0 // indirect
	github.com/samber/go-type-to-string v1.8.0 // indirect
	github.com/samber/hot v0.13.1 // indirect
	github.com/samber/ro v0.4.1 // indirect
	github.com/segmentio/asm v1.2.1 // indirect
	github.com/spf13/pflag v1.0.10 // indirect
	github.com/xo/terminfo v1.2.0 // indirect
	go.uber.org/multierr v1.11.0 // indirect
	go.yaml.in/yaml/v3 v3.0.5 // indirect
	golang.org/x/exp v0.0.0-20261014143641-f0251eb4aa3e // indirect
	golang.org/x/mod v0.42.0 // indirect
	golang.org/x/net v0.61.0 // indirect
	golang.org/x/sys v0.49.0 // indirect
	golang.org/x/term v0.47.0 // indirect
	golang.org/x/text v0.43.0 // indirect
	golang.org/x/time v0.16.0 // indirect
	google.golang.org/protobuf v1.36.12 // indirect
)
