package viz

import (
	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/samber/lo"
)

// countBySeverity counts violations by severity level.
func countBySeverity(violations []types.ErrorViolation) map[types.Severity]int {
	result := make(map[types.Severity]int, len(types.ValidSeverities()))
	for _, v := range violations {
		result[v.Severity]++
	}

	return result
}

// groupBySeverity groups violations by severity level.
func groupBySeverity(violations []types.ErrorViolation) map[types.Severity][]types.ErrorViolation {
	return lo.GroupBy(violations, func(v types.ErrorViolation) types.Severity { return v.Severity })
}
