package ast

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

const inlineCodeFixtureSrc = `package demo

import (
	errorfamily "github.com/larsartmann/go-error-family"
)

// Package-level sentinel: a named mint.
var ErrClosed error = errorfamily.NewRejection("bus.closed", "bus closed")

func load(path string) error {
	if path == "" {
		return errorfamily.NewRejection("path.empty", "path is empty")
	}

	// Formatted variants the hand-rolled regex pool classically misses.
	if bad(path) {
		return errorfamily.Newf(Rejection, "path.encoding_mismatch", "bad %s", path)
	}

	// One code, two families across sites: both pairs survive discovery so
	// taxonomy gates surface the conflict instead of hiding it.
	if slow(path) {
		return errorfamily.Newf(errorfamily.Transient, "path.empty", "%s not ready", path)
	}

	return errorfamily.Wrapf(ErrClosed, errorfamily.Rejection, "bus.wrapf", "wrapped")
}

func bad(string) bool { return false }
func slow(string) bool { return false }
`

func TestCollectInlineCodes(t *testing.T) {
	file := parseTemplateFixture(t, inlineCodeFixtureSrc)

	codes := collectInlineCodes(file, nil)

	byCode := map[string]string{}
	pairs := map[string]bool{}
	for _, code := range codes {
		byCode[code.Code] = code.Family
		pairs[code.Code+"/"+code.Family] = true
	}

	assert.Equal(t, map[string]string{
		"bus.closed":             "rejection",
		"path.empty":             "transient",
		"path.encoding_mismatch": "rejection",
		"bus.wrapf":              "rejection",
	}, byCode, "named mints, inline mints, Newf and Wrapf variants all collected")

	assert.True(t, pairs["path.empty/rejection"], "first mint of path.empty survives")
	assert.True(t, pairs["path.empty/transient"], "a code minted under a second family is kept as its own entry")
	assert.Len(t, codes, 5, "four codes plus the second-family mint of path.empty")
}

func TestCollectInlineCodes_SkipsIdentifierCodes(t *testing.T) {
	file := parseTemplateFixture(t, `package demo

import errorfamily "github.com/larsartmann/go-error-family"

func f() error {
	return errorfamily.NewRejection(CodeConfig, "msg")
}
`)

	codes := collectInlineCodes(file, nil)

	require.Empty(t, codes, "identifier-passed codes carry no literal value at the call site")
}
