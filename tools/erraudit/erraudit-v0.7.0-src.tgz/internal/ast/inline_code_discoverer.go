package ast

import (
	"go/ast"
	"go/token"
	"regexp"

	"github.com/larsartmann/erraudit/pkg/types"
)

// inlineCodePattern mirrors the taxonomy-code shape (lowercase dotted
// literals like "event.date_parse"): identifier-passed codes (CodeX
// constants) do not carry their literal value at the call site and stay on
// the named-error path, which records the identifier name.
var inlineCodePattern = regexp.MustCompile(`^[a-z0-9_]+(\.[a-z0-9_]+)+$`)

// inlineCodeKey deduplicates discoveries per code+family pair: one code
// minted under two families is a taxonomy fact, not a duplicate.
type inlineCodeKey struct {
	code   string
	family string
}

// collectInlineCodes walks every go-error-family constructor call in the
// file — including inline calls inside function bodies, which the named-error
// discoverer never sees (it walks package-level declarations only) — and
// records code→family with the minting position. This is the ground truth
// the errorflow export's `codes` array serves to taxonomy doc generators.
//
// Duplicate (code, family) pairs collapse to the first mint in source
// order; a code minted with TWO different families stays as two entries
// so taxonomy gates surface the conflict instead of hiding it (the
// export's codeEntries re-affirms this per-pair dedup). The export
// re-sorts by code anyway.
func collectInlineCodes(node ast.Node, fset *token.FileSet) []types.InlineCode {
	seen := make(map[inlineCodeKey]bool)

	var codes []types.InlineCode

	ast.Inspect(node, func(n ast.Node) bool {
		call, ok := n.(*ast.CallExpr)
		if !ok {
			return true
		}

		pkgName, methodName, ok := callSelector(call)
		if !ok {
			return true
		}

		info, found := errorFamilyConstructorInfo(pkgName, methodName)
		if !found {
			return true
		}

		code := extractCodeArg(call, info.codeIndex())
		if !inlineCodePattern.MatchString(code) {
			return true
		}

		family := info.family
		if family == "" {
			family = extractFamilyArg(call, info.codeIndex()-1)
		}

		if family == "" {
			family = familyForCode(code)
		}

		key := inlineCodeKey{code: code, family: family}
		if seen[key] {
			return true
		}

		seen[key] = true

		inlineCode := types.InlineCode{
			Code:   code,
			Family: family,
		}
		if fset != nil {
			inlineCode.Position = fset.Position(call.Pos())
		}

		codes = append(codes, inlineCode)

		return true
	})

	return codes
}
