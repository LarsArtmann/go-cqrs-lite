package ast

import (
	goast "go/ast"
	"go/parser"
	"go/token"
	"os"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

const templateFixtureSrc = `package demo

import (
	errorfamily "github.com/larsartmann/go-error-family"
)

const CodeConfigInvalid = "config.invalid"

var extra = map[string]errorfamily.MessageTemplate{
	"literal.code": {What: "Literal keyed.", Fix: "Literal fix."},
}

func init() {
	templates := map[string]errorfamily.MessageTemplate{
		CodeConfigInvalid: {
			What:   "The configuration is invalid.",
			Why:    "A value is missing or malformed.",
			Fix:    "Check the highlighted field.",
			WayOut: "Run with --help.",
		},
	}
	errorfamily.DefaultRegistry.RegisterTemplates(templates)
}

var notTemplates = map[string]string{"a": "b"}
`

func parseTemplateFixture(t *testing.T, src string) goast.Node {
	t.Helper()

	fset := token.NewFileSet()
	file, err := parser.ParseFile(fset, "fixture.go", src, parser.AllErrors)
	require.NoError(t, err)

	return file
}

func TestCollectMessageTemplates(t *testing.T) {
	file := parseTemplateFixture(t, templateFixtureSrc)

	templates := collectMessageTemplates(file)

	require.Len(t, templates, 2, "both the var-decl map and the init-body map are collected")

	ident := templates["CodeConfigInvalid"]
	assert.Equal(t, "The configuration is invalid.", ident.What)
	assert.Equal(t, "A value is missing or malformed.", ident.Why)
	assert.Equal(t, "Check the highlighted field.", ident.Fix)
	assert.Equal(t, "Run with --help.", ident.WayOut)

	literal := templates["literal.code"]
	assert.Equal(t, "Literal keyed.", literal.What)
	assert.Equal(t, "Literal fix.", literal.Fix)
	assert.Empty(t, literal.Why, "unset fields stay empty")
}

func TestCollectMessageTemplates_None(t *testing.T) {
	file := parseTemplateFixture(t, "package demo\n\nvar m = map[string]string{\"a\": \"b\"}\n")

	assert.Nil(t, collectMessageTemplates(file))
}

// TestCollectMessageTemplates_ErrauditOwnTemplates is the T7.2 dogfood proof
// (plan M92): the extractor reads erraudit's OWN pkg/errors/templates.go —
// the canonical registration shape — and yields non-empty texts for every
// registered code.
func TestCollectMessageTemplates_ErrauditOwnTemplates(t *testing.T) {
	src, err := os.ReadFile("../../pkg/errors/templates.go")
	require.NoError(t, err, "erraudit's own templates.go is the canonical fixture")

	file := parseTemplateFixture(t, string(src))

	templates := collectMessageTemplates(file)
	require.NotEmpty(t, templates)
	assert.Greater(t, len(templates), 10, "erraudit registers a full code taxonomy")

	for code, texts := range templates {
		assert.NotEmpty(t, texts.What, "code %s must register a What text", code)
		assert.NotEmpty(t, texts.Why, "code %s must register a Why text", code)
		assert.NotEmpty(t, texts.Fix, "code %s must register a Fix text", code)
		assert.NotEmpty(t, texts.WayOut, "code %s must register a WayOut text", code)
	}

	config, ok := templates["CodeConfigInvalid"]
	require.True(t, ok, "the identifier key keeps its name as written")
	assert.Equal(t, "The configuration is invalid.", config.What)

	var empty types.TemplateTexts
	for _, texts := range templates {
		assert.NotEqual(t, empty, texts)
	}
}
