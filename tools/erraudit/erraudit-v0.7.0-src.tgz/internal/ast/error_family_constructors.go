package ast

import (
	"go/ast"
	"go/token"
	"strings"

	"github.com/larsartmann/erraudit/pkg/types"
)

// errorFamilyPackageName is the canonical Go package name used by
// github.com/larsartmann/go-error-family. Users may alias it (e.g.
// `ef`), which is handled by the familySpecific flag below.
const errorFamilyPackageName = "errorfamily"

// Message argument indices for go-error-family constructor signatures.
const (
	msgIdxFamilyNew   = 1 // family-specific New*: (code, message)
	msgIdxGenericNew  = 2 // generic New/Newf: (code, data, message)
	msgIdxFamilyWrap  = 2 // family-specific Wrap*: (err, code, message)
	msgIdxGenericWrap = 3 // generic Wrap/Wrapf: (err, code, data, message)
)

// errorFamilyConstructor describes how to classify and extract information
// from a specific go-error-family constructor call.
type errorFamilyConstructor struct {
	kind           types.ErrorKind // ErrorKindFamilyNew or ErrorKindFamilyWrap
	isWrap         bool            // true for Wrap* variants (wrapped error is args[0])
	messageIndex   int             // 0-based index of the message/format-string argument
	familySpecific bool            // true for family-named constructors (unique method names)
	family         string          // family name for family-specific constructors ("" for generic)
}

// codeIndex returns the 0-based index of the code argument. Every
// errorfamily signature places the code immediately before the message
// (New* family: code, message; New generic: code, data, message;
// Wrap* family: err, code, message; Wrap generic: err, code, data,
// message), so the code index is uniformly messageIndex-1.
func (c errorFamilyConstructor) codeIndex() int {
	return c.messageIndex - 1
}

// errorFamilyConstructors is the immutable registry of all go-error-family
// constructor method names. Family-specific constructors (NewRejection,
// WrapConflict, etc.) have unique names that exist only in go-error-family, so
// they are accepted regardless of the package selector — this handles import
// aliases such as ef.NewRejection(...). Generic constructors (New, Wrap,
// Wrapf, WrapOnce, WrapOncef) share names with other packages and therefore
// require the canonical "errorfamily" package name to avoid false positives.
//
//nolint:gochecknoglobals // immutable constructor registry
var errorFamilyConstructors = map[string]errorFamilyConstructor{
	methodNew:   {kind: types.ErrorKindFamilyNew, messageIndex: msgIdxGenericNew},
	"Newf":      {kind: types.ErrorKindFamilyNew, messageIndex: msgIdxGenericNew},
	methodWrap:  {kind: types.ErrorKindFamilyWrap, isWrap: true, messageIndex: msgIdxGenericWrap},
	methodWrapf: {kind: types.ErrorKindFamilyWrap, isWrap: true, messageIndex: msgIdxGenericWrap},
	"WrapOnce":  {kind: types.ErrorKindFamilyWrap, isWrap: true, messageIndex: msgIdxGenericWrap},
	"WrapOncef": {kind: types.ErrorKindFamilyWrap, isWrap: true, messageIndex: msgIdxGenericWrap},

	// Family-specific New* constructors
	"NewRejection": {
		kind:           types.ErrorKindFamilyNew,
		messageIndex:   msgIdxFamilyNew,
		familySpecific: true,
		family:         "rejection",
	},
	"NewConflict": {
		kind:           types.ErrorKindFamilyNew,
		messageIndex:   msgIdxFamilyNew,
		familySpecific: true,
		family:         "conflict",
	},
	"NewTransient": {
		kind:           types.ErrorKindFamilyNew,
		messageIndex:   msgIdxFamilyNew,
		familySpecific: true,
		family:         "transient",
	},
	"NewCorruption": {
		kind:           types.ErrorKindFamilyNew,
		messageIndex:   msgIdxFamilyNew,
		familySpecific: true,
		family:         "corruption",
	},
	"NewInfrastructure": {
		kind:           types.ErrorKindFamilyNew,
		messageIndex:   msgIdxFamilyNew,
		familySpecific: true,
		family:         "infrastructure",
	},
	"NewOrchestration": {
		kind:           types.ErrorKindFamilyNew,
		messageIndex:   msgIdxFamilyNew,
		familySpecific: true,
		family:         "orchestration",
	},

	// Family-specific Wrap* constructors
	"WrapRejection": {
		kind:           types.ErrorKindFamilyWrap,
		isWrap:         true,
		messageIndex:   msgIdxFamilyWrap,
		familySpecific: true,
		family:         "rejection",
	},
	"WrapConflict": {
		kind:           types.ErrorKindFamilyWrap,
		isWrap:         true,
		messageIndex:   msgIdxFamilyWrap,
		familySpecific: true,
		family:         "conflict",
	},
	"WrapTransient": {
		kind:           types.ErrorKindFamilyWrap,
		isWrap:         true,
		messageIndex:   msgIdxFamilyWrap,
		familySpecific: true,
		family:         "transient",
	},
	"WrapCorruption": {
		kind:           types.ErrorKindFamilyWrap,
		isWrap:         true,
		messageIndex:   msgIdxFamilyWrap,
		familySpecific: true,
		family:         "corruption",
	},
	"WrapInfrastructure": {
		kind:           types.ErrorKindFamilyWrap,
		isWrap:         true,
		messageIndex:   msgIdxFamilyWrap,
		familySpecific: true,
		family:         "infrastructure",
	},
	"WrapOrchestration": {
		kind:           types.ErrorKindFamilyWrap,
		isWrap:         true,
		messageIndex:   msgIdxFamilyWrap,
		familySpecific: true,
		family:         "orchestration",
	},

	// Family-specific formatted Wrap*f constructors
	"WrapRejectionf": {
		kind:           types.ErrorKindFamilyWrap,
		isWrap:         true,
		messageIndex:   msgIdxFamilyWrap,
		familySpecific: true,
	},
	"WrapConflictf": {
		kind:           types.ErrorKindFamilyWrap,
		isWrap:         true,
		messageIndex:   msgIdxFamilyWrap,
		familySpecific: true,
	},
	"WrapTransientf": {
		kind:           types.ErrorKindFamilyWrap,
		isWrap:         true,
		messageIndex:   msgIdxFamilyWrap,
		familySpecific: true,
	},
	"WrapCorruptionf": {
		kind:           types.ErrorKindFamilyWrap,
		isWrap:         true,
		messageIndex:   msgIdxFamilyWrap,
		familySpecific: true,
	},
	"WrapInfrastructuref": {
		kind:           types.ErrorKindFamilyWrap,
		isWrap:         true,
		messageIndex:   msgIdxFamilyWrap,
		familySpecific: true,
	},
	"WrapOrchestrationf": {
		kind:           types.ErrorKindFamilyWrap,
		isWrap:         true,
		messageIndex:   msgIdxFamilyWrap,
		familySpecific: true,
	},
}

// isErrorFamilyCall reports whether call is a go-error-family constructor
// invocation. Family-specific constructors match by method name alone (they
// are unique to go-error-family); generic constructors require the canonical
// package name to avoid false positives.
func isErrorFamilyCall(call *ast.CallExpr) bool {
	pkgName, methodName, ok := callSelector(call)
	if !ok {
		return false
	}

	info, found := errorFamilyConstructors[methodName]

	return found && (pkgName == errorFamilyPackageName || info.familySpecific)
}

// errorFamilyConstructorInfo looks up the constructor descriptor for the given
// method name and package selector. Returns the descriptor and true when the
// call is a recognized go-error-family constructor.
func errorFamilyConstructorInfo(pkgName, methodName string) (errorFamilyConstructor, bool) {
	info, found := errorFamilyConstructors[methodName]
	if !found {
		return errorFamilyConstructor{}, false
	}

	if pkgName != errorFamilyPackageName && !info.familySpecific {
		return errorFamilyConstructor{}, false
	}

	return info, true
}

// extractStringArg returns the unquoted string value of the argument at index,
// or "" when the argument is missing or not a string literal.
func extractStringArg(call *ast.CallExpr, index int) string {
	if index >= len(call.Args) {
		return ""
	}

	if lit, ok := call.Args[index].(*ast.BasicLit); ok && lit.Kind == token.STRING {
		return strings.Trim(lit.Value, `"`)
	}

	return ""
}

// extractCodeArg returns the error code argument at index: the unquoted
// literal value for string literals, the identifier name for code constants
// (Code* idents carry the taxonomy name even when the string value lives in
// a constant), or "" for anything else.
func extractCodeArg(call *ast.CallExpr, index int) string {
	if index >= len(call.Args) {
		return ""
	}

	switch arg := call.Args[index].(type) {
	case *ast.BasicLit:
		if arg.Kind == token.STRING {
			return strings.Trim(arg.Value, `"`)
		}
	case *ast.Ident:
		return arg.Name
	}

	return ""
}

// familyForCode derives the family from a dotted code ("config.invalid" ->
// "config") for generic constructors, whose family is not in the method
// name. Returns "" for undotted codes.
func familyForCode(code string) string {
	if dot := strings.IndexByte(code, '.'); dot > 0 {
		return code[:dot]
	}

	return ""
}

// extractFamilyArg returns the family argument for GENERIC constructors
// (errorfamily.New/Newf/Wrap/Wrapf): the signature is (family, code, message)
// / (err, family, code, message), so the family sits immediately before the
// code at index-1, typically as a selector (errorfamily.Rejection) or bare
// ident. Family-specific constructors encode the family in the method name
// (NewRejection) and pass no family argument — for them info.family is used
// and this helper is not called. The name is lowercased to match the
// family-specific family spelling ("rejection").
func extractFamilyArg(call *ast.CallExpr, index int) string {
	if index < 0 || index >= len(call.Args) {
		return ""
	}

	switch arg := call.Args[index].(type) {
	case *ast.Ident:
		return strings.ToLower(arg.Name)
	case *ast.SelectorExpr:
		return strings.ToLower(arg.Sel.Name)
	}

	return ""
}
