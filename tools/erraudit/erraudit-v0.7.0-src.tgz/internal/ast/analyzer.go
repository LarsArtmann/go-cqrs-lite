package ast

// Analyzer has been refactored into focused components:
// - metrics_calculator.go for calculateMetrics
// - hierarchy_builder.go for buildHierarchy
// - file_cache.go for file caching

import (
	"context"
	"fmt"
	"go/ast"
	"go/token"
	"path/filepath"
	"slices"
	"sort"
	"strings"

	"github.com/larsartmann/erraudit/pkg/types"
)

// Analyzer error messages.
const (
	msgErrorWrapping           = "Error wrapping with %w"
	msgErrorNotProperlyWrapped = "Error not properly wrapped (use %w instead of %v or %s)"
	suggestionErrorWrapping    = `Use apierrors.Wrap(err, "message") to preserve error chain`
	msgPanicOnError            = "Panic on error - errors should be returned, not panic'd"
	suggestionReturnError      = "Return the error instead of panicking"
	msgLogFatalOnError         = "log.Fatal on error - errors should be returned, not cause process termination"
	suggestionAvoidLogFatal    = "Return the error instead of calling log.Fatal"
)

// Analyzer performs AST-based error analysis.
// Sub-analyzers handle focused responsibilities:.
type Analyzer struct {
	fset          *token.FileSet
	errors        []types.ErrorInfo
	violations    []types.ErrorViolation
	namedErrors   []types.NamedError
	relationships []types.ErrorRelationship
	pkgName       string
	fileName      string
	metrics       types.ErrorMetrics
	funcNameStack []string        // Stack of function names for nested function tracking
	funcTypeStack []*ast.FuncType // Stack of enclosing function type signatures (FuncDecl + FuncLit)
	wrapDepth     uint            // Track current error wrapping depth
	scopeVars     []string        // Track error variables in package scope

	// File cache for code snippets
	fileCache *FileCache

	// Sub-analyzers for focused responsibilities
	namedErrorDiscoverer *NamedErrorDiscoverer
	relationshipTracker  *RelationshipTracker
	violationDetector    *ViolationDetector
	contextLossDetector  *ContextLossDetector

	// Type information for type-aware violation detection (may be nil)
	typeResolver *TypeResolver

	// noSuppress bypasses AST-level false-positive heuristics (signature-aware
	// blank-identifier check, presence-flag sibling check) so that all potential
	// violations are reported. Corresponds to the --no-suppress CLI flag.
	noSuppress bool

	// funcSigs maps function/method names to their return-type signatures,
	// collected from all *ast.FuncDecl nodes in the file before the main walk.
	// Used by the signature-aware blank-identifier check in default mode (no
	// type info) to suppress false positives on calls to same-file functions
	// whose return type at the blank position is provably not error.
	funcSigs map[string][][]ast.Expr

	// packageSigs maps function/method names to their return-type signatures,
	// pre-collected from ALL files in the package (not just the current file).
	// Populated via WithPackageSigs when analyzing files in a package context.
	// Enables cross-file signature resolution for the blank-identifier check,
	// eliminating false positives where a helper defined in file A is called
	// from file B and its return type is not error.
	packageSigs map[string][][]ast.Expr

	// errorDecls holds names of package-level error variables: provided
	// package-wide via WithPackageErrorDecls and extended in an Analyze
	// pre-pass with the current file's own declarations. Used to identify
	// inline references (fmt.Errorf %w operands, errors.Is targets) to named
	// errors, including forward references within the file.
	errorDecls map[string]bool

	// messageTemplates maps error code to its registered What/Why/Fix/WayOut
	// texts, collected in an Analyze pre-pass from MessageTemplate map
	// literals. Attached to the hierarchy for the errorflow export's
	// template-text columns.
	messageTemplates map[string]types.TemplateTexts

	// inlineCodes carries every go-error-family code minted in the analyzed
	// file (named or inline), collected in an Analyze pre-pass. Attached to
	// the hierarchy for the errorflow export's `codes` array.
	inlineCodes []types.InlineCode

	// usage accumulates inline (function-body) wrap and check reference
	// counts, surfaced in the hierarchy metrics after the walk.
	usage errorUsage

	// deferredClosures holds the position spans of function literals that are
	// the direct callee of a defer statement (`defer func(){...}()`).
	// Collected in a pre-pass; used by the blank-identifier check to exempt
	// explicit `_ = x.Close()` teardown inside deferred closures, where an
	// error cannot propagate to the caller.
	deferredClosures []posSpan

	// currentFile holds the *ast.File being analyzed, set in Analyze when the
	// root node is a file. Used by the blank-identifier check to verify that a
	// qualified callee's package name resolves to a stdlib import in this file
	// (a project package imported under a stdlib name must not match).
	currentFile *ast.File

	// enforceErrorFamily enables the opt-in policy that flags stdlib error
	// constructors (errors.New, fmt.Errorf, errors.Join) as violations.
	// Default: false — erraudit is neutral by default.
	enforceErrorFamily bool

	// enforceSamberOops enables the opt-in policy that flags stdlib error
	// constructors as violations when the project enforces samber/oops. Also
	// enables oops-specific anti-pattern detection (redundant nil guards).
	// Default: false — erraudit is neutral by default.
	enforceSamberOops bool

	// enforceGenericReturn enables the opt-in policy that flags functions
	// returning bare error interface instead of a specific error type.
	// Default: false — returning error is standard Go practice.
	enforceGenericReturn bool

	// enforceDeferredClose enables the opt-in policy that flags defer x.Close()
	// patterns where the Close return value is ignored. Default: false —
	// defer file.Close() is standard Go practice taught in every tutorial.
	enforceDeferredClose bool

	// enforceCodedErrors enables the opt-in policy that flags go-error-family
	// constructor calls with an empty ("") error code. Empty-code errors lose
	// their What/Why/Fix template at the CLI boundary. Default: false.
	enforceCodedErrors bool

	// ctx is the context threaded from the analysis entry point
	// (AnalyzePackage/AnalyzeFile). Used by hooks during violation detection
	// so that cancellation and trace data propagate correctly. Stored on the
	// struct because ast.Visitor.Visit cannot accept a context parameter.
	// Defaults to context.Background() when not set via WithCtx.
	ctx context.Context //nolint:containedctx // Visitor pattern prevents passing ctx as parameter
}

// AnalyzerOption is a functional option for configuring the Analyzer.
type AnalyzerOption func(*Analyzer)

// WithFileCache sets a shared file cache for the analyzer.
func WithFileCache(cache *FileCache) AnalyzerOption {
	return func(a *Analyzer) {
		a.fileCache = cache
	}
}

// WithTypeResolver sets the type resolver for type-aware violation detection.
func WithTypeResolver(resolver *TypeResolver) AnalyzerOption {
	return func(a *Analyzer) {
		a.typeResolver = resolver
	}
}

// WithNoSuppress bypasses AST-level false-positive heuristics so that all
// potential violations are reported. Corresponds to the --no-suppress CLI flag.
func WithNoSuppress(enabled bool) AnalyzerOption {
	return func(a *Analyzer) {
		a.noSuppress = enabled
	}
}

// WithPackageSigs provides pre-collected function signatures from all files
// in the package, enabling cross-file resolution for the blank-identifier
// check. When set, the analyzer merges these with same-file signatures so
// that calls to helpers defined in sibling files are correctly resolved.
func WithPackageSigs(sigs map[string][][]ast.Expr) AnalyzerOption {
	return func(a *Analyzer) {
		a.packageSigs = sigs
	}
}

// appendViolation adds a violation with deduplication.
// Skips if an identical violation (same Key) already exists.
func (a *Analyzer) appendViolation(violation types.ErrorViolation) {
	for _, existing := range a.violations {
		if existing.Key() == violation.Key() {
			return
		}
	}

	a.violations = append(a.violations, violation)
}

// WithCtx sets the context for the analyzer, threaded from the analysis
// entry point. Used by hooks during violation detection so that cancellation
// and trace data propagate correctly. When not provided, defaults to
// context.Background().
func WithCtx(ctx context.Context) AnalyzerOption {
	return func(a *Analyzer) {
		a.ctx = ctx
	}
}

// WithEnforceErrorFamily enables the opt-in policy that flags stdlib error
// constructors as violations. When false (default), erraudit is neutral and
// does not judge constructor choice.
func WithEnforceErrorFamily(enabled bool) AnalyzerOption {
	return func(a *Analyzer) {
		a.enforceErrorFamily = enabled
	}
}

// WithEnforceSamberOops enables the opt-in policy that flags stdlib error
// constructors as violations when the project enforces samber/oops. When
// enabled, also detects oops-specific anti-patterns such as redundant nil
// guards before oops.Wrap/Wrapf. Default: false — erraudit is neutral.
func WithEnforceSamberOops(enabled bool) AnalyzerOption {
	return func(a *Analyzer) {
		a.enforceSamberOops = enabled
	}
}

// WithEnforceGenericReturn enables the opt-in policy that flags functions
// returning bare error interface instead of a specific error type. Default:
// false — returning error is standard Go practice and the check has low
// confidence (0.60).
func WithEnforceGenericReturn(enabled bool) AnalyzerOption {
	return func(a *Analyzer) {
		a.enforceGenericReturn = enabled
	}
}

// WithEnforceDeferredClose enables the opt-in policy that flags
// defer x.Close() patterns where the Close return value is ignored.
// Default: false — defer file.Close() is standard Go practice.
func WithEnforceDeferredClose(enabled bool) AnalyzerOption {
	return func(a *Analyzer) {
		a.enforceDeferredClose = enabled
	}
}

// WithEnforceCodedErrors enables the opt-in policy that flags go-error-family
// constructor calls whose error-code argument is the empty string literal.
// Empty-code errors cannot resolve a What/Why/Fix template at the CLI
// boundary. Default: false — erraudit is neutral by default.
func WithEnforceCodedErrors(enabled bool) AnalyzerOption {
	return func(a *Analyzer) {
		a.enforceCodedErrors = enabled
	}
}

// WithPackageErrorDecls provides pre-collected package-level error variable
// names from all files in the package (CollectErrorDeclNames), enabling
// cross-file identification of inline references to named errors.
func WithPackageErrorDecls(names map[string]bool) AnalyzerOption {
	return func(a *Analyzer) {
		a.errorDecls = names
	}
}

// NewAnalyzer creates a new AST analyzer.
func NewAnalyzer(fset *token.FileSet, pkgName, fileName string, opts ...AnalyzerOption) *Analyzer {
	analyzer := &Analyzer{
		fset:          fset,
		pkgName:       pkgName,
		fileName:      filepath.Base(fileName),
		errors:        make([]types.ErrorInfo, 0),
		violations:    make([]types.ErrorViolation, 0),
		namedErrors:   make([]types.NamedError, 0),
		relationships: make([]types.ErrorRelationship, 0),
		metrics: types.ErrorMetrics{
			MostCommonErrors: make(map[string]uint),
			WrapDepth:        0,
		},
		funcNameStack: make([]string, 0),
		funcTypeStack: make([]*ast.FuncType, 0),
		wrapDepth:     0,
		scopeVars:     make([]string, 0),
		usage: errorUsage{
			inlineWrapSites:       0,
			typeCheckSites:        0,
			wrapSitesByError:      make(map[string]uint),
			checkSitesByError:     make(map[string]uint),
			selectorWrapSites:     make(map[string]uint),
			selectorCheckSites:    make(map[string]uint),
			wrapSiteRefs:          make(map[string][]types.ErrorSiteRef),
			checkSiteRefs:         make(map[string][]types.ErrorSiteRef),
			selectorWrapSiteRefs:  make(map[string][]types.ErrorSiteRef),
			selectorCheckSiteRefs: make(map[string][]types.ErrorSiteRef),
		},
		fileCache: NewFileCache(),
	}

	// Apply functional options
	for _, opt := range opts {
		opt(analyzer)
	}

	// Default context if not provided via options
	if analyzer.ctx == nil {
		analyzer.ctx = context.Background()
	}

	// Initialize sub-analyzers
	analyzer.namedErrorDiscoverer = NewNamedErrorDiscoverer(analyzer)
	analyzer.relationshipTracker = NewRelationshipTracker(analyzer)
	analyzer.violationDetector = NewViolationDetector(analyzer)
	analyzer.contextLossDetector = NewContextLossDetector(analyzer)

	return analyzer
}

// currentFuncName returns the current function name from the top of the stack.
func (a *Analyzer) currentFuncName() string {
	if len(a.funcNameStack) == 0 {
		return ""
	}

	return a.funcNameStack[len(a.funcNameStack)-1]
}

// isMustFunction reports whether name follows a Must-panic convention. By Go
// convention, such functions intentionally panic on error — the name is the
// contract. Recognized patterns:
//   - "Must" exactly (the canonical helper, e.g. template.Must)
//   - "Must" + uppercase/digit (MustNewID, Must0)
//   - "must" + uppercase (mustParseID — unexported helper backing Must*)
//   - Name ending in "Must" (NewDateMust, NewWallTimeMust)

const mustPrefixLen = len("Must")

func isMustFunction(name string) bool {
	// "Must" or "must" exactly (template.Must, generic must[T])
	if name == "Must" || name == "must" {
		return true
	}

	if len(name) <= mustPrefixLen {
		return false
	}

	// MustXxx or mustXxx (capital or lowercase Must prefix + uppercase/digit)
	if strings.HasPrefix(name, "Must") || strings.HasPrefix(name, "must") {
		c := name[4]
		if c >= 'A' && c <= 'Z' || c >= '0' && c <= '9' {
			return true
		}
	}

	// A name ending in Must is the same convention (NewDateMust, NewWallTimeMust)
	return strings.HasSuffix(name, "Must")
}

// currentFuncType returns the innermost enclosing *ast.FuncType, or nil. Both
// top-level function declarations (*ast.FuncDecl) and function literals
// (*ast.FuncLit, e.g. deferred or goroutine closures) are pushed, so callers
// querying a return signature get the nearest scope — a `defer func(){...}()`
// or `go func(){...}()` reports the closure's own signature, not the outer
// function's. Used to decide whether an error return exists before classifying
// a swallow as CRITICAL.
func (a *Analyzer) currentFuncType() *ast.FuncType {
	if len(a.funcTypeStack) == 0 {
		return nil
	}

	return a.funcTypeStack[len(a.funcTypeStack)-1]
}

// pushFuncName pushes a function name onto the stack.
func (a *Analyzer) pushFuncName(name string) {
	a.funcNameStack = append(a.funcNameStack, name)
}

// pushFuncType pushes the enclosing function type signature for return-signature
// queries. Called for both *ast.FuncDecl and *ast.FuncLit. Must be balanced with
// popFuncType when the walk exits the function/closure.
func (a *Analyzer) pushFuncType(ft *ast.FuncType) {
	a.funcTypeStack = append(a.funcTypeStack, ft)
}

// popFuncName pops a function name from the stack.
func (a *Analyzer) popFuncName() {
	if len(a.funcNameStack) > 0 {
		a.funcNameStack = a.funcNameStack[:len(a.funcNameStack)-1]
	}
}

// popFuncType pops the innermost function type signature from the stack.
func (a *Analyzer) popFuncType() {
	if len(a.funcTypeStack) > 0 {
		a.funcTypeStack = a.funcTypeStack[:len(a.funcTypeStack)-1]
	}
}

// collectFuncSigs pre-scans the AST for all function and method declarations,
// building a map from function/method name to their return-type signatures.
// This enables the signature-aware blank-identifier check in default mode (no
// type info): when a call's callee is declared in the same file and its return
// type at the blank position is provably not error, the false positive is
// suppressed without needing go/types. Package-level sigs (from sibling files)
// are merged in so that cross-file calls are also resolved.
func (a *Analyzer) collectFuncSigs(node ast.Node) {
	a.funcSigs = make(map[string][][]ast.Expr)
	collectFuncSigsFromFile(node, a.funcSigs)

	for name, sigs := range a.packageSigs {
		a.funcSigs[name] = append(a.funcSigs[name], sigs...)
	}
}

// CollectFuncSigs builds a map of function/method names to their return-type
// signatures from all FuncDecl nodes across the given files. Used by
// package-level callers to provide cross-file signature resolution via
// WithPackageSigs, so that calls to helpers defined in sibling files are
// correctly resolved by the blank-identifier check.
func CollectFuncSigs(files []*ast.File) map[string][][]ast.Expr {
	sigs := make(map[string][][]ast.Expr)

	for _, file := range files {
		collectFuncSigsFromFile(file, sigs)
	}

	return sigs
}

func collectFuncSigsFromFile(node ast.Node, sigs map[string][][]ast.Expr) {
	ast.Inspect(node, func(n ast.Node) bool {
		fn, ok := n.(*ast.FuncDecl)
		if !ok || fn.Type == nil || fn.Type.Results == nil {
			return true
		}

		retTypes := extractReturnTypes(fn.Type.Results.List)
		if len(retTypes) > 0 {
			sigs[fn.Name.Name] = append(sigs[fn.Name.Name], retTypes)
		}

		return true
	})
}

// extractReturnTypes flattens an AST FieldList (function return parameters)
// into a positional slice of type expressions. Handles multi-name fields
// (e.g., "a, b int" → [int, int]) and anonymous fields (e.g., "int" → [int]).
func extractReturnTypes(fields []*ast.Field) []ast.Expr {
	var types []ast.Expr

	for _, field := range fields {
		count := len(field.Names)
		if count == 0 {
			count = 1
		}

		for range count {
			types = append(types, field.Type)
		}
	}

	return types
}

// calleeReturnsNonError reports whether all same-file function/method
// declarations named name have a non-error return type at the given index.
// Returns false when the name is unknown or any variant's return type at index
// looks like it could be an error — conservative (don't suppress) on ambiguity.
func (a *Analyzer) calleeReturnsNonError(name string, index int) bool {
	sigs, ok := a.funcSigs[name]
	if !ok || len(sigs) == 0 {
		return false
	}

	checked := false

	for _, retTypes := range sigs {
		if index >= len(retTypes) {
			continue
		}

		checked = true

		if returnTypeLooksLikeError(retTypes[index]) {
			return false
		}
	}

	return checked
}

// posSpan is an inclusive token position range [start, end].
type posSpan struct {
	start token.Pos
	end   token.Pos
}

// collectDeferredClosureSpans records the position spans of function literals
// that are the direct callee of a defer statement (`defer func(){...}()`).
// Nested closures inside such bodies are not collected as deferred, but nested
// defer statements within them are (ast.Inspect visits the whole subtree),
// so `defer func(){ defer func(){...}() }()` records both inner spans.
//
// Span membership is positional, so a synchronous callback DEFINED inside a
// deferred closure inherits the Close exemption. That is pinned, intentional
// behavior (2026-09-22): the enclosing deferred closure cannot return an
// error, so any Close discard in its subtree — including callbacks it invokes
// synchronously — is teardown by design, and `_ = x.Close()` is the only
// spelling golangci's errcheck also accepts there. Pinned by
// TestFeedback20260904_Ignored_DeferredClosureNestedSyncCallback_InheritsExempt.
func collectDeferredClosureSpans(node ast.Node) []posSpan {
	var spans []posSpan

	ast.Inspect(node, func(n ast.Node) bool {
		deferStmt, ok := n.(*ast.DeferStmt)
		if !ok {
			return true
		}

		fnLit, ok := deferStmt.Call.Fun.(*ast.FuncLit)
		if !ok {
			return true
		}

		spans = append(spans, posSpan{start: fnLit.Pos(), end: fnLit.End()})

		return true
	})

	return spans
}

// insideDeferredClosure reports whether pos falls within a function literal
// that is the direct callee of a defer statement.
func (a *Analyzer) insideDeferredClosure(pos token.Pos) bool {
	return slices.ContainsFunc(a.deferredClosures, func(s posSpan) bool {
		return pos >= s.start && pos <= s.end
	})
}

// Analyze analyzes the given AST node.
func (a *Analyzer) Analyze(node ast.Node) *types.ErrorGraph {
	// Remember the file root so heuristics can consult its imports (e.g. the
	// stdlib-qualified-callee check in the blank-identifier path).
	if file, ok := node.(*ast.File); ok {
		a.currentFile = file
	}

	// Pre-pass: collect same-file function signatures for the signature-aware
	// blank-identifier check in default mode.
	a.collectFuncSigs(node)

	// Pre-pass: collect the file's own package-level error declarations so
	// inline references to them are recognized regardless of declaration
	// order within the file.
	a.mergeErrorDecls(collectErrorDecls(node))

	// Pre-pass: collect MessageTemplate registrations (What/Why/Fix/WayOut
	// texts keyed by error code) for the errorflow export's template columns.
	a.mergeMessageTemplates(collectMessageTemplates(node))

	// Pre-pass: collect every go-error-family code minted in this file
	// (named or inline) for the errorflow export's `codes` array.
	a.inlineCodes = append(a.inlineCodes, collectInlineCodes(node, a.fset)...)

	// Pre-pass: collect deferred closure spans for the deferred-teardown
	// exemption in the blank-identifier check.
	a.deferredClosures = collectDeferredClosureSpans(node)

	// Single AST walk - Visit method handles both named error discovery and violation detection
	ast.Walk(a, node)

	// Context-loss detection runs as a separate pass after the main walk.
	// It needs the full function body (params + locals + returns) which is
	// more naturally collected in a dedicated traversal.
	a.contextLossDetector.Detect(node)

	// Opt-in enforcement: flag stdlib constructors when a target library is
	// enforced. Policies are ordered oops-first so that if both flags are on,
	// oops suggestions take priority (it is the more specific target).
	var policies []enforcePolicy

	if a.enforceSamberOops {
		policies = append(policies, oopsEnforcePolicy)
	}

	if a.enforceErrorFamily {
		policies = append(policies, errorFamilyEnforcePolicy)
	}

	if len(policies) > 0 {
		detectEnforcedStdlib(a, node, policies)
	}

	// Oops-specific anti-pattern detection (runs only under --enforce-samber-oops).
	if a.enforceSamberOops {
		detectOopsRedundantGuard(a, node)
		detectOopsMisusedW(a, node)
	}

	// Coded-errors detection (runs only under --enforce-coded-errors).
	if a.enforceCodedErrors {
		detectUncodedConstructors(a, node)
	}

	hierarchy := a.buildHierarchy()

	// Add code snippets to violations
	a.violationDetector.AddCodeSnippetsToViolations()

	graph := &types.ErrorGraph{
		Package:    a.pkgName,
		Errors:     a.errors,
		Violations: a.violations,
		Metrics:    a.calculateMetrics(),
		Hierarchy:  hierarchy,
	}

	return graph
}

// Visit implements the ast.Visitor interface.
func (a *Analyzer) Visit(node ast.Node) ast.Visitor {
	if node == nil {
		// Signal to check if we're exiting a FuncDecl by checking the stack
		// The pop is handled in a deferred manner after processing children
		return nil
	}

	// Track function entry and detect violations in a single pass
	switch n := node.(type) {
	case *ast.FuncDecl:
		// Push function onto stack for nested function support
		a.pushFuncName(n.Name.Name)
		a.pushFuncType(n.Type)
		// Reset wrap depth for new function
		a.wrapDepth = 0
		// Detect function-level violations
		a.violationDetector.DetectViolationsInFunction(n)
		// Use a wrapper visitor that pops on exit
		return &funcExitVisitor{analyzer: a, popName: true}
	case *ast.FuncLit:
		// A function literal (deferred closure or goroutine, or an inline
		// callback) is its own scope with its own return signature. Push its
		// type so return-signature queries (e.g. no-error-return downgrade)
		// resolve to the closure, not the enclosing function. It has no name.
		a.pushFuncType(n.Type)
		a.wrapDepth = 0

		return &funcExitVisitor{analyzer: a, popName: false}
	case *ast.GenDecl:
		// Analyze var/const declarations for named errors
		a.namedErrorDiscoverer.DiscoverNamedErrors(n)
	case *ast.CallExpr:
		a.trackErrorUsage(n)
		a.violationDetector.DetectViolationsInCallExpr(n)
	case *ast.ReturnStmt:
		a.violationDetector.DetectViolationsInReturnStmt(n)
	case *ast.AssignStmt:
		a.violationDetector.DetectViolationsInAssignStmt(n)
	case *ast.IfStmt:
		a.violationDetector.DetectViolationsInIfStmt(n)
	case *ast.DeferStmt:
		if a.enforceDeferredClose {
			a.violationDetector.DetectDeferredClose(n)
		}
	}

	return a
}

// funcExitVisitor wraps the analyzer to pop function scope on exit. popName
// controls whether the function-name stack is also popped (true for *ast.FuncDecl,
// false for *ast.FuncLit, which pushes only the type signature).
type funcExitVisitor struct {
	analyzer *Analyzer
	popName  bool
}

func (v *funcExitVisitor) Visit(node ast.Node) ast.Visitor {
	if node == nil {
		v.analyzer.popFuncType()

		if v.popName {
			v.analyzer.popFuncName()
		}

		return nil
	}

	return v.analyzer.Visit(node)
}

// analyzeErrorf analyzes an fmt.Errorf call.
func (a *Analyzer) analyzeErrorf(call *ast.CallExpr) {
	if len(call.Args) < minErrorfArgs {
		return
	}

	formatValue, ok := formatStringLiteral(call)
	if !ok {
		return
	}

	if strings.Contains(formatValue, "%w") {
		a.trackWrappingFormat(call, formatValue)
	} else if strings.Contains(formatValue, "%v") || strings.Contains(formatValue, "%s") {
		a.checkUnwrappedErrorf(call)
	}
}

// trackWrappingFormat records wrap-depth metrics and a wrapping violation.
func (a *Analyzer) trackWrappingFormat(call *ast.CallExpr, formatValue string) {
	wrapCount := strings.Count(formatValue, "%w")
	a.wrapDepth += uint(wrapCount)

	if a.wrapDepth > a.metrics.WrapDepth {
		a.metrics.WrapDepth = a.wrapDepth
	}

	a.addErrorInfoWithVars(
		call.Pos(),
		types.ErrorTypeWrapping,
		msgErrorWrapping,
		a.getContainingFunctionName(call),
		[]string{fmt.Sprintf("wrap_depth=%d", a.wrapDepth)},
	)
}

// checkUnwrappedErrorf flags fmt.Errorf with %v/%s instead of %w when the arg looks like an error.
func (a *Analyzer) checkUnwrappedErrorf(call *ast.CallExpr) {
	ident, ok := call.Args[1].(*ast.Ident)
	if !ok {
		return
	}

	if ident.Name != errorIdentifierSubstr && !strings.Contains(ident.Name, errorIdentifierSubstr) {
		return
	}

	a.violationDetector.addViolation(
		types.ErrorTypeUnwrapped,
		types.SeverityMedium,
		msgErrorNotProperlyWrapped,
		suggestionErrorWrapping,
		call,
		ident.Name,
	)
}

// analyzePanic analyzes a panic call.
func (a *Analyzer) analyzePanic(call *ast.CallExpr) {
	if a.shouldSkipTerminationCheck() {
		return
	}

	a.addErrorTerminationViolation(call, msgPanicOnError, suggestionReturnError)
}

// analyzeLogFatal analyzes a log.Fatal call.
func (a *Analyzer) analyzeLogFatal(call *ast.CallExpr) {
	if a.shouldSkipTerminationCheck() {
		return
	}

	a.addErrorTerminationViolation(call, msgLogFatalOnError, suggestionAvoidLogFatal)
}

// shouldSkipTerminationCheck reports whether panic/log.Fatal in the current
// function is acceptable by Go convention: MustXxx functions and the "must"
// package panic by design, and main() cannot return error.
func (a *Analyzer) shouldSkipTerminationCheck() bool {
	if isMustFunction(a.currentFuncName()) || a.pkgName == "must" {
		return true
	}

	return a.currentFuncName() == "main"
}

// addErrorTerminationViolation adds a violation for error termination (panic/fatal).
func (a *Analyzer) addErrorTerminationViolation(call *ast.CallExpr, message, suggestion string) {
	if len(call.Args) > 0 {
		if a.isErrorIdentifier(call.Args[0]) {
			a.violationDetector.addViolation(
				types.ErrorTypePanic,
				types.SeverityHigh,
				message,
				suggestion,
				call,
				identName(call.Args[0]),
			)
		}
	}
}

// trackScopeVar tracks a variable in the current scope.
func (a *Analyzer) trackScopeVar(name string) {
	// For package-level tracking, track error variables
	a.scopeVars = append(a.scopeVars, name)
}

// isErrorInScope checks if an error name is in scope.
func (a *Analyzer) isErrorInScope(name string) bool {
	return slices.Contains(a.scopeVars, name)
}

// isErrorDefinition checks if a name is a known error definition.
func (a *Analyzer) isErrorDefinition(name string) bool {
	for _, err := range a.namedErrors {
		if err.Name == name {
			return true
		}
	}

	return false
}

// cacheFile reads and caches a file's contents.
func (a *Analyzer) cacheFile(filename string) ([]string, error) {
	return a.fileCache.Load(filename)
}

// addErrorInfoWithVars creates and appends an error info record with the given parameters and vars.
func (a *Analyzer) addErrorInfoWithVars(
	pos token.Pos,
	errorType types.ErrorType,
	message, functionName string,
	vars []string,
) {
	a.errors = append(
		a.errors,
		createErrorInfoWithVars(
			a.fset,
			pos,
			errorType,
			message,
			functionName,
			a.pkgName,
			a.fileName,
			vars,
		),
	)
}

// buildHierarchy constructs the error hierarchy from discovered errors.
// The RelationshipTracker provides three capabilities that production
// previously bypassed: cycle removal (safety), deduplication (cleanliness),
// and graph-correct depth computation (accuracy).
func (a *Analyzer) buildHierarchy() *types.ErrorHierarchy {
	a.relationshipTracker.RemoveCyclicRelationships()
	a.relationshipTracker.ConsolidateDuplicateRelationships()

	builder := NewHierarchyBuilder(a.namedErrors, a.relationships)
	hierarchy := builder.Build()

	hierarchy.Metrics.InlineWrapSites = a.usage.inlineWrapSites
	hierarchy.Metrics.TypeCheckSites = a.usage.typeCheckSites
	hierarchy.Metrics.WrapSitesByError = a.usage.wrapSitesByError
	hierarchy.Metrics.CheckSitesByError = a.usage.checkSitesByError
	hierarchy.Metrics.SelectorWrapSites = a.usage.selectorWrapSites
	hierarchy.Metrics.SelectorCheckSites = a.usage.selectorCheckSites
	hierarchy.Metrics.WrapSiteRefs = a.usage.wrapSiteRefs
	hierarchy.Metrics.CheckSiteRefs = a.usage.checkSiteRefs
	hierarchy.Metrics.SelectorWrapSiteRefs = a.usage.selectorWrapSiteRefs
	hierarchy.Metrics.SelectorCheckSiteRefs = a.usage.selectorCheckSiteRefs
	hierarchy.MessageTemplates = a.messageTemplates
	hierarchy.InlineCodes = a.inlineCodes
	applyNodeReferenceCounts(hierarchy)

	a.enrichHierarchyDepths(hierarchy)
	a.enrichHierarchySummary(hierarchy)

	return hierarchy
}

// enrichHierarchyDepths overrides node depths and MaxDepth with
// graph-correct values computed by the RelationshipTracker. The builder
// uses rel.Depth (set at AST-traversal time from the wrapDepth counter,
// which reflects traversal order, not hierarchy position). The tracker
// walks the actual parent chain to compute true graph-theoretic depth.
//
// Node names are iterated in sorted order so that DeepestError tie-breaking
// is deterministic (lexicographically smallest name wins).
func (a *Analyzer) enrichHierarchyDepths(h *types.ErrorHierarchy) {
	names := make([]string, 0, len(h.AllNodes))
	for name := range h.AllNodes {
		names = append(names, name)
	}

	sort.Strings(names)

	var maxDepth uint

	var deepestError string

	for _, name := range names {
		depth := a.relationshipTracker.GetRelationshipDepth(name)
		h.AllNodes[name].Depth = depth

		if depth > maxDepth {
			maxDepth = depth
			deepestError = name
		}
	}

	h.Metrics.MaxDepth = maxDepth

	if deepestError != "" {
		h.Metrics.DeepestError = deepestError
	}
}

// enrichHierarchySummary populates branching and chain metrics from the
// RelationshipTracker. These are graph properties (not summable across files);
// FinalizeHierarchy recomputes them after cross-file merging. Chain length
// and root are derived from the deterministic MaxDepth/DeepestError (set by
// enrichHierarchyDepths) rather than GetLongestChain, so per-file and merged
// paths agree on which chain is longest.
func (a *Analyzer) enrichHierarchySummary(h *types.ErrorHierarchy) {
	summary := a.relationshipTracker.GetHierarchySummary()
	h.Metrics.AvgBranchingFactor = summary.AvgBranchingFactor
	h.Metrics.MaxBranchingParent = summary.MaxBranchingParent
	h.Metrics.MaxBranchingCount = uint(summary.MaxBranchingCount)

	if h.Metrics.DeepestError != "" {
		chain := a.relationshipTracker.GetErrorChain(h.Metrics.DeepestError)

		h.Metrics.LongestChainLength = uint(len(chain))
		if len(chain) > 0 {
			h.Metrics.LongestChainRoot = chain[0]
		}
	}
}

func (a *Analyzer) calculateMetrics() types.ErrorMetrics {
	calculator := NewMetricsCalculator(a.errors, a.violations, a.metrics.WrapDepth)

	return calculator.Calculate()
}
