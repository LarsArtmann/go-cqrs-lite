package ast

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

// TestErrorFamily_CodeAndFamilyCapture verifies that the code and family
// arguments of go-error-family constructors are captured onto NamedError:
// the code as the literal value (or Code* identifier name), the family from
// the family-specific method name, the generic family argument, or the
// dotted-code prefix, in that precedence.
func TestErrorFamily_CodeAndFamilyCapture(t *testing.T) {
	code := `package main

import (
	"errors"
	"github.com/larsartmann/go-error-family"
)

var ErrSpecific = errorfamily.NewRejection("config.invalid", "invalid config")
var ErrConstCode = errorfamily.NewRejection(CodeConfigInvalid, "invalid config")
var ErrGeneric = errorfamily.New(errorfamily.Conflict, "CON_001", "conflict")
var ErrWrapped = errorfamily.WrapRejection(ErrSpecific, "config.wrap", "wrapped")
var ErrDottedGeneric = errorfamily.New(errorfamily.Rejection, "analysis.toolchain", "needs toolchain")
`
	a, _ := helperParseAndAnalyze(t, code)

	specific := findNamedError(t, a, "ErrSpecific")
	assert.Equal(t, "config.invalid", specific.Code, "family-specific New*: code is the literal at index 0")
	assert.Equal(t, "rejection", specific.Family, "family-specific New*: family from the method name")

	constCode := findNamedError(t, a, "ErrConstCode")
	assert.Equal(t, "CodeConfigInvalid", constCode.Code, "code constants capture the identifier name")
	assert.Equal(t, "rejection", constCode.Family)

	generic := findNamedError(t, a, "ErrGeneric")
	assert.Equal(t, "CON_001", generic.Code, "generic New: code is the literal at index 1")
	assert.Equal(t, "conflict", generic.Family, "generic New: family from the family ident at index 0")

	wrapped := findNamedError(t, a, "ErrWrapped")
	assert.Equal(t, "config.wrap", wrapped.Code, "family-specific Wrap*: code is the literal at index 1")
	assert.Equal(t, "rejection", wrapped.Family)
	assert.Equal(t, "ErrSpecific", wrapped.ParentName)

	dotted := findNamedError(t, a, "ErrDottedGeneric")
	assert.Equal(t, "analysis.toolchain", dotted.Code)
	assert.Equal(t, "rejection", dotted.Family, "generic family ident wins over the dotted-code prefix")
}
