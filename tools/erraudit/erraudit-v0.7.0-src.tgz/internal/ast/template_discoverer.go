package ast

import (
	"go/ast"
	"go/token"
	"strconv"

	"github.com/larsartmann/erraudit/pkg/types"
)

// collectMessageTemplates extracts go-error-family message-template
// registrations from a file: composite literals of the shape
//
//	map[string]errorfamily.MessageTemplate{
//	    CodeConfigInvalid: {What: "...", Why: "...", Fix: "...", WayOut: "..."},
//	    "literal.code":    {What: "...", ...},
//	}
//
// wherever they appear — init bodies, package-level var decls, or arguments
// to RegisterTemplates — because the map literal itself carries all data.
//
// Keys are taken AS WRITTEN: a string literal keeps its value, an identifier
// keeps its name. NamedError.Code records constructor code arguments the same
// way (literal value, else identifier name), so same-package Code* constants
// join without constant-value resolution. The selector qualifier is accepted
// regardless of import alias (errorfamily, ef, ...); only the MessageTemplate
// member name is matched.
func collectMessageTemplates(node ast.Node) map[string]types.TemplateTexts {
	var templates map[string]types.TemplateTexts

	ast.Inspect(node, func(n ast.Node) bool {
		lit, ok := n.(*ast.CompositeLit)
		if !ok {
			return true
		}

		mapType, ok := lit.Type.(*ast.MapType)
		if !ok || !isMessageTemplateSelector(mapType.Value) {
			return true
		}

		for _, elt := range lit.Elts {
			pair, ok := elt.(*ast.KeyValueExpr)
			if !ok {
				continue
			}

			key, ok := templateKey(pair.Key)
			if !ok {
				continue
			}

			value, ok := pair.Value.(*ast.CompositeLit)
			if !ok {
				continue
			}

			if templates == nil {
				templates = make(map[string]types.TemplateTexts)
			}

			templates[key] = templateTexts(value)
		}

		return true
	})

	return templates
}

// isMessageTemplateSelector reports whether expr is a X.MessageTemplate
// selector for any qualifier X.
func isMessageTemplateSelector(expr ast.Expr) bool {
	selector, ok := expr.(*ast.SelectorExpr)
	if !ok {
		return false
	}

	return selector.Sel != nil && selector.Sel.Name == "MessageTemplate"
}

// templateKey resolves a map key to its join key: string literals keep their
// (unquoted) value, identifiers keep their name. Other key shapes are not
// template registrations.
func templateKey(expr ast.Expr) (string, bool) {
	switch key := expr.(type) {
	case *ast.BasicLit:
		if key.Kind != token.STRING {
			return "", false
		}

		return stringLitText(key)
	case *ast.Ident:
		return key.Name, true
	default:
		return "", false
	}
}

// templateTexts reads the What/Why/Fix/WayOut fields of one MessageTemplate
// composite literal. Fields with non-literal values are left empty.
func templateTexts(lit *ast.CompositeLit) types.TemplateTexts {
	var texts types.TemplateTexts

	for _, elt := range lit.Elts {
		pair, ok := elt.(*ast.KeyValueExpr)
		if !ok {
			continue
		}

		field, ok := pair.Key.(*ast.Ident)
		if !ok {
			continue
		}

		value, ok := pair.Value.(*ast.BasicLit)
		if !ok || value.Kind != token.STRING {
			continue
		}

		text, ok := stringLitText(value)
		if !ok {
			continue
		}

		switch field.Name {
		case "What":
			texts.What = text
		case "Why":
			texts.Why = text
		case "Fix":
			texts.Fix = text
		case "WayOut":
			texts.WayOut = text
		}
	}

	return texts
}

// stringLitText unquotes a string literal. Malformed literals (invalid
// escapes) report false so callers skip the entry instead of joining on a
// quoted non-code key.
func stringLitText(lit *ast.BasicLit) (string, bool) {
	text, err := strconv.Unquote(lit.Value)
	if err != nil {
		return "", false
	}

	return text, true
}
