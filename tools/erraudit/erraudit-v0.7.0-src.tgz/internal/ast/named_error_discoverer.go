package ast

// NamedErrorDiscoverer discovers named error definitions (sentinels, errorf
// results, custom error types, and aliases) from var/const declarations.
// Custom error type detection uses AST pattern matching plus type-first
// resolution when go/types info is available (see extractCustomErrorTypeName).

import (
	"go/ast"
	"go/token"
	"strings"

	"github.com/larsartmann/erraudit/pkg/types"
)

// NamedErrorDiscoverer handles discovery of named error definitions.
type NamedErrorDiscoverer struct {
	analyzer *Analyzer
}

// NewNamedErrorDiscoverer creates a new named error discoverer.
func NewNamedErrorDiscoverer(analyzer *Analyzer) *NamedErrorDiscoverer {
	return &NamedErrorDiscoverer{
		analyzer: analyzer,
	}
}

// DiscoverNamedErrors analyzes a GenDecl for named error definitions.
func (d *NamedErrorDiscoverer) DiscoverNamedErrors(decl *ast.GenDecl) {
	if decl.Tok != token.VAR && decl.Tok != token.CONST {
		return
	}

	for _, spec := range decl.Specs {
		if s, ok := spec.(*ast.ValueSpec); ok {
			for i, name := range s.Names {
				if len(s.Values) > i {
					d.analyzeNamedError(name.Name, s.Values[i])
				}
			}
		}
	}
}

// analyzeNamedError analyzes if a value spec defines a named error.
func (d *NamedErrorDiscoverer) analyzeNamedError(name string, value ast.Expr) {
	valuePos := d.analyzer.fset.Position(value.Pos())

	if typeName := d.extractCustomErrorTypeName(value); typeName != "" {
		d.analyzer.namedErrors = append(d.analyzer.namedErrors, types.NamedError{
			Name:     name,
			Kind:     types.ErrorKindCustom,
			Message:  "",
			Position: valuePos,
			FileName: d.analyzer.fileName,
		})
		d.analyzer.trackScopeVar(name)

		return
	}

	if call, ok := value.(*ast.CallExpr); ok && d.tryCallConstructors(name, call, valuePos) {
		return
	}

	d.tryWrappedIdent(name, value, valuePos)
}

// tryCallConstructors dispatches a call expression through the known error
// constructor detectors in priority order. Returns true when a detector
// matched and the named error was recorded.
func (d *NamedErrorDiscoverer) tryCallConstructors(name string, call *ast.CallExpr, valuePos token.Position) bool {
	detectors := []func(string, *ast.CallExpr, token.Position) bool{
		d.tryErrorsNew,
		d.tryFmtErrorf,
		d.tryErrorsJoin,
		d.tryErrorFamily,
		d.tryOops,
	}

	for _, detect := range detectors {
		if detect(name, call, valuePos) {
			return true
		}
	}

	return false
}

// callSelector extracts the package and method names from a selector expression call.
func callSelector(call *ast.CallExpr) (string, string, bool) {
	sel, sOk := call.Fun.(*ast.SelectorExpr)
	if !sOk {
		return "", "", false
	}

	ident, iOk := sel.X.(*ast.Ident)
	if !iOk {
		return "", "", false
	}

	return ident.Name, sel.Sel.Name, true
}

// isCallTo reports whether call is a selector expression invoking pkg.method
// (e.g. errors.New, fmt.Errorf). The boolean is false when the call has no
// resolvable selector of that shape.
func isCallTo(call *ast.CallExpr, pkg, method string) bool {
	pkgName, methodName, ok := callSelector(call)

	return ok && pkgName == pkg && methodName == method
}

// recordNamedError appends the discovered named error and tracks it in scope.
// Used by tryErrorsNew and tryFmtErrorf after they've classified the call.
func (d *NamedErrorDiscoverer) recordNamedError(err types.NamedError, name string) {
	d.analyzer.namedErrors = append(d.analyzer.namedErrors, err)
	d.analyzer.trackScopeVar(name)
}

// firstOr returns the first element of names, or "" when empty. Used by the
// wrap/join detectors to pick the NamedError.ParentName (conventionally the
// first wrapped cause) without repeating the guard at every call site.
func firstOr(names []string) string {
	if len(names) > 0 {
		return names[0]
	}

	return ""
}

// tryErrorsNew detects errors.New() and records a sentinel named error.
func (d *NamedErrorDiscoverer) tryErrorsNew(name string, call *ast.CallExpr, valuePos token.Position) bool {
	if !isCallTo(call, "errors", "New") {
		return false
	}

	d.recordNamedError(types.NamedError{
		Name:     name,
		Kind:     types.ErrorKindSentinel,
		Message:  d.extractErrorMessage(call),
		Position: valuePos,
		FileName: d.analyzer.fileName,
	}, name)

	return true
}

// recordMultiWrap records a named error (kind/message) whose first wrapped
// cause becomes ParentName, then emits one wrapping relationship per entry in
// wrapped. Shared by the %w (fmt.Errorf) and errors.Join detectors so the
// record-then-relate tail stays in one place.
func (d *NamedErrorDiscoverer) recordMultiWrap(
	name string,
	kind types.ErrorKind,
	message string,
	wrapped []string,
	valuePos token.Position,
) bool {
	d.recordNamedError(types.NamedError{
		Name:       name,
		Kind:       kind,
		Message:    message,
		Position:   valuePos,
		FileName:   d.analyzer.fileName,
		ParentName: firstOr(wrapped),
	}, name)

	d.recordWrapRelationships(name, wrapped, valuePos)

	return true
}

// tryFmtErrorf detects fmt.Errorf() and records an errorf named error with a
// wrapping relationship for every %w verb in the format string. Multi-wrap
// calls such as apierrors.Wrap(errB, "%w", errA) therefore produce one
// relationship per wrapped error, keeping the branching metrics non-trivial.
func (d *NamedErrorDiscoverer) tryFmtErrorf(name string, call *ast.CallExpr, valuePos token.Position) bool {
	if !isCallTo(call, "fmt", "Errorf") {
		return false
	}

	return d.recordMultiWrap(
		name,
		types.ErrorKindErrorf,
		d.extractErrorMessage(call),
		d.findWrappedErrorNames(call),
		valuePos,
	)
}

// tryErrorsJoin detects errors.Join() and records a join named error with a
// wrapping relationship for every joined error. Because errors.Join aggregates
// multiple causes, this is the primary source of multi-child parents that make
// the branching metrics (AvgBranchingFactor, MaxBranchingParent) non-trivial.
func (d *NamedErrorDiscoverer) tryErrorsJoin(name string, call *ast.CallExpr, valuePos token.Position) bool {
	if !isCallTo(call, "errors", "Join") {
		return false
	}

	return d.recordMultiWrap(
		name,
		types.ErrorKindJoin,
		"",
		d.knownErrorNames(call.Args),
		valuePos,
	)
}

// tryErrorFamily detects go-error-family constructors (errorfamily.New,
// errorfamily.Wrap, NewRejection, WrapConflict, etc.) and records the named
// error. New* variants record a standalone node (ErrorKindFamilyNew); Wrap*
// variants additionally emit a wraps relationship targeting the first argument
// (the wrapped cause) via recordMultiWrap.
//
// Family-specific constructors (NewRejection, WrapConflict, etc.) have unique
// method names, so they are accepted regardless of the package selector to
// handle import aliases (ef.NewRejection, errfam.WrapConflict, etc.). Generic
// constructors (New, Wrap, Wrapf, WrapOnce, WrapOncef) require the canonical
// "errorfamily" package name to avoid false positives.
func (d *NamedErrorDiscoverer) tryErrorFamily(name string, call *ast.CallExpr, valuePos token.Position) bool {
	pkgName, methodName, ok := callSelector(call)
	if !ok {
		return false
	}

	info, found := errorFamilyConstructorInfo(pkgName, methodName)
	if !found {
		return false
	}

	message := extractStringArg(call, info.messageIndex)
	code := extractCodeArg(call, info.codeIndex())

	family := info.family
	if family == "" {
		family = extractFamilyArg(call, info.codeIndex()-1)
	}

	if family == "" {
		family = familyForCode(code)
	}

	if info.isWrap {
		return d.recordFamilyWrap(name, info.kind, message, d.wrappedFromFirstArg(call), valuePos, code, family)
	}

	d.recordNamedError(types.NamedError{
		Name:     name,
		Kind:     info.kind,
		Message:  message,
		Position: valuePos,
		FileName: d.analyzer.fileName,
		Code:     code,
		Family:   family,
	}, name)

	return true
}

// recordFamilyWrap is recordMultiWrap for go-error-family Wrap* constructors,
// additionally carrying the code and family captured from the call site.
func (d *NamedErrorDiscoverer) recordFamilyWrap(
	name string,
	kind types.ErrorKind,
	message string,
	wrapped []string,
	valuePos token.Position,
	code, family string,
) bool {
	d.recordNamedError(types.NamedError{
		Name:       name,
		Kind:       kind,
		Message:    message,
		Position:   valuePos,
		FileName:   d.analyzer.fileName,
		ParentName: firstOr(wrapped),
		Code:       code,
		Family:     family,
	}, name)

	d.recordWrapRelationships(name, wrapped, valuePos)

	return true
}

// wrappedFromFirstArg extracts the known error name from the first argument of
// a Wrap* call (the wrapped cause). Returns nil when the argument is not a
// known error identifier — the named error is still recorded but without a
// wraps relationship.
func (d *NamedErrorDiscoverer) wrappedFromFirstArg(call *ast.CallExpr) []string {
	if len(call.Args) == 0 {
		return nil
	}

	if name, ok := d.knownErrorName(call.Args[0]); ok {
		return []string{name}
	}

	return nil
}

// tryOops detects samber/oops constructors (oops.Errorf, oops.New, oops.Wrap,
// oops.Wrapf) and records the named error. Errorf/New record a standalone node
// (ErrorKindOopsErrorf); Wrap/Wrapf additionally emit a wraps relationship
// targeting the first argument via recordMultiWrap. Only the canonical "oops"
// package name is matched — aliased imports are not recognized (documented
// limitation in oops_constructors.go).
func (d *NamedErrorDiscoverer) tryOops(name string, call *ast.CallExpr, valuePos token.Position) bool {
	if !isOopsCall(call) {
		return false
	}

	_, method, _ := callSelector(call)

	// Wrap/Wrapf: wrapping constructors — first arg is the wrapped cause
	if isOopsWrapMethod(method) {
		return d.recordMultiWrap(
			name,
			types.ErrorKindOopsWrap,
			d.extractErrorMessage(call),
			d.wrappedFromFirstArg(call),
			valuePos,
		)
	}

	// Errorf/New: terminal constructors — no wrapping relationship
	if method == "Errorf" || method == "New" {
		d.recordNamedError(types.NamedError{
			Name:     name,
			Kind:     types.ErrorKindOopsErrorf,
			Message:  d.extractErrorMessage(call),
			Position: valuePos,
			FileName: d.analyzer.fileName,
		}, name)

		return true
	}

	return false
}

// tryWrappedIdent detects var ErrFoo = ErrBar aliasing.
func (d *NamedErrorDiscoverer) tryWrappedIdent(name string, value ast.Expr, valuePos token.Position) {
	ident, ok := value.(*ast.Ident)
	if !ok {
		return
	}

	if !d.analyzer.isErrorIdentifier(ident) || !d.analyzer.isErrorInScope(ident.Name) {
		return
	}

	d.analyzer.relationships = append(d.analyzer.relationships, types.ErrorRelationship{
		Parent:           name,
		Child:            ident.Name,
		RelationshipType: types.RelationshipTypeAliases,
		Depth:            d.analyzer.wrapDepth,
		Position:         valuePos,
	})
}

// extractErrorMessage extracts the error message from an error creation call.
func (d *NamedErrorDiscoverer) extractErrorMessage(call *ast.CallExpr) string {
	message, ok := formatStringLiteral(call)
	if !ok {
		return ""
	}

	return message
}

// findWrappedErrorNames returns the names of all errors wrapped by a
// fmt.Errorf call. When the format string is a string literal, %w verb
// positions are correlated to the matching arguments so that multi-wrap
// calls (e.g. apierrors.Wrap(errB, "%w", errA)) yield every wrapped error.
// When the format string is not a literal or uses explicit positional
// indexing, it falls back to scanning all arguments for known error names.
func (d *NamedErrorDiscoverer) findWrappedErrorNames(call *ast.CallExpr) []string {
	if len(call.Args) < minErrorfArgs {
		return nil
	}

	if formatValue, ok := formatStringLiteral(call); ok {
		if !strings.Contains(formatValue, "%w") {
			return nil
		}

		indices, reliable := wrapArgIndices(formatValue)
		if reliable {
			return d.namesAtIndices(call.Args[1:], indices)
		}
	}

	return d.knownErrorNames(call.Args[1:])
}

// knownErrorName returns the name of arg when it is a known error identifier.
func (d *NamedErrorDiscoverer) knownErrorName(arg ast.Expr) (string, bool) {
	ident, ok := arg.(*ast.Ident)
	if !ok {
		return "", false
	}

	if !d.analyzer.isErrorIdentifier(ident) || !d.isKnownErrorName(ident.Name) {
		return "", false
	}

	return ident.Name, true
}

// namesAtIndices returns the known error names at the given 0-based argument
// positions, skipping out-of-range, non-identifier, or unknown arguments.
func (d *NamedErrorDiscoverer) namesAtIndices(args []ast.Expr, indices []int) []string {
	var names []string

	for _, idx := range indices {
		if idx >= len(args) {
			continue
		}

		if name, ok := d.knownErrorName(args[idx]); ok {
			names = append(names, name)
		}
	}

	return names
}

// knownErrorNames returns every known error name among the given expressions,
// in order. Shared fallback for non-literal format strings and errors.Join.
func (d *NamedErrorDiscoverer) knownErrorNames(args []ast.Expr) []string {
	var names []string

	for _, arg := range args {
		if name, ok := d.knownErrorName(arg); ok {
			names = append(names, name)
		}
	}

	return names
}

// recordWrapRelationships appends a "wraps" relationship for each child name,
// all rooted at the given parent. Shared by tryFmtErrorf and tryErrorsJoin so
// that multi-wrap and join both feed the branching metrics identically.
func (d *NamedErrorDiscoverer) recordWrapRelationships(
	parent string,
	children []string,
	pos token.Position,
) {
	for _, child := range children {
		d.analyzer.relationships = append(
			d.analyzer.relationships,
			types.ErrorRelationship{
				Parent:           parent,
				Child:            child,
				RelationshipType: types.RelationshipTypeWraps,
				Depth:            d.analyzer.wrapDepth + 1,
				Position:         pos,
			},
		)
	}
}

// isKnownErrorName returns true if the name is recognized as a defined or sentinel error.
func (d *NamedErrorDiscoverer) isKnownErrorName(name string) bool {
	return d.analyzer.isErrorInScope(name) ||
		d.analyzer.isErrorDefinition(name) ||
		strings.HasPrefix(name, "Err") ||
		strings.HasPrefix(name, "err")
}

// typeNameFromExpr extracts a type name from an AST expression that
// represents a type reference. Handles bare identifiers (MyError) and
// selector expressions (pkg.MyError), returning just the type name
// component (the SelectorExpr.Sel.Name for qualified types).
func typeNameFromExpr(expr ast.Expr) string {
	switch t := expr.(type) {
	case *ast.Ident:
		return t.Name
	case *ast.SelectorExpr:
		return t.Sel.Name
	default:
		return ""
	}
}

// extractCustomErrorTypeName returns the type name if the expression creates a
// custom error type (e.g., &MyError{}, pkg.MyError{}, NotFoundError("msg")), or "" otherwise.
//
// Detection uses two complementary strategies:
//
//  1. AST pattern matching — extracts a type name from struct-literal and
//     constructor-call expressions. Now handles selector expressions
//     (pkg.MyError{}) in addition to bare identifiers.
//  2. Type-first resolution — when go/types info is available and no AST
//     pattern matched, the expression's resolved type is checked directly.
//     This catches cross-package types and constructor calls that the AST
//     patterns cannot recognize.
//
// When type information is available (type-aware mode), both strategies verify
// the type actually implements the error interface, eliminating false positives
// like `var ErrCount = Counter{}`. When the type checker couldn't resolve the
// expression's type (e.g., cross-package type from an unresolved import), the
// naming heuristic (suffix "Error"/"Err") is used as a graceful fallback rather
// than producing a false negative.
func (d *NamedErrorDiscoverer) extractCustomErrorTypeName(expr ast.Expr) string {
	var typeName string

	switch e := expr.(type) {
	case *ast.UnaryExpr:
		if e.Op != token.AND {
			return ""
		}

		if cl, ok := e.X.(*ast.CompositeLit); ok {
			typeName = typeNameFromExpr(cl.Type)
		}
	case *ast.CompositeLit:
		typeName = typeNameFromExpr(e.Type)
	case *ast.CallExpr:
		// Only match bare-identifier calls (MyError("msg")) as potential
		// custom error constructors here. Selector calls (pkg.MyError())
		// are handled by the type-first path below, which avoids
		// misclassifying errors.New/fmt.Errorf as custom error types.
		if ident, ok := e.Fun.(*ast.Ident); ok {
			typeName = ident.Name
		}
	}

	// When type info is available and an AST type name was extracted, verify
	// the expression's type actually implements the error interface. This
	// eliminates false positives where a type name ends in "Error"/"Err" but
	// doesn't implement error. When the type couldn't be resolved (e.g.,
	// cross-package type from an unresolved import), fall through to the
	// naming heuristic — a false positive is better than a false negative.
	if typeName != "" && d.typeResolverAvailable() {
		switch d.analyzer.typeResolver.ExprTypeErrorStatus(expr) {
		case ErrorTypeImplements:
			return typeName
		case ErrorTypeDoesNotImplement:
			return ""
		case ErrorTypeUnresolved:
			// Fall through to naming heuristic below.
		}
	}

	// Type-first detection: when type info is available but no AST pattern
	// matched (e.g., selector expressions like pkg.MyError{}, constructor
	// calls like pkg.NewValidationError()), resolve the type name directly
	// from go/types. This catches cross-package custom error types that the
	// AST-only patterns miss entirely.
	//
	// errors.New/fmt.Errorf/errors.Join and go-error-family constructors are
	// excluded here — they are handled by their dedicated try* methods later
	// in the analyzeNamedError pipeline.
	if typeName == "" && d.typeResolverAvailable() {
		return d.resolveTypeNameFromTypes(expr)
	}

	if typeName == "" {
		return ""
	}

	// Fallback: naming heuristic (type-aware mode disabled or type unresolved).
	if strings.HasSuffix(typeName, "Error") || strings.HasSuffix(typeName, "Err") {
		return typeName
	}

	return ""
}

// typeResolverAvailable returns true when the analyzer has a usable type resolver.
func (d *NamedErrorDiscoverer) typeResolverAvailable() bool {
	return d.analyzer.typeResolver != nil && d.analyzer.typeResolver.Available()
}

// resolveTypeNameFromTypes delegates to go/types to resolve the type name of
// an error-creating expression, skipping stdlib constructors that are handled
// by dedicated try* methods.
func (d *NamedErrorDiscoverer) resolveTypeNameFromTypes(expr ast.Expr) string {
	if call, ok := expr.(*ast.CallExpr); ok {
		if isCallTo(call, errorsPkg, methodNew) || isCallTo(call, fmtPkg, methodErrorf) ||
			isCallTo(call, errorsPkg, "Join") {
			return ""
		}

		if isErrorFamilyCall(call) {
			return ""
		}
	}

	return d.analyzer.typeResolver.NamedErrorTypeName(expr)
}
