package lsp

import (
	"go/parser"
	"go/token"
	"testing"
)

// TestServerDoesNotImportJSONV2 pins the third BuildFlow jsonv1tov2 recurrence
// (2026-09-22 revert): sourcegraph/go-lsp request/response structs carry
// v1-only semantics (omitEmpty capital-E tags, interface{} payloads) that
// strict encoding/json/v2 does not honor, so server.go must stay on
// encoding/json v1 even as the rest of the repo migrates. The guard asserts
// encoding/json is still imported so it cannot pass vacuously once the v2
// import is (wrongly) added.
func TestServerDoesNotImportJSONV2(t *testing.T) {
	fset := token.NewFileSet()

	file, err := parser.ParseFile(fset, "server.go", nil, parser.ImportsOnly)
	if err != nil {
		t.Fatalf("parse server.go: %v", err)
	}

	var hasV1, hasV2 bool

	for _, imp := range file.Imports {
		switch imp.Path.Value {
		case `"encoding/json"`:
			hasV1 = true
		case `"encoding/json/v2"`:
			hasV2 = true
		}
	}

	if hasV2 {
		t.Error(
			"server.go imports encoding/json/v2; go-lsp structs require v1 semantics — migrate only when the go-lsp dependency is replaced",
		)
	}

	if !hasV1 {
		t.Error(
			"server.go no longer imports encoding/json; the LSP protocol codec requires it, so the v2 guard above is vacuous",
		)
	}
}
