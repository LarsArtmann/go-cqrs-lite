package fix

import (
	"bytes"
	"go/token"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"github.com/aymanbagabas/go-udiff"
	apierrors "github.com/larsartmann/erraudit/pkg/errors"
	"github.com/samber/lo"
	"golang.org/x/tools/go/analysis"
)

const sourceFilePerm = 0o644

// FileChange represents a modification to a single file.
type FileChange struct {
	Path      string
	Original  []byte
	Modified  []byte
	EditCount int
}

// Changed reports whether the file was modified.
func (c FileChange) Changed() bool {
	return !bytes.Equal(c.Original, c.Modified)
}

// Diff returns a unified diff string for this change.
func (c FileChange) Diff() string {
	// filepath.Join cleans leading double slashes when the path is absolute.
	oldPath := filepath.Join("a", c.Path)
	newPath := filepath.Join("b", c.Path)

	return udiff.Unified(oldPath, newPath, string(c.Original), string(c.Modified))
}

// Applier applies suggested fixes to source files.
type Applier struct {
	noBackup bool
}

// NewApplier creates a new fix applier.
func NewApplier() *Applier {
	return &Applier{}
}

// WithNoBackup disables .orig backup creation before overwriting files.
func (a *Applier) WithNoBackup() *Applier {
	a.noBackup = true

	return a
}

// Apply computes file changes from fixes without writing to disk.
// File changes are returned in lexicographic path order for deterministic output.
func (*Applier) Apply(fixes []Fix) ([]FileChange, error) {
	byFile := groupByFile(fixes)

	paths := make([]string, 0, len(byFile))
	for path := range byFile {
		paths = append(paths, path)
	}

	sort.Strings(paths)

	changes := make([]FileChange, 0, len(paths))

	for _, path := range paths {
		original, err := os.ReadFile(path)
		if err != nil {
			return nil, apierrors.Wrap(
				err,
				"read %s",
				path,
			)
		}

		modified, editCount, err := applyFileFixes(original, byFile[path])
		if err != nil {
			return nil, apierrors.Wrap(
				err,
				"apply fixes to %s",
				path,
			)
		}

		changes = append(changes, FileChange{
			Path:      path,
			Original:  original,
			Modified:  modified,
			EditCount: editCount,
		})
	}

	return changes, nil
}

// Write applies changes to disk.
// If backup is enabled (the default), the original file is preserved as
// <path>.orig before overwriting.
func (a *Applier) Write(changes []FileChange) error {
	for _, c := range changes {
		if !c.Changed() {
			continue
		}

		if !a.noBackup {
			backupPath := c.Path + ".orig"
			if err := os.WriteFile(backupPath, c.Original, sourceFilePerm); err != nil {
				return apierrors.Wrap(err, "backup %s", backupPath)
			}
		}

		err := os.WriteFile(c.Path, c.Modified, sourceFilePerm)
		if err != nil {
			return apierrors.Wrap(err, "write %s", c.Path)
		}
	}

	return nil
}

// groupByFile groups fixes by their file path.
func groupByFile(fixes []Fix) map[string][]Fix {
	return lo.GroupBy(fixes, func(f Fix) string { return f.FilePath })
}

// applyFileFixes applies all fixes for a single file.
// It detects overlapping edits and returns an error instead of corrupting output.
func applyFileFixes(content []byte, fixes []Fix) ([]byte, int, error) {
	// Collect all text edits.
	type edit struct {
		start   int
		end     int
		newText []byte
	}

	edits := make([]edit, 0)

	for _, fix := range fixes {
		for _, te := range fix.TextEdits {
			start, end, err := posRange(fix.Fset, te)
			if err != nil {
				return nil, 0, err
			}

			edits = append(edits, edit{
				start:   start,
				end:     end,
				newText: te.NewText,
			})
		}
	}

	if len(edits) == 0 {
		return content, 0, nil
	}

	// Sort by start position descending so earlier edits don't shift later ones.
	sort.Slice(edits, func(i, j int) bool {
		if edits[i].start != edits[j].start {
			return edits[i].start > edits[j].start
		}

		return edits[i].end > edits[j].end
	})

	// Detect overlapping edits. Since the list is sorted descending by start,
	// each subsequent edit must end at or before the previous edit's start.
	for i := 1; i < len(edits); i++ {
		prev := edits[i-1]
		curr := edits[i]

		if curr.end > prev.start {
			return nil, 0, apierrors.New(
				"overlapping text edits detected at byte offsets [%d:%d] and [%d:%d]",
				curr.start, curr.end, prev.start, prev.end,
			)
		}
	}

	result := append(make([]byte, 0, len(content)), content...)

	for _, e := range edits {
		if e.start < 0 || e.end > len(result) || e.start > e.end {
			return nil, 0, apierrors.New(
				"invalid edit range [%d:%d] (file length %d)",
				e.start, e.end, len(result),
			)
		}

		result = append(result[:e.start], append(e.newText, result[e.end:]...)...)
	}

	return result, len(edits), nil
}

// posRange converts analysis.TextEdit positions to byte offsets.
func posRange(fset *token.FileSet, te analysis.TextEdit) (int, int, error) {
	startPos := fset.Position(te.Pos)
	if !startPos.IsValid() {
		return 0, 0, apierrors.New("invalid start position %v", te.Pos)
	}

	start := startPos.Offset

	var end int

	if te.End.IsValid() {
		endPos := fset.Position(te.End)
		if !endPos.IsValid() {
			return 0, 0, apierrors.New(
				"invalid end position %v",
				te.End,
			)
		}

		end = endPos.Offset
	} else {
		// Insertion point.
		end = start
	}

	return start, end, nil
}

// FormatDiff formats a slice of file changes as a unified diff string.
func FormatDiff(changes []FileChange) string {
	var b strings.Builder

	for _, c := range changes {
		if !c.Changed() {
			continue
		}

		diff := c.Diff()
		if diff != "" {
			b.WriteString(diff)
			b.WriteByte('\n')
		}
	}

	return b.String()
}
