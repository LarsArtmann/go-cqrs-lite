package converter

import (
	"go/token"
	"os"
	"path/filepath"
	"slices"
	"sort"
	"strconv"
	"strings"
	"sync"

	"github.com/dustin/go-humanize/english"
	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/larsartmann/go-output"
)

const anonymousErrorName = "<anonymous>"

// TreeSortMode selects how root errors are ordered in tree output. The
// values are the strings accepted by the tree subcommand's --sort flag.
type TreeSortMode string

// Tree sort modes. TreeSortAuto orders by reference centrality when the
// hierarchy has no declared relationships (so hub errors surface first in
// flat codebases) and keeps name order otherwise; TreeSortName keeps the
// hierarchy's root order (name-sorted by the finalizer); TreeSortWraps
// always orders by reference centrality.
const (
	TreeSortAuto  TreeSortMode = "auto"
	TreeSortName  TreeSortMode = "name"
	TreeSortWraps TreeSortMode = "wraps"
)

// IsValidTreeSortMode reports whether s is an accepted --sort value.
func IsValidTreeSortMode(s string) bool {
	switch TreeSortMode(s) {
	case TreeSortAuto, TreeSortName, TreeSortWraps:
		return true
	default:
		return false
	}
}

// displayName returns the node's name, defaulting to the anonymous sentinel
// when empty. Shared by all tree-label builders.
func displayName(node *types.ErrorNode) string {
	if node.Name == "" {
		return anonymousErrorName
	}

	return node.Name
}

// TreeOptions controls how ErrorHierarchy nodes are converted to TreeNode
// labels. The zero value produces labels with kind, position, occurrences,
// and violations (full detail), name order, no grouping, and no inline
// site children.
type TreeOptions struct {
	NoPosition bool // omit source position from labels
	NoKind     bool // omit error kind from labels
	MaxDepth   int  // stop recursing past this depth (0 = unlimited)

	ShowWrapSites  bool         // render inline wrap/check sites as children
	Sort           TreeSortMode // root ordering (zero value behaves as auto)
	GroupByPackage bool         // group roots under per-directory containers
	MaxSites       int          // cap site children per node in ASCII (0 = unlimited)
}

// renderGroup is one ordered section of tree output: an optional package
// directory header plus the root errors under it. Label is empty when
// grouping is off (or a single group makes a header pointless).
type renderGroup struct {
	Label string
	Nodes []*types.ErrorNode
}

// HierarchyToTreeNode converts an ErrorHierarchy into a go-output TreeNode
// suitable for rendering via the go-output/tree package. The root node is a
// synthetic container labeled with the package; each root error becomes a
// child, and wrapping relationships are preserved as nested children.
func HierarchyToTreeNode(pkg string, h *types.ErrorHierarchy, opts TreeOptions) *output.TreeNode {
	label := "Error Hierarchy"
	if pkg != "" {
		label += " (" + pkg + ")"
	}

	root := output.NewTreeNode("hierarchy", label)

	for _, group := range buildRenderGroups(h, opts) {
		parent := root
		if group.Label != "" {
			parent = output.NewTreeNode("group-"+group.Label, group.Label)

			root.AddChild(parent)
		}

		for _, node := range group.Nodes {
			parent.AddChild(errorNodeToTreeNode(h, node, opts, 1))
		}
	}

	return root
}

// buildRenderGroups returns the ordered render sections for a hierarchy:
// roots sorted per opts.Sort, optionally bucketed into per-directory
// containers when opts.GroupByPackage is set. Grouping is skipped when it
// would produce a single container (no information, extra indentation).
// Roots are sorted on a copy — h.RootErrors is shared cache state and is
// never mutated.
func buildRenderGroups(h *types.ErrorHierarchy, opts TreeOptions) []renderGroup {
	if h == nil {
		return nil
	}

	roots := sortRootsForRender(h.RootErrors, h, opts)

	if !opts.GroupByPackage {
		return []renderGroup{{Label: "", Nodes: roots}}
	}

	buckets := make(map[string][]*types.ErrorNode)

	var dirs []string

	for _, node := range roots {
		dir := filepath.ToSlash(filepath.Dir(displayPath(node.Position.Filename)))
		if _, seen := buckets[dir]; !seen {
			dirs = append(dirs, dir)
		}

		buckets[dir] = append(buckets[dir], node)
	}

	if len(dirs) <= 1 {
		return []renderGroup{{Label: "", Nodes: roots}}
	}

	sort.Strings(dirs)

	groups := make([]renderGroup, 0, len(dirs))
	for _, dir := range dirs {
		label := dir
		if dir == "." {
			label = "(root)"
		}

		groups = append(groups, renderGroup{
			Label: label + " (" + strconv.Itoa(len(buckets[dir])) + ")",
			Nodes: buckets[dir],
		})
	}

	return groups
}

// sortRootsForRender returns a sorted COPY of roots per the sort mode.
// TreeSortAuto resolves to centrality order when the hierarchy has no
// declared relationships and to the incoming (name) order otherwise.
// Centrality compares inline wrap counts, then errors.Is check counts, then
// name — all descending except the lexicographic tiebreak.
func sortRootsForRender(roots []*types.ErrorNode, h *types.ErrorHierarchy, opts TreeOptions) []*types.ErrorNode {
	sorted := slices.Clone(roots)

	mode := opts.Sort
	if mode == TreeSortAuto || mode == "" {
		if h.Metrics.TotalRelationships == 0 {
			mode = TreeSortWraps
		} else {
			mode = TreeSortName
		}
	}

	if mode != TreeSortWraps {
		return sorted
	}

	sort.SliceStable(sorted, func(a, b int) bool {
		if sorted[a].InlineWraps != sorted[b].InlineWraps {
			return sorted[a].InlineWraps > sorted[b].InlineWraps
		}

		if sorted[a].Checks != sorted[b].Checks {
			return sorted[a].Checks > sorted[b].Checks
		}

		return displayName(sorted[a]) < displayName(sorted[b])
	})

	return sorted
}

// errorNodeToTreeNode converts a single ErrorNode (and its descendants) into
// a go-output TreeNode. All display information (name, kind, position,
// occurrences, violations) is embedded in the label string so the rendered
// tree is fully self-describing regardless of metadata map ordering.
func errorNodeToTreeNode(h *types.ErrorHierarchy, node *types.ErrorNode, opts TreeOptions, depth int) *output.TreeNode {
	name := displayName(node)

	treeNode := output.NewTreeNode(name, errorNodeLabel(name, node, opts, declConnectedNames(h)))

	if opts.ShowWrapSites {
		for _, siteLabel := range siteChildLabels(h, node, opts, true) {
			treeNode.AddChild(output.NewTreeNode("site", siteLabel))
		}
	}

	if opts.MaxDepth > 0 && depth >= opts.MaxDepth {
		return treeNode
	}

	for _, child := range node.Children {
		treeNode.AddChild(errorNodeToTreeNode(h, child, opts, depth+1))
	}

	return treeNode
}

// errorNodeLabel builds the display label for an error node, appending kind,
// source position, occurrence count, and violation count when available and
// not suppressed by opts.
func errorNodeLabel(name string, node *types.ErrorNode, opts TreeOptions, declConnected map[string]bool) string {
	label := name

	if !opts.NoKind && node.Kind != "" {
		label += " [" + string(node.Kind) + "]"
	}

	if !opts.NoPosition {
		if pos := shortPosition(node.Position); pos != "" {
			label += " @" + pos
		}
	}

	if node.Occurrences > 1 {
		label += " (x" + strconv.FormatUint(uint64(node.Occurrences), 10) + ")"
	}

	if node.Violations > 0 {
		label += " [" + strconv.FormatUint(uint64(node.Violations), 10) + " violations]"
	}

	label += referenceAnnotation(node, declConnected[displayName(node)])

	return label
}

// referenceAnnotation renders the inline reference-site counts (wrap sites
// and errors.Is checks) as a " · " prefixed suffix segment. Nodes with zero
// inline references and no recorded usage anywhere — no declared
// relationship, no children — are annotated "unreferenced": the
// dead-sentinel candidate signal (hedged: identifier references within the
// analyzed scope; cross-package references resolve via selector
// attribution).
func referenceAnnotation(node *types.ErrorNode, declConnected bool) string {
	var parts []string

	if node.InlineWraps > 0 {
		parts = append(parts, pluralizeCount(uint64(node.InlineWraps), "inline wrap"))
	}

	if node.Checks > 0 {
		parts = append(parts, pluralizeCount(uint64(node.Checks), "check"))
	}

	if len(parts) == 0 {
		if !declConnected && len(node.Children) == 0 {
			return unreferencedAnnotation()
		}

		return ""
	}

	return " · " + strings.Join(parts, " · ")
}

// unreferencedAnnotation marks nodes without any recorded inline reference
// or declared wrapping.
func unreferencedAnnotation() string {
	return " · unreferenced"
}

// declConnectedNames collects every error name that appears in a declared
// relationship (as parent OR child) — such nodes are in use regardless of
// their inline reference counts.
func declConnectedNames(h *types.ErrorHierarchy) map[string]bool {
	connected := make(map[string]bool, 2*len(h.Relationships))
	for _, rel := range h.Relationships {
		connected[rel.Parent] = true
		connected[rel.Child] = true
	}

	return connected
}

// pluralizeCount renders "N name" or "1 name" without a plural suffix,
// via english.Plural so plural rules stay library-backed.
func pluralizeCount(count uint64, name string) string {
	return english.Plural(int(count), name, "")
}

// siteChildLabels renders the inline reference-site lines for one error
// node: wrap sites first, then check sites, each sorted by source position.
// When capped is false (Markdown output) every site is rendered; otherwise
// opts.MaxSites caps the list with a trailing "+K more" line. Empty when
// opts.ShowWrapSites is off or the error has no recorded references.
func siteChildLabels(h *types.ErrorHierarchy, node *types.ErrorNode, opts TreeOptions, capped bool) []string {
	if h == nil || !opts.ShowWrapSites {
		return nil
	}

	name := displayName(node)

	wraps := append([]types.ErrorSiteRef(nil), h.Metrics.WrapSiteRefs[name]...)
	checks := append([]types.ErrorSiteRef(nil), h.Metrics.CheckSiteRefs[name]...)

	if len(wraps) == 0 && len(checks) == 0 {
		return nil
	}

	sortSiteRefs(wraps)
	sortSiteRefs(checks)

	labels := make([]string, 0, len(wraps)+len(checks)+1)

	for _, ref := range wraps {
		labels = append(labels, siteLabel("wrapped", ref))
	}

	for _, ref := range checks {
		labels = append(labels, siteLabel("checked", ref))
	}

	if capped && opts.MaxSites > 0 && len(labels) > opts.MaxSites {
		kept := labels[:opts.MaxSites]
		kept = append(kept, "+"+strconv.Itoa(len(labels)-opts.MaxSites)+" more site(s)")

		return kept
	}

	return labels
}

// siteLabel renders one reference-site line: what happens, where, and in
// which function (when the site sits in a named function).
func siteLabel(verb string, ref types.ErrorSiteRef) string {
	label := verb + " @" + shortPosition(ref.Position)
	if ref.Function != "" {
		label += " " + ref.Function
	}

	return label
}

// sortSiteRefs orders reference sites by source position (file, line,
// column) so children render deterministically regardless of map and walk
// order.
func sortSiteRefs(refs []types.ErrorSiteRef) {
	sort.SliceStable(refs, func(i, j int) bool {
		a, b := refs[i].Position, refs[j].Position
		if a.Filename != b.Filename {
			return a.Filename < b.Filename
		}

		if a.Line != b.Line {
			return a.Line < b.Line
		}

		return a.Column < b.Column
	})
}

// shortPosition returns a compact "file:line" position string. Relative
// paths are shown as-is; absolute paths are made relative to the working
// directory so positions stay navigable and unambiguous in multi-package
// trees (internal/pbx/client.go:43 instead of an ambiguous client.go:43).
func shortPosition(pos token.Position) string {
	if pos.Filename == "" {
		return ""
	}

	file := displayPath(pos.Filename)
	if pos.Line > 0 {
		return file + ":" + strconv.Itoa(pos.Line)
	}

	return file
}

// workingDir resolves the process working directory once per render process;
// empty when it cannot be determined.
//
//nolint:gochecknoglobals // memoized cwd for relative position rendering
var workingDir = sync.OnceValue(func() string {
	dir, err := os.Getwd()
	if err != nil {
		return ""
	}

	return dir
})

// displayPath makes an absolute path relative to the working directory when
// it lives under it. Relative paths pass through unchanged; absolute paths
// outside the working directory fall back to their base name.
func displayPath(path string) string {
	if !filepath.IsAbs(path) {
		return path
	}

	cwd := workingDir()
	if cwd == "" {
		return filepath.Base(path)
	}

	rel, err := filepath.Rel(cwd, path)
	if err != nil || rel == ".." || strings.HasPrefix(rel, ".."+string(filepath.Separator)) {
		return filepath.Base(path)
	}

	return filepath.ToSlash(rel)
}
