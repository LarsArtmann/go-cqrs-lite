package finding

import (
	"go/token"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	finding "github.com/larsartmann/go-finding"
	findingsdk "github.com/larsartmann/go-finding"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestViolationToFinding_BasicFields(t *testing.T) {
	v := types.ErrorViolation{
		Position: token.Position{Filename: "main.go", Line: 42, Column: 5},
		Type:     types.ErrorTypeReturn,
		Severity: types.SeverityHigh,
		Message:  "returns error",
	}

	f, err := ViolationToFinding(v)
	require.NoError(t, err)

	assert.Equal(t, finding.RuleName("return"), f.Rule)
	assert.Equal(t, finding.ToolName("erraudit"), f.ToolName)
	assert.Equal(t, "returns error", f.Message)
	assert.Equal(t, finding.SeverityCritical, f.Severity)
	assert.Equal(t, finding.FilePath("main.go"), f.Position.File)
	assert.Equal(t, 42, f.Position.Line)
	assert.Equal(t, 5, f.Position.Column)
	assert.Equal(t, finding.CategoryErrorHandling, f.Category)
	assert.Contains(t, f.Tags, finding.Tag("return"))
	assert.True(t, f.IsValid())
}

func TestViolationToFinding_PanicMapsToCritical(t *testing.T) {
	v := types.MakeTestViolation("main.go", 42, types.ErrorTypePanic, types.SeverityHigh, "panic on error")

	f, err := ViolationToFinding(v)
	require.NoError(t, err)

	assert.Equal(t, finding.SeverityCritical, f.Severity)
}

func TestViolationToFinding_WithSuggestion(t *testing.T) {
	v := types.ErrorViolation{
		Position:   token.Position{Filename: "f.go", Line: 10, Column: 1},
		Type:       types.ErrorTypeGenericReturn,
		Severity:   types.SeverityMedium,
		Message:    "returns generic error",
		Suggestion: "Define a specific error type",
	}

	f, err := ViolationToFinding(v)
	require.NoError(t, err)

	assert.Equal(t, finding.FixStrategySuggest, f.FixStrategy)
	assert.Equal(t, "Define a specific error type", f.Suggestion)
	assert.True(t, f.HasSuggestion())
}

func TestViolationToFinding_WithCodeSnippet(t *testing.T) {
	v := types.ErrorViolation{
		Position:    token.Position{Filename: "f.go", Line: 10, Column: 1},
		Type:        types.ErrorTypePanic,
		Severity:    types.SeverityHigh,
		Message:     "panic found",
		CodeSnippet: "  9 \n> 10 panic(err)\n  11 }",
	}

	f, err := ViolationToFinding(v)
	require.NoError(t, err)

	assert.Contains(t, f.Snippet, "10 panic(err)")
	assert.NotContains(t, f.Snippet, "> 10")
}

func TestViolationToFinding_NoSuggestion(t *testing.T) {
	v := types.ErrorViolation{
		Position: token.Position{Filename: "f.go", Line: 1, Column: 1},
		Type:     types.ErrorTypeReturn,
		Severity: types.SeverityLow,
		Message:  "returns error",
	}

	f, err := ViolationToFinding(v)
	require.NoError(t, err)

	assert.Equal(t, finding.FixStrategyNone, f.FixStrategy)
	assert.False(t, f.HasFix())
}

func TestViolationToFinding_Metadata(t *testing.T) {
	v := types.ErrorViolation{
		Position: token.Position{Filename: "f.go", Line: 1, Column: 1},
		Type:     types.ErrorTypeLegacyAs,
		Severity: types.SeverityLow,
		Message:  "uses errors.As",
	}

	f, err := ViolationToFinding(v)
	require.NoError(t, err)

	assert.Equal(t, "legacy_as", f.Metadata["erraudit/error-type"])
	assert.Equal(t, "warning", f.Metadata["erraudit/severity"])
}

func TestViolationToFinding_UsesPositionFilename(t *testing.T) {
	v := types.MakeTestViolation("pos.go", 1, types.ErrorTypePanic, types.SeverityHigh, "test")

	f, err := ViolationToFinding(v)
	require.NoError(t, err)

	assert.Equal(t, finding.FilePath("pos.go"), f.Position.File)
}

func TestSeverityMapping(t *testing.T) {
	tests := []struct {
		input    types.Severity
		expected finding.Severity
	}{
		{types.SeverityHigh, finding.SeverityCritical},
		{types.SeverityMedium, finding.SeverityError},
		{types.SeverityLow, finding.SeverityWarning},
		{types.Severity("unknown"), finding.SeverityWarning},
	}

	for _, tc := range tests {
		t.Run(string(tc.input), func(t *testing.T) {
			result := MapSeverity(tc.input)
			assert.Equal(t, tc.expected, result)
		})
	}
}

func TestMapRelation(t *testing.T) {
	// Every valid RelationshipType must map to a KNOWN go-finding constant
	// (never a free-form string). This is the regression guard for finding #6.
	knownConstants := map[finding.RelationKind]bool{
		finding.RelationCloneOf: true,
		finding.RelationCauses:  true,
		finding.RelationWraps:   true,
		finding.RelationRelated: true,
	}

	for _, rel := range types.ValidRelationshipTypes() {
		mapped := MapRelation(rel)
		assert.True(t, knownConstants[mapped],
			"RelationshipType %q mapped to unknown RelationKind %q", rel, mapped)
	}

	// Direct mappings.
	assert.Equal(t, finding.RelationWraps, MapRelation(types.RelationshipTypeWraps))
	assert.Equal(t, finding.RelationRelated, MapRelation(types.RelationshipTypeAliases))
	assert.Equal(t, finding.RelationRelated, MapRelation(types.RelationshipType("unknown")))
}

func TestViolationsToFindings(t *testing.T) {
	violations := []types.ErrorViolation{
		types.MakeTestViolation("a.go", 1, types.ErrorTypePanic, types.SeverityHigh, "p1"),
		types.MakeTestViolation("b.go", 2, types.ErrorTypeIgnored, types.SeverityMedium, "i1"),
	}

	findings := ViolationsToFindings(violations)

	assert.Len(t, findings, 2)
	assert.True(t, findings[0].IsValid())
	assert.True(t, findings[1].IsValid())
}

// sampleViolations provides a standard set of violations for reuse across filter and report tests.
var sampleViolations = []types.ErrorViolation{
	types.MakeTestViolation("a.go", 1, types.ErrorTypeReturn, types.SeverityHigh, "critical"),
	types.MakeTestViolation("b.go", 2, types.ErrorTypeIgnored, types.SeverityMedium, "med"),
	types.MakeTestViolation("c.go", 3, types.ErrorTypeCheck, types.SeverityLow, "warning"),
}

// reportFromViolations builds a report the way production code does after
// the deprecated graph-report constructor removal: NewToolReport + convert +
// sort + ComputeSummary. Test helper for the report-shape assertions below.
func reportFromViolations(
	violations []types.ErrorViolation,
	rels []types.ErrorRelationship,
) *finding.Report {
	report := NewToolReport()

	findings := ViolationsToFindingsWithRelated(violations, rels)
	findingsdk.SortByPosition(findings)
	report.AddFindings(findings)
	report.ComputeSummary()

	return report
}

func TestReportFromViolations(t *testing.T) {
	report := reportFromViolations(sampleViolations, nil)

	assert.Equal(t, "erraudit", report.Tool.Name)
	assert.Equal(t, 3, report.Summary.Total)
	assert.Equal(t, 1, report.Summary.BySeverity[finding.SeverityCritical])
	assert.Equal(t, 1, report.Summary.BySeverity[finding.SeverityError])
	assert.Equal(t, 1, report.Summary.BySeverity[finding.SeverityWarning])
	assert.Equal(t, 3, report.Summary.FilesAffected)
}

func TestCleanSnippet(t *testing.T) {
	tests := []struct {
		name     string
		input    string
		expected string
	}{
		{"removes > marker", "  41 \n> 42 panic(err)\n  43 }", "41\n42 panic(err)\n43 }"},
		{"no markers", "line1\nline2", "line1\nline2"},
		{"empty lines skipped", "line1\n\nline2", "line1\nline2"},
		{"trailing newline trimmed", "line1\n", "line1"},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			result := CleanSnippet(tc.input)
			assert.Equal(t, tc.expected, result)
		})
	}
}

func TestReportFromViolations_SARIFOutput(t *testing.T) {
	violations := []types.ErrorViolation{
		{
			Position:   token.Position{Filename: "main.go", Line: 42, Column: 5},
			Type:       types.ErrorTypePanic,
			Severity:   types.SeverityHigh,
			Message:    "panic on error",
			Suggestion: "Return error instead",
		},
	}

	report := reportFromViolations(violations, nil)

	sarif, err := report.ToSARIF()
	require.NoError(t, err)

	assert.Contains(t, string(sarif), `"2.1.0"`)
	assert.Contains(t, string(sarif), "main.go")
	assert.Contains(t, string(sarif), "panic on error")
	assert.Contains(t, string(sarif), "erraudit")
}

func TestReportFromViolations_Nil(t *testing.T) {
	report := reportFromViolations(nil, nil)

	assert.Equal(t, "erraudit", report.Tool.Name)
	assert.Equal(t, 0, report.Summary.Total)
}

func TestReportFromViolations_EmptyViolations(t *testing.T) {
	graph := &types.ErrorGraph{
		Package:    "empty",
		Violations: []types.ErrorViolation{},
	}

	report := reportFromViolations(graph.Violations, nil)

	assert.Equal(t, "erraudit", report.Tool.Name)
	assert.Equal(t, 0, report.Summary.Total)
}

func TestReportFromViolations_EmptyGraph(t *testing.T) {
	graph := &types.ErrorGraph{
		Package:    "empty",
		Violations: nil,
		Errors:     nil,
	}

	report := reportFromViolations(graph.Violations, nil)

	assert.Equal(t, "erraudit", report.Tool.Name)
	assert.Equal(t, 0, report.Summary.Total)
}

func TestIntegration_FullPipeline_SARIFRoundTrip(t *testing.T) {
	violations := []types.ErrorViolation{
		{
			Position:   token.Position{Filename: "handler.go", Line: 42, Column: 5},
			Type:       types.ErrorTypePanic,
			Severity:   types.SeverityHigh,
			Message:    "panic on error in handler",
			Suggestion: "Return error instead",
		},
		{
			Position: token.Position{Filename: "service.go", Line: 15, Column: 3},
			Type:     types.ErrorTypeIgnored,
			Severity: types.SeverityMedium,
			Message:  "error ignored with blank identifier",
		},
		{
			Position: token.Position{Filename: "util.go", Line: 8, Column: 1},
			Type:     types.ErrorTypeReturn,
			Severity: types.SeverityLow,
			Message:  "function returns error",
		},
	}

	report := reportFromViolations(violations, nil)

	t.Run("report has correct structure", func(t *testing.T) {
		assert.Equal(t, "erraudit", report.Tool.Name)
		assert.Equal(t, 3, report.Summary.Total)
		assert.Equal(t, 1, report.Summary.BySeverity[finding.SeverityCritical])
		assert.Equal(t, 1, report.Summary.BySeverity[finding.SeverityError])
		assert.Equal(t, 1, report.Summary.BySeverity[finding.SeverityWarning])
	})

	t.Run("SARIF output is valid JSON", func(t *testing.T) {
		sarif, err := report.ToSARIF()
		require.NoError(t, err)

		assert.Contains(t, string(sarif), `"2.1.0"`)
		assert.Contains(t, string(sarif), "handler.go")
		assert.Contains(t, string(sarif), "service.go")
		assert.Contains(t, string(sarif), "panic on error in handler")
		assert.Contains(t, string(sarif), "error ignored with blank identifier")
	})

	t.Run("JSON output round-trips", func(t *testing.T) {
		jsonStr, err := report.PrettyJSON()
		require.NoError(t, err)

		assert.Contains(t, jsonStr, "erraudit")
		assert.Contains(t, jsonStr, "handler.go")
		assert.Contains(t, jsonStr, "panic on error in handler")
	})
}

func TestViolationsToFindingsWithRelated(t *testing.T) {
	violations := []types.ErrorViolation{
		{
			Position:  token.Position{Filename: "main.go", Line: 10, Column: 1},
			Type:      types.ErrorTypeWrapping,
			Severity:  types.SeverityMedium,
			Message:   "wraps ErrNotFound",
			ErrorName: "ErrNotFound",
		},
		{
			Position:  token.Position{Filename: "main.go", Line: 20, Column: 1},
			Type:      types.ErrorTypePanic,
			Severity:  types.SeverityHigh,
			Message:   "panic on error",
			ErrorName: "",
		},
	}

	relationships := []types.ErrorRelationship{
		{
			Parent:           "ErrGeneric",
			Child:            "ErrNotFound",
			RelationshipType: types.RelationshipTypeWraps,
		},
	}

	findings := ViolationsToFindingsWithRelated(violations, relationships)

	require.Len(t, findings, 2)

	errNotFound := findings[0]
	assert.Equal(t, "ErrNotFound", errNotFound.Metadata["erraudit/error-name"])
	assert.Len(t, errNotFound.Related, 1)
	assert.Equal(t, finding.ID("ErrGeneric"), errNotFound.Related[0].FindingID)
	assert.Equal(t, finding.RelationKind("wraps"), errNotFound.Related[0].Relation)

	noName := findings[1]
	assert.Empty(t, noName.Related)
}

func TestViolationsToFindingsWithRelated_PositionWired(t *testing.T) {
	rels := []types.ErrorRelationship{
		{
			Parent:           "ErrParent",
			Child:            "ErrChild",
			RelationshipType: types.RelationshipTypeWraps,
			Position:         token.Position{Filename: "errors.go", Line: 5, Column: 1},
		},
	}

	violations := []types.ErrorViolation{
		{
			Position:  token.Position{Filename: "main.go", Line: 10, Column: 1},
			Type:      types.ErrorTypeWrapping,
			Severity:  types.SeverityMedium,
			Message:   "wraps",
			ErrorName: "ErrChild",
		},
	}

	findings := ViolationsToFindingsWithRelated(violations, rels)
	require.Len(t, findings, 1)

	assert.Len(t, findings[0].Related, 1)
	assert.Equal(t, finding.FilePath("errors.go"), findings[0].Related[0].Position.File)
	assert.Equal(t, 5, findings[0].Related[0].Position.Line)
}

func TestReportFromViolationsWithRelated(t *testing.T) {
	graph := &types.ErrorGraph{
		Package: "main",
		Violations: []types.ErrorViolation{
			{
				Position:  token.Position{Filename: "handler.go", Line: 10, Column: 1},
				Type:      types.ErrorTypeWrapping,
				Severity:  types.SeverityMedium,
				Message:   "wraps ErrDB",
				ErrorName: "ErrDB",
			},
		},
		Hierarchy: &types.ErrorHierarchy{
			Relationships: []types.ErrorRelationship{
				{
					Parent:           "ErrService",
					Child:            "ErrDB",
					RelationshipType: types.RelationshipTypeWraps,
				},
			},
		},
	}

	report := reportFromViolations(graph.Violations, graph.Hierarchy.Relationships)

	assert.Equal(t, "erraudit", report.Tool.Name)
	assert.Equal(t, 1, report.Summary.Total)

	findings := report.FindingsSnapshot()
	require.Len(t, findings, 1)
	f := findings[0]
	assert.Equal(t, "ErrDB", f.Metadata["erraudit/error-name"])
	assert.Len(t, f.Related, 1)
	assert.Equal(t, finding.ID("ErrService"), f.Related[0].FindingID)
}

func TestReportFromViolationsWithRelated_NilHierarchy(t *testing.T) {
	graph := &types.ErrorGraph{
		Package: "main",
		Violations: []types.ErrorViolation{
			types.MakeTestViolation("main.go", 1, types.ErrorTypePanic, types.SeverityHigh, "p"),
		},
	}

	report := reportFromViolations(graph.Violations, nil)

	assert.Equal(t, 1, report.Summary.Total)
	findings := report.FindingsSnapshot()
	assert.Empty(t, findings[0].Related)
}

func TestDeduplicateFindings(t *testing.T) {
	v1 := types.ErrorViolation{
		Position: token.Position{Filename: "main.go", Line: 10, Column: 1},
		Type:     types.ErrorTypePanic,
		Severity: types.SeverityHigh,
		Message:  "panic",
	}
	v2 := types.ErrorViolation{
		Position: token.Position{Filename: "main.go", Line: 20, Column: 1},
		Type:     types.ErrorTypePanic,
		Severity: types.SeverityHigh,
		Message:  "another panic",
	}

	findings := ViolationsToFindings([]types.ErrorViolation{v1, v1, v2})

	deduped := DeduplicateFindings(findings)

	assert.Len(t, deduped, 2)
}

func TestViolationToFinding_ErrorNameInMetadata(t *testing.T) {
	v := types.ErrorViolation{
		Position:  token.Position{Filename: "main.go", Line: 42, Column: 5},
		Type:      types.ErrorTypePanic,
		Severity:  types.SeverityHigh,
		Message:   "panic on error",
		ErrorName: "errConnection",
	}

	f, err := ViolationToFinding(v)
	require.NoError(t, err)

	assert.Equal(t, "errConnection", f.Metadata["erraudit/error-name"])
}

func TestViolationToFinding_NoErrorName(t *testing.T) {
	v := types.MakeTestViolation("main.go", 42, types.ErrorTypePanic, types.SeverityHigh, "panic on error")

	f, err := ViolationToFinding(v)
	require.NoError(t, err)

	_, hasKey := f.Metadata["erraudit/error-name"]
	assert.False(t, hasKey)
}

// TestViolationKeyEquivalenceToFindingKey is the regression guard for
// SPLIT-BRAIN finding #1. It asserts that the domain dedup key
// (ErrorViolation.Key) and the interchange dedup key (Finding.Key, which
// returns the auto-generated ID) agree on duplicity for every case:
// two violations share a violation.Key() IFF their converted findings share
// a finding.Key(). If this test ever fails, the two dedup stages have
// diverged and output formats will disagree on violation counts.
func TestViolationKeyEquivalenceToFindingKey(t *testing.T) {
	cases := []types.ErrorViolation{
		types.MakeTestViolation("a.go", 10, types.ErrorTypePanic, types.SeverityHigh, "msg-1"),
		types.MakeTestViolation(
			"a.go",
			10,
			types.ErrorTypePanic,
			types.SeverityHigh,
			"msg-2 (same pos+type, diff msg)",
		),
		types.MakeTestViolation("a.go", 11, types.ErrorTypePanic, types.SeverityHigh, "diff line"),
		types.MakeTestViolation("a.go", 10, types.ErrorTypeIgnored, types.SeverityMedium, "diff type"),
		types.MakeTestViolation("b.go", 10, types.ErrorTypePanic, types.SeverityHigh, "diff file"),
	}

	findings := make([]finding.Finding, len(cases))
	for i, v := range cases {
		f, err := ViolationToFinding(v)
		require.NoError(t, err)
		findings[i] = f
	}

	for i := range cases {
		for j := range cases {
			vKeyEqual := cases[i].Key() == cases[j].Key()
			fKeyEqual := findings[i].Key() == findings[j].Key()
			assert.Equal(t, vKeyEqual, fKeyEqual,
				"key agreement broken between violation %d and %d: violation.Key equal=%v, finding.Key equal=%v",
				i, j, vKeyEqual, fKeyEqual)
		}
	}
}

func TestViolationToFinding_OopsRedundantGuard(t *testing.T) {
	v := types.MakeTestViolation("main.go", 10,
		types.ErrorTypeOopsRedundantGuard, types.SeverityLow,
		"Redundant nil guard before oops.Wrap(err)")

	f, err := ViolationToFinding(v)
	require.NoError(t, err)

	assert.Equal(t, finding.RuleName("oops_redundant_guard"), f.Rule)
	assert.Contains(t, f.Tags, finding.Tag("oops-redundant-guard"))
	assert.Contains(t, f.Tags, finding.TagStyle)
	assert.Contains(t, f.Tags, finding.Tag(finding.CategoryErrorHandling))
	assert.True(t, f.IsValid())
}
