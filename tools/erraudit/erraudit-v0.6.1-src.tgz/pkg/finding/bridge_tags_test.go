package finding

import (
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	findingsdk "github.com/larsartmann/go-finding"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// TestViolationTypeToTags_CoversAllTypes iterates the CANONICAL ErrorType
// list (types.ValidErrorTypes), not a hand-copied table, so adding a new
// violation type makes this test fail until its tag mapping is decided.
func TestViolationTypeToTags_CoversAllTypes(t *testing.T) {
	valid := types.ValidErrorTypes()
	require.NotEmpty(t, valid)

	for _, errorType := range valid {
		t.Run(string(errorType), func(t *testing.T) {
			tags := violationTypeToTags(errorType)

			require.NotEmpty(t, tags, "every violation type must map to at least one tag")

			// Invariants shared by every type: category tag + slug tag.
			assert.Contains(t, tags, findingsdk.Tag(findingsdk.CategoryErrorHandling),
				"category tag must always be present")
			slug := findingsdk.Tag(replaceUnderscores(string(errorType)))
			assert.Contains(t, tags, slug, "type-slug tag must always be present")
		})
	}
}

func replaceUnderscores(s string) string {
	out := make([]byte, 0, len(s))
	for i := range len(s) {
		if s[i] == '_' {
			out = append(out, '-')

			continue
		}

		out = append(out, s[i])
	}

	return string(out)
}

// Expected semantic tag per violation type — the mapping contract.
func TestViolationTypeToTags_SemanticMapping(t *testing.T) {
	cases := []struct {
		errorType    types.ErrorType
		expectedTags []findingsdk.Tag
	}{
		{types.ErrorTypePanic, []findingsdk.Tag{findingsdk.TagBug, findingsdk.TagCorrectness}},
		{types.ErrorTypeSilentSwallow, []findingsdk.Tag{findingsdk.TagBug, findingsdk.TagCorrectness}},
		{types.ErrorTypeIgnored, []findingsdk.Tag{findingsdk.TagBug, findingsdk.TagCorrectness}},
		{types.ErrorTypeUnwrapped, []findingsdk.Tag{findingsdk.TagCorrectness}},
		{types.ErrorTypeSentinelConcreteType, []findingsdk.Tag{findingsdk.TagCorrectness}},
		{types.ErrorTypeGenericReturn, []findingsdk.Tag{findingsdk.TagStyle}},
		{types.ErrorTypeLegacyAs, []findingsdk.Tag{findingsdk.TagDeprecated}},
		{types.ErrorTypeLegacyIs, []findingsdk.Tag{findingsdk.TagDeprecated}},
		{types.ErrorTypeWrapping, []findingsdk.Tag{findingsdk.TagCorrectness}},
		{types.ErrorTypePropagation, []findingsdk.Tag{findingsdk.TagCorrectness}},
		{types.ErrorTypeReturn, []findingsdk.Tag{findingsdk.TagCorrectness}},
		{types.ErrorTypeAssignment, []findingsdk.Tag{findingsdk.TagCorrectness}},
		{types.ErrorTypeCheck, []findingsdk.Tag{findingsdk.TagCorrectness}},
		{types.ErrorTypeContextLoss, []findingsdk.Tag{findingsdk.TagCorrectness}},
		{types.ErrorTypeDeferredCloseIgnored, []findingsdk.Tag{findingsdk.TagCorrectness}},
		{types.ErrorTypeStdlibConstructor, []findingsdk.Tag{findingsdk.TagStyle}},
		{types.ErrorTypeOopsRedundantGuard, []findingsdk.Tag{findingsdk.TagStyle}},
		{types.ErrorTypeOopsMisusedW, []findingsdk.Tag{findingsdk.TagStyle}},
	}

	for _, tc := range cases {
		t.Run(string(tc.errorType), func(t *testing.T) {
			tags := violationTypeToTags(tc.errorType)
			for _, want := range tc.expectedTags {
				assert.Contains(t, tags, want)
			}
		})
	}
}

// TestViolationToFinding_WindowsPathsAreNotMangled pins the bridge's
// position handling for Windows-style paths: Filename must flow through
// verbatim (no separator rewriting, no drive-letter stripping). The actual
// separator convention stays the caller's (go/token) responsibility.
func TestViolationToFinding_WindowsPathsAreNotMangled(t *testing.T) {
	violation := types.MakeTestViolation(`C:\src\app\handler.go`, 42, types.ErrorTypePanic, types.SeverityHigh, "panic")

	f, err := ViolationToFinding(violation)
	require.NoError(t, err)

	assert.Equal(t, findingsdk.FilePath(`C:\src\app\handler.go`), f.Position.File)
}
