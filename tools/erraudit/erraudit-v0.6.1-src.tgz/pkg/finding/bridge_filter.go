package finding

import (
	"github.com/larsartmann/erraudit/pkg/suppression"
	"github.com/larsartmann/erraudit/pkg/types"
	findingsdk "github.com/larsartmann/go-finding"
)

// DeduplicateFindings removes duplicate findings using the go-finding library's
// MergeIter function with ID-based deduplication. This delegates to the shared
// ecosystem dedup algorithm rather than a custom implementation.
func DeduplicateFindings(findings []findingsdk.Finding) []findingsdk.Finding {
	if len(findings) <= 1 {
		return findings
	}

	report := NewToolReport()
	report.AddFindings(findings)

	result := make([]findingsdk.Finding, 0, len(findings))
	for f := range findingsdk.MergeIter(
		[]*findingsdk.Report{report},
		findingsdk.WithDeduplication(true),
	) {
		result = append(result, f)
	}

	return result
}

// ApplyNolintSuppressions marks findings as suppressed where the source file
// contains a //nolint comment on the same line. The engine must be built from
// the same source files (see suppression.BuildEngineFromFiles). Findings that
// match are annotated with a Suppression so that Report.ActiveFindings()
// excludes them from SARIF/JSON output.
func ApplyNolintSuppressions(
	findings []findingsdk.Finding,
	engine *suppression.Engine,
) []findingsdk.Finding {
	if engine == nil || engine.RuleCount() == 0 {
		return findings
	}

	for i := range findings {
		if engine.ShouldSuppress(
			types.ErrorType(findings[i].Rule),
			string(findings[i].Position.File),
			findings[i].Position.Line,
			"",
		) {
			findings[i].Suppression = &findingsdk.Suppression{ //nolint:exhaustruct_v5 // ExpiresAt is intentionally nil - nolint suppressions have no expiry
				Kind:   findingsdk.SuppressionInSource,
				Rule:   findingsdk.RuleName(string(findings[i].Rule)),
				Reason: nolintSuppressionReason,
			}
		}
	}

	return findings
}
