package finding

import (
	"context"

	apierrors "github.com/larsartmann/erraudit/pkg/errors"
	"github.com/larsartmann/erraudit/pkg/types"
	findingsdk "github.com/larsartmann/go-finding"
)

const detectorName = "erraudit"

// GraphAnalyzer is the function signature the detector calls to produce an
// ErrorGraph from a given context. The caller (typically cmd/pipeline) supplies
// the concrete analyzer implementation, keeping pkg/finding free of
// internal/analyzer imports.
type GraphAnalyzer func(ctx context.Context) (*types.ErrorGraph, error)

// ErrauditDetector implements the go-finding Detector interface by
// wrapping the erraudit analysis pipeline. It is the integration
// point that makes erraudit a first-class participant in the
// go-finding ecosystem: any tool that accepts a finding.Detector can use it.
type ErrauditDetector struct {
	analyze GraphAnalyzer
}

// NewErrauditDetector creates a detector that runs the given analysis
// function and converts the resulting ErrorGraph into go-finding Findings.
// The analyze function should perform the full analysis (file/dir/package) and
// return the populated ErrorGraph.
func NewErrauditDetector(analyze GraphAnalyzer) *ErrauditDetector {
	return &ErrauditDetector{analyze: analyze}
}

// Name returns the detector's unique name in the go-finding ecosystem.
func (d *ErrauditDetector) Name() string {
	return detectorName
}

// Detect runs the analysis pipeline and converts violations to go-finding
// Findings. Findings include parent-child error relationships when the graph
// contains hierarchy data. Returns an empty slice (not nil) when no violations
// are found.
func (d *ErrauditDetector) Detect(ctx context.Context) ([]findingsdk.Finding, error) {
	graph, err := d.analyze(ctx)
	if err != nil {
		return nil, apierrors.Wrap(err, "erraudit detector analysis failed")
	}

	if graph == nil {
		return []findingsdk.Finding{}, nil
	}

	var rels []types.ErrorRelationship
	if graph.Hierarchy != nil {
		rels = graph.Hierarchy.Relationships
	}

	findings := ViolationsToFindingsWithRelated(graph.Violations, rels)

	return findings, nil
}

// Compile-time interface compliance check.
var _ findingsdk.Detector = (*ErrauditDetector)(nil)
