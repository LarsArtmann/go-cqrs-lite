package finding

import (
	"go/token"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
)

func FuzzViolationToFinding(f *testing.F) {
	f.Add("main.go", 1, 1, "panic", "some message")
	f.Add("", 0, 0, "", "")
	f.Add("file with spaces.go", 99999, 99999, "return", "")

	f.Fuzz(func(t *testing.T, file string, line, col int, vtype, msg string) {
		v := types.ErrorViolation{
			Type:    types.ErrorType(vtype),
			Message: msg,
			Position: token.Position{
				Filename: file,
				Line:     line,
				Column:   col,
			},
		}

		_, _ = ViolationToFinding(v)
		// Test passes if no panic
	})
}

func FuzzCleanSnippet(f *testing.F) {
	f.Add("line1\nline2\nline3")
	f.Add("")
	f.Add("no newline")
	f.Add("\n\n\n")

	f.Fuzz(func(t *testing.T, snippet string) {
		_ = CleanSnippet(snippet)
		// Test passes if no panic
	})
}

func FuzzToFindingPosition(f *testing.F) {
	f.Add("main.go", 1, 1)
	f.Add("", 0, 0)
	f.Add("path/to/file.go", 99999, 1)

	f.Fuzz(func(t *testing.T, filename string, line, col int) {
		pos := token.Position{
			Filename: filename,
			Line:     line,
			Column:   col,
		}
		result := ToFindingPosition(pos)
		_ = result
		// Test passes if no panic
	})
}
