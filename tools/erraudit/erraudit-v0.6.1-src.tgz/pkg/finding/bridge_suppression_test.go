package finding

import (
	"go/token"
	"os"
	"path/filepath"
	"testing"

	"github.com/larsartmann/erraudit/pkg/suppression"
	"github.com/larsartmann/erraudit/pkg/types"
	findingsdk "github.com/larsartmann/go-finding"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// TestApplyNolintSuppressions_E2E is the end-to-end regression test for
// SPLIT-BRAIN finding #3. It proves that a //nolint comment in source code
// actually suppresses the corresponding finding in the go-finding output path.
//
// Before the fix, suppression was a ghost system: fully modeled, unit-tested
// in isolation, and producing zero effect in production because the engine was
// always passed nil. This test creates a real temp file with a //nolint
// comment, builds the engine from it, applies suppressions, and asserts the
// suppression flows through to the Finding.Suppression field.
func TestApplyNolintSuppressions_E2E(t *testing.T) {
	// Source file with a //nolint on line 3 (bare) and //nolint:erraudit:panic on line 7.
	source := `package main

func a() error { //nolint
	return nil
}

func b() { //nolint:erraudit:panic
	panic("x")
}
`
	dir := t.TempDir()
	srcFile := filepath.Join(dir, "main.go")
	require.NoError(t, os.WriteFile(srcFile, []byte(source), 0o644))

	// Build the engine from the source file — this is what the output pipeline does.
	engine := suppression.BuildEngineFromFiles([]string{srcFile})
	assert.Greater(t, engine.RuleCount(), 0, "engine should have rules from the //nolint comments")

	// Create findings at the nolint lines and a non-nolint line.
	findings := []findingsdk.Finding{
		{
			ID:       findingsdk.ID("erraudit:panic:main.go:3:1"),
			Rule:     findingsdk.RuleName(types.ErrorTypePanic),
			ToolName: findingsdk.ToolName("erraudit"),
			Message:  "panic on error",
			Position: findingsdk.Position{File: findingsdk.FilePath(srcFile), Line: 3},
		},
		{
			ID:       findingsdk.ID("erraudit:panic:main.go:7:1"),
			Rule:     findingsdk.RuleName(types.ErrorTypePanic),
			ToolName: findingsdk.ToolName("erraudit"),
			Message:  "panic on error (specific suppression)",
			Position: findingsdk.Position{File: findingsdk.FilePath(srcFile), Line: 7},
		},
		{
			ID:       findingsdk.ID("erraudit:ignored:main.go:12:1"),
			Rule:     findingsdk.RuleName(types.ErrorTypeIgnored),
			ToolName: findingsdk.ToolName("erraudit"),
			Message:  "not suppressed",
			Position: findingsdk.Position{File: findingsdk.FilePath(srcFile), Line: 12},
		},
	}

	result := ApplyNolintSuppressions(findings, engine)

	// Line 3: bare //nolint → suppressed.
	assert.NotNil(t, result[0].Suppression, "finding on line 3 (bare //nolint) must be suppressed")
	assert.Equal(t, findingsdk.SuppressionInSource, result[0].Suppression.Kind)

	// Line 7: //nolint:erraudit:panic → suppressed for panic type.
	assert.NotNil(t, result[1].Suppression, "finding on line 7 (typed //nolint) must be suppressed")

	// Line 12: no //nolint → NOT suppressed.
	assert.Nil(t, result[2].Suppression, "finding on line 12 (no //nolint) must NOT be suppressed")
}

// TestApplyNolintSuppressions_NilEngine is a nil-safety guard: calling
// ApplyNolintSuppressions with a nil engine should return findings unchanged.
func TestApplyNolintSuppressions_NilEngine(t *testing.T) {
	findings := []findingsdk.Finding{
		{Rule: findingsdk.RuleName("panic"), Position: findingsdk.Position{File: "a.go", Line: 1}},
	}

	result := ApplyNolintSuppressions(findings, nil)
	assert.Len(t, result, 1)
	assert.Nil(t, result[0].Suppression)
}

// TestApplyNolintSuppressions_EmptyEngine is a no-op guard: an engine with
// zero rules should not modify any findings.
func TestApplyNolintSuppressions_EmptyEngine(t *testing.T) {
	engine := suppression.NewEngine()
	findings := []findingsdk.Finding{
		{Rule: findingsdk.RuleName("panic"), Position: findingsdk.Position{File: "a.go", Line: 1}},
	}

	result := ApplyNolintSuppressions(findings, engine)
	assert.Len(t, result, 1)
	assert.Nil(t, result[0].Suppression)
}

// TestApplyNolintSuppressions_OopsRedundantGuard verifies that
// //nolint:erraudit:oops_redundant_guard suppresses findings for the
// oops_redundant_guard violation type.
func TestApplyNolintSuppressions_OopsRedundantGuard(t *testing.T) {
	source := `package main

import "github.com/samber/oops"

func process() error {
	err := step()
	if err != nil { //nolint:erraudit:oops_redundant_guard
		return oops.Wrap(err)
	}
	return nil
}

func step() error { return nil }
`
	dir := t.TempDir()
	srcFile := filepath.Join(dir, "main.go")
	require.NoError(t, os.WriteFile(srcFile, []byte(source), 0o644))

	engine := suppression.BuildEngineFromFiles([]string{srcFile})
	assert.Greater(t, engine.RuleCount(), 0, "engine should have the oops_redundant_guard rule")

	findings := []findingsdk.Finding{
		{
			ID:       findingsdk.ID("erraudit:oops_redundant_guard:main.go:7:2"),
			Rule:     findingsdk.RuleName(types.ErrorTypeOopsRedundantGuard),
			ToolName: findingsdk.ToolName("erraudit"),
			Message:  "Redundant nil guard before oops.Wrap(err)",
			Position: findingsdk.Position{File: findingsdk.FilePath(srcFile), Line: 7},
		},
	}

	result := ApplyNolintSuppressions(findings, engine)
	assert.NotNil(t, result[0].Suppression,
		"oops_redundant_guard finding on nolint line must be suppressed")
}

// TestToFindingPosition_RoundTrip verifies that ToFindingPosition preserves
// file, line, and column — the contract for the single position boundary
// (SPLIT-BRAIN finding #10).
func TestToFindingPosition_RoundTrip(t *testing.T) {
	cases := []struct {
		name string
		pos  token.Position
	}{
		{"full position", token.Position{Filename: "main.go", Line: 42, Column: 7}},
		{"no column", token.Position{Filename: "a/b.go", Line: 10, Column: 0}},
		{"empty filename", token.Position{Filename: "", Line: 5, Column: 3}},
		{"zero position", token.Position{}},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			result := ToFindingPosition(tc.pos)
			assert.Equal(t, findingsdk.FilePath(tc.pos.Filename), result.File, "File must match")
			assert.Equal(t, tc.pos.Line, result.Line, "Line must match")
			assert.Equal(t, tc.pos.Column, result.Column, "Column must match")
		})
	}
}
