package finding_test

import (
	"fmt"
	"go/token"

	"github.com/larsartmann/erraudit/pkg/finding"
	"github.com/larsartmann/erraudit/pkg/types"
)

func ExampleMapSeverity() {
	fmt.Println(finding.MapSeverity(types.SeverityHigh))
	fmt.Println(finding.MapSeverity(types.SeverityMedium))
	fmt.Println(finding.MapSeverity(types.SeverityLow))
	// Output:
	// critical
	// error
	// warning
}

func ExampleViolationToFinding() {
	violation := types.ErrorViolation{
		Type:     types.ErrorTypeLegacyAs,
		Severity: types.SeverityHigh,
		Message:  "use errors.AsType instead of errors.As",
		Position: token.Position{Filename: "main.go", Line: 42, Column: 5},
	}

	f, err := finding.ViolationToFinding(violation)
	if err != nil {
		panic(err)
	}

	fmt.Println(f.Rule)
	fmt.Println(f.Severity)
	// Output:
	// legacy_as
	// critical
}

func ExampleViolationsToFindings() {
	violations := []types.ErrorViolation{
		{
			Type:     types.ErrorTypeLegacyAs,
			Severity: types.SeverityHigh,
			Message:  "first",
			Position: token.Position{Filename: "a.go", Line: 1},
		},
		{
			Type:     types.ErrorTypeLegacyIs,
			Severity: types.SeverityLow,
			Message:  "second",
			Position: token.Position{Filename: "b.go", Line: 2},
		},
	}

	findings := finding.ViolationsToFindings(violations)
	fmt.Println(len(findings))
	fmt.Println(findings[0].Rule)
	fmt.Println(findings[1].Rule)
	// Output:
	// 2
	// legacy_as
	// legacy_is
}
