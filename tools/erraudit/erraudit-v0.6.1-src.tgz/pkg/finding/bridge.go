// Package finding provides a bridge between erraudit domain types
// and the go-finding unified data model. This enables SARIF output, filtering,
// report generation, and interoperability with other static analysis tools.
package finding

import (
	"go/token"

	"github.com/larsartmann/erraudit/pkg/types"
	findingsdk "github.com/larsartmann/go-finding"
	findingsdkanalysis "github.com/larsartmann/go-finding/analysis"
)

const toolName = "erraudit"

// Metadata key constants for go-finding Finding metadata.
const (
	MetaKeyErrorType   = "erraudit/error-type"
	MetaKeySeverity    = "erraudit/severity"
	MetaKeyErrorName   = "erraudit/error-name"
	MetaKeyExplanation = "erraudit/explanation"

	nolintSuppressionReason = "suppressed by //nolint comment in source"
)

// SeverityMapping maps erraudit severity to go-finding severity.
//
//nolint:gochecknoglobals // Severity mapping is intentionally global for consistent conversion
var SeverityMapping = map[types.Severity]findingsdk.Severity{
	types.SeverityHigh:   findingsdk.SeverityCritical,
	types.SeverityMedium: findingsdk.SeverityError,
	types.SeverityLow:    findingsdk.SeverityWarning,
}

// MapSeverity converts a erraudit Severity to a go-finding Severity.
func MapSeverity(sev types.Severity) findingsdk.Severity {
	if mapped, ok := SeverityMapping[sev]; ok {
		return mapped
	}

	return findingsdk.SeverityWarning
}

// MapRelation converts a erraudit RelationshipType to the closest
// go-finding RelationKind. "wraps" maps directly; "aliases" (no go-finding
// counterpart) maps to RelationRelated so every valid relationship resolves to
// a known constant rather than a free-form string.
func MapRelation(rel types.RelationshipType) findingsdk.RelationKind {
	switch rel {
	case types.RelationshipTypeWraps:
		return findingsdk.RelationWraps
	case types.RelationshipTypeAliases:
		return findingsdk.RelationRelated
	default:
		return findingsdk.RelationRelated
	}
}

// ToFindingPosition converts a go/token.Position to a go-finding Position.
// This is the single boundary between the Go AST position system and the
// go-finding position system — all conversions must go through here so the
// mapping can be audited and tested in one place.
func ToFindingPosition(pos token.Position) findingsdk.Position {
	return findingsdkanalysis.FromTokenPosition(pos)
}
