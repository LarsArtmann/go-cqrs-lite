package finding

import (
	"log"
	"strings"

	apierrors "github.com/larsartmann/erraudit/pkg/errors"
	"github.com/larsartmann/erraudit/pkg/types"
	findingsdk "github.com/larsartmann/go-finding"
)

// ViolationToFinding converts an ErrorViolation to a go-finding Finding.
// Per-violation //nolint suppression is NOT applied here; it is handled either
// at the domain level (pipeline.SuppressViolations, which removes violations
// before any output) or post-conversion in batch form via
// ApplyNolintSuppressions (which marks findings for SARIF/JSON output).
// violationTemplate pre-stamps the fields shared by every converted finding
// (tool name, error-handling category) so per-violation conversion only
// varies rule, message, severity, and position.
//
//nolint:gochecknoglobals // immutable template factory, shared by all conversions
var violationTemplate = findingsdk.NewTemplate(findingsdk.ToolName(toolName)).
	WithCategory(findingsdk.CategoryErrorHandling)

func ViolationToFinding(violation types.ErrorViolation) (findingsdk.Finding, error) {
	pos := ToFindingPosition(violation.Position)

	sev := MapSeverity(violation.Severity)

	fixStrategy := findingsdk.FixStrategyNone
	if violation.Suggestion != "" {
		fixStrategy = findingsdk.FixStrategySuggest
	}

	builder := violationTemplate.
		Builder(findingsdk.RuleName(violation.Type), violation.Message, sev, pos).
		WithTags(violationTypeToTags(violation.Type)...).
		WithFixStrategy(fixStrategy)

	if violation.Suggestion != "" {
		builder = builder.WithSuggestion(violation.Suggestion)
	}

	if violation.CodeSnippet != "" {
		builder = builder.WithSnippet(CleanSnippet(violation.CodeSnippet))
	}

	if violation.EndPosition.IsValid() {
		endPos := ToFindingPosition(violation.EndPosition)
		builder = builder.WithRange(findingsdk.Range{
			Start: pos,
			End:   endPos,
		})
	}

	if violation.Confidence > 0 {
		// The raw cast is safe: types.Confidence is already validated to [0,1]
		// by NewConfidence, and WithConfidence clamps again defensively.
		builder = builder.WithConfidence(findingsdk.Confidence(violation.Confidence.Float()))
	}

	metadata := map[string]string{
		MetaKeyErrorType: string(violation.Type),
		MetaKeySeverity:  string(violation.Severity),
	}

	if violation.ErrorName != "" {
		metadata[MetaKeyErrorName] = violation.ErrorName
	}

	if violation.Explanation != "" {
		metadata[MetaKeyExplanation] = violation.Explanation
	}

	result, err := builder.WithMetadata(metadata).Build()
	if err != nil {
		return findingsdk.Finding{}, apierrors.Wrap(
			err,
			"finding.Builder.Build() failed for violation at %s:%d",
			violation.Position.Filename,
			violation.Position.Line,
		)
	}

	return result, nil
}

// ViolationsToFindings converts a slice of ErrorViolations to Findings.
// Violations that fail conversion are skipped with a warning log.
func ViolationsToFindings(violations []types.ErrorViolation) []findingsdk.Finding {
	findings := make([]findingsdk.Finding, 0, len(violations))

	for _, violation := range violations {
		f, err := ViolationToFinding(violation)
		if err != nil { //nolint:erraudit // best-effort conversion; logs and skips individual violation
			log.Printf(
				"warning: skipping violation at %s:%d: %v",
				violation.Position.Filename,
				violation.Position.Line,
				err,
			)

			continue
		}

		findings = append(findings, f)
	}

	return findings
}

// ViolationsToFindingsWithRelated converts violations to Findings with parent-child
// error relationships linked via go-finding RelatedRef.
// Each related ref uses the error name as FindingID and the relationship type as Relation.
func ViolationsToFindingsWithRelated(
	violations []types.ErrorViolation,
	relationships []types.ErrorRelationship,
) []findingsdk.Finding {
	relatedMap := buildRelatedRefMap(relationships)

	findings := make([]findingsdk.Finding, 0, len(violations))

	for _, violation := range violations {
		finding, err := ViolationToFinding(violation)
		if err != nil { //nolint:erraudit // best-effort conversion; logs and skips individual violation
			log.Printf(
				"warning: skipping violation at %s:%d: %v",
				violation.Position.Filename,
				violation.Position.Line,
				err,
			)

			continue
		}

		if violation.ErrorName != "" {
			if refs, ok := relatedMap[violation.ErrorName]; ok {
				finding.Related = append(finding.Related, refs...)
			}
		}

		findings = append(findings, finding)
	}

	return findings
}

// buildRelatedRefMap builds a map from error name → list of RelatedRef
// capturing both parent (wraps) and child (wrapped-by) relationships.
// Positions are populated from ErrorRelationship.Position when available.
func buildRelatedRefMap(
	rels []types.ErrorRelationship,
) map[string][]findingsdk.RelatedRef {
	result := make(map[string][]findingsdk.RelatedRef)

	for _, rel := range rels {
		pos := findingsdk.Position{}
		if rel.Position.Filename != "" {
			pos = ToFindingPosition(rel.Position)
		}

		parentRef := findingsdk.RelatedRef{
			Position:  pos,
			FindingID: findingsdk.ID(rel.Parent),
			Relation:  MapRelation(rel.RelationshipType),
			Range:     nil, // Range is optional in SARIF
		}
		result[rel.Child] = append(result[rel.Child], parentRef)

		childRef := findingsdk.RelatedRef{
			Position:  pos,
			FindingID: findingsdk.ID(rel.Child),
			Relation:  MapRelation(types.RelationshipTypeWraps),
			Range:     nil, // Range is optional in SARIF
		}
		result[rel.Parent] = append(result[rel.Parent], childRef)
	}

	return result
}

// violationTypeToTags maps an ErrorType to semantic go-finding Tags.
// Each violation type gets the rule name as a tag plus relevant semantic tags.
func violationTypeToTags(errorType types.ErrorType) []findingsdk.Tag {
	tags := []findingsdk.Tag{
		findingsdk.Tag(findingsdk.CategoryErrorHandling),
		findingsdk.Tag(strings.ReplaceAll(string(errorType), "_", "-")),
	}

	switch errorType {
	case types.ErrorTypePanic:
		tags = append(tags, findingsdk.TagBug, findingsdk.TagCorrectness)
	case types.ErrorTypeSilentSwallow, types.ErrorTypeIgnored:
		tags = append(tags, findingsdk.TagBug, findingsdk.TagCorrectness)
	case types.ErrorTypeUnwrapped, types.ErrorTypeSentinelConcreteType:
		tags = append(tags, findingsdk.TagCorrectness)
	case types.ErrorTypeGenericReturn:
		tags = append(tags, findingsdk.TagStyle)
	case types.ErrorTypeLegacyAs, types.ErrorTypeLegacyIs:
		tags = append(tags, findingsdk.TagDeprecated)
	case types.ErrorTypeWrapping, types.ErrorTypePropagation:
		tags = append(tags, findingsdk.TagCorrectness)
	case types.ErrorTypeReturn, types.ErrorTypeAssignment, types.ErrorTypeCheck:
		tags = append(tags, findingsdk.TagCorrectness)
	case types.ErrorTypeContextLoss:
		tags = append(tags, findingsdk.TagCorrectness)
	case types.ErrorTypeDeferredCloseIgnored:
		tags = append(tags, findingsdk.TagCorrectness)
	case types.ErrorTypeStdlibConstructor:
		tags = append(tags, findingsdk.TagStyle)
	case types.ErrorTypeUncodedConstructor:
		tags = append(tags, findingsdk.TagStyle)
	case types.ErrorTypeOopsRedundantGuard, types.ErrorTypeOopsMisusedW:
		tags = append(tags, findingsdk.TagStyle)
	}

	return tags
}

// CleanSnippet cleans a code snippet by removing line markers, trimming
// whitespace, and collapsing empty lines. This is used by both the bridge
// and the SARIF visualizer.
func CleanSnippet(snippet string) string {
	var builder strings.Builder

	for line := range strings.SplitSeq(snippet, "\n") {
		if line == "" {
			continue
		}

		trimmed := strings.TrimLeft(line, " \t")
		trimmed = strings.TrimRight(trimmed, " \t")

		if len(trimmed) > 0 && trimmed[0] == '>' {
			trimmed = strings.TrimPrefix(trimmed, ">")
			trimmed = strings.TrimLeft(trimmed, " \t")
		}

		builder.WriteString(trimmed)
		builder.WriteString("\n")
	}

	return strings.TrimRight(builder.String(), "\n")
}
