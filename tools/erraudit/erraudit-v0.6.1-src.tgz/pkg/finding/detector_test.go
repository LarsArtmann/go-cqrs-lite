package finding

import (
	"context"
	"errors"
	"go/token"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestErrauditDetector_Name(t *testing.T) {
	d := NewErrauditDetector(func(_ context.Context) (*types.ErrorGraph, error) {
		return &types.ErrorGraph{}, nil
	})

	assert.Equal(t, "erraudit", d.Name())
}

func TestErrauditDetector_Detect_NilGraph(t *testing.T) {
	d := NewErrauditDetector(func(_ context.Context) (*types.ErrorGraph, error) {
		return nil, nil
	})

	findings, err := d.Detect(context.Background())
	require.NoError(t, err)
	assert.NotNil(t, findings)
	assert.Empty(t, findings)
}

func TestErrauditDetector_Detect_EmptyGraph(t *testing.T) {
	d := NewErrauditDetector(func(_ context.Context) (*types.ErrorGraph, error) {
		return &types.ErrorGraph{}, nil
	})

	findings, err := d.Detect(context.Background())
	require.NoError(t, err)
	assert.NotNil(t, findings)
	assert.Empty(t, findings)
}

func TestErrauditDetector_Detect_WithViolations(t *testing.T) {
	graph := &types.ErrorGraph{
		Violations: []types.ErrorViolation{
			{
				Position: token.Position{Filename: "test.go", Line: 10, Column: 5},
				Type:     types.ErrorTypeSilentSwallow,
				Severity: types.SeverityHigh,
				Message:  "error silently swallowed",
			},
		},
	}
	d := NewErrauditDetector(func(_ context.Context) (*types.ErrorGraph, error) {
		return graph, nil
	})

	findings, err := d.Detect(context.Background())
	require.NoError(t, err)
	assert.Len(t, findings, 1)
	assert.Equal(t, "silent_swallow", string(findings[0].Rule))
}

func TestErrauditDetector_Detect_AnalysisError(t *testing.T) {
	expectedErr := errors.New("analysis blew up")
	d := NewErrauditDetector(func(_ context.Context) (*types.ErrorGraph, error) {
		return nil, expectedErr
	})

	findings, err := d.Detect(context.Background())
	require.Error(t, err)
	assert.Nil(t, findings)
	assert.ErrorIs(t, err, expectedErr)
}
