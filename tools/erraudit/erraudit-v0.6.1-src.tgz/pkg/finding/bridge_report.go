package finding

import (
	"github.com/larsartmann/erraudit/pkg/version"
	findingsdk "github.com/larsartmann/go-finding"
)

// NewToolReport creates a go-finding Report with erraudit's tool info but no
// findings. Add findings yourself (after dedup/suppression) via AddFindings.
func NewToolReport() *findingsdk.Report {
	return findingsdk.NewReport(findingsdk.ToolInfo{
		Name:    toolName,
		Version: version.Version,
	})
}
