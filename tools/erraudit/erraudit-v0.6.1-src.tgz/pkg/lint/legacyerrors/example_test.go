package legacyerrors_test

import (
	"fmt"

	"github.com/larsartmann/erraudit/pkg/lint/legacyerrors"
)

func ExampleAnalyzer() {
	a := legacyerrors.Analyzer
	fmt.Println(a.Name)
	fmt.Println(a.Doc)
	// Output:
	// legacyerrors
	// detect uses of errors.As that should be replaced with errors.AsType (Go 1.26+)
}

func ExampleCategoryLegacyAs() {
	fmt.Println(legacyerrors.CategoryLegacyAs)
	fmt.Println(legacyerrors.CategoryLegacyIs)
	// Output:
	// legacy_as
	// legacy_is
}
