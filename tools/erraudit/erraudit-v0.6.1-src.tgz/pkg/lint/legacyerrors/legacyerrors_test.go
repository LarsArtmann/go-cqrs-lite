package legacyerrors_test

import (
	"testing"

	"github.com/larsartmann/erraudit/pkg/lint/legacyerrors"
	"golang.org/x/tools/go/analysis/analysistest"
)

func TestAnalyzer(t *testing.T) {
	testdata := analysistest.TestData()

	for _, pkg := range []string{"errorsas", "errorsis", "aliased", "sentinels", "sentineltypes"} {
		t.Run(pkg, func(t *testing.T) {
			analysistest.Run(t, testdata, legacyerrors.Analyzer, pkg)
		})
	}
}

func TestAnalyzerName(t *testing.T) {
	if legacyerrors.Analyzer.Name != "legacyerrors" {
		t.Errorf("expected analyzer name 'legacyerrors', got %q", legacyerrors.Analyzer.Name)
	}
}

func TestAnalyzerDoc(t *testing.T) {
	if legacyerrors.Analyzer.Doc == "" {
		t.Error("expected non-empty analyzer doc")
	}
}
