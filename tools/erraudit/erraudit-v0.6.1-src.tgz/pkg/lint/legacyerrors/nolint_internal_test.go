package legacyerrors

import "testing"

func TestIsBareNolint(t *testing.T) {
	tests := []struct {
		name string
		text string
		bare bool
	}{
		{name: "bare directive", text: "//nolint", bare: true},
		{name: "bare with reason", text: "//nolint // best-effort teardown", bare: true},
		{name: "bare with tab reason", text: "//nolint\treason", bare: true},
		{name: "targeted single linter", text: "//nolint:errcheck", bare: false},
		{name: "targeted with reason", text: "//nolint:legacyerrors // why", bare: false},
		{name: "other comment", text: "// regular comment", bare: false},
		{name: "empty comment", text: "//", bare: false},
		{name: "prefix-like word", text: "//nolintx", bare: false},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := isBareNolint(tt.text); got != tt.bare {
				t.Errorf("isBareNolint(%q) = %v, want %v", tt.text, got, tt.bare)
			}
		})
	}
}
