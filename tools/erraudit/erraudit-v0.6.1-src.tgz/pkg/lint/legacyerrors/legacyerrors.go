// Package legacyerrors provides a go/analysis linter that detects
// uses of the pre-Go 1.26 errors.As and errors.Is functions
// and suggests replacing them with the modern, generic errors.AsType.
//
// errors.AsType[E error](err error) (E, bool) is type-safe, faster,
// and produces cleaner code than the old pointer-target pattern.
package legacyerrors

import (
	"fmt"
	"go/ast"
	"go/token"
	"go/types"
	"os"
	"strings"
	"sync/atomic"

	apierrors "github.com/larsartmann/erraudit/pkg/errors"
	"golang.org/x/tools/go/analysis"
	"golang.org/x/tools/go/analysis/passes/inspect"
	"golang.org/x/tools/go/ast/inspector"
)

// DisableNolintSuppression, when true, causes the analyzer to emit diagnostics
// even for calls that have a //nolint:legacyerrors comment. The lint subcommand
// sets this so it can apply (or skip) suppression at the pipeline level via
// --no-suppress, giving users a single place to audit their suppression lists.
//
// Package-level state follows the go/analysis convention (cf. analysis.Flags).
// Callers MUST restore the previous value after their run to avoid leaking the
// toggle into concurrent consumers of the Analyzer.
//
//nolint:gochecknoglobals // package-level toggle following go/analysis convention (cf. analysis.Flags)
var DisableNolintSuppression atomic.Bool

const suppressComment = "nolint:legacyerrors"

const bareNolint = "//nolint"

const analyzerName = "legacyerrors"

// Diagnostic categories emitted by reportAs and reportIs. Consumers (notably
// internal/analyzer.convertLegacyDiagnostic) read these to classify each
// diagnostic into the correct ErrorType + Severity pair without parsing the
// human-readable message.
const (
	// CategoryLegacyAs marks errors.As calls — a real modernization with
	// high precision. Converted to ErrorTypeLegacyAs at SeverityMedium.
	CategoryLegacyAs = "legacy_as"

	// CategoryLegacyIs marks errors.Is calls that survived the sentinel
	// guard — an advisory that the call MIGHT benefit from AsType. Converted
	// to ErrorTypeLegacyIs at SeverityLow so --severity-threshold error
	// filters it out.
	CategoryLegacyIs = "legacy_is"

	// CategorySentinelConcreteType marks package-level sentinel vars
	// (Err*/err* names) whose declared or inferred type is a concrete error
	// implementation instead of the error interface. Converted to
	// ErrorTypeSentinelConcreteType at SeverityMedium. These declarations
	// are the ROOT CAUSE of legacy_is findings at every errors.Is call site
	// that matches them: isSentinelMatch only exempts vars whose declared
	// type is the error interface, so a concrete-typed sentinel makes each
	// call site unfixable without changing the declaration.
	CategorySentinelConcreteType = "sentinel_concrete_type"
)

// hasSuppressComment checks if the node has a //nolint:legacyerrors or bare
// //nolint comment on the same line or the line immediately above. The bare
// form follows the standard Go convention of suppressing all linters.
func hasSuppressComment(pass *analysis.Pass, node ast.Node) bool {
	nodePos := pass.Fset.Position(node.Pos())
	targetLine := nodePos.Line

	for _, file := range pass.Files {
		filePos := pass.Fset.Position(file.Pos())
		if filePos.Filename != nodePos.Filename {
			continue
		}

		for _, group := range file.Comments {
			for _, comment := range group.List {
				commentLine := pass.Fset.Position(comment.Pos()).Line
				if commentLine == targetLine || commentLine == targetLine-1 {
					if strings.Contains(comment.Text, suppressComment) {
						return true
					}

					if isBareNolint(comment.Text) {
						return true
					}
				}
			}
		}

		break
	}

	return false
}

// isBareNolint returns true for comments like "//nolint" or "//nolint // reason"
// but NOT for "//nolint:somelinter" which targets a specific linter.
func isBareNolint(text string) bool {
	trimmed := strings.TrimSpace(text)
	if !strings.HasPrefix(trimmed, bareNolint) {
		return false
	}

	rest := trimmed[len(bareNolint):]
	if rest == "" {
		return true
	}

	return strings.HasPrefix(rest, " ") || strings.HasPrefix(rest, "\t")
}

// Analyzer detects legacy errors.As/Is usage.
//
//nolint:gochecknoglobals // go/analysis requires Analyzer to be a package-level var
var Analyzer = &analysis.Analyzer{
	Name:             analyzerName,
	Doc:              "detect uses of errors.As that should be replaced with errors.AsType (Go 1.26+)",
	URL:              "https://pkg.go.dev/errors#AsType",
	Requires:         []*analysis.Analyzer{inspect.Analyzer},
	Run:              run,
	RunDespiteErrors: false,
}

func run(pass *analysis.Pass) (any, error) {
	insp, ok := pass.ResultOf[inspect.Analyzer].(*inspector.Inspector)
	if !ok {
		//nolint:nilnil // go/analysis requires (any, error) return; nil result with no error is valid
		return nil, nil
	}

	// Precompute call-site contexts for safe auto-fix generation.
	callSites := buildCallSites(pass.Files)

	nodeFilter := []ast.Node{
		(*ast.CallExpr)(nil),
		(*ast.GenDecl)(nil),
	}

	insp.Preorder(nodeFilter, func(n ast.Node) {
		switch node := n.(type) {
		case *ast.CallExpr:
			reportLegacyCall(pass, node, callSites)
		case *ast.GenDecl:
			reportConcreteSentinels(pass, node)
		}
	})

	//nolint:nilnil // go/analysis requires (any, error) return; nil result with no error is valid
	return nil, nil
}

// reportLegacyCall checks a single CallExpr for legacy errors.As/Is usage.
// Split out of run so the Preorder switch stays flat.
func reportLegacyCall(pass *analysis.Pass, call *ast.CallExpr, callSites map[*ast.CallExpr]callSite) {
	// Check for suppression comment on the same line or line above.
	// Skipped when DisableNolintSuppression is set: the lint subcommand
	// uses the toggle to move suppression to the pipeline level so
	// --no-suppress can audit the full violation list.
	if !DisableNolintSuppression.Load() && hasSuppressComment(pass, call) {
		return
	}

	sel, valid := call.Fun.(*ast.SelectorExpr)
	if !valid {
		return
	}

	ident, valid := sel.X.(*ast.Ident)
	if !valid {
		return
	}

	obj := pass.TypesInfo.Uses[ident]
	if obj == nil {
		return
	}

	pkgName, isPkg := obj.(*types.PkgName)
	if !isPkg || pkgName.Imported().Path() != "errors" {
		return
	}

	switch sel.Sel.Name {
	case "As":
		reportAs(pass, call, ident.Name, callSites)
	case "Is":
		reportIs(pass, call, ident.Name)
	}
}

// reportConcreteSentinels flags package-level sentinel vars (Err*/err* names)
// whose type is a concrete error implementation instead of the error
// interface. Fixing the declaration (var ErrX error = ...) is the ONLY way to
// make errors.Is(err, ErrX) call sites pass the sentinel guard, so the rule
// targets the root cause instead of the (unfixable) call sites.
func reportConcreteSentinels(pass *analysis.Pass, decl *ast.GenDecl) {
	if decl.Tok != token.VAR {
		return
	}

	for _, spec := range decl.Specs {
		valueSpec, ok := spec.(*ast.ValueSpec)
		if !ok {
			continue
		}

		for i, name := range valueSpec.Names {
			if !isSentinelVarName(name.Name) {
				continue
			}

			obj := pass.TypesInfo.Defs[name]
			if obj == nil {
				continue
			}

			// Package-level only: function-local Err* vars cannot be
			// matched by errors.Is from other packages and are rare.
			if obj.Parent() != pass.Pkg.Scope() {
				continue
			}

			// Correctly declared as (or inferred as) an interface: nothing
			// to fix. This is the state the rule wants. Underlying() covers
			// named interface types and aliases; pointers and structs have
			// non-interface underlying types and fall through.
			varType := obj.Type()
			if _, isIface := varType.Underlying().(*types.Interface); isIface {
				continue
			}

			if !implementsError(varType) {
				continue
			}

			if !DisableNolintSuppression.Load() && hasSuppressComment(pass, valueSpec) {
				continue
			}

			initText := ""
			if i < len(valueSpec.Values) {
				initText = types.ExprString(valueSpec.Values[i])
			}

			pass.Report(analysis.Diagnostic{
				Pos:      valueSpec.Pos(),
				End:      valueSpec.End(),
				Category: CategorySentinelConcreteType,
				Message: fmt.Sprintf(
					"sentinel %s has concrete type %s; declare it as the error interface "+
						"(var %s error = %s) so errors.Is(err, %s) call sites match the "+
						"sentinel guard instead of being flagged as legacy_is",
					name.Name, varType.String(), name.Name, initText, name.Name,
				),
			})
		}
	}
}

// isSentinelVarName reports whether a package-level var name follows Go's
// sentinel naming convention (Err* exported, err* unexported).
func isSentinelVarName(name string) bool {
	return strings.HasPrefix(name, "Err") || strings.HasPrefix(name, "err")
}

// errorInterface is the universe error interface, resolved once for
// Implements checks in implementsError.
//
//nolint:gochecknoglobals // derived once from types.Universe, immutable
var errorInterface = func() *types.Interface {
	iface, _ := types.Universe.Lookup("error").Type().Underlying().(*types.Interface)

	return iface
}()

// implementsError reports whether t implements the built-in error interface.
func implementsError(t types.Type) bool {
	return types.Implements(t, errorInterface)
}

// callSite describes the AST context in which a CallExpr appears.
// Only the relevant field is populated; the rest remain nil/zero.
type callSite struct {
	exprStmt   *ast.ExprStmt   // standalone expression statement: errors.As(err, &t)
	ifStmt     *ast.IfStmt     // condition of an if statement: if errors.As(...)
	negated    bool            // negated condition: if !errors.As(...)
	assignStmt *ast.AssignStmt // assignment: ok := errors.As(err, &t)
}

// buildCallSites maps each CallExpr to its surrounding statement context.
// It detects four patterns: standalone expression statements, direct if
// conditions, negated if conditions, and single-LHS assignments. All other
// contexts produce no entry.
func buildCallSites(files []*ast.File) map[*ast.CallExpr]callSite {
	sites := make(map[*ast.CallExpr]callSite)

	for _, file := range files {
		ast.Inspect(file, func(n ast.Node) bool {
			switch node := n.(type) {
			case *ast.ExprStmt:
				if call, ok := node.X.(*ast.CallExpr); ok {
					s := sites[call]
					s.exprStmt = node
					sites[call] = s
				}

			case *ast.IfStmt:
				// Direct condition: if errors.As(...)
				if call, ok := node.Cond.(*ast.CallExpr); ok {
					s := sites[call]
					s.ifStmt = node
					sites[call] = s
				}

				// Negated condition: if !errors.As(...)
				if unary, ok := node.Cond.(*ast.UnaryExpr); ok && unary.Op == token.NOT {
					if call, ok := unary.X.(*ast.CallExpr); ok {
						s := sites[call]
						s.ifStmt = node
						s.negated = true
						sites[call] = s
					}
				}

			case *ast.AssignStmt:
				// Single-LHS assignment: ok := errors.As(...) or ok = errors.As(...)
				if len(node.Lhs) == 1 && len(node.Rhs) == 1 {
					if call, ok := node.Rhs[0].(*ast.CallExpr); ok {
						s := sites[call]
						s.assignStmt = node
						sites[call] = s
					}
				}
			}

			return true
		})
	}

	return sites
}

const expectedArgCount = 2

// reportAs emits a diagnostic for errors.As usage with a suggested migration.
// Auto-fix TextEdits are generated for four patterns:
//   - Standalone expression statement: errors.As(err, &target)
//     (only when target is read afterward; otherwise advisory-only)
//   - Direct if condition: if errors.As(err, &target) {
//   - Negated if condition: if !errors.As(err, &target) {
//   - Assignment: ok := errors.As(err, &target)
//
// Patterns that cannot be safely transformed (compound conditions, return
// statements, standalone expr with unused target, etc.) emit a diagnostic
// without TextEdits.
func reportAs(
	pass *analysis.Pass,
	call *ast.CallExpr,
	pkgIdent string,
	sites map[*ast.CallExpr]callSite,
) {
	if len(call.Args) != expectedArgCount {
		return
	}

	typeExpr := extractTargetType(pass, call.Args[1])
	suggestion := buildAsSuggestion(pkgIdent, typeExpr)

	site := sites[call]

	var textEdits []analysis.TextEdit

	switch {
	case site.exprStmt != nil:
		textEdits = buildExprStmtEdits(pass, site.exprStmt, call, pkgIdent, typeExpr)
	case site.ifStmt != nil && !site.negated:
		textEdits = buildIfStmtEdits(pass, site.ifStmt, call, pkgIdent, typeExpr)
	case site.ifStmt != nil && site.negated:
		textEdits = buildNegatedIfStmtEdits(pass, site.ifStmt, call, pkgIdent, typeExpr)
	case site.assignStmt != nil:
		textEdits = buildAssignStmtEdits(pass, site.assignStmt, call, pkgIdent, typeExpr)
	}

	pass.Report(analysis.Diagnostic{
		Pos:     call.Pos(),
		End:     call.End(),
		Message: fmt.Sprintf("use errors.AsType instead of %s.As for type-safe, cleaner error matching", pkgIdent),
		SuggestedFixes: []analysis.SuggestedFix{{
			Message:   suggestion,
			TextEdits: textEdits,
		}},
		Category: CategoryLegacyAs,
	})
}

// buildExprStmtEdits generates TextEdits for a standalone expression statement:
//
//	var target *FooError
//	errors.As(err, &target)
//	// target is used later...
//	→
//	var target *FooError
//	target, _ = errors.AsType[*FooError](err)
//	// target is used later...
//
// The standalone pattern is only auto-fixable when target is read after the
// expression statement. In the original code, &target counts as a "use" of
// target (taking its address). After migration, target, _ = ... only assigns
// to target — it does NOT count as a use. If target is never read afterward,
// the fixed code would trigger "declared and not used". In that case no fix
// is generated (the diagnostic remains advisory-only).
func buildExprStmtEdits(
	pass *analysis.Pass,
	exprStmt *ast.ExprStmt,
	call *ast.CallExpr,
	pkgIdent, typeExpr string,
) []analysis.TextEdit {
	return withStrictContext(pass, exprStmt, call, typeExpr, func(ctx asCallContext) []analysis.TextEdit {
		// Target must be read after the expression statement. In the original
		// code, &target counts as a use (address-of is a read). After migration,
		// target, _ = ... only assigns. Without a subsequent read, Go would flag
		// "declared and not used".
		if !isIdentUsedAfter(pass, ctx.targetVar, exprStmt.End(), ctx.funcDecl) {
			return nil
		}

		newText := fmt.Sprintf("%s, _ = %s.AsType[%s](%s)", ctx.targetName, pkgIdent, typeExpr, ctx.arg0Text)

		return []analysis.TextEdit{{
			Pos:     exprStmt.Pos(),
			End:     exprStmt.End(),
			NewText: []byte(newText),
		}}
	})
}

// buildIfStmtEdits generates TextEdits for a direct if condition:
//
//	var target *FooError
//	if errors.As(err, &target) {
//	→
//	if target, ok := errors.AsType[*FooError](err); ok {
//
// The var declaration is removed. This requires that target is NOT used
// after the if block (scope analysis prevents silent value loss).
func buildIfStmtEdits(
	pass *analysis.Pass,
	ifStmt *ast.IfStmt,
	call *ast.CallExpr,
	pkgIdent, typeExpr string,
) []analysis.TextEdit {
	return withStrictContext(pass, ifStmt, call, typeExpr, func(ctx asCallContext) []analysis.TextEdit {
		// target must NOT be used after the if block — otherwise scoping it
		// into the if-init would silently lose the value.
		if isIdentUsedAfter(pass, ctx.targetVar, ifStmt.End(), ctx.funcDecl) {
			return nil
		}

		// target must NOT be used between its declaration and the if — otherwise
		// scoping it into the if-init would shadow the outer variable.
		if isIdentUsedBetween(pass, ctx.targetVar, ctx.targetVar.Pos(), ifStmt.Pos(), ctx.funcDecl) {
			return nil
		}

		declRemoval, ok := findVarDeclRemoval(pass, ctx.targetVar, ctx.funcDecl.Body)
		if !ok {
			return nil
		}

		// If target is not used inside the if body NOR the else branch, use _
		// to avoid "declared and not used" in the if-init clause. The if-init
		// binding is in scope for both branches, so keeping the name is always
		// compilable; `_` is only safe when no branch reads the target.
		effectiveName := ctx.targetName
		if !isTargetReadIn(pass, ctx.targetVar, ifStmt.Body) &&
			(ifStmt.Else == nil || !isTargetReadIn(pass, ctx.targetVar, ifStmt.Else)) {
			effectiveName = "_"
		}

		newCond := fmt.Sprintf("if %s, ok := %s.AsType[%s](%s); ok", effectiveName, pkgIdent, typeExpr, ctx.arg0Text)

		return []analysis.TextEdit{
			declRemoval,
			{
				Pos:     ifStmt.Pos(),
				End:     ifStmt.Cond.End(),
				NewText: []byte(newCond),
			},
		}
	})
}

// buildNegatedIfStmtEdits generates TextEdits for a negated if condition:
//
//	var target *FooError
//	if !errors.As(err, &target) {
//	    return
//	}
//	→
//	target, ok := errors.AsType[*FooError](err)
//	if !ok {
//	    return
//	}
//
// The call is hoisted out of the if into a preceding statement, and the
// condition is simplified to !ok. The var declaration is removed when
// possible; if it cannot be found the fix is still valid (just leaves a
// redundant declaration).
func buildNegatedIfStmtEdits(
	pass *analysis.Pass,
	ifStmt *ast.IfStmt,
	call *ast.CallExpr,
	pkgIdent, typeExpr string,
) []analysis.TextEdit {
	return withLenientContext(pass, ifStmt, call, typeExpr, func(ctx asCallContext) []analysis.TextEdit {
		indent := lineIndent(pass, ifStmt.Pos())
		effectiveName := resolveEffectiveName(pass, ctx, ifStmt.End())

		newHeader := fmt.Sprintf("%s, ok := %s.AsType[%s](%s)\n%sif !ok",
			effectiveName, pkgIdent, typeExpr, ctx.arg0Text, indent)

		edits := []analysis.TextEdit{{
			Pos:     ifStmt.Pos(),
			End:     ifStmt.Cond.End(),
			NewText: []byte(newHeader),
		}}

		return appendVarDeclRemoval(edits, pass, ctx, ifStmt.Pos())
	})
}

// buildAssignStmtEdits generates TextEdits for an assignment pattern:
//
//	var target *FooError
//	ok := errors.As(err, &target)
//	→
//	target, ok := errors.AsType[*FooError](err)
//
// The var declaration is removed when safe. Uses the same scope analysis
// as the if-statement patterns to prevent shadowing and broken references.
func buildAssignStmtEdits(
	pass *analysis.Pass,
	assignStmt *ast.AssignStmt,
	call *ast.CallExpr,
	pkgIdent, typeExpr string,
) []analysis.TextEdit {
	return withLenientContext(pass, assignStmt, call, typeExpr, func(ctx asCallContext) []analysis.TextEdit {
		lhsIdent, ok := assignStmt.Lhs[0].(*ast.Ident)
		if !ok {
			return nil
		}

		assignOp := ":="
		if assignStmt.Tok != token.DEFINE {
			assignOp = "="
		}

		effectiveName := resolveEffectiveName(pass, ctx, assignStmt.End())
		newText := fmt.Sprintf("%s, %s %s %s.AsType[%s](%s)",
			effectiveName, lhsIdent.Name, assignOp, pkgIdent, typeExpr, ctx.arg0Text)

		edits := []analysis.TextEdit{{
			Pos:     assignStmt.Pos(),
			End:     assignStmt.End(),
			NewText: []byte(newText),
		}}

		return appendVarDeclRemoval(edits, pass, ctx, assignStmt.Pos())
	})
}

// reportIs emits an advisory diagnostic for errors.Is usage.
//
// Sentinel matches (errors.Is(err, io.EOF), errors.Is(err, pkg.ErrFoo), etc.)
// are silently skipped: errors.Is is the documented, correct API for value
// matching, and flagging those calls produces false positives that erode trust
// in the linter (see docs/feedback/new/2026-07-21_errors-is-sentinel-*.md).
// Only calls where the second argument is NOT a recognizable sentinel survive
// the guard — those are the cases that MIGHT benefit from errors.AsType.
func reportIs(pass *analysis.Pass, call *ast.CallExpr, pkgIdent string) {
	if len(call.Args) != expectedArgCount {
		return
	}

	if isSentinelMatch(pass, call.Args[1]) {
		return
	}

	reportLegacyDiagnostic(
		pass,
		call,
		pkgIdent,
		CategoryLegacyIs,
		"errors.Is is correct for sentinel value matches (io.EOF, sql.ErrNoRows, "+
			"syscall.EXDEV, package-level var Err*); only migrate to %s.AsType "+
			"if the target is a typed custom error AND you need to read its fields",
		extractIsTargetType,
		buildIsSuggestion,
	)
}

// isSentinelMatch reports whether the second argument to errors.Is is a
// sentinel value — the use case for which errors.Is is the documented API.
//
// Recognized sentinel shapes (any one triggers a skip):
//
//   - *types.Const (e.g. syscall.EXDEV, syscall.ECONNRESET) — typed and
//     untyped constants exported by stdlib and most third-party packages.
//   - *types.Var whose type is exactly the universe `error` interface
//     (e.g. io.EOF, context.Canceled, var ErrFoo = errors.New(...)).
//     Catches every sentinel initialized from errors.New/fmt.Errorf and
//     every stdlib sentinel regardless of naming convention.
//   - *types.Var whose name begins with "Err" (e.g. ErrNotFound, ErrFoo) —
//     catches typed sentinels (`var ErrFoo *MyError`) that don't satisfy
//     the error-interface check but follow Go's sentinel naming convention.
//
// Returning true means "errors.Is is correct here; do not flag."
//
// The guard is conservative: it never skips a real migration. A PACKAGE-LEVEL
// typed var used as the second argument to errors.Is without an Err* name is
// still flagged (that is the misuse the linter exists to catch), and so is a
// function-local ZERO-VALUE declaration (`var customErr *CustomError` with no
// initializer — the canonical errors.As-mistyped-as-Is pattern, since a zero
// value can never value-match). Function-local variables that ARE initialized
// (or parameters) are live runtime values being value-matched: errors.Is is
// the correct API for them (2026-09-22 false-positive fix — a local wrap
// result like `inner := errorfamily.NewRejection(...)` used to be flagged).
// Users whose sentinels fall outside these shapes can rename, suppress with
// a suppression comment, or extend this heuristic.
func isSentinelMatch(pass *analysis.Pass, arg ast.Expr) bool {
	ident := sentinelIdent(arg)
	if ident == nil {
		return false
	}

	obj := pass.TypesInfo.Uses[ident]
	if obj == nil {
		return false
	}

	// Const sentinels: syscall.EXDEV, syscall.ECONNRESET, etc.
	if _, ok := obj.(*types.Const); ok {
		return true
	}

	variable, ok := obj.(*types.Var)
	if !ok {
		return false
	}

	// error-typed vars are sentinels by definition: errors.Is's value-match
	// semantics is exactly the right API for them. Covers io.EOF,
	// context.Canceled, context.DeadlineExceeded, and every errors.New /
	// fmt.Errorf sentinel regardless of naming convention.
	if isErrorInterface(variable.Type()) {
		return true
	}

	// Live local values (initialized locals, parameters) are value-matched,
	// not declared: errors.Is is correct for them. Only zero-value local
	// declarations keep the advisory. Package-level vars fall through to the
	// naming check so the typed-var misuse stays visible.
	if !isPackageLevelVar(pass, variable) {
		if spec := declaringValueSpec(pass, variable); spec == nil || len(spec.Values) > 0 {
			return true
		}
	}

	// Typed sentinels that follow the Go naming convention
	// (var ErrFoo *MyError). These don't satisfy the error-interface check
	// but the Err prefix is the documented sentinel convention.
	return strings.HasPrefix(variable.Name(), "Err")
}

// isPackageLevelVar reports whether v is declared in the analyzed package's
// package scope (not inside a function, not a struct field, not a parameter).
// Vars from OTHER packages compare false: they are not part of the code being
// linted, so they are treated as live values like locals.
func isPackageLevelVar(pass *analysis.Pass, v *types.Var) bool {
	return v.Parent() != nil && v.Parent() == pass.Pkg.Scope()
}

// declaringValueSpec returns the *ast.ValueSpec that declares v, or nil when
// the declaration is not a var spec (parameters, fields, short decls inside
// type switches, ...). Errors.Is call sites are rare, so the per-call file
// scan is not a hot path.
func declaringValueSpec(pass *analysis.Pass, v *types.Var) *ast.ValueSpec {
	for _, f := range pass.Files {
		if v.Pos() < f.Pos() || v.Pos() > f.End() {
			continue
		}

		var spec *ast.ValueSpec

		ast.Inspect(f, func(n ast.Node) bool {
			vs, ok := n.(*ast.ValueSpec)
			if !ok {
				return true
			}

			for _, name := range vs.Names {
				if name.Pos() == v.Pos() {
					spec = vs

					return false
				}
			}

			return true
		})

		if spec != nil {
			return spec
		}
	}

	return nil
}

// isErrorInterface reports whether t is exactly the universe `error`
// interface type — not a type that merely implements error. We compare
// against the universe scope so user-defined interfaces named "error" (which
// would require shadowing the universe type) don't trigger a false skip.
func isErrorInterface(t types.Type) bool {
	errObj := types.Universe.Lookup("error")
	if errObj == nil {
		return false
	}

	return types.Identical(t, errObj.Type())
}

// sentinelIdent extracts the *ast.Ident that errors.Is's second argument
// resolves to. Handles bare identifiers (ErrFoo) and qualified selector
// expressions (pkg.ErrFoo, io.EOF). Returns nil for any other shape.
func sentinelIdent(arg ast.Expr) *ast.Ident {
	switch a := arg.(type) {
	case *ast.Ident:
		return a
	case *ast.SelectorExpr:
		return a.Sel
	default:
		return nil
	}
}

// reportLegacyDiagnostic emits a diagnostic with a suggested fix for legacy errors usage.
func reportLegacyDiagnostic(
	pass *analysis.Pass,
	call *ast.CallExpr,
	pkgIdent string,
	category string,
	messageFmt string,
	extractFn func(*analysis.Pass, ast.Expr) string,
	suggestFn func(string, string) string,
) {
	typeExpr := extractFn(pass, call.Args[1])
	suggestion := suggestFn(pkgIdent, typeExpr)

	pass.Report(analysis.Diagnostic{
		Pos:     call.Pos(),
		End:     call.End(),
		Message: fmt.Sprintf(messageFmt, pkgIdent),
		SuggestedFixes: []analysis.SuggestedFix{{
			Message:   suggestion,
			TextEdits: nil,
		}},
		Category: category,
	})
}

// prepareAsCall validates the call and extracts the pieces every build*Edits
// helper needs: the resolved target identifier name and the source text of
// the error argument. Returns ok=false when the call lacks a resolvable
// type/name; callers MUST return nil in that case.
//
// Collapsing "validate target name + read arg0 source" into one helper
// eliminates the repeated prelude shared by every build*Edits function.
func prepareAsCall(pass *analysis.Pass, typeExpr string, call *ast.CallExpr) (string, string, bool) {
	if typeExpr == "" {
		return "", "", false
	}

	name := extractTargetName(call.Args[1])
	if name == "" {
		return "", "", false
	}

	return name, sourceText(pass, call.Args[0]), true
}

// asCallContext bundles the per-call state every build*Edits helper needs
// after the initial validation. Built by resolveAsCallContext.
type asCallContext struct {
	targetName string
	arg0Text   string
	targetVar  *types.Var
	funcDecl   *ast.FuncDecl
}

// resolveAsCallContext validates the call, extracts its source text, looks
// up the target identifier's declaration, and finds the enclosing function
// of node. Returns ok=false when any of those prerequisites are missing;
// callers MUST return nil in that case.
//
// This is the shared prelude for buildExprStmtEdits and buildIfStmtEdits;
// the other two helpers do their own target-var resolution.
func resolveAsCallContext(
	pass *analysis.Pass,
	node ast.Node,
	call *ast.CallExpr,
	typeExpr string,
) (asCallContext, bool) {
	targetName, arg0Text, ok := prepareAsCall(pass, typeExpr, call)
	if !ok {
		return asCallContext{}, false //nolint:exhaustruct_v5 // intentional zero-value "not found" sentinel
	}

	targetVar := findTargetVar(pass, call.Args[1])
	if targetVar == nil {
		return asCallContext{}, false //nolint:exhaustruct_v5 // intentional zero-value "not found" sentinel
	}

	funcDecl := enclosingFuncDecl(pass, node)
	if funcDecl == nil || funcDecl.Body == nil {
		return asCallContext{}, false //nolint:exhaustruct_v5 // intentional zero-value "not found" sentinel
	}

	return asCallContext{
		targetName: targetName,
		arg0Text:   arg0Text,
		targetVar:  targetVar,
		funcDecl:   funcDecl,
	}, true
}

// withStrictContext resolves the call context requiring a non-nil target
// variable and enclosing function, then invokes build with the validated
// context. Returns nil when the prerequisites are missing.
func withStrictContext(
	pass *analysis.Pass,
	node ast.Node,
	call *ast.CallExpr,
	typeExpr string,
	build func(ctx asCallContext) []analysis.TextEdit,
) []analysis.TextEdit {
	ctx, ok := resolveAsCallContext(pass, node, call, typeExpr)
	if !ok {
		return nil
	}

	return build(ctx)
}

// withLenientContext resolves the call context tolerating a missing target
// variable or enclosing function. The core migration edit is still produced;
// only var-decl removal is skipped when the target is unavailable.
func withLenientContext(
	pass *analysis.Pass,
	node ast.Node,
	call *ast.CallExpr,
	typeExpr string,
	build func(ctx asCallContext) []analysis.TextEdit,
) []analysis.TextEdit {
	targetName, arg0Text, ok := prepareAsCall(pass, typeExpr, call)
	if !ok {
		return nil
	}

	return build(asCallContext{
		targetName: targetName,
		arg0Text:   arg0Text,
		targetVar:  findTargetVar(pass, call.Args[1]),
		funcDecl:   enclosingFuncDecl(pass, node),
	})
}

// resolveEffectiveName returns the target name to use in generated code,
// substituting "_" when the target is not read after endPos (prevents
// "declared and not used"). Tolerates a nil targetVar or funcDecl.
func resolveEffectiveName(pass *analysis.Pass, ctx asCallContext, endPos token.Pos) string {
	if ctx.targetVar == nil || ctx.funcDecl == nil || ctx.funcDecl.Body == nil {
		return ctx.targetName
	}

	if !isIdentUsedAfter(pass, ctx.targetVar, endPos, ctx.funcDecl) {
		return "_"
	}

	return ctx.targetName
}

// appendVarDeclRemoval best-effort appends a var-declaration removal edit
// when target is not referenced between its declaration and stmtPos. It is
// a no-op when the target variable or enclosing function is unavailable.
func appendVarDeclRemoval(
	edits []analysis.TextEdit,
	pass *analysis.Pass,
	ctx asCallContext,
	stmtPos token.Pos,
) []analysis.TextEdit {
	if ctx.targetVar == nil || ctx.funcDecl == nil || ctx.funcDecl.Body == nil {
		return edits
	}

	if isIdentUsedBetween(pass, ctx.targetVar, ctx.targetVar.Pos(), stmtPos, ctx.funcDecl) {
		return edits
	}

	if declRemoval, ok := findVarDeclRemoval(pass, ctx.targetVar, ctx.funcDecl.Body); ok {
		return append(edits, declRemoval)
	}

	return edits
}

// extractTargetName extracts the identifier name from &target in errors.As(err, &target).
func extractTargetName(arg ast.Expr) string {
	unary, ok := arg.(*ast.UnaryExpr)
	if !ok || unary.Op != token.AND {
		return ""
	}

	ident, ok := unary.X.(*ast.Ident)
	if !ok {
		return ""
	}

	return ident.Name
}

// sourceText returns the original source text for the given AST node.
// It prefers pass.ReadFile when available (allows virtualized file trees
// and avoids redundant disk I/O), falling back to os.ReadFile.
func sourceText(pass *analysis.Pass, node ast.Node) string {
	pos := pass.Fset.Position(node.Pos())
	end := pass.Fset.Position(node.End())

	content, err := readSourceFile(pass, pos.Filename)
	if err != nil {
		return ""
	}

	return string(content[pos.Offset:end.Offset])
}

// readSourceFile reads a source file, preferring pass.ReadFile when available.
func readSourceFile(pass *analysis.Pass, filename string) ([]byte, error) {
	read := pass.ReadFile
	if read == nil {
		read = os.ReadFile
	}

	return readFileWith(read, filename)
}

// readFileWith invokes read and wraps any I/O error with the filename.
// Centralizes the "read bytes, return wrapped error" idiom used by both
// the pass.ReadFile and os.ReadFile branches of readSourceFile.
func readFileWith(read func(string) ([]byte, error), filename string) ([]byte, error) {
	content, err := read(filename)
	if err != nil {
		return nil, apierrors.Wrap(err, "read source file %s", filename)
	}

	return content, nil
}

// extractTargetType resolves the concrete type from the second argument of
// errors.As(err, &target). Returns the type string relative to the package
// being analyzed and its imports (e.g. "*FooError" for in-package types,
// "*other.Alias" for imported types) or "".
func extractTargetType(pass *analysis.Pass, arg ast.Expr) string {
	unary, valid := arg.(*ast.UnaryExpr)
	if !valid || unary.Op.String() != "&" {
		return ""
	}

	ident, valid := unary.X.(*ast.Ident)
	if !valid {
		return ""
	}

	obj := pass.TypesInfo.Uses[ident]
	if obj == nil {
		return ""
	}

	variable, valid := obj.(*types.Var)
	if !valid {
		return ""
	}

	qf := qualifierFor(pass, arg)

	return types.TypeString(variable.Type(), qf)
}

// qualifierFor returns a types.Qualifier that uses the import aliases from
// the file containing the given node. In-package types are unqualified.
func qualifierFor(pass *analysis.Pass, node ast.Node) types.Qualifier {
	file := fileForNode(pass, node)
	if file == nil {
		return types.RelativeTo(pass.Pkg)
	}

	aliases := importAliases(file)

	return func(pkg *types.Package) string {
		if pkg == pass.Pkg {
			return ""
		}

		if alias, ok := aliases[pkg.Path()]; ok {
			return alias
		}

		return pkg.Name()
	}
}

// fileForNode finds the *ast.File that contains the given node.
func fileForNode(pass *analysis.Pass, node ast.Node) *ast.File {
	pos := node.Pos()

	for _, f := range pass.Files {
		if f.Pos() <= pos && pos < f.End() {
			return f
		}
	}

	return nil
}

// importAliases builds a map from import path to alias/name for the file.
func importAliases(file *ast.File) map[string]string {
	aliases := make(map[string]string)

	for _, imp := range file.Imports {
		path := strings.Trim(imp.Path.Value, `"`)

		if imp.Name != nil {
			aliases[path] = imp.Name.Name
		} else {
			// Best-effort: derive package name from last path segment.
			aliases[path] = pathBase(path)
		}
	}

	return aliases
}

// pathBase returns the last path segment, roughly equivalent to path.Base
// without importing path for this single use.
func pathBase(importPath string) string {
	for i := len(importPath) - 1; i >= 0; i-- {
		if importPath[i] == '/' {
			return importPath[i+1:]
		}
	}

	return importPath
}

// extractIsTargetType resolves the type of the target argument in errors.Is.
func extractIsTargetType(pass *analysis.Pass, arg ast.Expr) string {
	ident, valid := arg.(*ast.Ident)
	if !valid {
		return ""
	}

	obj := pass.TypesInfo.Uses[ident]
	if obj == nil {
		return ""
	}

	switch resolved := obj.(type) {
	case *types.Var:
		return types.TypeString(resolved.Type(), qualifierFor(pass, arg))
	case *types.Const:
		return types.TypeString(resolved.Type(), qualifierFor(pass, arg))
	case *types.Func:
		return resolved.Name()
	}

	return ""
}

// buildAsSuggestion creates a human-readable suggestion for replacing errors.As.
func buildAsSuggestion(pkgIdent, typeExpr string) string {
	//art-dupl:accept idiomatic empty-string default guard, 3 lines, unrelated packages, different defaults and domains
	if typeExpr == "" {
		typeExpr = "*YourError"
	}

	return fmt.Sprintf("Replace:  var target %s; %s.As(err, &target)\n"+
		"With:     target, ok := %s.AsType[%s](err)",
		typeExpr, pkgIdent, pkgIdent, typeExpr)
}

// buildIsSuggestion creates a suggestion for errors.Is.
func buildIsSuggestion(pkgIdent, typeExpr string) string {
	if typeExpr != "" && strings.HasPrefix(typeExpr, "*") {
		return fmt.Sprintf(
			"If matching by type, use:  target, ok := %s.AsType[%s](err)",
			pkgIdent,
			typeExpr,
		)
	}

	return fmt.Sprintf(
		"If you need type-based matching, use:  target, ok := %s.AsType[*YourError](err)",
		pkgIdent,
	)
}

// findTargetVar resolves the *types.Var from the &target expression in
// errors.As(err, &target). Returns nil if the argument is not &ident or
// ident does not resolve to a variable.
func findTargetVar(pass *analysis.Pass, arg ast.Expr) *types.Var {
	unary, ok := arg.(*ast.UnaryExpr)
	if !ok || unary.Op != token.AND {
		return nil
	}

	ident, ok := unary.X.(*ast.Ident)
	if !ok {
		return nil
	}

	varObj, ok := pass.TypesInfo.Uses[ident].(*types.Var)
	if !ok {
		return nil
	}

	return varObj
}

// enclosingFuncDecl finds the *ast.FuncDecl that contains the given node.
func enclosingFuncDecl(pass *analysis.Pass, node ast.Node) *ast.FuncDecl {
	pos := node.Pos()

	for _, file := range pass.Files {
		if file.Pos() > pos || pos >= file.End() {
			continue
		}

		for _, decl := range file.Decls {
			fn, ok := decl.(*ast.FuncDecl)
			if !ok {
				continue
			}

			if fn.Pos() <= pos && pos < fn.End() {
				return fn
			}
		}
	}

	return nil
}

// isIdentUsedAfter reports whether the given variable is referenced anywhere
// in funcBody at a position strictly after afterPos. This is used for scope
// analysis: if target is used after the if block, we cannot safely scope it
// into the if-init clause.
func isIdentUsedAfter(pass *analysis.Pass, target *types.Var, afterPos token.Pos, funcDecl *ast.FuncDecl) bool {
	return isIdentUsedBetween(pass, target, afterPos, token.NoPos, funcDecl)
}

// isTargetReadIn reports whether the target variable is read (used) anywhere
// within the given AST node. Used to decide whether to emit `target, ...` or
// `_, ...` in fix output, preventing "declared and not used" compile errors.
func isTargetReadIn(pass *analysis.Pass, target *types.Var, node ast.Node) bool {
	found := false

	ast.Inspect(node, func(n ast.Node) bool {
		if found {
			return false
		}

		ident, ok := n.(*ast.Ident)
		if !ok {
			return true
		}

		if pass.TypesInfo.Uses[ident] == target {
			found = true
		}

		return true
	})

	return found
}

// isIdentUsedBetween reports whether the given variable is referenced at a
// position strictly after fromPos and (if toPos is valid) strictly before
// toPos. Used to detect usage between the var declaration and the if statement.
func isIdentUsedBetween(
	pass *analysis.Pass,
	target *types.Var,
	fromPos, toPos token.Pos,
	funcDecl *ast.FuncDecl,
) bool {
	found := false

	ast.Inspect(funcDecl, func(n ast.Node) bool {
		if found {
			return false
		}

		ident, ok := n.(*ast.Ident)
		if !ok {
			return true
		}

		if ident.Pos() <= fromPos {
			return true
		}

		if toPos.IsValid() && ident.Pos() >= toPos {
			return true
		}

		if pass.TypesInfo.Uses[ident] == target {
			found = true
		}

		return true
	})

	return found
}

// findVarDeclRemoval searches funcBody for a standalone var declaration
// (single spec, single name) matching targetVar and returns a TextEdit
// that removes it including the trailing newline.
func findVarDeclRemoval(pass *analysis.Pass, targetVar *types.Var, funcBody *ast.BlockStmt) (analysis.TextEdit, bool) {
	var found *ast.DeclStmt

	ast.Inspect(funcBody, func(n ast.Node) bool {
		if found != nil {
			return false
		}

		declStmt, ok := n.(*ast.DeclStmt)
		if !ok {
			return true
		}

		genDecl, ok := declStmt.Decl.(*ast.GenDecl)
		if !ok || genDecl.Tok != token.VAR {
			return true
		}

		if len(genDecl.Specs) != 1 {
			return true
		}

		valueSpec, ok := genDecl.Specs[0].(*ast.ValueSpec)
		if !ok || len(valueSpec.Names) != 1 {
			return true
		}

		// Skip vars with initializers — removing them would lose side effects.
		if len(valueSpec.Values) > 0 {
			return true
		}

		if pass.TypesInfo.Defs[valueSpec.Names[0]] == targetVar {
			found = declStmt

			return false
		}

		return true
	})

	if found == nil {
		return analysis.TextEdit{}, false //nolint:exhaustruct_v5 // intentional zero-value "not found" sentinel
	}

	// Extend the removal range to include the full line: leading indentation
	// through the trailing newline. This prevents leftover whitespace.
	startPos := found.Pos()
	end := found.End()

	startPosInfo := pass.Fset.Position(startPos)
	endPosInfo := pass.Fset.Position(end)

	content, err := readSourceFile(pass, startPosInfo.Filename)
	if err == nil {
		// Walk start backwards to include leading whitespace (indentation).
		startOffset := startPosInfo.Offset
		for startOffset > 0 && (content[startOffset-1] == '\t' || content[startOffset-1] == ' ') {
			startOffset--
		}

		startPos -= token.Pos(startPosInfo.Offset - startOffset)

		// Walk end forward to include the trailing newline.
		endOffset := endPosInfo.Offset
		if endOffset < len(content) && content[endOffset] == '\n' {
			end++
		}
	}

	return analysis.TextEdit{
		Pos:     startPos,
		End:     end,
		NewText: []byte{},
	}, true
}

// lineIndent returns the whitespace (tabs/spaces) at the beginning of the
// line containing pos. Used to indent inserted statements.
func lineIndent(pass *analysis.Pass, pos token.Pos) string {
	filePos := pass.Fset.Position(pos)

	content, err := readSourceFile(pass, filePos.Filename)
	if err != nil {
		return "\t"
	}

	lineStart := max(filePos.Offset-filePos.Column+1, 0)

	var indent []byte

	for i := lineStart; i < len(content) && (content[i] == '\t' || content[i] == ' '); i++ {
		indent = append(indent, content[i])
	}

	if len(indent) == 0 {
		return "\t"
	}

	return string(indent)
}
