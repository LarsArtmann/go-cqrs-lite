package aliased

import (
	errs "errors"
)

type NotFoundError struct {
	msg string
}

func (e *NotFoundError) Error() string { return e.msg }

func aliasedAs(err error) {
	var target *NotFoundError
	if errs.As(err, &target) { // want `use errors.AsType instead of errs.As for type-safe, cleaner error matching`
		_ = target
	}
}

func aliasedIs(err error) {
	var sentinel *NotFoundError
	_ = errs.Is(err, sentinel) // want `errs\.AsType`
}
