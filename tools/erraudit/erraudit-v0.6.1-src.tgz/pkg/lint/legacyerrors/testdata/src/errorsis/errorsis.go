package errorsis

import "errors"

var ErrNotFound = errors.New("not found")

// oldIsPattern uses errors.Is against a typed local variable — the pattern
// the linter SHOULD flag, because errors.Is performs value comparison while
// the intent here is type matching. This is the canonical "real migration"
// case for errors.Is → errors.AsType.
func oldIsPattern(err error) {
	var customErr *CustomError
	if errors.Is(err, customErr) { // want `errors\.AsType`
		_ = err
	}
}

// sentinelMatch is the canonical sentinel pattern and MUST NOT be flagged.
// errors.Is is the documented API for sentinel value matching.
func sentinelMatch(err error) {
	if errors.Is(err, ErrNotFound) {
		_ = err
	}
}

func alreadyModern(err error) {
	target, ok := errors.AsType[*CustomError](err)
	_ = target
	_ = ok
}

type CustomError struct {
	msg string
}

func (e *CustomError) Error() string { return e.msg }

func newCustomMsg() *CustomError { return &CustomError{msg: "live"} }

// liveLocalConcrete value-matches an INITIALIZED local: a live runtime value,
// for which errors.Is is the correct API. NOT flagged (2026-09-22 FP fix —
// local wrap results like `inner := errorfamily.NewRejection(...)` used to be
// flagged here).
func liveLocalConcrete(err error) {
	inner := newCustomMsg()
	if errors.Is(err, inner) {
		_ = err
	}
}

// paramTarget value-matches a typed parameter: also a live value, NOT flagged.
func paramTarget(err error, target *CustomError) {
	if errors.Is(err, target) {
		_ = err
	}
}
