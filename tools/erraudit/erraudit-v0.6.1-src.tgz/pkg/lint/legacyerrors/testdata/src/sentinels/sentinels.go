package sentinels

import (
	"errors"
	"io"
	"syscall"
)

// ErrNotFound is the textbook user-defined sentinel: package-level var,
// name prefixed with Err, initialized from errors.New. The linter must NOT
// flag errors.Is(err, ErrNotFound).
var ErrNotFound = errors.New("not found")

// ErrValidation is a second in-package sentinel exercising the same path
// with a different name, ensuring the heuristic isn't name-specific.
var ErrValidation = errors.New("validation failed")

// constSentinel exercises the *types.Const branch: syscall.EXDEV is a typed
// constant of type syscall.Errno. The stdlib itself documents
// errors.Is(err, syscall.EXDEV) as the correct API.
func constSentinel(err error) {
	if errors.Is(err, syscall.EXDEV) {
		_ = err
	}
}

// stdlibSentinel exercises the *types.Const branch against io.EOF, the
// canonical sentinel from the standard library.
func stdlibSentinel(err error) {
	if errors.Is(err, io.EOF) {
		_ = err
	}
}

// varSentinel exercises the *types.Var + Err-prefix branch against an
// in-package var initialized from errors.New.
func varSentinel(err error) {
	if errors.Is(err, ErrNotFound) {
		_ = err
	}
}

// secondVarSentinel exercises the same branch against a different in-package
// sentinel, ensuring the heuristic is consistent across multiple vars.
func secondVarSentinel(err error) {
	if errors.Is(err, ErrValidation) {
		_ = err
	}
}
