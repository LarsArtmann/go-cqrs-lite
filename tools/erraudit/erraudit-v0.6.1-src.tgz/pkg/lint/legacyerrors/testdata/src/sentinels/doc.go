// Package sentinels is a negative-test fixture: every errors.Is call in this
// file targets a recognized sentinel value and MUST NOT produce a diagnostic.
// The analysistest harness fails if the analyzer emits anything here.
package sentinels
