package errorsas

import "errors"

type CustomError struct {
	msg string
}

func (e *CustomError) Error() string { return e.msg }

func oldAsPattern(err error) {
	var target *CustomError
	if errors.As(err, &target) { // want `use errors.AsType instead of errors.As for type-safe, cleaner error matching`
		_ = target
	}
}

func oldAsAssigned(err error) {
	var customErr *CustomError
	ok := errors.As( // want `use errors.AsType instead of errors.As for type-safe, cleaner error matching`
		err,
		&customErr,
	)
	_ = ok
}

func alreadyModern(err error) {
	target, ok := errors.AsType[*CustomError](err)
	_ = target
	_ = ok
}
