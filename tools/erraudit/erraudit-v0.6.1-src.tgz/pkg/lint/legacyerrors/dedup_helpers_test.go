package legacyerrors

import (
	"go/ast"
	"go/token"
	"go/types"
	"testing"

	"github.com/larsartmann/erraudit/internal/testutil"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"golang.org/x/tools/go/analysis"
)

// analysisFixture holds the parsed and type-checked state for a test source.
type analysisFixture struct {
	pass *analysis.Pass
	file *ast.File
	fset *token.FileSet
	src  string
}

// newFixture parses and type-checks src, returning a fixture with a fully
// populated *analysis.Pass whose ReadFile returns src from memory.
func newFixture(t *testing.T, src string) analysisFixture {
	t.Helper()

	pr := testutil.ParseAndTypeCheck(t, "fixture.go", src)

	pass := &analysis.Pass{ //nolint:exhaustruct_v5 // only fields needed for tests are populated
		Fset:      pr.Fset,
		Files:     []*ast.File{pr.File},
		Pkg:       pr.Pkg,
		TypesInfo: pr.Info,
		ReadFile:  func(_ string) ([]byte, error) { return []byte(src), nil },
		ResultOf:  make(map[*analysis.Analyzer]any),
		Report:    func(analysis.Diagnostic) {},
	}

	return analysisFixture{pass: pass, file: pr.File, fset: pr.Fset, src: src}
}

// findCallExpr searches the AST for the first errors.As call expression.
func findCallExpr(t *testing.T, file *ast.File) *ast.CallExpr {
	t.Helper()

	var found *ast.CallExpr

	ast.Inspect(file, func(n ast.Node) bool {
		if found != nil {
			return false
		}

		call, ok := n.(*ast.CallExpr)
		if !ok {
			return true
		}

		sel, ok := call.Fun.(*ast.SelectorExpr)
		if !ok || sel.Sel.Name != "As" {
			return true
		}

		found = call

		return false
	})

	require.NotNil(t, found, "no errors.As call found in source")

	return found
}

// findFuncDecl returns the first function declaration with the given name.
func findFuncDecl(t *testing.T, file *ast.File, name string) *ast.FuncDecl {
	t.Helper()

	for _, decl := range file.Decls {
		fn, ok := decl.(*ast.FuncDecl)
		if ok && fn.Name.Name == name {
			return fn
		}
	}

	require.Failf(t, "function not found", "no function named %q in source", name)

	return nil
}

const sourceTargetUsedAfter = `package testpkg

import "errors"

type MyError struct{ msg string }

func (e *MyError) Error() string { return e.msg }

func targetUsedAfter(err error) {
	var target *MyError
	errors.As(err, &target)
	_ = target
}
`

const sourceTargetNotUsed = `package testpkg

import "errors"

type MyError struct{ msg string }

func (e *MyError) Error() string { return e.msg }

func targetNotUsed(err error) {
	var target *MyError
	errors.As(err, &target)
}
`

// ---------------------------------------------------------------------------
// resolveEffectiveName
// ---------------------------------------------------------------------------

func TestResolveEffectiveName_NilTargetVarReturnsTargetName(t *testing.T) {
	fix := newFixture(t, sourceTargetUsedAfter)

	ctx := asCallContext{targetName: "myTarget"}
	result := resolveEffectiveName(fix.pass, ctx, token.NoPos)

	assert.Equal(t, "myTarget", result)
}

func TestResolveEffectiveName_NilFuncDeclReturnsTargetName(t *testing.T) {
	fix := newFixture(t, sourceTargetUsedAfter)

	ctx := asCallContext{targetName: "myTarget", targetVar: &types.Var{}}
	result := resolveEffectiveName(fix.pass, ctx, token.NoPos)

	assert.Equal(t, "myTarget", result)
}

func TestResolveEffectiveName_NilFuncBodyReturnsTargetName(t *testing.T) {
	fix := newFixture(t, sourceTargetUsedAfter)

	fn := &ast.FuncDecl{Name: &ast.Ident{Name: "f"}}
	ctx := asCallContext{targetName: "myTarget", targetVar: &types.Var{}, funcDecl: fn}
	result := resolveEffectiveName(fix.pass, ctx, token.NoPos)

	assert.Equal(t, "myTarget", result)
}

func TestResolveEffectiveName_TargetUsedAfterReturnsName(t *testing.T) {
	fix := newFixture(t, sourceTargetUsedAfter)
	fn := findFuncDecl(t, fix.file, "targetUsedAfter")
	call := findCallExpr(t, fix.file)

	targetVar := findTargetVar(fix.pass, call.Args[1])
	require.NotNil(t, targetVar)

	ctx := asCallContext{targetName: "target", targetVar: targetVar, funcDecl: fn}
	result := resolveEffectiveName(fix.pass, ctx, call.End())

	// target IS used after the call (_ = target), so name is returned.
	assert.Equal(t, "target", result)
}

func TestResolveEffectiveName_TargetNotUsedAfterReturnsUnderscore(t *testing.T) {
	fix := newFixture(t, sourceTargetNotUsed)
	fn := findFuncDecl(t, fix.file, "targetNotUsed")
	call := findCallExpr(t, fix.file)

	targetVar := findTargetVar(fix.pass, call.Args[1])
	require.NotNil(t, targetVar)

	ctx := asCallContext{targetName: "target", targetVar: targetVar, funcDecl: fn}
	result := resolveEffectiveName(fix.pass, ctx, call.End())

	// target is NOT used after the call, so "_" is returned.
	assert.Equal(t, "_", result)
}

// ---------------------------------------------------------------------------
// appendVarDeclRemoval
// ---------------------------------------------------------------------------

func TestAppendVarDeclRemoval_NilTargetVarReturnsEditsUnchanged(t *testing.T) {
	fix := newFixture(t, sourceTargetUsedAfter)

	original := []analysis.TextEdit{{Pos: 1, End: 10}}
	result := appendVarDeclRemoval(original, fix.pass, asCallContext{}, token.NoPos)

	assert.Equal(t, original, result)
	assert.Len(t, result, 1)
}

func TestAppendVarDeclRemoval_NilFuncDeclReturnsEditsUnchanged(t *testing.T) {
	fix := newFixture(t, sourceTargetUsedAfter)

	original := []analysis.TextEdit{{Pos: 1, End: 10}}
	ctx := asCallContext{targetVar: &types.Var{}}
	result := appendVarDeclRemoval(original, fix.pass, ctx, token.NoPos)

	assert.Equal(t, original, result)
	assert.Len(t, result, 1)
}

func TestAppendVarDeclRemoval_NilFuncBodyReturnsEditsUnchanged(t *testing.T) {
	fix := newFixture(t, sourceTargetUsedAfter)

	original := []analysis.TextEdit{{Pos: 1, End: 10}}
	fn := &ast.FuncDecl{Name: &ast.Ident{Name: "f"}}
	ctx := asCallContext{targetVar: &types.Var{}, funcDecl: fn}
	result := appendVarDeclRemoval(original, fix.pass, ctx, token.NoPos)

	assert.Equal(t, original, result)
	assert.Len(t, result, 1)
}

func TestAppendVarDeclRemoval_TargetUsedBetweenReturnsEditsUnchanged(t *testing.T) {
	const src = `package testpkg

import "errors"

type MyError struct{ msg string }
func (e *MyError) Error() string { return e.msg }

func usedBetween(err error) {
	var target *MyError
	_ = target
	errors.As(err, &target)
}
`
	fix := newFixture(t, src)
	fn := findFuncDecl(t, fix.file, "usedBetween")
	call := findCallExpr(t, fix.file)

	targetVar := findTargetVar(fix.pass, call.Args[1])
	require.NotNil(t, targetVar)

	original := []analysis.TextEdit{{Pos: 1, End: 10}}
	ctx := asCallContext{targetVar: targetVar, funcDecl: fn}
	result := appendVarDeclRemoval(original, fix.pass, ctx, call.Pos())

	// target IS used between its decl and the call (_ = target), so no removal.
	assert.Equal(t, original, result)
	assert.Len(t, result, 1)
}

func TestAppendVarDeclRemoval_VarDeclFoundAppendsRemoval(t *testing.T) {
	fix := newFixture(t, sourceTargetNotUsed)
	fn := findFuncDecl(t, fix.file, "targetNotUsed")
	call := findCallExpr(t, fix.file)

	targetVar := findTargetVar(fix.pass, call.Args[1])
	require.NotNil(t, targetVar)

	original := []analysis.TextEdit{{Pos: call.Pos(), End: call.End()}}
	ctx := asCallContext{targetVar: targetVar, funcDecl: fn}
	result := appendVarDeclRemoval(original, fix.pass, ctx, call.Pos())

	// var target *MyError is not used between its decl and the call, so
	// the removal edit should be appended.
	require.Len(t, result, 2, "expected original edit + var-decl removal")
	assert.Equal(t, original[0], result[0])
	// The removal edit should cover the var declaration line.
	assert.Less(t, result[1].Pos, call.Pos(), "removal edit should start before the call")
}

// ---------------------------------------------------------------------------
// withStrictContext
// ---------------------------------------------------------------------------

func TestWithStrictContext_EmptyTypeExprReturnsNil(t *testing.T) {
	fix := newFixture(t, sourceTargetUsedAfter)
	call := findCallExpr(t, fix.file)

	result := withStrictContext(fix.pass, call, call, "", func(_ asCallContext) []analysis.TextEdit {
		t.Fatal("build should not be called when typeExpr is empty")

		return nil
	})

	assert.Nil(t, result)
}

func TestWithStrictContext_AllValidCallsBuild(t *testing.T) {
	fix := newFixture(t, sourceTargetUsedAfter)
	fn := findFuncDecl(t, fix.file, "targetUsedAfter")
	call := findCallExpr(t, fix.file)

	expectedEdits := []analysis.TextEdit{{Pos: 100, End: 200, NewText: []byte("test")}}

	result := withStrictContext(fix.pass, call, call, "*MyError", func(ctx asCallContext) []analysis.TextEdit {
		assert.Equal(t, "target", ctx.targetName)
		assert.NotNil(t, ctx.targetVar)
		assert.NotNil(t, ctx.funcDecl)
		assert.Equal(t, fn, ctx.funcDecl)
		assert.NotEmpty(t, ctx.arg0Text)

		return expectedEdits
	})

	assert.Equal(t, expectedEdits, result)
}

func TestWithStrictContext_NilTargetVarReturnsNil(t *testing.T) {
	// When the target argument is not &ident, findTargetVar returns nil
	// and withStrictContext should return nil (via resolveAsCallContext).
	const src = `package testpkg

import "errors"

type MyError struct{ msg string }
func (e *MyError) Error() string { return e.msg }

func badTarget(err error) {
	errors.As(err, MyError{})  // not &ident
}
`
	fix := newFixture(t, src)
	call := findCallExpr(t, fix.file)

	result := withStrictContext(fix.pass, call, call, "*MyError", func(_ asCallContext) []analysis.TextEdit {
		t.Fatal("build should not be called when targetVar is nil")

		return nil
	})

	assert.Nil(t, result)
}

// ---------------------------------------------------------------------------
// withLenientContext
// ---------------------------------------------------------------------------

func TestWithLenientContext_EmptyTypeExprReturnsNil(t *testing.T) {
	fix := newFixture(t, sourceTargetUsedAfter)
	call := findCallExpr(t, fix.file)

	result := withLenientContext(fix.pass, call, call, "", func(_ asCallContext) []analysis.TextEdit {
		t.Fatal("build should not be called when typeExpr is empty")

		return nil
	})

	assert.Nil(t, result)
}

func TestWithLenientContext_NonIdentTargetReturnsNil(t *testing.T) {
	// When the target argument is not &ident (e.g. MyError{}), extractTargetName
	// returns "" and prepareAsCall fails, so build is NOT called. withLenientContext
	// tolerates a nil funcDecl (unlike withStrictContext) but still requires a
	// valid targetVar from an &ident argument.
	const src = `package testpkg

import "errors"

type MyError struct{ msg string }
func (e *MyError) Error() string { return e.msg }

func badTarget(err error) {
	errors.As(err, MyError{})
}
`
	fix := newFixture(t, src)
	call := findCallExpr(t, fix.file)

	result := withLenientContext(fix.pass, call, call, "*MyError", func(_ asCallContext) []analysis.TextEdit {
		t.Fatal("build should not be called when target arg is not &ident")

		return nil
	})

	assert.Nil(t, result)
}

func TestWithLenientContext_AllValidCallsBuildWithFullContext(t *testing.T) {
	fix := newFixture(t, sourceTargetUsedAfter)
	fn := findFuncDecl(t, fix.file, "targetUsedAfter")
	call := findCallExpr(t, fix.file)

	expectedEdits := []analysis.TextEdit{{Pos: 100, End: 200, NewText: []byte("lenient")}}

	result := withLenientContext(fix.pass, call, call, "*MyError", func(ctx asCallContext) []analysis.TextEdit {
		assert.Equal(t, "target", ctx.targetName)
		assert.NotNil(t, ctx.targetVar)
		assert.NotNil(t, ctx.funcDecl)
		assert.Equal(t, fn, ctx.funcDecl)
		assert.NotEmpty(t, ctx.arg0Text)

		return expectedEdits
	})

	assert.Equal(t, expectedEdits, result)
}

func TestWithLenientContext_ToleratesMissingFuncDecl(t *testing.T) {
	// withLenientContext should still call build when funcDecl is missing
	// (e.g., when the call is at package scope, though unusual).
	fix := newFixture(t, sourceTargetUsedAfter)
	call := findCallExpr(t, fix.file)

	// Pass a node that's NOT inside any function — enclosingFuncDecl returns nil.
	// Using the call itself should still be inside the function though...
	// Let's pass the file as the node, which is not inside any FuncDecl.
	result := withLenientContext(fix.pass, fix.file, call, "*MyError", func(ctx asCallContext) []analysis.TextEdit {
		// funcDecl should be nil since the file node is not inside a function.
		assert.Nil(t, ctx.funcDecl)
		assert.NotNil(t, ctx.targetVar)
		assert.Equal(t, "target", ctx.targetName)

		return []analysis.TextEdit{{Pos: 1, End: 2}}
	})

	assert.Len(t, result, 1)
}
