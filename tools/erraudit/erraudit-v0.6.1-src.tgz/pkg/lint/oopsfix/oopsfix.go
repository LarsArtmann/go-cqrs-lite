// Package oopsfix provides a go/analysis analyzer that detects and auto-fixes
// the redundant nil guard anti-pattern when using samber/oops:
//
//	if err != nil {
//	    return oops.Wrap(err)
//	}
//	return nil
//
// Since oops.Wrap/Wrapf return nil when the input error is nil, the guard is
// unnecessary. The fix replaces the if-block and the trailing return nil with
// a single `return oops.Wrap(err)`.
package oopsfix

import (
	"bytes"
	"go/ast"
	"go/format"
	"go/token"

	"github.com/larsartmann/erraudit/pkg/oopspattern"
	"github.com/larsartmann/erraudit/pkg/types"
	"golang.org/x/tools/go/analysis"
	"golang.org/x/tools/go/analysis/passes/inspect"
	"golang.org/x/tools/go/ast/inspector"
)

const analyzerName = "oopsfix"

// Analyzer detects redundant nil guards before oops.Wrap/Wrapf and suggests
// replacing them with a single return.
//
//nolint:gochecknoglobals // go/analysis requires Analyzer to be a package-level var
var Analyzer = &analysis.Analyzer{
	Name:             analyzerName,
	Doc:              "detect and fix redundant nil guards before oops.Wrap/Wrapf calls",
	Requires:         []*analysis.Analyzer{inspect.Analyzer},
	Run:              run,
	RunDespiteErrors: true,
}

func run(pass *analysis.Pass) (any, error) {
	insp, ok := pass.ResultOf[inspect.Analyzer].(*inspector.Inspector)
	if !ok {
		return nil, nil //nolint:nilnil // go/analysis requires (any, error) return
	}

	nodeFilter := []ast.Node{
		(*ast.BlockStmt)(nil),
	}

	insp.Preorder(nodeFilter, func(n ast.Node) {
		block, ok := n.(*ast.BlockStmt)
		if !ok {
			return
		}

		matches := oopspattern.FindRedundantGuards(block)
		for _, m := range matches {
			emitDiagnostic(pass, m)
		}
	})

	return nil, nil //nolint:nilnil // go/analysis requires (any, error) return
}

func emitDiagnostic(pass *analysis.Pass, m oopspattern.RedundantGuardMatch) {
	replacement, ok := renderReturn(m.WrapRet)
	if !ok {
		return
	}

	pass.Report(analysis.Diagnostic{
		Pos:      m.IfStmt.Pos(),
		End:      m.NilRet.End(),
		Message:  "redundant nil guard before oops.Wrap — Wrap returns nil for nil input",
		Category: string(types.ErrorTypeOopsRedundantGuard),
		SuggestedFixes: []analysis.SuggestedFix{
			{
				Message: "Replace if-block and return nil with single return",
				TextEdits: []analysis.TextEdit{
					{
						Pos:     m.IfStmt.Pos(),
						End:     m.NilRet.End(),
						NewText: []byte(replacement),
					},
				},
			},
		},
	})
}

// renderReturn renders a ReturnStmt to source text using go/format.
func renderReturn(ret *ast.ReturnStmt) (string, bool) {
	var buf bytes.Buffer

	err := format.Node(&buf, token.NewFileSet(), ret)
	if err != nil {
		return "", false
	}

	return buf.String(), true
}
