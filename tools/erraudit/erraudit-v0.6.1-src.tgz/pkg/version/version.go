// Package version holds the single source of truth for the erraudit
// version string. Every build self-identifies with the git commit it was
// built from, plus a "-dirty" suffix when the working tree had uncommitted
// changes:
//
//   - Builds that inject at link time (flake ldflags or release scripts)
//     override everything via the injected variable.
//   - Plain go build / go install binaries read the VCS stamp the Go
//     toolchain embeds (debug.BuildInfo vcs.revision and vcs.modified),
//     yielding "10bd9ac" or "10bd9ac-dirty". The toolchain only stamps
//     build/install binaries — go run and go test builds are unstamped
//     and fall through to the module version / "dev".
//   - Binaries installed from the module proxy (go install ...@vX.Y.Z)
//     carry no VCS stamp but do carry the requested version in
//     debug.BuildInfo Main.Version, which becomes the version string.
//   - Builds from sources without VCS metadata and without a module
//     version (go run, go test) fall back to "dev".
//
// Fleet standard + adoption guide:
// ../file-and-image-renamer/docs/FLEET-STANDARD-VERSION-STAMPS.md
package version

import (
	"runtime/debug"
)

// injected is set at link time, e.g.:
//
//	-X github.com/larsartmann/erraudit/pkg/version.injected=<shortRev>
//
// It is a separate variable because -X can only replace statically
// initialized strings; Version's dynamic initializer would clobber it.
//
//nolint:gochecknoglobals // ldflags injection requires a package-level var
var injected string

// Version is the tool version: the ldflags-injected string when present,
// otherwise the git-derived VCS stamp, otherwise the module-proxy install
// version, otherwise "dev".
//
//nolint:gochecknoglobals // resolved once at package init; consumers read it
var Version = resolve(injected, readBuildInfo())

// resolve picks the version. Precedence: ldflags injection (nix shortRev
// or an explicit release string), then the toolchain's VCS stamp, then the
// main module version (module-proxy installs), then "dev".
func resolve(injected string, buildInfo *debug.BuildInfo) string {
	if injected != "" {
		return injected
	}

	if stamp := vcsStamp(buildInfo); stamp != "" {
		return stamp
	}

	if v := moduleVersion(buildInfo); v != "" {
		return v
	}

	return "dev"
}

// moduleVersion reports the main module version recorded in the build
// info, which the go command sets for binaries installed from the module
// proxy (go install ...@vX.Y.Z). Local source builds carry the pseudo
// version "(devel)" there; they are excluded so only real installs report.
func moduleVersion(buildInfo *debug.BuildInfo) string {
	if buildInfo == nil {
		return ""
	}

	const devel = "(devel)"

	if v := buildInfo.Main.Version; v != "" && v != devel {
		return v
	}

	return ""
}

func readBuildInfo() *debug.BuildInfo {
	bi, _ := debug.ReadBuildInfo() //nolint:erraudit // best-effort: missing build info falls back to the "dev" stamp

	return bi
}

// vcsStamp derives "<shortrev>" or "<shortrev>-dirty" from the build's
// embedded VCS settings. It returns the empty string when the binary
// carries no VCS metadata (nix builds, go install).
func vcsStamp(buildInfo *debug.BuildInfo) string {
	if buildInfo == nil {
		return ""
	}

	var revision, modified string

	for _, setting := range buildInfo.Settings {
		switch setting.Key {
		case "vcs.revision":
			revision = setting.Value
		case "vcs.modified":
			modified = setting.Value
		}
	}

	if revision == "" {
		return ""
	}

	short := revision
	if len(short) > shortRevLength {
		short = short[:shortRevLength]
	}

	if modified == "true" {
		return short + dirtySuffix
	}

	return short
}

const (
	// shortRevLength matches the nix shortRev width so plain and nix
	// builds report identically shaped versions.
	shortRevLength = 7
	// dirtySuffix matches the nix dirtyShortRev suffix.
	dirtySuffix = "-dirty"
)
