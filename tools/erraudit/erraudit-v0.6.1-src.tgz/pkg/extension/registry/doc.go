// Package registry provides the extension registry and base interfaces for the
// erraudit analyzer extension system.
package registry
