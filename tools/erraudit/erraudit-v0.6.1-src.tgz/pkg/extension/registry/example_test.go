package registry_test

import (
	"context"
	"fmt"

	"github.com/larsartmann/erraudit/pkg/extension/registry"
)

func ExampleExtensionMetadata() {
	meta := registry.NewExtensionMetadata("my-feature", "1.0.0", registry.TypeAnalyzer).
		WithDescription("Detects custom error patterns").
		WithAuthor("erraudit team").
		WithPriority(10)

	m := meta.Metadata()
	fmt.Println(m.Name, m.Version, m.Type)
	// Output: my-feature 1.0.0 analyzer
}

func ExampleNewRegistry() {
	r := registry.NewRegistry()

	feature := &myFeature{}
	if err := r.Register(context.Background(), feature); err != nil {
		panic(err)
	}

	fmt.Println(r.Names())
	// Output: [demo-feature]
}

// myFeature is a minimal Extension implementation for the example.
type myFeature struct{}

func (m *myFeature) Metadata() registry.Metadata {
	return registry.Metadata{
		Name:    "demo-feature",
		Version: "1.0.0",
		Type:    registry.TypeAnalyzer,
	}
}

func (m *myFeature) Initialize(_ context.Context) error { return nil }

func (m *myFeature) Shutdown(_ context.Context) error { return nil }

func ExampleRegistry_GetByType() {
	r := registry.NewRegistry()

	if err := r.Register(context.Background(), &myFeature{}); err != nil {
		panic(err)
	}

	features := r.GetByType(registry.TypeAnalyzer)
	fmt.Println(len(features))
	// Output: 1
}
