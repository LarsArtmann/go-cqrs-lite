package registry

import (
	"context"
	"testing"
)

func TestRegistry_Register(t *testing.T) {
	r := NewRegistry()
	p := &ExtensionMetadata{name: "test-feature", version: "1.0.0", featureType: TypeAnalyzer}

	if err := r.Register(context.Background(), p); err != nil {
		t.Fatalf("failed to register feature: %v", err)
	}
	if r.Get("test-feature") == nil {
		t.Error("feature not found after registration")
	}
}

func TestRegistry_RegisterDuplicate(t *testing.T) {
	r := NewRegistry()
	p1 := &ExtensionMetadata{name: "duplicate", version: "1.0.0", featureType: TypeAnalyzer}
	p2 := &ExtensionMetadata{name: "duplicate", version: "2.0.0", featureType: TypeVisualizer}

	if err := r.Register(context.Background(), p1); err != nil {
		t.Fatalf("first registration failed: %v", err)
	}
	if err := r.Register(context.Background(), p2); err == nil {
		t.Error("expected error for duplicate registration")
	}
}

func TestRegistry_RegisterNil(t *testing.T) {
	r := NewRegistry()
	if err := r.Register(context.Background(), nil); err == nil {
		t.Error("expected error for nil feature")
	}
}

func TestRegistry_GetByType(t *testing.T) {
	r := NewRegistry()
	_ = r.Register(
		context.Background(),
		&ExtensionMetadata{name: "a1", version: "1.0", featureType: TypeAnalyzer, priority: 1},
	)
	_ = r.Register(
		context.Background(),
		&ExtensionMetadata{name: "v1", version: "1.0", featureType: TypeVisualizer, priority: 1},
	)
	_ = r.Register(
		context.Background(),
		&ExtensionMetadata{name: "a2", version: "1.0", featureType: TypeAnalyzer, priority: 2},
	)

	analyzers := r.GetByType(TypeAnalyzer)
	if len(analyzers) != 2 {
		t.Errorf("expected 2 analyzers, got %d", len(analyzers))
	}
	if analyzers[0].Metadata().Priority > analyzers[1].Metadata().Priority {
		t.Error("analyzers not sorted by priority")
	}
}

func TestRegistry_Unregister(t *testing.T) {
	r := NewRegistry()
	p := &ExtensionMetadata{name: "to-remove", version: "1.0", featureType: TypeAnalyzer}
	_ = r.Register(context.Background(), p)

	if r.Get("to-remove") == nil {
		t.Fatal("feature not registered")
	}
	if err := r.Unregister(context.Background(), "to-remove"); err != nil {
		t.Fatalf("failed to unregister: %v", err)
	}
	if r.Get("to-remove") != nil {
		t.Error("feature still found after unregistration")
	}
}

func registerTestFeatures(r *Registry) {
	_ = r.Register(context.Background(), &ExtensionMetadata{name: "p1", version: "1.0", featureType: TypeAnalyzer})
	_ = r.Register(context.Background(), &ExtensionMetadata{name: "p2", version: "1.0", featureType: TypeVisualizer})
}

func TestRegistry_List(t *testing.T) {
	r := NewRegistry()
	registerTestFeatures(r)
	list := r.List()
	if len(list) != 2 {
		t.Errorf("expected 2 features, got %d", len(list))
	}
}

func TestRegistry_Clear(t *testing.T) {
	r := NewRegistry()
	registerTestFeatures(r)
	if err := r.Clear(context.Background()); err != nil {
		t.Fatalf("clear failed: %v", err)
	}
	if len(r.List()) != 0 {
		t.Error("registry not empty after clear")
	}
}

func TestFeatureMetadata_Builder(t *testing.T) {
	pm := NewExtensionMetadata("test", "1.0.0", TypeAnalyzer).
		WithDescription("desc").
		WithAuthor("author").
		WithPriority(42)

	meta := pm.Metadata()
	if meta.Name != "test" {
		t.Errorf("expected name test, got %s", meta.Name)
	}
	if meta.Description != "desc" {
		t.Errorf("expected description desc, got %s", meta.Description)
	}
	if meta.Author != "author" {
		t.Errorf("expected author author, got %s", meta.Author)
	}
	if meta.Priority != 42 {
		t.Errorf("expected priority 42, got %d", meta.Priority)
	}
}
