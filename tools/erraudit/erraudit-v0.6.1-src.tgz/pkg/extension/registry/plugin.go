package registry

import (
	"context"
	"sort"
	"sync"

	"github.com/larsartmann/erraudit/pkg/errors"
)

// ExtensionType categorizes features by their functionality.
type ExtensionType string

const (
	// TypeAnalyzer provides custom error analysis capabilities.
	TypeAnalyzer ExtensionType = "analyzer"
	// TypeVisualizer provides custom output formatting.
	TypeVisualizer ExtensionType = "visualizer"
	// TypeViolationDetector provides custom violation detection rules.
	TypeViolationDetector ExtensionType = "violation_detector"
	// TypeMetricsProvider provides custom metrics calculation.
	TypeMetricsProvider ExtensionType = "metrics_provider"
)

// Metadata contains feature identification and configuration.
type Metadata struct {
	// Name is the unique identifier for the feature
	Name string
	// Version follows semantic versioning (e.g., "1.0.0")
	Version string
	// Type categorizes the feature's functionality
	Type ExtensionType
	// Description provides a human-readable summary
	Description string
	// Author identifies the feature creator
	Author string
	// Priority determines execution order (higher = later)
	Priority int
}

// Extension is the base interface that all extensions must implement.
type Extension interface {
	// Metadata returns extension identification and configuration
	Metadata() Metadata
	// Initialize is called when the extension is loaded
	Initialize(ctx context.Context) error
	// Shutdown is called when the extension is unloaded
	Shutdown(ctx context.Context) error
}

// Registry manages all registered features.
//
// NOTE on lock patterns: art-dupl reports the explicit `r.mu.Lock(); defer
// r.mu.Unlock()` pairs across the package as duplicated (and the
// `r.mu.RLock(); defer r.mu.RUnlock()` pairs in the same file). This is the
// canonical Go mutex idiom — every Go style guide and the standard library
// itself rely on the explicit form. Extracting it behind a `withLock(func())`
// closure would shift return values into outer-scope variables and add a
// nesting level for every method, which is the textbook case where the
// abstraction costs more than the duplication. We keep the explicit form.
type Registry struct {
	mu       sync.RWMutex
	features map[string]Extension
	byType   map[ExtensionType][]Extension
}

// globalRegistry is the default feature registry.
//
//nolint:gochecknoglobals // Global registry is intentionally global for feature system
var globalRegistry = NewRegistry()

// NewRegistry creates a new feature registry.
func NewRegistry() *Registry {
	return &Registry{
		features: make(map[string]Extension),
		byType:   make(map[ExtensionType][]Extension),
	}
}

// GlobalRegistry returns the global feature registry.
func GlobalRegistry() *Registry {
	return globalRegistry
}

// Register adds a feature to the registry.
func (r *Registry) Register(ctx context.Context, extension Extension) error {
	if extension == nil {
		return errors.New("cannot register nil extension")
	}

	meta := extension.Metadata()
	if meta.Name == "" {
		return errors.New("extension name cannot be empty")
	}

	r.mu.Lock()
	defer r.mu.Unlock()

	if _, exists := r.features[meta.Name]; exists {
		return errors.New(
			"extension %q already registered (type=%s, version=%s)",
			meta.Name,
			meta.Type,
			meta.Version,
		)
	}

	initErr := extension.Initialize(ctx)
	if initErr != nil {
		return errors.Wrap(
			initErr,
			"failed to initialize extension %q (type=%s, version=%s)",
			meta.Name,
			meta.Type,
			meta.Version,
		)
	}

	r.features[meta.Name] = extension
	r.byType[meta.Type] = append(r.byType[meta.Type], extension)

	return nil
}

// Unregister removes a feature from the registry.
func (r *Registry) Unregister(ctx context.Context, name string) error {
	r.mu.Lock()
	defer r.mu.Unlock()

	feature, exists := r.features[name]
	if !exists {
		return errors.New("feature %q not found", name)
	}

	// Shutdown the feature
	shutdownErr := feature.Shutdown(ctx)
	if shutdownErr != nil {
		return errors.Wrap(shutdownErr, "failed to shutdown feature %q", name)
	}

	meta := feature.Metadata()

	delete(r.features, name)

	// Remove from byType slice
	typed := r.byType[meta.Type]
	for i, f := range typed {
		if f.Metadata().Name == name {
			r.byType[meta.Type] = append(typed[:i], typed[i+1:]...)

			break
		}
	}

	return nil
}

// Get retrieves a feature by name.
//
//nolint:ireturn // feature registry pattern requires returning the interface abstraction
func (r *Registry) Get(name string) Extension {
	r.mu.RLock()
	defer r.mu.RUnlock()

	return r.features[name]
}

// GetByType returns all features of a specific type, sorted by priority.
func (r *Registry) GetByType(t ExtensionType) []Extension {
	r.mu.RLock()
	defer r.mu.RUnlock()

	features := make([]Extension, 0, len(r.byType[t]))
	features = append(features, r.byType[t]...)

	sort.SliceStable(features, func(i, j int) bool {
		return features[i].Metadata().Priority < features[j].Metadata().Priority
	})

	return features
}

// List returns all registered features.
func (r *Registry) List() []Extension {
	r.mu.RLock()
	defer r.mu.RUnlock()

	features := make([]Extension, 0, len(r.features))
	for _, f := range r.features {
		features = append(features, f)
	}

	return features
}

// Names returns all registered feature names.
func (r *Registry) Names() []string {
	r.mu.RLock()
	defer r.mu.RUnlock()

	names := make([]string, 0, len(r.features))
	for name := range r.features {
		names = append(names, name)
	}

	return names
}

// Clear removes all features from the registry.
func (r *Registry) Clear(ctx context.Context) error {
	r.mu.Lock()
	defer r.mu.Unlock()

	var errs []error

	for featureName, feature := range r.features {
		shutdownErr := feature.Shutdown(ctx)
		if shutdownErr != nil {
			errs = append(errs, errors.Wrap(shutdownErr, "shutdown %s", featureName))
		}
	}

	r.features = make(map[string]Extension)
	r.byType = make(map[ExtensionType][]Extension)

	if len(errs) > 0 {
		return errors.New("errors during clear: %v", errs)
	}

	return nil
}

// ExtensionMetadata provides common feature metadata and default implementations for embedding.
type ExtensionMetadata struct {
	name        string
	version     string
	featureType ExtensionType
	description string
	author      string
	priority    int
}

// NewExtensionMetadata creates a new feature metadata holder.
func NewExtensionMetadata(name, version string, featureType ExtensionType) *ExtensionMetadata {
	return &ExtensionMetadata{
		name:        name,
		version:     version,
		featureType: featureType,
	}
}

// WithDescription sets the description.
func (b *ExtensionMetadata) WithDescription(desc string) *ExtensionMetadata {
	b.description = desc

	return b
}

// WithAuthor sets the author.
func (b *ExtensionMetadata) WithAuthor(author string) *ExtensionMetadata {
	b.author = author

	return b
}

// WithPriority sets the priority.
func (b *ExtensionMetadata) WithPriority(priority int) *ExtensionMetadata {
	b.priority = priority

	return b
}

// Metadata returns the feature metadata.
func (b *ExtensionMetadata) Metadata() Metadata {
	return Metadata{
		Name:        b.name,
		Version:     b.version,
		Type:        b.featureType,
		Description: b.description,
		Author:      b.author,
		Priority:    b.priority,
	}
}

// Initialize does nothing by default.
func (b *ExtensionMetadata) Initialize(_ context.Context) error {
	return nil
}

// Shutdown does nothing by default.
func (b *ExtensionMetadata) Shutdown(_ context.Context) error {
	return nil
}
