package hooks

import (
	"context"
	"sort"
	"sync"

	"github.com/larsartmann/erraudit/pkg/errors"
)

// HookPoint defines points in the analysis lifecycle where extensions can attach.
type HookPoint string

const (
	// HookPreAnalysis is called before analysis begins.
	HookPreAnalysis HookPoint = "pre_analysis"
	// HookPostAnalysis is called after analysis completes.
	HookPostAnalysis HookPoint = "post_analysis"
	// HookPreFile is called before each file is analyzed.
	HookPreFile HookPoint = "pre_file"
	// HookPostFile is called after each file is analyzed.
	HookPostFile HookPoint = "post_file"
	// HookPreViolation is called before violation is added.
	HookPreViolation HookPoint = "pre_violation"
	// HookPostViolation is called after violation is added.
	HookPostViolation HookPoint = "post_violation"
	// HookPreOutput is called before output is generated.
	HookPreOutput HookPoint = "pre_output"
	// HookPostOutput is called after output is generated.
	HookPostOutput HookPoint = "post_output"
	// HookPreFix is called before fix changes are applied.
	HookPreFix HookPoint = "pre_fix"
	// HookPostFix is called after fix changes are applied.
	HookPostFix HookPoint = "post_fix"
)

// Default hook priorities.
const (
	// PriorityPreHooks is the default priority for pre-hooks (executed first).
	PriorityPreHooks = -1000
	// PriorityPostHooks is the default priority for post-hooks (executed last).
	PriorityPostHooks = 1000
	// PriorityBuiltinPostHooks is the priority for built-in post-hooks.
	PriorityBuiltinPostHooks = 999
)

// HookContext provides context data to hook functions.
//
//nolint:containedctx // intentional: hooks need context for cancellation/deadlines
type HookContext struct {
	// Ctx is the context.Context passed by the caller (for cancellation, deadlines, values)
	Ctx context.Context
	// Point indicates which hook point is being called
	Point HookPoint
	// Data contains hook-specific data (type depends on hook point)
	Data any
	// Cancel can be set to true to cancel the operation
	Cancel bool
	// Result can be modified to change the result
	Result any
}

// HookFunc is the function signature for hook callbacks.
type HookFunc func(ctx *HookContext) error

// Hook represents a registered hook callback.
type Hook struct {
	// Name identifies the hook for debugging
	Name string
	// Point is where this hook is attached
	Point HookPoint
	// Func is the callback function
	Func HookFunc
	// Priority determines execution order (lower = earlier)
	Priority int
}

// HookRegistry manages hooks for the analysis lifecycle.
type HookRegistry struct {
	mu    sync.RWMutex
	hooks map[HookPoint][]Hook
}

// globalHookRegistry is the default hook registry.
//
//nolint:gochecknoglobals // Global registry is intentionally global for extension system
var globalHookRegistry = NewHookRegistry()

// NewHookRegistry creates a new hook registry.
func NewHookRegistry() *HookRegistry {
	return &HookRegistry{
		hooks: make(map[HookPoint][]Hook),
	}
}

// GlobalHookRegistry returns the global hook registry.
func GlobalHookRegistry() *HookRegistry {
	return globalHookRegistry
}

// RegisterHook adds a hook at a specific point.
func (r *HookRegistry) RegisterHook(hook Hook) error {
	if hook.Func == nil {
		return errors.New("hook function cannot be nil")
	}

	r.mu.Lock()
	defer r.mu.Unlock()

	r.hooks[hook.Point] = append(r.hooks[hook.Point], hook)

	// Sort by priority (stable to preserve registration order for equal priorities)
	sort.SliceStable(r.hooks[hook.Point], func(i, j int) bool {
		return r.hooks[hook.Point][i].Priority < r.hooks[hook.Point][j].Priority
	})

	return nil
}

// UnregisterHook removes a hook by name.
func (r *HookRegistry) UnregisterHook(point HookPoint, name string) error {
	r.mu.Lock()
	defer r.mu.Unlock()

	hooks := r.hooks[point]
	for i, hook := range hooks {
		if hook.Name == name {
			r.hooks[point] = append(hooks[:i], hooks[i+1:]...)

			return nil
		}
	}

	return errors.New("hook %q not found at point %s", name, point)
}

// Execute runs all hooks at a specific point.
func (r *HookRegistry) Execute(ctx context.Context, point HookPoint, data any) (*HookContext, error) {
	r.mu.RLock()
	hooks := make([]Hook, 0, len(r.hooks[point]))
	hooks = append(hooks, r.hooks[point]...)
	r.mu.RUnlock()

	hookCtx := &HookContext{
		Ctx:   ctx,
		Point: point,
		Data:  data,
	}

	for _, hook := range hooks {
		hookErr := hook.Func(hookCtx)
		if hookErr != nil {
			return hookCtx, errors.Wrap(hookErr, "hook %q failed at point %s", hook.Name, point)
		}

		if hookCtx.Cancel {
			return hookCtx, errors.New("operation cancelled by hook %q at point %s", hook.Name, point)
		}
	}

	return hookCtx, nil
}

// GetHooks returns all hooks at a specific point.
func (r *HookRegistry) GetHooks(point HookPoint) []Hook {
	r.mu.RLock()
	defer r.mu.RUnlock()

	hooks := make([]Hook, 0, len(r.hooks[point]))
	hooks = append(hooks, r.hooks[point]...)

	return hooks
}

// Clear removes all hooks.
func (r *HookRegistry) Clear() {
	r.mu.Lock()
	defer r.mu.Unlock()

	r.hooks = make(map[HookPoint][]Hook)
}

// RegisterHook is a convenience function for the global registry.
func RegisterHook(h Hook) error {
	return globalHookRegistry.RegisterHook(h)
}

// ExecuteHooks is a convenience function for the global registry.
//
// Deprecated: Use Fire[T] or Notify[T] for type safety.
func ExecuteHooks(ctx context.Context, point HookPoint, data any) (*HookContext, error) {
	return globalHookRegistry.Execute(ctx, point, data)
}

// PreAnalysisData contains data for HookPreAnalysis.
type PreAnalysisData struct {
	Path    string
	Options map[string]any
}

// PostAnalysisData contains data for HookPostAnalysis.
type PostAnalysisData struct {
	Path       string
	Graph      any
	Violations any
	Duration   int64 // milliseconds
}

// PreFileData contains data for HookPreFile.
type PreFileData struct {
	FilePath string
}

// PostFileData contains data for HookPostFile.
type PostFileData struct {
	FilePath   string
	Graph      any
	Violations any
	Error      error
}

// PreViolationData contains data for HookPreViolation.
type PreViolationData struct {
	Violation any
	File      string
}

// PostViolationData contains data for HookPostViolation.
type PostViolationData struct {
	Violation any
	Added     bool
}

// PreOutputData contains data for HookPreOutput.
type PreOutputData struct {
	Format     string
	Graph      any
	Violations any
}

// PostOutputData contains data for HookPostOutput.
type PostOutputData struct {
	Format string
	Output string
}

// PreFixData contains data for HookPreFix.
type PreFixData struct {
	Fixes []string // file paths that will be modified
}

// PostFixData contains data for HookPostFix.
type PostFixData struct {
	Fixes       []string // file paths that were modified
	ChangeCount int
}
