package hooks

import (
	"context"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestTypedHook_TypeSafeCallback(t *testing.T) {
	t.Parallel()

	registry := NewHookRegistry()
	executed := false

	err := registry.RegisterHook(Hook{
		Name:  "typed-pre-analysis",
		Point: HookPreAnalysis,
		Func: TypedHook(func(data *PreAnalysisData) error {
			executed = true
			assert.Equal(t, "main.go", data.Path)
			return nil
		}),
	})
	require.NoError(t, err)

	_, err = registry.Execute(context.Background(), HookPreAnalysis, &PreAnalysisData{Path: "main.go"})
	require.NoError(t, err)
	assert.True(t, executed, "typed hook should have been called")
}

func TestTypedHook_TypeMismatch_NoOp(t *testing.T) {
	t.Parallel()

	registry := NewHookRegistry()
	executed := false

	err := registry.RegisterHook(Hook{
		Name:  "typed-mismatch",
		Point: HookPreAnalysis,
		Func: TypedHook(func(data *PreFileData) error { // wrong type
			executed = true
			return nil
		}),
	})
	require.NoError(t, err)

	// Execute with PreAnalysisData, but hook expects *PreFileData
	_, err = registry.Execute(context.Background(), HookPreAnalysis, &PreAnalysisData{Path: "."})
	require.NoError(t, err)
	assert.False(t, executed, "hook should no-op when data type doesn't match")
}

func TestTypedHook_ValueType(t *testing.T) {
	t.Parallel()

	registry := NewHookRegistry()
	executed := false

	err := registry.RegisterHook(Hook{
		Name:  "typed-value",
		Point: HookPreAnalysis,
		Func: TypedHook(func(data PreAnalysisData) error { // value, not pointer
			executed = true
			assert.Equal(t, "val.go", data.Path)
			return nil
		}),
	})
	require.NoError(t, err)

	_, err = registry.Execute(context.Background(), HookPreAnalysis, PreAnalysisData{Path: "val.go"})
	require.NoError(t, err)
	assert.True(t, executed)
}

func TestFire_ReturnsData(t *testing.T) {
	globalHookRegistry.Clear()
	t.Cleanup(globalHookRegistry.Clear)

	require.NoError(t, RegisterHook(Hook{
		Name:  "fire-observer",
		Point: HookPreAnalysis,
		Func:  TypedHook(func(data *PreAnalysisData) error { return nil }),
	}))

	data, cancelled, err := Fire(context.Background(), HookPreAnalysis, &PreAnalysisData{Path: "test.go"})
	require.NoError(t, err)
	assert.False(t, cancelled)
	assert.Equal(t, "test.go", data.Path)
}

func TestFire_CancelPropagates(t *testing.T) {
	globalHookRegistry.Clear()
	t.Cleanup(globalHookRegistry.Clear)

	require.NoError(t, RegisterHook(Hook{
		Name:  "fire-cancel",
		Point: HookPreAnalysis,
		Func: func(ctx *HookContext) error {
			ctx.Cancel = true
			return nil
		},
	}))

	_, cancelled, err := Fire(context.Background(), HookPreAnalysis, &PreAnalysisData{Path: "."})
	require.NoError(t, err) // cancel is not an error
	assert.True(t, cancelled)
}

func TestFire_ErrorPropagates(t *testing.T) {
	globalHookRegistry.Clear()
	t.Cleanup(globalHookRegistry.Clear)

	require.NoError(t, RegisterHook(Hook{
		Name:  "fire-error",
		Point: HookPreAnalysis,
		Func:  func(_ *HookContext) error { return assertError("hook blew up") },
	}))

	_, _, err := Fire(context.Background(), HookPreAnalysis, &PreAnalysisData{Path: "."})
	require.Error(t, err)
	assert.Contains(t, err.Error(), "hook blew up")
}

func TestFire_ModifiedDataViaResult(t *testing.T) {
	globalHookRegistry.Clear()
	t.Cleanup(globalHookRegistry.Clear)

	require.NoError(t, RegisterHook(Hook{
		Name:  "fire-modifier",
		Point: HookPreAnalysis,
		Func: func(ctx *HookContext) error {
			ctx.Result = &PreAnalysisData{Path: "modified.go"}
			return nil
		},
	}))

	data, cancelled, err := Fire(context.Background(), HookPreAnalysis, &PreAnalysisData{Path: "original.go"})
	require.NoError(t, err)
	assert.False(t, cancelled)
	assert.Equal(t, "modified.go", data.Path)
}

func TestFire_InPlacePointerModification(t *testing.T) {
	globalHookRegistry.Clear()
	t.Cleanup(globalHookRegistry.Clear)

	require.NoError(t, RegisterHook(Hook{
		Name:  "fire-inplace",
		Point: HookPreAnalysis,
		Func: TypedHook(func(data *PreAnalysisData) error {
			data.Path = "changed-in-place.go"
			return nil
		}),
	}))

	data, cancelled, err := Fire(context.Background(), HookPreAnalysis, &PreAnalysisData{Path: "original.go"})
	require.NoError(t, err)
	assert.False(t, cancelled)
	assert.Equal(t, "changed-in-place.go", data.Path)
}

func TestFire_NoHooksRegistered(t *testing.T) {
	globalHookRegistry.Clear()
	t.Cleanup(globalHookRegistry.Clear)

	data, cancelled, err := Fire(context.Background(), HookPreAnalysis, &PreAnalysisData{Path: "lonely.go"})
	require.NoError(t, err)
	assert.False(t, cancelled)
	assert.Equal(t, "lonely.go", data.Path)
}

func TestNotify_FiresAndDiscards(t *testing.T) {
	globalHookRegistry.Clear()
	t.Cleanup(globalHookRegistry.Clear)

	executed := false
	require.NoError(t, RegisterHook(Hook{
		Name:  "notify-test",
		Point: HookPostFile,
		Func: TypedHook(func(data *PostFileData) error {
			executed = true
			assert.Equal(t, "main.go", data.FilePath)
			return nil
		}),
	}))

	// Notify discards all return values and doesn't panic
	Notify(context.Background(), HookPostFile, &PostFileData{FilePath: "main.go"})
	assert.True(t, executed, "Notify should fire the hook")
}

func TestDataAs_MatchingType(t *testing.T) {
	t.Parallel()

	ctx := &HookContext{Data: &PreAnalysisData{Path: "match.go"}}
	data, ok := DataAs[*PreAnalysisData](ctx)
	require.True(t, ok)
	assert.Equal(t, "match.go", data.Path)
}

func TestDataAs_NonMatchingType(t *testing.T) {
	t.Parallel()

	ctx := &HookContext{Data: &PreFileData{FilePath: "wrong.go"}}
	_, ok := DataAs[*PreAnalysisData](ctx)
	assert.False(t, ok)
}

func TestResultAs_MatchingType(t *testing.T) {
	t.Parallel()

	ctx := &HookContext{Result: &PreAnalysisData{Path: "result.go"}}
	data, ok := ResultAs[*PreAnalysisData](ctx)
	require.True(t, ok)
	assert.Equal(t, "result.go", data.Path)
}

func TestResultAs_NilResult(t *testing.T) {
	t.Parallel()

	ctx := &HookContext{}
	_, ok := ResultAs[*PreAnalysisData](ctx)
	assert.False(t, ok)
}
