package hooks

import (
	"context"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestHookRegistry_UnregisterHook(t *testing.T) {
	registry := NewHookRegistry()
	require.NoError(t, registry.RegisterHook(Hook{
		Name:     "test-hook",
		Point:    HookPreAnalysis,
		Func:     func(_ *HookContext) error { return nil },
		Priority: 0,
	}))

	err := registry.UnregisterHook(HookPreAnalysis, "test-hook")
	require.NoError(t, err)

	hooks := registry.GetHooks(HookPreAnalysis)
	assert.Empty(t, hooks)
}

func TestHookRegistry_UnregisterHook_NotFound(t *testing.T) {
	registry := NewHookRegistry()
	err := registry.UnregisterHook(HookPreAnalysis, "nonexistent")
	require.Error(t, err)
}

func TestHookRegistry_GetHooks(t *testing.T) {
	registry := NewHookRegistry()
	require.NoError(t, registry.RegisterHook(Hook{
		Name: "a", Point: HookPreAnalysis, Func: func(_ *HookContext) error { return nil },
	}))
	require.NoError(t, registry.RegisterHook(Hook{
		Name: "b", Point: HookPostAnalysis, Func: func(_ *HookContext) error { return nil },
	}))

	preHooks := registry.GetHooks(HookPreAnalysis)
	assert.Len(t, preHooks, 1)
	assert.Equal(t, "a", preHooks[0].Name)

	postHooks := registry.GetHooks(HookPostAnalysis)
	assert.Len(t, postHooks, 1)
	assert.Equal(t, "b", postHooks[0].Name)
}

func TestHookRegistry_GetHooks_Empty(t *testing.T) {
	registry := NewHookRegistry()
	hooks := registry.GetHooks(HookPreAnalysis)
	assert.Empty(t, hooks)
}

func TestHookRegistry_Clear(t *testing.T) {
	registry := NewHookRegistry()
	require.NoError(t, registry.RegisterHook(Hook{
		Name: "a", Point: HookPreAnalysis, Func: func(_ *HookContext) error { return nil },
	}))
	require.NoError(t, registry.RegisterHook(Hook{
		Name: "b", Point: HookPostAnalysis, Func: func(_ *HookContext) error { return nil },
	}))

	registry.Clear()

	assert.Empty(t, registry.GetHooks(HookPreAnalysis))
	assert.Empty(t, registry.GetHooks(HookPostAnalysis))
}

func TestHookRegistry_PriorityOrder(t *testing.T) {
	registry := NewHookRegistry()
	var order []string

	require.NoError(t, registry.RegisterHook(Hook{
		Name:     "low-priority",
		Point:    HookPreAnalysis,
		Func:     func(_ *HookContext) error { order = append(order, "low"); return nil },
		Priority: 100,
	}))
	require.NoError(t, registry.RegisterHook(Hook{
		Name:     "high-priority",
		Point:    HookPreAnalysis,
		Func:     func(_ *HookContext) error { order = append(order, "high"); return nil },
		Priority: -100,
	}))
	require.NoError(t, registry.RegisterHook(Hook{
		Name:     "medium-priority",
		Point:    HookPreAnalysis,
		Func:     func(_ *HookContext) error { order = append(order, "medium"); return nil },
		Priority: 0,
	}))

	_, err := registry.Execute(context.Background(), HookPreAnalysis, nil)
	require.NoError(t, err)

	assert.Equal(t, []string{"high", "medium", "low"}, order)
}

func TestHookRegistry_ExecuteHookError(t *testing.T) {
	registry := NewHookRegistry()
	require.NoError(t, registry.RegisterHook(Hook{
		Name:  "failing-hook",
		Point: HookPreAnalysis,
		Func:  func(_ *HookContext) error { return assertError("hook failed") },
	}))

	_, err := registry.Execute(context.Background(), HookPreAnalysis, nil)
	require.Error(t, err)
}

func TestRegisterHook_NilFunc(t *testing.T) {
	registry := NewHookRegistry()
	err := registry.RegisterHook(Hook{Name: "nil", Point: HookPreAnalysis})
	require.Error(t, err)
}

func TestGlobalHookRegistry(t *testing.T) {
	registry := GlobalHookRegistry()
	assert.NotNil(t, registry)
}

func TestHookRegistry_Execute_NoHooks(t *testing.T) {
	registry := NewHookRegistry()
	ctx, err := registry.Execute(context.Background(), HookPreAnalysis, "test-data")
	require.NoError(t, err)
	assert.NotNil(t, ctx)
	assert.Equal(t, "test-data", ctx.Data)
}

func TestHookRegistry_Execute_CancelStopsExecution(t *testing.T) {
	registry := NewHookRegistry()
	executed := false

	require.NoError(t, registry.RegisterHook(Hook{
		Name:  "cancelling-hook",
		Point: HookPreAnalysis,
		Func: func(ctx *HookContext) error {
			ctx.Cancel = true
			return nil
		},
	}))
	require.NoError(t, registry.RegisterHook(Hook{
		Name:  "should-not-run",
		Point: HookPreAnalysis,
		Func: func(_ *HookContext) error {
			executed = true
			return nil
		},
	}))

	_, err := registry.Execute(context.Background(), HookPreAnalysis, nil)
	require.Error(t, err)
	assert.False(t, executed)
}

func assertError(msg string) error {
	return &simpleError{msg: msg}
}

type simpleError struct{ msg string }

func (e *simpleError) Error() string { return e.msg }
