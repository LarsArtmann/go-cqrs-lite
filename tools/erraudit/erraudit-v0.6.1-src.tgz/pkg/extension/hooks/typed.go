package hooks

import "context"

// This file provides generic typed helpers that eliminate manual type
// assertions throughout the hook system. They are fully backward compatible —
// the existing Execute/RegisterHook API continues to work unchanged.

// TypedHook adapts a typed callback into a HookFunc, eliminating manual type
// assertions in every hook function. The callback receives typed data extracted
// from HookContext.Data. If the runtime data type does not match T, the hook
// returns nil (no-op).
//
// Example:
//
//	hooks.RegisterHook(hooks.Hook{
//	    Name:  "my-logger",
//	    Point: hooks.HookPreAnalysis,
//	    Func:  hooks.TypedHook(func(data *hooks.PreAnalysisData) error {
//	        log.Println("analyzing:", data.Path)
//	        return nil
//	    }),
//	})
func TypedHook[T any](fn func(data T) error) HookFunc {
	return func(ctx *HookContext) error {
		data, ok := ctx.Data.(T)
		if !ok {
			return nil
		}

		return fn(data)
	}
}

// Fire executes hooks at the given point with typed data and returns the
// (possibly modified) data, whether the operation was cancelled, and any error.
//
// When data is passed as a pointer (the convention for all built-in hook data
// types), hooks can modify fields in-place — no need to set ctx.Result.
//
// Example (observer):
//
//	_, cancelled, err := hooks.Fire(ctx, hooks.HookPreAnalysis, &hooks.PreAnalysisData{Path: "."})
//	if cancelled { return }
//
// Example (modifier — hooks modify fields through the pointer):
//
//	data, cancelled, _ := hooks.Fire(ctx, hooks.HookPreViolation, &hooks.PreViolationData{
//	    Violation: violation,
//	    File:      fileName,
//	})
//	if cancelled { return }
//	violation = data.Violation // possibly modified by a hook
func Fire[T any](ctx context.Context, point HookPoint, data T) (T, bool, error) {
	hookCtx, execErr := globalHookRegistry.Execute(ctx, point, data)

	// Execute returns an error on cancel — distinguish from real hook errors.
	if hookCtx != nil && hookCtx.Cancel {
		return data, true, nil
	}

	if execErr != nil {
		return data, false, execErr
	}

	// If a hook set ctx.Result to the same type, return the modified value.
	// This supports the legacy Result-based modification pattern.
	if hookCtx != nil && hookCtx.Result != nil {
		if modified, ok := hookCtx.Result.(T); ok {
			return modified, false, nil
		}
	}

	return data, false, nil
}

// Notify fires hooks at a point for side effects only, discarding the return
// values. Use for observer hooks (Post*) where you don't need the result,
// cancellation status, or error.
//
// Example:
//
//	hooks.Notify(ctx, hooks.HookPostFile, &hooks.PostFileData{FilePath: "main.go"})
func Notify[T any](ctx context.Context, point HookPoint, data T) {
	_, _, _ = Fire(ctx, point, data) //nolint:dogsled,erraudit // fire-and-forget by design
}

// DataAs safely extracts typed data from a HookContext.
// Returns the typed data and true if the data matches type T.
func DataAs[T any](ctx *HookContext) (T, bool) {
	data, ok := ctx.Data.(T)

	return data, ok
}

// ResultAs safely extracts a typed result from a HookContext.
// Returns the typed result and true if the result matches type T.
func ResultAs[T any](ctx *HookContext) (T, bool) {
	result, ok := ctx.Result.(T)

	return result, ok
}
