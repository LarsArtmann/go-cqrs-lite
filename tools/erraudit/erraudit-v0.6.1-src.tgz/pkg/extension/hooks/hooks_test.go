package hooks

import (
	"context"
	"testing"
)

func TestHookRegistry_RegisterHook(t *testing.T) {
	hr := NewHookRegistry()
	h := Hook{
		Name:     "test-hook",
		Point:    HookPreAnalysis,
		Priority: 0,
		Func:     func(ctx *HookContext) error { return nil },
	}
	if err := hr.RegisterHook(h); err != nil {
		t.Fatalf("failed to register hook: %v", err)
	}
	hooks := hr.GetHooks(HookPreAnalysis)
	if len(hooks) != 1 {
		t.Errorf("expected 1 hook, got %d", len(hooks))
	}
}

func TestHookRegistry_Execute(t *testing.T) {
	hr := NewHookRegistry()
	executed := false
	h := Hook{
		Name:     "exec-hook",
		Point:    HookPreFile,
		Priority: 0,
		Func: func(ctx *HookContext) error {
			executed = true
			return nil
		},
	}
	_ = hr.RegisterHook(h)
	_, err := hr.Execute(context.Background(), HookPreFile, &PreFileData{FilePath: "test.go"})
	if err != nil {
		t.Fatalf("execute failed: %v", err)
	}
	if !executed {
		t.Error("hook was not executed")
	}
}

func TestHookRegistry_ExecuteWithCancel(t *testing.T) {
	hr := NewHookRegistry()
	h := Hook{
		Name:     "cancel-hook",
		Point:    HookPreAnalysis,
		Priority: 0,
		Func: func(ctx *HookContext) error {
			ctx.Cancel = true
			return nil
		},
	}
	_ = hr.RegisterHook(h)
	_, err := hr.Execute(context.Background(), HookPreAnalysis, &PreAnalysisData{Path: "."})
	if err == nil {
		t.Error("expected error on cancel")
	}
}

func TestHookRegistry_FixHooks(t *testing.T) {
	hr := NewHookRegistry()

	preExecuted := false
	postExecuted := false

	_ = hr.RegisterHook(Hook{
		Name:     "pre-fix",
		Point:    HookPreFix,
		Priority: 0,
		Func: func(ctx *HookContext) error {
			preExecuted = true
			data, ok := ctx.Data.(*PreFixData)
			if !ok || len(data.Fixes) != 2 {
				t.Errorf("expected 2 fixes in PreFixData, got %v", data)
			}
			return nil
		},
	})

	_ = hr.RegisterHook(Hook{
		Name:     "post-fix",
		Point:    HookPostFix,
		Priority: 0,
		Func: func(ctx *HookContext) error {
			postExecuted = true
			data, ok := ctx.Data.(*PostFixData)
			if !ok || data.ChangeCount != 2 {
				t.Errorf("expected ChangeCount=2 in PostFixData, got %v", data)
			}
			return nil
		},
	})

	_, err := hr.Execute(context.Background(), HookPreFix, &PreFixData{Fixes: []string{"a.go", "b.go"}})
	if err != nil {
		t.Fatalf("pre-fix execute failed: %v", err)
	}

	_, err = hr.Execute(
		context.Background(),
		HookPostFix,
		&PostFixData{Fixes: []string{"a.go", "b.go"}, ChangeCount: 2},
	)
	if err != nil {
		t.Fatalf("post-fix execute failed: %v", err)
	}

	if !preExecuted {
		t.Error("pre-fix hook was not executed")
	}
	if !postExecuted {
		t.Error("post-fix hook was not executed")
	}
}

func TestHookRegistry_PreFixCancel(t *testing.T) {
	hr := NewHookRegistry()
	_ = hr.RegisterHook(Hook{
		Name:     "cancel-fix",
		Point:    HookPreFix,
		Priority: 0,
		Func: func(ctx *HookContext) error {
			ctx.Cancel = true
			return nil
		},
	})

	_, err := hr.Execute(context.Background(), HookPreFix, &PreFixData{Fixes: []string{"a.go"}})
	if err == nil {
		t.Error("expected error on pre-fix cancel")
	}
}
