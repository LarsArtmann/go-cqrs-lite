// Package hooks provides the hook system for the erraudit analyzer,
// allowing extensions to attach callbacks at 10 points in the analysis lifecycle.
//
// # Typed API (preferred)
//
// For compile-time type safety, use the generic helpers instead of manual
// type assertions on HookContext.Data:
//
//	hooks.RegisterHook(hooks.Hook{
//	    Name:  "my-logger",
//	    Point: hooks.HookPreAnalysis,
//	    Func:  hooks.TypedHook(func(data *hooks.PreAnalysisData) error {
//	        log.Println("analyzing:", data.Path)
//	        return nil
//	    }),
//	})
//
//	data, cancelled, err := hooks.Fire(ctx, hooks.HookPreAnalysis, &hooks.PreAnalysisData{Path: "."})
package hooks
