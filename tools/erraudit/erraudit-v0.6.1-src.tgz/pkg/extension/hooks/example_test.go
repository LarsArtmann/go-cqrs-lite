package hooks_test

import (
	"context"
	"fmt"

	"github.com/larsartmann/erraudit/pkg/extension/hooks"
)

func ExampleTypedHook() {
	registry := hooks.NewHookRegistry()

	err := registry.RegisterHook(hooks.Hook{
		Name:     "my-pre-analysis",
		Point:    hooks.HookPreAnalysis,
		Priority: 0,
		Func: hooks.TypedHook(func(data *hooks.PreAnalysisData) error {
			fmt.Println("analyzing:", data.Path)
			return nil
		}),
	})
	if err != nil {
		fmt.Println("register error:", err)
	}

	_, err = registry.Execute(context.Background(), hooks.HookPreAnalysis, &hooks.PreAnalysisData{Path: "./mypkg"})
	if err != nil {
		fmt.Println("execute error:", err)
	}
	// Output:
	// analyzing: ./mypkg
}

func ExampleFire() {
	// Fire returns typed data, cancellation status, and error — no manual assertions.
	data, cancelled, err := hooks.Fire(
		context.Background(),
		hooks.HookPreAnalysis,
		&hooks.PreAnalysisData{Path: "./mypkg"},
	)
	if err != nil {
		fmt.Println("error:", err)
		return
	}

	fmt.Println("path:", data.Path)
	fmt.Println("cancelled:", cancelled)
	// Output:
	// path: ./mypkg
	// cancelled: false
}

func ExampleHookRegistry_UnregisterHook() {
	registry := hooks.NewHookRegistry()

	_ = registry.RegisterHook(hooks.Hook{
		Name:  "temp",
		Point: hooks.HookPreFile,
		Func:  func(ctx *hooks.HookContext) error { return nil },
	})

	fmt.Println("before:", len(registry.GetHooks(hooks.HookPreFile)))

	_ = registry.UnregisterHook(hooks.HookPreFile, "temp")

	fmt.Println("after:", len(registry.GetHooks(hooks.HookPreFile)))
	// Output:
	// before: 1
	// after: 0
}

func ExampleHookPoint() {
	points := []hooks.HookPoint{
		hooks.HookPreAnalysis,
		hooks.HookPostAnalysis,
		hooks.HookPreFix,
	}

	for _, p := range points {
		fmt.Println(p)
	}
	// Output:
	// pre_analysis
	// post_analysis
	// pre_fix
}
