package builtins

import (
	"context"
	"fmt"
	"os"
	"sync"

	pkgerrors "github.com/larsartmann/erraudit/pkg/errors"
	"github.com/larsartmann/erraudit/pkg/extension/hooks"
	"github.com/larsartmann/erraudit/pkg/extension/registry"
)

// registerHooks registers multiple hooks and returns an error if any registration fails.
func registerHooks(hookList []hooks.Hook) error {
	for _, h := range hookList {
		err := hooks.RegisterHook(h)
		if err != nil {
			return pkgerrors.Wrap(err, "failed to register hook")
		}
	}

	return nil
}

// unregisterHooks removes every (point, name) pair from the global registry.
// Errors are intentionally swallowed: shutdown must not fail if a hook was
// never registered (e.g. when Initialize was skipped due to an error).
func unregisterHooks(hookNames map[hooks.HookPoint]string) error {
	for point, name := range hookNames {
		_ = hooks.GlobalHookRegistry(). //nolint:erraudit // cleanup: hook may not be registered
						UnregisterHook(point, name)
	}

	return nil
}

// LoggingExtension is a built-in feature that logs analysis lifecycle events.
type LoggingExtension struct {
	*registry.ExtensionMetadata

	logger func(format string, args ...any)
}

// NewLoggingExtension creates a logging feature.
func NewLoggingExtension(logger func(format string, args ...any)) *LoggingExtension {
	if logger == nil {
		logger = func(format string, args ...any) {
			fmt.Fprintf(os.Stderr, "[feature:logger] "+format+"\n", args...)
		}
	}

	return &LoggingExtension{
		ExtensionMetadata: registry.NewExtensionMetadata("builtin-logger", "1.0.0", registry.TypeMetricsProvider).
			WithDescription("Built-in logging feature for analysis lifecycle events").
			WithAuthor("erraudit"),
		logger: logger,
	}
}

// Initialize sets up the logging hooks.
func (p *LoggingExtension) Initialize(_ context.Context) error {
	hookList := []hooks.Hook{
		{
			Name:     "logger-pre-analysis",
			Point:    hooks.HookPreAnalysis,
			Priority: hooks.PriorityPreHooks,
			Func:     p.logPreAnalysis,
		},
		{
			Name:     "logger-post-analysis",
			Point:    hooks.HookPostAnalysis,
			Priority: hooks.PriorityPostHooks,
			Func:     p.logPostAnalysis,
		},
		{Name: "logger-pre-file", Point: hooks.HookPreFile, Priority: hooks.PriorityPreHooks, Func: p.logPreFile},
		{Name: "logger-post-file", Point: hooks.HookPostFile, Priority: hooks.PriorityPostHooks, Func: p.logPostFile},
	}

	return registerHooks(hookList)
}

// Shutdown removes the logging hooks.
func (p *LoggingExtension) Shutdown(_ context.Context) error {
	hookNames := map[hooks.HookPoint]string{
		hooks.HookPreAnalysis:  "logger-pre-analysis",
		hooks.HookPostAnalysis: "logger-post-analysis",
		hooks.HookPreFile:      "logger-pre-file",
		hooks.HookPostFile:     "logger-post-file",
	}

	return unregisterHooks(hookNames)
}

func (p *LoggingExtension) logPreAnalysis(ctx *hooks.HookContext) error {
	data, ok := hooks.DataAs[*hooks.PreAnalysisData](ctx)
	if !ok {
		return nil
	}

	p.logger("Starting analysis of %s", data.Path)

	return nil
}

func (p *LoggingExtension) logPostAnalysis(ctx *hooks.HookContext) error {
	data, ok := hooks.DataAs[*hooks.PostAnalysisData](ctx)
	if !ok {
		return nil
	}

	p.logger("Completed analysis of %s in %dms", data.Path, data.Duration)

	return nil
}

func (p *LoggingExtension) logPreFile(ctx *hooks.HookContext) error {
	data, ok := hooks.DataAs[*hooks.PreFileData](ctx)
	if !ok {
		return nil
	}

	p.logger("Analyzing file: %s", data.FilePath)

	return nil
}

func (p *LoggingExtension) logPostFile(ctx *hooks.HookContext) error {
	data, ok := hooks.DataAs[*hooks.PostFileData](ctx)
	if !ok {
		return nil
	}

	if data.Error != nil {
		p.logger("Failed to analyze %s: %v", data.FilePath, data.Error)
	} else {
		p.logger("Finished analyzing %s", data.FilePath)
	}

	return nil
}

// MetricsCollectorExtension is a built-in feature that collects analysis metrics.
type MetricsCollectorExtension struct {
	*registry.ExtensionMetadata

	mu           sync.Mutex
	fileCount    int
	violations   int
	errors       int
	durations    []int64
	errorDetails []string
}

// NewMetricsCollectorExtension creates a metrics collector feature.
func NewMetricsCollectorExtension() *MetricsCollectorExtension {
	return &MetricsCollectorExtension{
		ExtensionMetadata: registry.NewExtensionMetadata("builtin-metrics", "1.0.0", registry.TypeMetricsProvider).
			WithDescription("Built-in feature for collecting analysis metrics").
			WithAuthor("erraudit"),
		durations:    make([]int64, 0),
		errorDetails: make([]string, 0),
	}
}

// Initialize sets up the metrics collection hooks.
func (p *MetricsCollectorExtension) Initialize(_ context.Context) error {
	hookList := []hooks.Hook{
		{
			Name:     "metrics-pre-analysis",
			Point:    hooks.HookPreAnalysis,
			Priority: hooks.PriorityPreHooks + 1,
			Func:     p.preAnalysis,
		},
		{
			Name:     "metrics-post-analysis",
			Point:    hooks.HookPostAnalysis,
			Priority: hooks.PriorityBuiltinPostHooks,
			Func:     hooks.TypedHook(p.postAnalysis),
		},
		{
			Name:     "metrics-post-file",
			Point:    hooks.HookPostFile,
			Priority: hooks.PriorityBuiltinPostHooks,
			Func:     hooks.TypedHook(p.postFile),
		},
		{
			Name:     "metrics-post-violation",
			Point:    hooks.HookPostViolation,
			Priority: hooks.PriorityBuiltinPostHooks,
			Func:     hooks.TypedHook(p.postViolation),
		},
	}

	return registerHooks(hookList)
}

// Shutdown removes the metrics hooks.
func (p *MetricsCollectorExtension) Shutdown(_ context.Context) error {
	hookNames := map[hooks.HookPoint]string{
		hooks.HookPreAnalysis:   "metrics-pre-analysis",
		hooks.HookPostAnalysis:  "metrics-post-analysis",
		hooks.HookPostFile:      "metrics-post-file",
		hooks.HookPostViolation: "metrics-post-violation",
	}

	return unregisterHooks(hookNames)
}

func (p *MetricsCollectorExtension) preAnalysis(_ *hooks.HookContext) error {
	p.mu.Lock()
	defer p.mu.Unlock()

	p.fileCount = 0
	p.violations = 0
	p.errors = 0
	p.durations = p.durations[:0]
	p.errorDetails = p.errorDetails[:0]

	return nil
}

func (p *MetricsCollectorExtension) postAnalysis(data *hooks.PostAnalysisData) error {
	p.mu.Lock()
	p.durations = append(p.durations, data.Duration)
	p.mu.Unlock()

	return nil
}

func (p *MetricsCollectorExtension) postFile(data *hooks.PostFileData) error {
	p.mu.Lock()

	p.fileCount++
	if data.Error != nil {
		p.errors++
		p.errorDetails = append(p.errorDetails, data.FilePath+": "+data.Error.Error())
	}
	p.mu.Unlock()

	return nil
}

func (p *MetricsCollectorExtension) postViolation(_ *hooks.PostViolationData) error {
	p.mu.Lock()
	p.violations++
	p.mu.Unlock()

	return nil
}

// Builtins registers all built-in features with the global registry.
func Builtins(ctx context.Context) error {
	return BuiltinsWithLogger(ctx, nil)
}

// BuiltinsWithLogger registers all built-in features, using the provided logger
// for the LoggingExtension. When logger is nil, the default stderr logger is
// used. Pass a no-op function to suppress all log output (e.g. for --quiet).
func BuiltinsWithLogger(ctx context.Context, logger func(format string, args ...any)) error {
	if err := registerBuiltin(ctx, "logging feature", NewLoggingExtension(logger)); err != nil {
		return err
	}

	return registerBuiltin(ctx, "metrics feature", NewMetricsCollectorExtension())
}

// registerBuiltin registers a single feature with the global registry and wraps
// any failure with the feature name for diagnostics. Returns nil on success.
func registerBuiltin(ctx context.Context, name string, f registry.Extension) error {
	return pkgerrors.Wrap(registry.GlobalRegistry().Register(ctx, f), "failed to register %s", name)
}
