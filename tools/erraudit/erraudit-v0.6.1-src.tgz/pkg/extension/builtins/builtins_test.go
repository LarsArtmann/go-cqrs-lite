package builtins

import (
	"context"
	"io"
	"os"
	"testing"

	"github.com/larsartmann/erraudit/pkg/extension/hooks"
	"github.com/larsartmann/erraudit/pkg/extension/registry"
	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// newNoopHook builds a hook with the given name, point, and a no-op function.
func newNoopHook(name string, point hooks.HookPoint) hooks.Hook {
	return hooks.Hook{
		Name:     name,
		Point:    point,
		Priority: 0,
		Func:     func(_ *hooks.HookContext) error { return nil },
	}
}

func TestNewLoggingFeature_WithCustomLogger(t *testing.T) {
	t.Parallel()

	var logged []string
	logger := func(format string, args ...any) {
		logged = append(logged, format)
	}

	ext := NewLoggingExtension(logger)
	require.NotNil(t, ext)
	assert.Equal(t, "builtin-logger", ext.Metadata().Name)
	assert.Equal(t, "1.0.0", ext.Metadata().Version)
}

func TestNewLoggingFeature_DefaultLogger(t *testing.T) {
	t.Parallel()

	ext := NewLoggingExtension(nil)
	require.NotNil(t, ext)
	assert.Equal(t, "builtin-logger", ext.Metadata().Name)
	assert.NotNil(t, ext.logger)
}

func TestLoggingExtension_InitializeAndShutdown(t *testing.T) {
	// Not parallel: manipulates global hook registry
	hooks.GlobalHookRegistry().Clear()
	t.Cleanup(func() {
		hooks.GlobalHookRegistry().Clear()
	})

	var logged []string
	logger := func(format string, args ...any) {
		logged = append(logged, format)
	}

	ext := NewLoggingExtension(logger)
	err := ext.Initialize(context.Background())
	require.NoError(t, err)

	// Verify hooks were registered
	assert.Len(t, hooks.GlobalHookRegistry().GetHooks(hooks.HookPreAnalysis), 1)
	assert.Len(t, hooks.GlobalHookRegistry().GetHooks(hooks.HookPostAnalysis), 1)
	assert.Len(t, hooks.GlobalHookRegistry().GetHooks(hooks.HookPreFile), 1)
	assert.Len(t, hooks.GlobalHookRegistry().GetHooks(hooks.HookPostFile), 1)

	// Execute a hook to verify it logs
	_, _, err = hooks.Fire(context.Background(), hooks.HookPreAnalysis, &hooks.PreAnalysisData{Path: "test.go"})
	require.NoError(t, err)
	assert.Len(t, logged, 1)
	assert.Contains(t, logged[0], "Starting analysis")

	// Shutdown should unregister hooks
	err = ext.Shutdown(context.Background())
	require.NoError(t, err)

	assert.Empty(t, hooks.GlobalHookRegistry().GetHooks(hooks.HookPreAnalysis))
	assert.Empty(t, hooks.GlobalHookRegistry().GetHooks(hooks.HookPostAnalysis))
	assert.Empty(t, hooks.GlobalHookRegistry().GetHooks(hooks.HookPreFile))
	assert.Empty(t, hooks.GlobalHookRegistry().GetHooks(hooks.HookPostFile))
}

func TestLoggingExtension_LogPreFile(t *testing.T) {
	hooks.GlobalHookRegistry().Clear()
	t.Cleanup(func() {
		hooks.GlobalHookRegistry().Clear()
	})

	var logged []string
	logger := func(format string, args ...any) {
		logged = append(logged, format)
	}

	ext := NewLoggingExtension(logger)
	require.NoError(t, ext.Initialize(context.Background()))
	defer ext.Shutdown(context.Background())

	_, _, err := hooks.Fire(context.Background(), hooks.HookPreFile, &hooks.PreFileData{FilePath: "main.go"})
	require.NoError(t, err)

	require.Len(t, logged, 1)
	assert.Contains(t, logged[0], "Analyzing file")
}

func TestLoggingExtension_LogPostFile_Error(t *testing.T) {
	hooks.GlobalHookRegistry().Clear()
	t.Cleanup(func() {
		hooks.GlobalHookRegistry().Clear()
	})

	var logged []string
	logger := func(format string, args ...any) {
		logged = append(logged, format)
	}

	ext := NewLoggingExtension(logger)
	require.NoError(t, ext.Initialize(context.Background()))
	defer ext.Shutdown(context.Background())

	_, _, err := hooks.Fire(
		context.Background(),
		hooks.HookPostFile,
		&hooks.PostFileData{FilePath: "main.go", Error: assert.AnError},
	)
	require.NoError(t, err)

	require.Len(t, logged, 1)
	assert.Contains(t, logged[0], "Failed to analyze")
}

func TestNewMetricsCollectorFeature(t *testing.T) {
	t.Parallel()

	ext := NewMetricsCollectorExtension()
	require.NotNil(t, ext)
	assert.Equal(t, "builtin-metrics", ext.Metadata().Name)
	assert.Equal(t, "1.0.0", ext.Metadata().Version)
	assert.NotNil(t, ext.durations)
	assert.NotNil(t, ext.errorDetails)
}

func TestMetricsCollectorExtension_InitializeAndShutdown(t *testing.T) {
	hooks.GlobalHookRegistry().Clear()
	t.Cleanup(func() {
		hooks.GlobalHookRegistry().Clear()
	})

	ext := NewMetricsCollectorExtension()
	err := ext.Initialize(context.Background())
	require.NoError(t, err)

	// Verify hooks were registered
	assert.Len(t, hooks.GlobalHookRegistry().GetHooks(hooks.HookPreAnalysis), 1)
	assert.Len(t, hooks.GlobalHookRegistry().GetHooks(hooks.HookPostAnalysis), 1)
	assert.Len(t, hooks.GlobalHookRegistry().GetHooks(hooks.HookPostFile), 1)
	assert.Len(t, hooks.GlobalHookRegistry().GetHooks(hooks.HookPostViolation), 1)

	// Execute post-analysis hook
	_, _, err = hooks.Fire(
		context.Background(),
		hooks.HookPostAnalysis,
		&hooks.PostAnalysisData{Path: "test.go", Duration: 42},
	)
	require.NoError(t, err)
	assert.Equal(t, []int64{42}, ext.durations)

	// Execute post-file hook with error
	_, _, err = hooks.Fire(
		context.Background(),
		hooks.HookPostFile,
		&hooks.PostFileData{FilePath: "main.go", Error: assert.AnError},
	)
	require.NoError(t, err)
	assert.Equal(t, 1, ext.fileCount)
	assert.Equal(t, 1, ext.errors)

	// Execute post-violation hook
	_, _, err = hooks.Fire(
		context.Background(),
		hooks.HookPostViolation,
		&hooks.PostViolationData{Violation: types.ErrorViolation{}},
	)
	require.NoError(t, err)
	assert.Equal(t, 1, ext.violations)

	// Execute pre-analysis hook to reset
	_, _, err = hooks.Fire(context.Background(), hooks.HookPreAnalysis, &hooks.PreAnalysisData{Path: "test.go"})
	require.NoError(t, err)
	assert.Equal(t, 0, ext.fileCount)
	assert.Equal(t, 0, ext.violations)
	assert.Equal(t, 0, ext.errors)

	// Shutdown should unregister hooks
	err = ext.Shutdown(context.Background())
	require.NoError(t, err)

	assert.Empty(t, hooks.GlobalHookRegistry().GetHooks(hooks.HookPreAnalysis))
	assert.Empty(t, hooks.GlobalHookRegistry().GetHooks(hooks.HookPostAnalysis))
	assert.Empty(t, hooks.GlobalHookRegistry().GetHooks(hooks.HookPostFile))
	assert.Empty(t, hooks.GlobalHookRegistry().GetHooks(hooks.HookPostViolation))
}

func TestMetricsCollectorExtension_PostFile_Success(t *testing.T) {
	hooks.GlobalHookRegistry().Clear()
	t.Cleanup(func() {
		hooks.GlobalHookRegistry().Clear()
	})

	ext := NewMetricsCollectorExtension()
	require.NoError(t, ext.Initialize(context.Background()))
	defer ext.Shutdown(context.Background())

	_, _, err := hooks.Fire(context.Background(), hooks.HookPostFile, &hooks.PostFileData{FilePath: "main.go"})
	require.NoError(t, err)

	assert.Equal(t, 1, ext.fileCount)
	assert.Equal(t, 0, ext.errors)
	assert.Empty(t, ext.errorDetails)
}

func TestBuiltins(t *testing.T) {
	// Not parallel: manipulates global registries
	hooks.GlobalHookRegistry().Clear()
	registry.GlobalRegistry().Clear(context.Background())
	t.Cleanup(func() {
		hooks.GlobalHookRegistry().Clear()
		registry.GlobalRegistry().Clear(context.Background())
	})

	err := Builtins(context.Background())
	require.NoError(t, err)

	// Verify extensions are registered
	extensions := registry.GlobalRegistry().List()
	require.Len(t, extensions, 2)

	names := make([]string, len(extensions))
	for i, p := range extensions {
		names[i] = p.Metadata().Name
	}
	assert.Contains(t, names, "builtin-logger")
	assert.Contains(t, names, "builtin-metrics")
}

func TestRegisterHooks_Failure(t *testing.T) {
	t.Parallel()

	hooks.GlobalHookRegistry().Clear()
	t.Cleanup(func() {
		hooks.GlobalHookRegistry().Clear()
	})

	// Register a hook first, then try to register a duplicate
	// The global registry should handle duplicates but let's test error path
	err := registerHooks([]hooks.Hook{newNoopHook("test-hook", hooks.HookPreAnalysis)})
	require.NoError(t, err)

	// Registering the same hook again should succeed (registry allows duplicates)
	err = registerHooks([]hooks.Hook{newNoopHook("test-hook-2", hooks.HookPreAnalysis)})
	require.NoError(t, err)

	assert.Len(t, hooks.GlobalHookRegistry().GetHooks(hooks.HookPreAnalysis), 2)
}

func TestLoggingExtension_DefaultLoggerWritesToStderr(t *testing.T) {
	t.Parallel()

	ext := NewLoggingExtension(nil)
	require.NotNil(t, ext)
	require.NotNil(t, ext.Metadata())

	ctx := &hooks.PostFileData{
		FilePath: "test.go",
	}

	oldStderr := os.Stderr
	r, w, _ := os.Pipe()
	os.Stderr = w

	hooks.GlobalHookRegistry().Clear()
	t.Cleanup(func() {
		hooks.GlobalHookRegistry().Clear()
		os.Stderr = oldStderr
	})

	require.NoError(t, ext.Initialize(context.Background()))
	hooks.Notify(context.Background(), hooks.HookPostFile, ctx)

	w.Close()
	os.Stderr = oldStderr

	output, _ := io.ReadAll(r)
	assert.Contains(t, string(output), "test.go",
		"ext logger output should go to stderr, not stdout")
}
