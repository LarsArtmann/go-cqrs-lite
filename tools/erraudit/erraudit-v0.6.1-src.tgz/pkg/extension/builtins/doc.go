// Package builtins provides built-in extensions (logger, metrics) that ship with
// the erraudit analyzer.
package builtins
