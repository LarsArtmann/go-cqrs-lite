package builtins_test

import (
	"context"
	"fmt"

	"github.com/larsartmann/erraudit/pkg/extension/builtins"
)

func ExampleNewLoggingExtension() {
	feature := builtins.NewLoggingExtension(func(format string, args ...any) {
		fmt.Printf(format, args...)
		fmt.Println()
	})

	if err := feature.Initialize(context.Background()); err != nil {
		fmt.Println("init error:", err)
		return
	}

	fmt.Println("feature name:", feature.Metadata().Name)

	_ = feature.Shutdown(context.Background())
	// Output:
	// feature name: builtin-logger
}

func ExampleNewMetricsCollectorExtension() {
	feature := builtins.NewMetricsCollectorExtension()

	if err := feature.Initialize(context.Background()); err != nil {
		fmt.Println("init error:", err)
		return
	}

	fmt.Println("feature name:", feature.Metadata().Name)

	_ = feature.Shutdown(context.Background())
	// Output:
	// feature name: builtin-metrics
}
