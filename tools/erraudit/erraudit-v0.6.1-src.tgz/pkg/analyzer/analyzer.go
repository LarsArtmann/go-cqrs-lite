// Package analyzer provides public access to the erraudit analysis engine.
// It re-exports the internal analyzer types and functions so external consumers
// can create analyzers, run analysis, and feed results into the finding pipeline
// without importing internal packages.
package analyzer

import (
	"time"

	internalanalyzer "github.com/larsartmann/erraudit/internal/analyzer"
)

// Analyzer defines the interface for error analysis operations.
type Analyzer = internalanalyzer.Analyzer

// MainAnalyzer performs comprehensive error analysis on Go source files.
type MainAnalyzer = internalanalyzer.MainAnalyzer

// MainAnalyzerOption is a functional option for configuring MainAnalyzer.
type MainAnalyzerOption = internalanalyzer.MainAnalyzerOption

// NewMainAnalyzer creates a new main analyzer with default settings.
func NewMainAnalyzer() *MainAnalyzer {
	return internalanalyzer.NewMainAnalyzer()
}

// NewMainAnalyzerWithOptions creates a new main analyzer with functional options.
func NewMainAnalyzerWithOptions(opts ...MainAnalyzerOption) *MainAnalyzer {
	return internalanalyzer.NewMainAnalyzerWithOptions(opts...)
}

// NewMainAnalyzerWithExclusions creates a new main analyzer with excluded paths.
func NewMainAnalyzerWithExclusions(excludedPaths []string) *MainAnalyzer {
	return internalanalyzer.NewMainAnalyzerWithExclusions(excludedPaths)
}

// WithPackageCache enables package caching with the specified TTL.
func WithPackageCache(ttl time.Duration) MainAnalyzerOption {
	return internalanalyzer.WithPackageCache(ttl)
}

// WithExclusions sets the excluded paths for the analyzer.
func WithExclusions(excludedPaths []string) MainAnalyzerOption {
	return internalanalyzer.WithExclusions(excludedPaths)
}

// WithMaxConcurrentFiles sets the maximum number of files to analyze concurrently.
func WithMaxConcurrentFiles(maxCount int) MainAnalyzerOption {
	return internalanalyzer.WithMaxConcurrentFiles(maxCount)
}

// WithTypeInfo enables go/types integration for type-aware violation detection.
func WithTypeInfo(enabled bool) MainAnalyzerOption {
	return internalanalyzer.WithTypeInfo(enabled)
}
