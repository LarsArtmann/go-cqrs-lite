package provider

import "context"

// Options carries per-invocation provider configuration via the context.
// The zero value means "production defaults" (DefaultAnalysisSpec): type-aware
// analysis, //nolint suppression, explanations, no enforcement opt-ins.
type Options struct {
	// ExcludedPaths are paths to skip during analysis.
	ExcludedPaths []string

	// TypeAware overrides the type-aware default. nil = default (on).
	TypeAware *bool

	// NoSuppress disables //nolint suppression (audit mode).
	NoSuppress bool

	// Enforcement opt-ins, mirroring the CLI flags of the same names.
	EnforceErrorFamily   bool
	EnforceSamberOops    bool
	EnforceGenericReturn bool
	EnforceDeferredClose bool

	// AllowDegraded lets analysis fall back to AST-only mode when the
	// type-aware package load fails (e.g. broken module metadata in the
	// target). Without it, a failed type-aware load is an error.
	AllowDegraded bool
}

// optionsKey is the context key for provider Options.
type optionsKey struct{}

// WithOptions returns a context carrying the given provider Options.
func WithOptions(ctx context.Context, opts Options) context.Context {
	return context.WithValue(ctx, optionsKey{}, opts)
}

// OptionsFromContext returns the Options carried by ctx, or the zero value
// (production defaults) when none are set.
func OptionsFromContext(ctx context.Context) Options {
	opts, _ := ctx.Value(optionsKey{}).(Options)

	return opts
}
