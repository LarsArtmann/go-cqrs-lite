package provider_test

import (
	"context"
	"os"
	"path/filepath"
	"testing"

	"github.com/larsartmann/erraudit/pkg/provider"
	findingsdk "github.com/larsartmann/go-finding"
	"github.com/stretchr/testify/require"
)

const optionsProbeSource = "package probe\n\nfunc doIt() error { return nil }\n\nfunc run() {\n\terr := doIt()\n\tif err != nil {\n\t}\n}\n"

func writeProbeFile(t *testing.T, dir, name, content string) {
	t.Helper()
	require.NoError(t, os.WriteFile(filepath.Join(dir, name), []byte(content), 0o600))
}

func detectFindings(t *testing.T, ctx context.Context) []findingsdk.Finding {
	t.Helper()

	findings, err := provider.Provider.Detect.Detect(ctx)
	require.NoError(t, err)

	return findings
}

func TestOptionsRoundTrip(t *testing.T) {
	ctx := context.Background()
	require.Equal(
		t,
		provider.Options{},
		provider.OptionsFromContext(ctx),
		"unset context must yield zero-value defaults",
	)

	opts := provider.Options{NoSuppress: true, ExcludedPaths: []string{"gen/**"}}
	require.Equal(t, opts, provider.OptionsFromContext(provider.WithOptions(ctx, opts)))
}

func TestOptionsExcludedPaths(t *testing.T) {
	dir := t.TempDir()
	writeProbeFile(t, dir, "go.mod", "module probemod\n\ngo 1.21\n")
	writeProbeFile(t, dir, "probe.go", optionsProbeSource)

	ctx := provider.WithOptions(
		findingsdk.WithWorkingDir(context.Background(), dir),
		provider.Options{ExcludedPaths: []string{dir}},
	)

	require.Empty(t, detectFindings(t, ctx), "excluded path must yield no findings")
}

func TestOptionsNoSuppress(t *testing.T) {
	dir := t.TempDir()
	writeProbeFile(t, dir, "go.mod", "module probemod\n\ngo 1.21\n")
	writeProbeFile(
		t,
		dir,
		"probe.go",
		"package probe\n\nfunc doIt() error { return nil }\n\nfunc run() {\n\terr := doIt()\n\tif err != nil {\n\t} //nolint:erraudit\n}\n",
	)

	base := findingsdk.WithWorkingDir(context.Background(), dir)

	for _, f := range detectFindings(t, base) {
		require.NotEqual(t, "silent_swallow", f.Rule, "suppression must be on by default")
	}

	auditCtx := provider.WithOptions(base, provider.Options{NoSuppress: true})

	var sawSilentSwallow bool

	for _, f := range detectFindings(t, auditCtx) {
		if f.Rule == "silent_swallow" {
			sawSilentSwallow = true
		}
	}

	require.True(t, sawSilentSwallow, "NoSuppress must surface the suppressed violation")
}

func TestOptionsEnforcementToggle(t *testing.T) {
	dir := t.TempDir()
	writeProbeFile(t, dir, "go.mod", "module probemod\n\ngo 1.21\n")
	writeProbeFile(
		t,
		dir,
		"probe.go",
		"package probe\n\nimport \"errors\"\n\nfunc makeErr() error {\n\treturn errors.New(\"boom\")\n}\n",
	)

	base := findingsdk.WithWorkingDir(context.Background(), dir)

	for _, f := range detectFindings(t, base) {
		require.NotEqual(t, "generic_return", f.Rule, "generic_return must stay opt-in through the provider")
	}

	enforceCtx := provider.WithOptions(base, provider.Options{EnforceGenericReturn: true})

	var sawGenericReturn bool

	for _, f := range detectFindings(t, enforceCtx) {
		if f.Rule == "generic_return" {
			sawGenericReturn = true
		}
	}

	require.True(t, sawGenericReturn, "EnforceGenericReturn must activate the opt-in check")
}

func TestOptionsAllowDegraded(t *testing.T) {
	dir := t.TempDir()
	writeProbeFile(t, dir, "go.mod", "module broken!!!mod\n\ngo 1.21\n")
	writeProbeFile(t, dir, "probe.go", optionsProbeSource)

	base := findingsdk.WithWorkingDir(context.Background(), dir)

	t.Run("without AllowDegraded the error surfaces", func(t *testing.T) {
		_, err := provider.Provider.Detect.Detect(base)
		require.Error(t, err, "a broken module must fail the type-aware load without degradation")
	})

	t.Run("with AllowDegraded analysis falls back to AST-only", func(t *testing.T) {
		ctx := provider.WithOptions(base, provider.Options{AllowDegraded: true})

		var sawSilentSwallow bool

		for _, f := range detectFindings(t, ctx) {
			if f.Rule == "silent_swallow" {
				sawSilentSwallow = true
			}
		}

		require.True(t, sawSilentSwallow, "degraded AST-only run must still detect violations")
	})
}

func TestProviderWorkingDirEdges(t *testing.T) {
	fixture := "package probe\n\nfunc doIt() error { return nil }\n\nfunc run() {\n\terr := doIt()\n\tif err != nil {\n\t}\n}\n"

	newFixture := func(t *testing.T) string {
		t.Helper()

		dir := t.TempDir()
		writeProbeFile(t, dir, "go.mod", "module probemod\n\ngo 1.21\n")
		writeProbeFile(t, dir, "probe.go", fixture)

		return dir
	}

	hasSilentSwallow := func(findings []findingsdk.Finding) bool {
		for _, f := range findings {
			if f.Rule == "silent_swallow" {
				return true
			}
		}

		return false
	}

	t.Run("unset working dir resolves to process CWD", func(t *testing.T) {
		dir := newFixture(t)
		t.Chdir(dir)

		findings, err := provider.Provider.Detect.Detect(context.Background())
		require.NoError(t, err)
		require.True(t, hasSilentSwallow(findings), "unset context must fall back to \".\" (CWD)")
	})

	t.Run("relative working dir resolves against process CWD", func(t *testing.T) {
		dir := newFixture(t)
		t.Chdir(dir)
		require.NoError(t, os.MkdirAll(filepath.Join(dir, "sub"), 0o755))
		writeProbeFile(t, filepath.Join(dir, "sub"), "probe.go", fixture)

		findings, err := provider.Provider.Detect.Detect(
			findingsdk.WithWorkingDir(context.Background(), "sub"),
		)
		require.NoError(t, err)
		require.True(t, hasSilentSwallow(findings), "relative dirs must resolve against CWD")
	})
}
