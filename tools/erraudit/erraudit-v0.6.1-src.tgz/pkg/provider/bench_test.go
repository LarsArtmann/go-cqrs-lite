package provider_test

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"testing"

	"github.com/larsartmann/erraudit/pkg/provider"
	findingsdk "github.com/larsartmann/go-finding"
)

// benchFixtureModule builds a module with nFiles analyzed files, each
// containing one silent-swallow pattern.
func benchFixtureModule(b *testing.B, nFiles int) string {
	b.Helper()

	dir := b.TempDir()
	if err := os.WriteFile(filepath.Join(dir, "go.mod"), []byte("module benchmod\n\ngo 1.21\n"), 0o600); err != nil {
		b.Fatal(err)
	}

	src := "package benchmod\n\nfunc doIt%d() error { return nil }\n\nfunc run%d() {\n\terr := doIt%d()\n\tif err != nil {\n\t}\n}\n"

	for i := range nFiles {
		name := filepath.Join(dir, fmt.Sprintf("file%03d.go", i))
		body := fmt.Sprintf(src, i, i, i)
		if err := os.WriteFile(name, []byte(body), 0o600); err != nil {
			b.Fatal(err)
		}
	}

	return dir
}

// BenchmarkProviderDetect measures a full provider Detect run (analysis +
// suppression + explanation + finding conversion) over a 10-file module.
// This is a coarse end-to-end regression detector: type-aware package loading
// dominates, so large swings indicate toolchain/package-resolution drift.
func BenchmarkProviderDetect(b *testing.B) {
	dir := benchFixtureModule(b, 10)
	ctx := findingsdk.WithWorkingDir(context.Background(), dir)

	b.ReportAllocs()
	b.ResetTimer()

	for b.Loop() {
		findings, err := provider.Provider.Detect.Detect(ctx)
		if err != nil {
			b.Fatal(err)
		}

		if len(findings) == 0 {
			b.Fatal("expected findings from fixture module")
		}
	}
}
