package provider_test

import (
	"context"
	"os"
	"path/filepath"
	"testing"

	"github.com/larsartmann/erraudit/pkg/provider"
	findingsdk "github.com/larsartmann/go-finding"
	"github.com/larsartmann/go-finding/toolsdk"
	"github.com/stretchr/testify/require"
)

func TestProviderRegistered(t *testing.T) {
	var registered bool

	for _, spec := range toolsdk.All() {
		if spec.Name == "erraudit" {
			registered = true

			break
		}
	}

	require.True(t, registered, "erraudit spec must be registered in the process-global toolsdk registry")
}

func TestProviderSpecShape(t *testing.T) {
	require.NotEmpty(t, provider.Provider.Name)
	require.NotEmpty(t, provider.Provider.Description)
	require.NotNil(t, provider.Provider.Detect, "erraudit is a detection tool")
	require.Equal(t, "go", provider.Provider.Trigger.Language)
	require.Contains(t, provider.Provider.Trigger.Requires, "**/go.mod", "type-aware analysis needs module context")
}

func TestDetectFindsSilentSwallow(t *testing.T) {
	dir := t.TempDir()

	writeFile(t, dir, "go.mod", "module tmpmod\n\ngo 1.21\n")
	writeFile(
		t,
		dir,
		"tmpmod.go",
		"package tmpmod\n\nfunc doIt() error { return nil }\n\nfunc run() {\n\terr := doIt()\n\tif err != nil {\n\t}\n}\n",
	)

	ctx := findingsdk.WithWorkingDir(context.Background(), dir)
	findings, err := provider.Provider.Detect.Detect(ctx)
	require.NoError(t, err)

	var foundSilentSwallow bool

	for _, f := range findings {
		if f.Rule == "silent_swallow" {
			foundSilentSwallow = true

			break
		}
	}

	require.True(
		t,
		foundSilentSwallow,
		"empty if err != nil block must be detected as silent_swallow, got %d findings",
		len(findings),
	)
}

func writeFile(t *testing.T, dir, name, content string) {
	t.Helper()

	require.NoError(t, os.WriteFile(filepath.Join(dir, name), []byte(content), 0o600))
}
