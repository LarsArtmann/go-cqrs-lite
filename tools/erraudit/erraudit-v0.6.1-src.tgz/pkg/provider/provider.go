// Package provider registers erraudit as a BuildFlow DAG tool via the
// go-finding toolsdk provider contract. BuildFlow discovers this Spec
// (toolsdk.All) whenever it imports this package, turning erraudit into a
// first-class pipeline tool without BuildFlow-side glue.
package provider

import (
	"context"
	"os/exec"

	"github.com/larsartmann/erraudit/cmd/erraudit/cmd/pipeline"
	apierrors "github.com/larsartmann/erraudit/pkg/errors"
	"github.com/larsartmann/erraudit/pkg/finding"
	"github.com/larsartmann/erraudit/pkg/types"
	findingsdk "github.com/larsartmann/go-finding"
	"github.com/larsartmann/go-finding/toolsdk"
)

// Provider is the BuildFlow tool spec for erraudit. Detection runs the full
// analysis in the caller's working directory (finding.WithWorkingDir, "."
// when unset) with type-aware resolution and //nolint suppression honored.
// ModuleFanOut declares per-module fan-out: in multi-module workspaces
// BuildFlow runs detection once per Go module, matching erraudit's hard
// module boundaries (a root-only run would analyze just the root module).
// The enforcement checks that are opt-in on the CLI (go-error-family,
// samber/oops, generic-return, deferred-close) stay opt-in here.
//
//nolint:gochecknoglobals // toolsdk contract: specs self-register as package-level vars
var Provider = toolsdk.Register(newSpec())

// newSpec builds the toolsdk.Spec for erraudit.
func newSpec() toolsdk.Spec {
	return toolsdk.Spec{
		Name:         "erraudit",
		Description:  "Error-handling static analysis: silent swallows, ignored errors, context loss, error-hierarchy violations",
		Trigger:      toolsdk.OnGoModule(),
		DependsOn:    nil,
		ModuleFanOut: true,
		Inputs:       []string{"**/*.go"},
		Detect:       finding.NewErrauditDetector(analyzeWorkingDir),
		Repair:       nil,
		HealthCheck:  checkGoToolchain,
	}
}

// checkGoToolchain verifies the `go` command is available: type-aware
// analysis resolves packages through go/packages, which shells out to the
// module toolchain.
func checkGoToolchain(ctx context.Context) error {
	if _, err := exec.LookPath("go"); err != nil {
		return apierrors.Wrap(apierrors.ErrAnalysisToolchainMissing, "%v", err)
	}

	return nil
}

// analyzeWorkingDir adapts the shared analysis pipeline to the toolsdk
// detector contract: resolve the target directory from the context, build the
// analysis spec from the shared defaults plus context options, and run it.
func analyzeWorkingDir(ctx context.Context) (*types.ErrorGraph, error) {
	path := findingsdk.WorkingDirFromContext(ctx)
	//art-dupl:accept idiomatic empty-string default guard, 3 lines, unrelated packages, different defaults and domains
	if path == "" {
		path = "."
	}

	spec := specForContext(ctx, path)

	analyzeGraph := pipeline.NewDefaultGraphAnalyzer(spec)

	graph, err := analyzeGraph(ctx)
	if err != nil {
		if opts := OptionsFromContext(ctx); opts.AllowDegraded && spec.TypeAware {
			degraded := spec
			degraded.TypeAware = false

			degradedAnalyzer := pipeline.NewDefaultGraphAnalyzer(degraded)

			var degradedErr error

			graph, degradedErr = degradedAnalyzer(ctx)
			if degradedErr != nil {
				err = degradedErr
			} else {
				err = nil
			}
		}

		if err != nil {
			return nil, apierrors.Wrap(err, "erraudit analysis failed for %s", path)
		}
	}

	if graph == nil {
		return nil, nil //nolint:nilnil // no violations is a valid empty result; ErrauditDetector converts nil graphs to empty findings
	}

	return graph, nil
}

// specForContext merges the shared production defaults with the per-invocation
// Options carried by the context. Unset options leave the defaults intact, so
// provider behavior can never drift from the documented contract.
func specForContext(ctx context.Context, path string) pipeline.AnalysisSpec {
	opts := OptionsFromContext(ctx)
	spec := pipeline.DefaultAnalysisSpec(path)

	spec.ExcludedPaths = opts.ExcludedPaths
	spec.NoSuppress = opts.NoSuppress
	spec.Suppress = !opts.NoSuppress
	spec.EnforceErrorFamily = opts.EnforceErrorFamily
	spec.EnforceSamberOops = opts.EnforceSamberOops
	spec.EnforceGenericReturn = opts.EnforceGenericReturn
	spec.EnforceDeferredClose = opts.EnforceDeferredClose

	if opts.TypeAware != nil {
		spec.TypeAware = *opts.TypeAware
	}

	return spec
}
