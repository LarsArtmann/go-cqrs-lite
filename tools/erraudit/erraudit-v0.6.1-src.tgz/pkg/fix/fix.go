// Package fix provides public access to the erraudit fix infrastructure.
// It re-exports the internal fix types and functions so external consumers can
// run analyzers, collect suggested fixes, and apply them to source files
// without importing internal packages.
package fix

import (
	internalfix "github.com/larsartmann/erraudit/internal/fix"
	"golang.org/x/tools/go/analysis"
)

// Fix represents a single suggested fix for a file.
type Fix = internalfix.Fix

// Summary describes what the runner found, regardless of whether fixes were generated.
type Summary = internalfix.Summary

// Runner executes analyzers on Go packages and collects suggested fixes.
type Runner = internalfix.Runner

// Applier applies suggested fixes to source files.
type Applier = internalfix.Applier

// FileChange represents a modification to a single file.
type FileChange = internalfix.FileChange

// NewRunner creates a runner for the given analyzers.
func NewRunner(analyzers ...*analysis.Analyzer) *Runner {
	return internalfix.NewRunner(analyzers...)
}

// NewApplier creates a new fix applier.
func NewApplier() *Applier {
	return internalfix.NewApplier()
}

// FormatDiff formats a slice of file changes as a unified diff string.
func FormatDiff(changes []FileChange) string {
	return internalfix.FormatDiff(changes)
}
