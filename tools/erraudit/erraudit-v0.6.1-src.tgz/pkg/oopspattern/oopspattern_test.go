package oopspattern

import (
	"go/ast"
	"go/parser"
	"go/token"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestLooksLikeErrorName(t *testing.T) {
	tests := []struct {
		name string
		want bool
	}{
		// Exact match
		{"err", true},
		{"Err", true},
		{"ERR", true},

		// Contains "err" (the behavioral change: previously only HasPrefix("err") matched)
		{"statErr", true},
		{"myErr", true},
		{"foobarErr", true},
		{"errCheck", true},
		{"errorThing", true},

		// Does NOT look like an error name
		{"", false},
		{"foo", false},
		{"result", false},
		{"data", false},
		{"config", false},
		{"path", false},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			assert.Equal(t, tt.want, LooksLikeErrorName(tt.name))
		})
	}
}

func TestLooksLikeErrorName_BehavioralChange_ContainsNotPrefix(t *testing.T) {
	// This test documents the behavioral change from the oopspattern extraction.
	// The old oopsfix.go used strings.HasPrefix(name, "err"), which only matched
	// names starting with "err". The shared version uses strings.Contains(lower, "err"),
	// matching names like "statErr", "myErr" that contain "err" anywhere.
	//
	// These would NOT have matched with HasPrefix but DO match with Contains:
	assert.True(t, LooksLikeErrorName("statErr"))
	assert.True(t, LooksLikeErrorName("myErr"))
	assert.True(t, LooksLikeErrorName("processErr"))
}

func TestIsOopsWrapMethod(t *testing.T) {
	tests := []struct {
		method string
		want   bool
	}{
		// Core methods
		{"Wrap", true},
		{"Wrapf", true},

		// Numeric variants (Wrap2-Wrap10, Wrapf2-Wrapf10)
		{"Wrap2", true},
		{"Wrap10", true},
		{"Wrapf2", true},
		{"Wrapf10", true},

		// Not wrap methods
		{"Errorf", false},
		{"Error", false},
		{"WrapX", false},   // not digits after "Wrap"
		{"WrapfX", false},  // not digits after "Wrapf"
		{"Wrap-1", false},  // dash not digit
		{"wrapped", false}, // lowercase, wrong name
		{"", false},
	}

	for _, tt := range tests {
		t.Run(tt.method, func(t *testing.T) {
			assert.Equal(t, tt.want, isOopsWrapMethod(tt.method))
		})
	}
}

func TestIsAllDigits(t *testing.T) {
	assert.True(t, IsAllDigits("2"))
	assert.True(t, IsAllDigits("10"))
	assert.False(t, IsAllDigits(""))
	assert.False(t, IsAllDigits("X"))
}

func TestIsNilIdent(t *testing.T) {
	assert.True(t, IsNilIdent(&ast.Ident{Name: "nil"}))
	assert.False(t, IsNilIdent(&ast.Ident{Name: "err"}))
	assert.False(t, IsNilIdent(&ast.BasicLit{}))
}

func TestIsNilReturn(t *testing.T) {
	assert.True(t, IsNilReturn(&ast.ReturnStmt{
		Results: []ast.Expr{&ast.Ident{Name: "nil"}},
	}))
	assert.False(t, IsNilReturn(&ast.ReturnStmt{
		Results: []ast.Expr{&ast.Ident{Name: "err"}},
	}))
	assert.False(t, IsNilReturn(&ast.ReturnStmt{
		Results: []ast.Expr{},
	}))
}

func TestFindRedundantGuards(t *testing.T) {
	src := `package test

import "github.com/samber/oops"

func bad(err error) error {
	if err != nil {
		return oops.Wrap(err)
	}
	return nil
}

func good(err error) error {
	if err != nil {
		return oops.Wrap(err)
	}
	return err
}
`
	fset := mustParseFile(t, src)
	funcs := findFuncDecls(t, fset)
	require.Len(t, funcs, 2)

	matches := FindRedundantGuards(funcs[0].Body)
	require.Len(t, matches, 1, "should find one redundant guard in bad()")
	assert.Equal(t, "err", matches[0].ErrName)

	// good() does NOT have a redundant guard (returns err, not nil)
	goodMatches := FindRedundantGuards(funcs[1].Body)
	assert.Empty(t, goodMatches)
}

func TestFindRedundantGuards_MultipleMatches(t *testing.T) {
	src := `package test

import "github.com/samber/oops"

func multi(a error, b error) (error, error) {
	if a != nil {
		return oops.Wrap(a), nil
	}
	return nil, nil
}
`
	fset := mustParseFile(t, src)
	funcs := findFuncDecls(t, fset)
	require.Len(t, funcs, 1)

	// This has `return oops.Wrap(a), nil` which has 2 results, so IsOopsWrapReturn
	// checks for exactly 1 result and should NOT match.
	matches := FindRedundantGuards(funcs[0].Body)
	assert.Empty(t, matches, "multi-result return should not match")
}

func findFuncDecls(t *testing.T, f *ast.File) []*ast.FuncDecl {
	t.Helper()

	var funcs []*ast.FuncDecl
	for _, decl := range f.Decls {
		if fn, ok := decl.(*ast.FuncDecl); ok {
			funcs = append(funcs, fn)
		}
	}

	return funcs
}

func mustParseFile(t *testing.T, src string) *ast.File {
	t.Helper()

	f, err := parser.ParseFile(
		token.NewFileSet(),
		"test.go",
		src,
		0,
	)
	require.NoError(t, err)

	return f
}
