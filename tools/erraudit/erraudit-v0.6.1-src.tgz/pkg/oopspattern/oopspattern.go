// Package oopspattern provides shared detection logic for samber/oops
// anti-patterns. Both the erraudit violation detector (internal/ast) and the
// go/analysis auto-fixer (pkg/lint/oopsfix) use these helpers to avoid
// duplicating the pattern-matching logic.
package oopspattern

import (
	"go/ast"
	"strings"
)

// RedundantGuardMatch describes a detected redundant nil guard:
//
//	if errName != nil { return oops.Wrap(errName) }
//	return nil
type RedundantGuardMatch struct {
	IfStmt  *ast.IfStmt
	WrapRet *ast.ReturnStmt
	NilRet  *ast.ReturnStmt
	ErrName string
}

const (
	nilLiteral      = "nil"
	errSubstring    = "err"
	wrapMethodName  = "Wrap"
	wrapfMethodName = "Wrapf"
)

// FindRedundantGuards scans a block for all instances of the redundant guard
// pattern and returns matches. Both the autofixer and the violation detector
// call this; each applies its own reporting logic to the returned matches.
func FindRedundantGuards(block *ast.BlockStmt) []RedundantGuardMatch {
	var matches []RedundantGuardMatch

	for i := 0; i+1 < len(block.List); i++ {
		ifStmt, ok := block.List[i].(*ast.IfStmt)
		if !ok {
			continue
		}

		errName := GuardErrorName(ifStmt.Cond)
		if errName == "" || ifStmt.Else != nil {
			continue
		}

		ret := SingleReturnFromBody(ifStmt.Body)
		if ret == nil || !IsOopsWrapReturn(ret, errName) {
			continue
		}

		nextRet, ok := block.List[i+1].(*ast.ReturnStmt)
		if !ok || !IsNilReturn(nextRet) {
			continue
		}

		matches = append(matches, RedundantGuardMatch{
			IfStmt:  ifStmt,
			WrapRet: ret,
			NilRet:  nextRet,
			ErrName: errName,
		})
	}

	return matches
}

// GuardErrorName extracts the error variable name from `errName != nil`.
// Returns "" if the expression is not a nil-check on an error-like variable.
func GuardErrorName(cond ast.Expr) string {
	bin, ok := cond.(*ast.BinaryExpr)
	if !ok || bin.Op.String() != "!=" {
		return ""
	}

	if ident, ok := bin.X.(*ast.Ident); ok {
		if IsNilIdent(bin.Y) && LooksLikeErrorName(ident.Name) {
			return ident.Name
		}
	}

	if ident, ok := bin.Y.(*ast.Ident); ok {
		if IsNilIdent(bin.X) && LooksLikeErrorName(ident.Name) {
			return ident.Name
		}
	}

	return ""
}

// IsNilIdent reports whether expr is the bare identifier `nil`.
func IsNilIdent(expr ast.Expr) bool {
	ident, ok := expr.(*ast.Ident)

	return ok && ident.Name == nilLiteral
}

// LooksLikeErrorName reports whether name looks like an error variable.
// Uses substring matching to catch names like `statErr`, `myErr`, etc.
func LooksLikeErrorName(name string) bool {
	lower := strings.ToLower(name)

	return lower == errSubstring || strings.Contains(lower, errSubstring)
}

// SingleReturnFromBody returns the sole ReturnStmt in a block, or nil.
func SingleReturnFromBody(body *ast.BlockStmt) *ast.ReturnStmt {
	if body == nil || len(body.List) != 1 {
		return nil
	}

	ret, ok := body.List[0].(*ast.ReturnStmt)
	if !ok {
		return nil
	}

	return ret
}

// IsOopsWrapReturn checks whether ret is `return oops.Wrap(errName)` or
// `return oops.Wrapf(errName, ...)` where the first argument matches errName.
func IsOopsWrapReturn(ret *ast.ReturnStmt, errName string) bool {
	if len(ret.Results) != 1 {
		return false
	}

	call, ok := ret.Results[0].(*ast.CallExpr)
	if !ok {
		return false
	}

	sel, ok := call.Fun.(*ast.SelectorExpr)
	if !ok {
		return false
	}

	pkgIdent, ok := sel.X.(*ast.Ident)
	if !ok || pkgIdent.Name != "oops" {
		return false
	}

	method := sel.Sel.Name
	if !isOopsWrapMethod(method) {
		return false
	}

	if len(call.Args) == 0 {
		return false
	}

	firstArg, ok := call.Args[0].(*ast.Ident)

	return ok && firstArg.Name == errName
}

// isOopsWrapMethod reports whether method is an oops.Wrap-family method name.
func isOopsWrapMethod(method string) bool {
	if method == wrapMethodName || method == wrapfMethodName {
		return true
	}

	// Check Wrapf before Wrap — "Wrapf2" has prefix "Wrap" but the remainder
	// "f2" is not all digits. Checking the longer prefix first avoids this.
	if strings.HasPrefix(method, wrapfMethodName) {
		return isWrapWithDigits(method, len(wrapfMethodName))
	}

	if strings.HasPrefix(method, wrapMethodName) {
		return isWrapWithDigits(method, len(wrapMethodName))
	}

	return false
}

func isWrapWithDigits(method string, prefixLen int) bool {
	rest := method[prefixLen:]

	return rest != "" && IsAllDigits(rest)
}

// IsAllDigits reports whether s consists entirely of ASCII digit characters
// (0-9). Returns false for the empty string.
func IsAllDigits(s string) bool {
	if s == "" {
		return false
	}

	for _, c := range s {
		if c < '0' || c > '9' {
			return false
		}
	}

	return true
}

// IsNilReturn reports whether ret is `return nil`.
func IsNilReturn(ret *ast.ReturnStmt) bool {
	if len(ret.Results) != 1 {
		return false
	}

	ident, ok := ret.Results[0].(*ast.Ident)

	return ok && ident.Name == nilLiteral
}
