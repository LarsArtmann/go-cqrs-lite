package oopspattern

import (
	"fmt"
	"go/ast"
	"go/parser"
	"go/token"
	"strings"
	"testing"

	"pgregory.net/rapid"
)

// funcBodyGen generates random Go function bodies that exercise the
// FindRedundantGuards detector with both matching and non-matching patterns.
// Every generated source is guaranteed to parse as valid Go.
func funcBodyGen() *rapid.Generator[string] {
	return rapid.Custom(func(rt *rapid.T) string {
		errName := rapid.SampledFrom([]string{"err", "statErr", "myErr", "processErr"}).Draw(rt, "errName")
		wrapMethod := rapid.SampledFrom([]string{"Wrap", "Wrapf", "Wrap2", "Wrapf3", "Wrap10"}).Draw(rt, "wrapMethod")
		pkgName := rapid.SampledFrom([]string{"oops", "errors", "fmt"}).Draw(rt, "pkgName")
		hasGuard := rapid.Bool().Draw(rt, "hasGuard")
		hasReturnNil := rapid.Bool().Draw(rt, "hasReturnNil")
		hasElse := rapid.Bool().Draw(rt, "hasElse")
		multiReturn := rapid.Bool().Draw(rt, "multiReturn")
		extraStmtInBody := rapid.Bool().Draw(rt, "extraStmt")

		imports := []string{fmt.Sprintf(`"github.com/samber/%s"`, pkgName)}
		importBlock := fmt.Sprintf("import (\n%s\n)\n", strings.Join(imports, "\n"))
		if pkgName == "errors" {
			importBlock = "import \"errors\"\n"
		} else if pkgName == "fmt" {
			importBlock = "import \"fmt\"\n"
		}

		var body strings.Builder
		body.WriteString(fmt.Sprintf("\t%s := step()\n", errName))
		body.WriteString(fmt.Sprintf("\t_ = %s\n", errName))

		if hasGuard {
			body.WriteString(fmt.Sprintf("\tif %s != nil {\n", errName))
			if extraStmtInBody {
				body.WriteString(fmt.Sprintf("\t\tlog.Printf(\"err: %%v\", %s)\n", errName))
			}
			if multiReturn {
				body.WriteString(fmt.Sprintf("\t\treturn %s.%s(%s), nil\n", pkgName, wrapMethod, errName))
			} else {
				body.WriteString(fmt.Sprintf("\t\treturn %s.%s(%s)\n", pkgName, wrapMethod, errName))
			}
			if hasElse {
				body.WriteString("\t} else {\n")
				body.WriteString("\t\treturn nil\n")
				body.WriteString("\t}\n")
			} else {
				body.WriteString("\t}\n")
			}
			if hasReturnNil && !hasElse {
				body.WriteString("\treturn nil\n")
			} else if !hasReturnNil && !hasElse {
				body.WriteString("\treturn step()\n")
			}
		} else {
			body.WriteString("\treturn nil\n")
		}

		return fmt.Sprintf(`package main

%sfunc process() error {
%s
func step() error { return nil }

func logPrintf(format string, args ...any) {}
`, importBlock, body.String())
	})
}

// TestFindRedundantGuards_NoPanic ensures FindRedundantGuards never panics
// on any valid Go source, regardless of structure.
func TestFindRedundantGuards_NoPanic(t *testing.T) {
	rapid.Check(t, func(rt *rapid.T) {
		code := funcBodyGen().Draw(rt, "code")

		fset := token.NewFileSet()
		node, err := parser.ParseFile(fset, "test.go", code, 0)
		if err != nil {
			return
		}

		for _, decl := range node.Decls {
			fn, ok := decl.(*ast.FuncDecl)
			if !ok || fn.Body == nil {
				continue
			}
			_ = FindRedundantGuards(fn.Body)
		}
	})
}

// TestFindRedundantGuards_Soundness ensures that when the exact redundant guard
// pattern is present (oops package, single return, no else, return nil follows),
// it is always detected.
func TestFindRedundantGuards_Soundness(t *testing.T) {
	rapid.Check(t, func(rt *rapid.T) {
		errName := rapid.SampledFrom([]string{"err", "statErr", "myErr"}).Draw(rt, "errName")
		wrapMethod := rapid.SampledFrom([]string{"Wrap", "Wrapf", "Wrap2", "Wrapf3"}).Draw(rt, "wrapMethod")

		code := fmt.Sprintf(`package main

import "github.com/samber/oops"

func process() error {
	%s := step()
	if %s != nil {
		return oops.%s(%s)
	}
	return nil
}

func step() error { return nil }
`, errName, errName, wrapMethod, errName)

		fset := token.NewFileSet()
		node, err := parser.ParseFile(fset, "test.go", code, 0)
		if err != nil {
			rt.Fatalf("generated code failed to parse: %v", err)
		}

		fn := findFirstFunc(node)
		if fn == nil || fn.Body == nil {
			rt.Fatalf("no function body found")
		}

		matches := FindRedundantGuards(fn.Body)
		if len(matches) != 1 {
			rt.Fatalf("expected 1 match for errName=%s wrapMethod=%s, got %d", errName, wrapMethod, len(matches))
		}

		if matches[0].ErrName != errName {
			rt.Fatalf("expected ErrName=%s, got %s", errName, matches[0].ErrName)
		}
	})
}

// TestFindRedundantGuards_NoFalsePositive_NonOopsPackage ensures the detector
// does NOT flag when the package is not "oops" (e.g., errors.Wrap, fmt.Wrapf).
func TestFindRedundantGuards_NoFalsePositive_NonOopsPackage(t *testing.T) {
	rapid.Check(t, func(rt *rapid.T) {
		pkgName := rapid.SampledFrom([]string{"errors", "fmt", "log"}).Draw(rt, "pkgName")
		wrapMethod := rapid.SampledFrom([]string{"Wrap", "Wrapf", "Wrap2"}).Draw(rt, "wrapMethod")

		code := fmt.Sprintf(`package main

func process() error {
	err := step()
	if err != nil {
		return %s.%s(err)
	}
	return nil
}

func step() error { return nil }
`, pkgName, wrapMethod)

		fset := token.NewFileSet()
		node, err := parser.ParseFile(fset, "test.go", code, 0)
		if err != nil {
			rt.Fatalf("generated code failed to parse: %v", err)
		}

		fn := findFirstFunc(node)
		if fn == nil || fn.Body == nil {
			rt.Fatalf("no function body found")
		}

		matches := FindRedundantGuards(fn.Body)
		if len(matches) != 0 {
			rt.Fatalf("expected 0 matches for non-oops package %s, got %d", pkgName, len(matches))
		}
	})
}

// TestFindRedundantGuards_NoFalsePositive_ElseBranch ensures the detector
// does NOT flag when the if statement has an else branch.
func TestFindRedundantGuards_NoFalsePositive_ElseBranch(t *testing.T) {
	rapid.Check(t, func(rt *rapid.T) {
		wrapMethod := rapid.SampledFrom([]string{"Wrap", "Wrapf", "Wrap2"}).Draw(rt, "wrapMethod")

		code := fmt.Sprintf(`package main

import "github.com/samber/oops"

func process() error {
	err := step()
	if err != nil {
		return oops.%s(err)
	} else {
		return nil
	}
}

func step() error { return nil }
`, wrapMethod)

		fset := token.NewFileSet()
		node, err := parser.ParseFile(fset, "test.go", code, 0)
		if err != nil {
			rt.Fatalf("generated code failed to parse: %v", err)
		}

		fn := findFirstFunc(node)
		if fn == nil || fn.Body == nil {
			rt.Fatalf("no function body found")
		}

		matches := FindRedundantGuards(fn.Body)
		if len(matches) != 0 {
			rt.Fatalf("expected 0 matches with else branch, got %d", len(matches))
		}
	})
}

// TestFindRedundantGuards_NoFalsePositive_MultiReturn ensures the detector
// does NOT flag when the return has multiple values (e.g., return oops.Wrap(err), nil).
func TestFindRedundantGuards_NoFalsePositive_MultiReturn(t *testing.T) {
	rapid.Check(t, func(rt *rapid.T) {
		wrapMethod := rapid.SampledFrom([]string{"Wrap", "Wrapf", "Wrap2"}).Draw(rt, "wrapMethod")

		code := fmt.Sprintf(`package main

import "github.com/samber/oops"

func process() (error, int) {
	err := step()
	if err != nil {
		return oops.%s(err), 0
	}
	return nil, 0
}

func step() error { return nil }
`, wrapMethod)

		fset := token.NewFileSet()
		node, err := parser.ParseFile(fset, "test.go", code, 0)
		if err != nil {
			rt.Fatalf("generated code failed to parse: %v", err)
		}

		fn := findFirstFunc(node)
		if fn == nil || fn.Body == nil {
			rt.Fatalf("no function body found")
		}

		matches := FindRedundantGuards(fn.Body)
		if len(matches) != 0 {
			rt.Fatalf("expected 0 matches for multi-value return, got %d", len(matches))
		}
	})
}

// TestFindRedundantGuards_NoFalsePositive_NonErrorVar ensures the detector
// does NOT flag when the if-condition variable doesn't look like an error name.
func TestFindRedundantGuards_NoFalsePositive_NonErrorVar(t *testing.T) {
	rapid.Check(t, func(rt *rapid.T) {
		varName := rapid.SampledFrom([]string{"result", "data", "config", "foo"}).Draw(rt, "varName")
		wrapMethod := rapid.SampledFrom([]string{"Wrap", "Wrapf"}).Draw(rt, "wrapMethod")

		code := fmt.Sprintf(`package main

import "github.com/samber/oops"

func process() error {
	%s := step()
	if %s != nil {
		return oops.%s(%s)
	}
	return nil
}

func step() error { return nil }
`, varName, varName, wrapMethod, varName)

		fset := token.NewFileSet()
		node, err := parser.ParseFile(fset, "test.go", code, 0)
		if err != nil {
			rt.Fatalf("generated code failed to parse: %v", err)
		}

		fn := findFirstFunc(node)
		if fn == nil || fn.Body == nil {
			rt.Fatalf("no function body found")
		}

		matches := FindRedundantGuards(fn.Body)
		if len(matches) != 0 {
			rt.Fatalf("expected 0 matches for non-error var name %s, got %d", varName, len(matches))
		}
	})
}

// findFirstFunc returns the first FuncDecl with a body in the file.
func findFirstFunc(node *ast.File) *ast.FuncDecl {
	for _, decl := range node.Decls {
		if fn, ok := decl.(*ast.FuncDecl); ok && fn.Body != nil {
			return fn
		}
	}
	return nil
}
