package errors

import (
	"go/ast"
	"go/parser"
	"go/token"
	"testing"

	errorfamily "github.com/larsartmann/go-error-family"
)

// allErrorCodes extracts every Code* constant's string value from errors.go
// via go/parser, so a newly added code can never silently escape the
// template-coverage guard (a hand-maintained list would drift exactly the way
// the guard exists to prevent).
func allErrorCodes(t *testing.T) []string {
	t.Helper()

	fset := token.NewFileSet()

	file, err := parser.ParseFile(fset, "errors.go", nil, 0)
	if err != nil {
		t.Fatalf("failed to parse errors.go: %v", err)
	}

	var codes []string

	for _, decl := range file.Decls {
		genDecl, ok := decl.(*ast.GenDecl)
		if !ok {
			continue
		}

		for _, spec := range genDecl.Specs {
			valueSpec, ok := spec.(*ast.ValueSpec)
			if !ok {
				continue
			}

			for i, name := range valueSpec.Names {
				if len(name.Name) < 4 || name.Name[:4] != "Code" {
					continue
				}

				if i >= len(valueSpec.Values) {
					continue
				}

				lit, ok := valueSpec.Values[i].(*ast.BasicLit)
				if !ok || lit.Kind != token.STRING {
					continue
				}

				codes = append(codes, unquote(lit.Value))
			}
		}
	}

	if len(codes) == 0 {
		t.Fatal("extracted zero Code* constants — extraction is broken")
	}

	return codes
}

func unquote(value string) string {
	if len(value) >= 2 && value[0] == '"' && value[len(value)-1] == '"' {
		return value[1 : len(value)-1]
	}

	return value
}

// TestAllErrorCodesHaveTemplates guards the What/Why/Fix template contract:
// every error code erraudit can emit must render a helpful message via
// errorfamily.HandleError. A code without a template falls back to bare text
// at the CLI boundary — the exact gap this package exists to prevent.
func TestAllErrorCodesHaveTemplates(t *testing.T) {
	t.Parallel()

	for _, code := range allErrorCodes(t) {
		t.Run(code, func(t *testing.T) {
			t.Parallel()

			template, ok := errorfamily.DefaultRegistry.TemplateForCode(code)
			if !ok {
				t.Fatalf("code %q has no registered message template — add one in templates.go", code)
			}

			if template.What == "" || template.Fix == "" {
				t.Errorf("code %q template is incomplete (What and Fix are required): %+v", code, template)
			}
		})
	}
}
