package errors

import (
	"encoding/json/v2"
	stderrors "errors"
	"io"
	"maps"

	errorfamily "github.com/larsartmann/go-error-family"
)

// ErrorEnvelope is the machine-readable failure contract: when erraudit exits
// non-zero for an operational failure (not exit 2, which means findings), a
// json-family --format emits this shape on stdout so scripts and embedders
// can branch on code/family instead of parsing stderr text.
type ErrorEnvelope struct {
	Code     string            `json:"code,omitempty"`
	Family   string            `json:"family"`
	ExitCode int               `json:"exit_code"` //nolint:tagliatelle // snake_case by contract: consistent with the findings JSON keys consumers already parse
	Message  string            `json:"message"`
	Fix      string            `json:"fix,omitempty"`
	Context  map[string]string `json:"context,omitempty"`
}

// NewErrorEnvelope builds the envelope for err from its go-error-family
// classification: code, family, exit code, the concrete error text, the
// template-suggested fix, and structured context (when the error is
// Contextual).
func NewErrorEnvelope(err error) ErrorEnvelope {
	detailed := errorfamily.HandleErrorDetailed(err)

	envelope := ErrorEnvelope{
		Code:     errorfamily.Code(err),
		Family:   errorfamily.Classify(err).String(),
		ExitCode: detailed.ExitCode,
		Message:  err.Error(),
		Fix:      detailed.SuggestedFix,
		Context:  nil,
	}

	if contextual, ok := stderrors.AsType[errorfamily.Contextual](err); ok {
		envelope.Context = maps.Clone(contextual.ErrorContext())
	}

	return envelope
}

// WriteJSONErrorEnvelope marshals the envelope for err as
// {"error":{...}} and writes it to w. Errors from the writer or the marshal
// are returned; callers treat them as best-effort (the exit code still
// classifies the failure).
func WriteJSONErrorEnvelope(w io.Writer, err error) error {
	envelope := struct {
		Error ErrorEnvelope `json:"error"`
	}{Error: NewErrorEnvelope(err)}

	encoded, marshalErr := json.Marshal(envelope)
	if marshalErr != nil {
		return errorfamily.WrapRejectionf(marshalErr, CodeOutputEnvelopeMarshal, "marshalling error envelope")
	}

	if _, writeErr := w.Write(encoded); writeErr != nil {
		return errorfamily.WrapRejectionf(writeErr, CodeOutputEnvelopeWrite, "writing error envelope")
	}

	if _, writeErr := w.Write([]byte("\n")); writeErr != nil {
		return errorfamily.WrapRejectionf(writeErr, CodeOutputEnvelopeWrite, "writing error envelope newline")
	}

	return nil
}
