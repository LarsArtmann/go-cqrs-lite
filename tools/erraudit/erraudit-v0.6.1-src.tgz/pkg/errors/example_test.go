package errors_test

import (
	"fmt"

	pkgerrors "github.com/larsartmann/erraudit/pkg/errors"
	errorfamily "github.com/larsartmann/go-error-family"
)

func ExampleNew() {
	err := pkgerrors.New("failed to parse %s", "config.yaml")
	fmt.Println(err)
	// Output: [rejection:] failed to parse config.yaml
}

func ExampleWrap() {
	base := pkgerrors.New("disk full")
	wrapped := pkgerrors.Wrap(base, "cannot write cache")
	fmt.Println(wrapped)
	// Output: [rejection:] cannot write cache: [rejection:] disk full
}

func ExampleHandleError() {
	// HandleError returns a BSD sysexits.h exit code derived from the
	// error's family classification. A nil error returns 0 (success).
	code := pkgerrors.HandleError(nil)
	fmt.Println(code)
	// Output: 0
}

func ExampleErrConfigInvalid() {
	// ErrConfigInvalid wraps ErrInput, creating a domain hierarchy
	// visible to erraudit's own tree subcommand. Sentinels are declared
	// as the error interface; Coded carries the machine-readable code.
	coded := pkgerrors.ErrConfigInvalid.(errorfamily.Coded)
	fmt.Println(coded.ErrorCode())
	// Output: config.invalid
}
