package errors

import (
	"bytes"
	"testing"

	errorfamily "github.com/larsartmann/go-error-family"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNewErrorEnvelope_codedSentinel(t *testing.T) {
	t.Parallel()

	envelope := NewErrorEnvelope(Wrap(ErrConfigInvalid, "loading %s", "app.yaml"))

	assert.Equal(t, CodeConfigInvalid, envelope.Code, "code must survive wrapping (inheritance)")
	assert.Equal(t, "rejection", envelope.Family)
	assert.Equal(t, 1, envelope.ExitCode)
	assert.Contains(t, envelope.Message, "loading app.yaml", "message must be the concrete error text")
	assert.NotEmpty(t, envelope.Fix, "suggested fix from the config.invalid template must surface")
}

func TestNewErrorEnvelope_uncodedError(t *testing.T) {
	t.Parallel()

	envelope := NewErrorEnvelope(New("some context message"))

	assert.Empty(t, envelope.Code)
	assert.Equal(t, "rejection", envelope.Family)
}

func TestWriteJSONErrorEnvelope(t *testing.T) {
	t.Parallel()

	var buf bytes.Buffer

	require.NoError(t, WriteJSONErrorEnvelope(&buf, ErrPathEmpty))

	output := buf.String()
	assert.Contains(t, output, `"error"`)
	assert.Contains(t, output, CodePathEmpty)
	assert.Contains(t, output, `"family"`)
	assert.Contains(t, output, `"exit_code":1`)
	assert.True(t, bytes.HasSuffix([]byte(output), []byte("}\n")), "envelope must end with a newline")
}

func TestNewErrorEnvelope_contextSurfaces(t *testing.T) {
	t.Parallel()

	coded := errorfamily.WrapRejection(ErrAnalysis, "analysis.retry", "flaky")
	envelope := NewErrorEnvelope(coded.WithContext("pattern", "./pkg/..."))

	require.NotNil(t, envelope.Context)
	assert.Equal(t, "./pkg/...", envelope.Context["pattern"])
}
