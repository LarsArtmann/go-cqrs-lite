package errors

import (
	"errors"
	"strings"
	"testing"

	errorfamily "github.com/larsartmann/go-error-family"
)

func TestNew(t *testing.T) {
	t.Parallel()

	err := New("something went wrong")
	if err == nil {
		t.Fatal("expected non-nil error")
	}

	if err.Error() == "" {
		t.Error("expected non-empty error message")
	}

	efErr, ok := asErrorFamily(err)
	if !ok {
		t.Fatalf("expected *errorfamily.Error, got %T", err)
	}

	if efErr.ErrorFamily() != errorfamily.Rejection {
		t.Errorf("expected Rejection family, got %v", efErr.ErrorFamily())
	}

	if efErr.Message() != "something went wrong" {
		t.Errorf("expected message %q, got %q", "something went wrong", efErr.Message())
	}
}

func TestNew_formatted(t *testing.T) {
	t.Parallel()

	err := New("value is %d", 42)
	efErr, ok := asErrorFamily(err)
	if !ok {
		t.Fatalf("expected *errorfamily.Error, got %T", err)
	}

	if efErr.Message() != "value is 42" {
		t.Errorf("expected formatted message %q, got %q", "value is 42", efErr.Message())
	}
}

func TestWrap(t *testing.T) {
	t.Parallel()

	t.Run("with non-nil error", func(t *testing.T) {
		t.Parallel()

		original := errors.New("original")
		wrapped := Wrap(original, "context")

		//nolint:err113 // testing stdlib error interface
		if !errors.Is(wrapped, original) {
			t.Error("expected underlying error to be preserved via Unwrap chain")
		}

		efErr, ok := asErrorFamily(wrapped)
		if !ok {
			t.Fatalf("expected *errorfamily.Error, got %T", wrapped)
		}

		if efErr.Message() != "context" {
			t.Errorf("expected message %q, got %q", "context", efErr.Message())
		}
	})

	t.Run("with nil error", func(t *testing.T) {
		t.Parallel()

		result := Wrap(nil, "context")
		if result != nil {
			t.Error("expected nil when wrapping nil error")
		}
	})

	t.Run("with formatting", func(t *testing.T) {
		t.Parallel()

		original := errors.New("original")
		wrapped := Wrap(original, "error code %d", 500)

		efErr, ok := asErrorFamily(wrapped)
		if !ok {
			t.Fatalf("expected *errorfamily.Error, got %T", wrapped)
		}

		if efErr.Message() != "error code 500" {
			t.Errorf("expected formatted message, got %q", efErr.Message())
		}
	})
}

func TestPredefinedErrors(t *testing.T) {
	t.Parallel()

	predefinedErrors := map[string]error{
		"ErrConfigInvalid":              ErrConfigInvalid,
		"ErrNotGoFile":                  ErrNotGoFile,
		"ErrExtensionNotFound":          ErrExtensionNotFound,
		"ErrCacheItemTooLarge":          ErrCacheItemTooLarge,
		"ErrUnsupportedType":            ErrUnsupportedType,
		"ErrNoStrategyRegistered":       ErrNoStrategyRegistered,
		"ErrPathEmpty":                  ErrPathEmpty,
		"ErrViolationsOnlyIncompatible": ErrViolationsOnlyIncompatible,
		"ErrVerboseIncompatible":        ErrVerboseIncompatible,
	}

	for name, err := range predefinedErrors {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			if err == nil {
				t.Fatal("expected error to be non-nil")
			}

			efErr, ok := asErrorFamily(err)
			if !ok {
				t.Fatalf("expected *errorfamily.Error, got %T", err)
			}

			if efErr.Message() == "" {
				t.Error("expected message to be non-empty")
			}

			if efErr.ErrorCode() == "" {
				t.Error("expected code to be non-empty")
			}

			if efErr.ErrorFamily() != errorfamily.Rejection {
				t.Errorf("expected Rejection family, got %v", efErr.ErrorFamily())
			}
		})
	}
}

func TestDomainHierarchy(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name     string
		leaf     error
		root     error
		rootCode string
	}{
		{"ErrConfigInvalid wraps ErrInput", ErrConfigInvalid, ErrInput, "input"},
		{"ErrNotGoFile wraps ErrInput", ErrNotGoFile, ErrInput, "input"},
		{"ErrPathEmpty wraps ErrInput", ErrPathEmpty, ErrInput, "input"},
		{"ErrViolationsOnlyIncompatible wraps ErrInput", ErrViolationsOnlyIncompatible, ErrInput, "input"},
		{"ErrVerboseIncompatible wraps ErrInput", ErrVerboseIncompatible, ErrInput, "input"},
		{"ErrUnsupportedType wraps ErrAnalysis", ErrUnsupportedType, ErrAnalysis, "analysis"},
		{"ErrCacheItemTooLarge wraps ErrAnalysis", ErrCacheItemTooLarge, ErrAnalysis, "analysis"},
		{"ErrNoStrategyRegistered wraps ErrOutput", ErrNoStrategyRegistered, ErrOutput, "output"},
		{"ErrExtensionNotFound wraps ErrExtension", ErrExtensionNotFound, ErrExtension, "extension"},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			//nolint:err113 // testing stdlib error interface
			if !errors.Is(tt.leaf, tt.root) {
				t.Errorf("expected errors.Is(%v, %v) to be true via Unwrap chain", tt.leaf, tt.root)
			}
		})
	}
}

func TestErrorsJoinCompatibility(t *testing.T) {
	t.Parallel()

	inner := errorfamily.NewRejection("test.inner", "inner")
	wrapped := Wrap(inner, "outer")

	//nolint:err113 // testing stdlib error interface
	if !errors.Is(wrapped, inner) {
		t.Error("expected errors.Is to work with wrapped error")
	}
}

func TestFormatWithCause(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		message string
		cause   error
		want    string
	}{
		{
			name:    "with cause",
			message: "operation failed",
			cause:   errors.New("underlying error"),
			want:    "operation failed: underlying error",
		},
		{
			name:    "without cause",
			message: "operation failed",
			cause:   nil,
			want:    "operation failed",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			got := FormatWithCause(tt.message, tt.cause)
			if got != tt.want {
				t.Errorf("FormatWithCause() = %q, want %q", got, tt.want)
			}
		})
	}
}

func TestExitCode(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name     string
		err      error
		expected int
	}{
		{"nil error returns 0", nil, 0},
		{"rejection returns 1", errorfamily.NewRejection("test", "msg"), 1},
		{"conflict returns 1", errorfamily.NewConflict("test", "msg"), 1},
		{"transient returns 75", errorfamily.NewTransient("test", "msg"), 75},
		{"corruption returns 65", errorfamily.NewCorruption("test", "msg"), 65},
		{"infrastructure returns 69", errorfamily.NewInfrastructure("test", "msg"), 69},
		{
			"plain error defaults to transient (75)",
			errors.New("plain error"),
			75,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			got := ExitCode(tt.err)
			if got != tt.expected {
				t.Errorf("ExitCode() = %d, want %d", got, tt.expected)
			}
		})
	}
}

func TestClassify(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name     string
		err      error
		expected errorfamily.Family
	}{
		{"nil returns zero value (rejection)", nil, errorfamily.Rejection},
		{"rejection error", errorfamily.NewRejection("test", "msg"), errorfamily.Rejection},
		{"transient error", errorfamily.NewTransient("test", "msg"), errorfamily.Transient},
		{"plain error defaults to transient", errors.New("plain"), errorfamily.Transient},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			got := Classify(tt.err)
			if got != tt.expected {
				t.Errorf("Classify() = %v, want %v", got, tt.expected)
			}
		})
	}
}

func TestHandleError(t *testing.T) {
	t.Parallel()

	t.Run("returns exit code matching ExitCode for rejection", func(t *testing.T) {
		t.Parallel()

		err := errorfamily.NewRejection("test.handle", "handle test")

		exitCode := HandleError(err)
		expected := ExitCode(err)
		if exitCode != expected {
			t.Errorf("HandleError() = %d, want %d (matching ExitCode)", exitCode, expected)
		}
	})

	t.Run("returns 75 for transient", func(t *testing.T) {
		t.Parallel()

		err := errorfamily.NewTransient("test.transient", "transient failure")

		if got := HandleError(err); got != 75 {
			t.Errorf("HandleError() = %d, want 75", got)
		}
	})
}

func TestRegisterMessageTemplate(t *testing.T) {
	t.Parallel()

	RegisterMessageTemplate("test.custom_code", errorfamily.MessageTemplate{
		What:   "Custom test error.",
		Why:    "Testing template registration.",
		Fix:    "No fix needed for tests.",
		WayOut: "This is a test.",
	})

	result := errorfamily.HandleErrorDetailed(errorfamily.NewRejection("test.custom_code", "custom error"))

	if !strings.Contains(result.Message, "Custom test error") {
		t.Errorf("expected rendered message to contain template What text, got: %s", result.Message)
	}
}

func TestInitTemplatesRegistered(t *testing.T) {
	t.Parallel()

	codes := []string{
		CodeConfigInvalid,
		CodeFileNotGo,
		CodeExtensionNotFound,
		CodeCacheItemTooLarge,
		CodeTypeUnsupported,
		CodeOutputNoStrategy,
		CodePathEmpty,
		CodeFlagViolationsOnlyConflict,
		CodeFlagVerboseConflict,
	}

	for _, code := range codes {
		t.Run(code, func(t *testing.T) {
			t.Parallel()

			err := errorfamily.NewRejection(code, "test trigger")

			result := errorfamily.HandleErrorDetailed(err)
			if result.Message == "" {
				t.Errorf("expected non-empty rendered message for code %q", code)
			}

			if result.ExitCode != 1 {
				t.Errorf("expected exit code 1 for rejection (code=%s), got %d", code, result.ExitCode)
			}
		})
	}
}

// asErrorFamily extracts *errorfamily.Error from an error chain.
func asErrorFamily(err error) (*errorfamily.Error, bool) {
	target, ok := errors.AsType[*errorfamily.Error](err)

	return target, ok
}

func TestWrapContext_attachesOperationalContext(t *testing.T) {
	t.Parallel()

	wrapped := WrapContext(
		ErrAnalysisToolchainMissing,
		map[string]string{"path": "./pkg/...", "type_aware": "true"},
		"analysis failed for %s",
		"./pkg/...",
	)

	if got := errorfamily.Code(wrapped); got != CodeAnalysisToolchainMissing {
		t.Errorf("expected inherited code %q, got %q", CodeAnalysisToolchainMissing, got)
	}

	contextual, ok := errors.AsType[errorfamily.Contextual](wrapped)
	if !ok {
		t.Fatal("expected wrapped error to be Contextual")
	}

	if contextual.ErrorContext()["path"] != "./pkg/..." {
		t.Errorf("expected path context, got %v", contextual.ErrorContext())
	}

	envelope := NewErrorEnvelope(wrapped)
	if envelope.Context["type_aware"] != "true" {
		t.Errorf("expected context to surface in the JSON envelope, got %v", envelope.Context)
	}
}

func TestWrap_codeInheritance(t *testing.T) {
	t.Parallel()

	t.Run("coded cause code is inherited", func(t *testing.T) {
		t.Parallel()

		wrapped := Wrap(ErrConfigInvalid, "loading %s", "config.yaml")

		if got := errorfamily.Code(wrapped); got != CodeConfigInvalid {
			t.Errorf("expected inherited code %q, got %q", CodeConfigInvalid, got)
		}
	})

	t.Run("uncoded cause keeps empty code", func(t *testing.T) {
		t.Parallel()

		//nolint:err113 // testing stdlib error interface
		wrapped := Wrap(errors.New("plain"), "context")

		if got := errorfamily.Code(wrapped); got != "" {
			t.Errorf("expected empty code for uncoded cause, got %q", got)
		}
	})

	t.Run("double wrap preserves the innermost code", func(t *testing.T) {
		t.Parallel()

		once := Wrap(ErrPathEmpty, "first layer")
		twice := Wrap(once, "second layer")

		if got := errorfamily.Code(twice); got != CodePathEmpty {
			t.Errorf("expected code %q through two wraps, got %q", CodePathEmpty, got)
		}
	})

	t.Run("wrapped sentinel still resolves template via HandleErrorDetailed", func(t *testing.T) {
		t.Parallel()

		wrapped := Wrap(ErrConfigInvalid, "loading config")

		result := errorfamily.HandleErrorDetailed(wrapped)
		if result.ExitCode == 0 {
			t.Fatal("expected non-zero exit code")
		}

		if result.SuggestedFix == "" {
			t.Error("expected suggested fix from config.invalid template to survive wrapping")
		}
	})
}
