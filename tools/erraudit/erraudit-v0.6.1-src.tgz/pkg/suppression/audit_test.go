package suppression

import (
	"slices"
	"sort"
	"testing"
)

// containsLine checks whether want is present in got.
func containsLine(t *testing.T, got []int, want int) {
	t.Helper()

	if slices.Contains(got, want) {
		return
	}

	t.Errorf("expected %v to contain %d", got, want)
}

func sortedInts(s []int) []int {
	cp := make([]int, len(s))
	copy(cp, s)
	sort.Ints(cp)

	return cp
}

// TestEffectiveDirectiveLines_PackageLevelVar verifies that a directive on a
// package-level declaration (no enclosing block) returns only that line.
func TestEffectiveDirectiveLines_PackageLevelVar(t *testing.T) {
	t.Parallel()

	src := "package main\n" + // 1
		"\n" + // 2
		"var ErrA = errors.New(\"foo\") //nolint:erraudit\n" // 3

	got := EffectiveDirectiveLines(src, 3)
	if len(got) != 1 || got[0] != 3 {
		t.Errorf("expected [3], got %v", got)
	}
}

// TestEffectiveDirectiveLines_InsideIfBlock verifies that a directive inside
// an if block also covers the block's opening line.
func TestEffectiveDirectiveLines_InsideIfBlock(t *testing.T) {
	t.Parallel()

	src := "package main\n" + // 1
		"\n" + // 2
		"func main() {\n" + // 3
		"\terr := doSomething()\n" + // 4
		"\tif err != nil {\n" + // 5 — block start
		"\t\treturn err //nolint:erraudit\n" + // 6 — directive
		"\t}\n" + // 7
		"}\n" // 8

	got := EffectiveDirectiveLines(src, 6)
	containsLine(t, got, 6) // directive line
	containsLine(t, got, 5) // enclosing block start
}

// TestEffectiveDirectiveLines_MultiLineStatement verifies that a directive on
// the closing paren of a multi-line statement also covers the statement start.
func TestEffectiveDirectiveLines_MultiLineStatement(t *testing.T) {
	t.Parallel()

	src := "package main\n" + // 1
		"\n" + // 2
		"func main() {\n" + // 3
		"\treturn wrap(\n" + // 4 — statement start
		"\t    err,\n" + // 5
		"\t    \"msg\",\n" + // 6
		"\t) //nolint:erraudit\n" + // 7 — directive
		"}\n" // 8

	got := EffectiveDirectiveLines(src, 7)
	containsLine(t, got, 7) // directive line
	containsLine(t, got, 4) // statement start
}

// TestEffectiveDirectiveLines_MultiLineStatementInsideBlock verifies that a
// directive on a multi-line statement inside an if block covers all three lines.
func TestEffectiveDirectiveLines_MultiLineStatementInsideBlock(t *testing.T) {
	t.Parallel()

	src := "package main\n" + // 1
		"\n" + // 2
		"func main() {\n" + // 3
		"\terr := doSomething()\n" + // 4
		"\tif err != nil {\n" + // 5 — block start
		"\t\treturn wrap(\n" + // 6 — statement start
		"\t\t    err,\n" + // 7
		"\t\t    \"msg\",\n" + // 8
		"\t\t) //nolint:erraudit\n" + // 9 — directive
		"\t}\n" + // 10
		"}\n" // 11

	got := EffectiveDirectiveLines(src, 9)
	containsLine(t, got, 9) // directive line
	containsLine(t, got, 6) // statement start
	containsLine(t, got, 5) // block start
}

// TestEffectiveDirectiveLines_NoDuplicates verifies that no duplicate line
// numbers appear in the result.
func TestEffectiveDirectiveLines_NoDuplicates(t *testing.T) {
	t.Parallel()

	src := "package main\n" + // 1
		"\n" + // 2
		"func main() {\n" + // 3
		"\treturn err //nolint:erraudit\n" + // 4
		"}\n" // 5

	got := EffectiveDirectiveLines(src, 4)

	seen := map[int]bool{}
	for _, l := range got {
		if seen[l] {
			t.Errorf("duplicate line %d in result %v", l, got)
		}

		seen[l] = true
	}
}

// TestEffectiveDirectiveLines_AlwaysReturnsSorted verifies the output is
// deterministic with the directive line first.
func TestEffectiveDirectiveLines_DirectiveLineAlwaysPresent(t *testing.T) {
	t.Parallel()

	src := "package main\n" +
		"var _ = 1 //nolint:erraudit\n"

	got := EffectiveDirectiveLines(src, 2)

	sorted := sortedInts(got)
	if len(sorted) == 0 {
		t.Fatal("expected at least one line")
	}

	containsLine(t, got, 2)
}
