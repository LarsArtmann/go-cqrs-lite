package suppression

import (
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
)

func TestCommentParser_ParseNolintComments(t *testing.T) {
	parser := NewCommentParser()

	content := `
package main

func main() { //nolint
	return
}

func other() { //nolint:generic_return
	return
}

//nolint:legacy_as
func third() error {
	return nil
}

func fourth() { // nolint: panic
	panic("test")
}

func fifth() {}
`

	suppressions := parser.ParseNolintComments(content)

	// Should find 4 nolint comments
	assert.Len(t, suppressions, 4)

	// Line 4: //nolint (no specific type)
	assert.Contains(t, suppressions, 4)
	assert.Equal(t, types.ErrorType(""), suppressions[4].Type)

	// Line 8: //nolint:generic_return
	assert.Contains(t, suppressions, 8)
	assert.Equal(t, types.ErrorType("generic_return"), suppressions[8].Type)

	// Line 12: //nolint:legacy_as
	assert.Contains(t, suppressions, 12)
	assert.Equal(t, types.ErrorType("legacy_as"), suppressions[12].Type)

	// Line 17: // nolint: panic (with space)
	assert.Contains(t, suppressions, 17)
	assert.Equal(t, types.ErrorType("panic"), suppressions[17].Type)
}

func TestCommentParser_IsLineSuppressed(t *testing.T) {
	parser := NewCommentParser()
	content := `
func main() { //nolint
func other() {}
`

	assert.True(t, parser.IsLineSuppressed(content, 2))
	assert.False(t, parser.IsLineSuppressed(content, 3))
}

func TestCommentParser_IsLineSuppressedForType(t *testing.T) {
	parser := NewCommentParser()
	content := `
func main() { //nolint
func other() { //nolint:generic_return
func third() { //nolint:legacy_as
`

	// Line 2: //nolint (suppresses all)
	assert.True(t, parser.IsLineSuppressedForType(content, 2, "generic_return"))
	assert.True(t, parser.IsLineSuppressedForType(content, 2, "legacy_as"))

	// Line 3: //nolint:generic_return (suppresses only generic_return)
	assert.True(t, parser.IsLineSuppressedForType(content, 3, "generic_return"))
	assert.False(t, parser.IsLineSuppressedForType(content, 3, "legacy_as"))

	// Line 4: //nolint:legacy_as (suppresses only legacy_as)
	assert.False(t, parser.IsLineSuppressedForType(content, 4, "generic_return"))
	assert.True(t, parser.IsLineSuppressedForType(content, 4, "legacy_as"))
}

func TestCommentParser_ParseNolintCommentsWithLinter(t *testing.T) {
	parser := NewCommentParser()

	content := `func main() { //nolint:erraudit
func other() { //nolint:erraudit:generic_return
func third() { //nolint:otherlinter
func fourth() { //nolint
`

	suppressions := parser.ParseNolintCommentsWithLinter(content, "erraudit")

	// Should match lines 1 and 2 (our linter)
	// Line 1: //nolint:erraudit (suppress all for our linter)
	assert.Contains(t, suppressions, 1)
	assert.Equal(t, types.ErrorType(""), suppressions[1].Type)

	// Line 2: //nolint:erraudit:generic_return (suppress specific rule)
	assert.Contains(t, suppressions, 2)
	assert.Equal(t, types.ErrorType("generic_return"), suppressions[2].Type)

	// Line 3: //nolint:otherlinter (different linter, should be skipped)
	assert.NotContains(t, suppressions, 3)

	// Line 4: //nolint (no linter specified, should match)
	assert.Contains(t, suppressions, 4)
}

func TestCommentParser_CommaSeparatedNolints(t *testing.T) {
	t.Parallel()

	parser := NewCommentParser()

	content := `func a() { //nolint:wrapcheck,erraudit
func b() { //nolint:erraudit,wrapcheck
func c() { //nolint:wrapcheck,erraudit:legacy_as
func d() { //nolint:wrapcheck,otherlinter
}`

	suppressions := parser.ParseNolintCommentsWithLinter(content, "erraudit")

	// Line 1: //nolint:wrapcheck,erraudit (erraudit is second — must still match)
	assert.Contains(t, suppressions, 1)
	assert.Equal(t, types.ErrorType(""), suppressions[1].Type)

	// Line 2: //nolint:erraudit,wrapcheck (erraudit is first)
	assert.Contains(t, suppressions, 2)
	assert.Equal(t, types.ErrorType(""), suppressions[2].Type)

	// Line 3: //nolint:wrapcheck,erraudit:legacy_as (erraudit second + rule)
	assert.Contains(t, suppressions, 3)
	assert.Equal(t, types.ErrorType("legacy_as"), suppressions[3].Type)

	// Line 4: //nolint:wrapcheck,otherlinter (erraudit not present)
	assert.NotContains(t, suppressions, 4)
}

func TestCommentParser_MultipleNolintDirectivesPerLine(t *testing.T) {
	t.Parallel()

	parser := NewCommentParser()

	content := `func a() { //nolint:wrapcheck //nolint:erraudit
func b() { //nolint:erraudit //nolint:wrapcheck
func c() { //nolint:wrapcheck //nolint:erraudit:legacy_as
func d() { //nolint:wrapcheck //nolint:otherlinter
}`

	suppressions := parser.ParseNolintCommentsWithLinter(content, "erraudit")

	// Line 1: second directive matches erraudit
	assert.Contains(t, suppressions, 1)
	assert.Equal(t, types.ErrorType(""), suppressions[1].Type)

	// Line 2: first directive matches erraudit
	assert.Contains(t, suppressions, 2)
	assert.Equal(t, types.ErrorType(""), suppressions[2].Type)

	// Line 3: second directive matches erraudit with rule
	assert.Contains(t, suppressions, 3)
	assert.Equal(t, types.ErrorType("legacy_as"), suppressions[3].Type)

	// Line 4: neither directive matches erraudit
	assert.NotContains(t, suppressions, 4)
}
