package suppression

import (
	"os"
	"path/filepath"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestBuildEngineFromFiles_WithNolintComments(t *testing.T) {
	dir := t.TempDir()
	filePath := filepath.Join(dir, "test.go")
	content := "package main\n\n" +
		"func foo() error {\n" +
		"\treturn nil //nolint:erraudit\n" +
		"}\n"
	require.NoError(t, os.WriteFile(filePath, []byte(content), 0o644))

	engine := BuildEngineFromFiles([]string{filePath})
	assert.Greater(t, engine.RuleCount(), 0)
}

func TestBuildEngineFromFiles_EmptyPaths(t *testing.T) {
	engine := BuildEngineFromFiles([]string{})
	assert.Equal(t, 0, engine.RuleCount())
}

func TestBuildEngineFromFiles_NonExistentFile(t *testing.T) {
	engine := BuildEngineFromFiles([]string{"/nonexistent/file.go"})
	assert.Equal(t, 0, engine.RuleCount())
}

func TestBuildEngineFromFiles_EmptyPath(t *testing.T) {
	engine := BuildEngineFromFiles([]string{""})
	assert.Equal(t, 0, engine.RuleCount())
}

func TestBuildEngineFromFiles_DuplicatePaths(t *testing.T) {
	dir := t.TempDir()
	filePath := filepath.Join(dir, "test.go")
	content := "package main\n\n" +
		"func foo() error {\n" +
		"\treturn nil //nolint:erraudit\n" +
		"}\n"
	require.NoError(t, os.WriteFile(filePath, []byte(content), 0o644))

	engine := BuildEngineFromFiles([]string{filePath, filePath})
	// 2 rules: one for the nolint line, one for the enclosing block opener
	// (func foo() line). Duplicate path is deduplicated by the seen map.
	assert.Equal(t, 2, engine.RuleCount())
}

func TestBuildEngineFromFiles_NoNolintComments(t *testing.T) {
	dir := t.TempDir()
	filePath := filepath.Join(dir, "test.go")
	content := "package main\n\nfunc foo() int {\n\treturn 42\n}\n"
	require.NoError(t, os.WriteFile(filePath, []byte(content), 0o644))

	engine := BuildEngineFromFiles([]string{filePath})
	assert.Equal(t, 0, engine.RuleCount())
}

func TestBuildEngineFromFiles_BlockScopedNolintSuppressesBlockOpeningLine(t *testing.T) {
	dir := t.TempDir()
	filePath := filepath.Join(dir, "test.go")
	content := "package main\n\n" +
		"func foo() error {\n" +
		"\terr := bar()\n" +
		"\tif err != nil {\n" + // line 5 — violation reported here
		"\t\tlog.Printf(\"err: %v\", err)\n" + // line 6
		"\t\tcontinue\n" + // line 7
		"\t} //nolint:erraudit // intentional\n" + // line 8 — nolint here
		"\treturn nil\n" +
		"}\n"
	require.NoError(t, os.WriteFile(filePath, []byte(content), 0o644))

	engine := BuildEngineFromFiles([]string{filePath})
	require.Greater(t, engine.RuleCount(), 0)

	// Violation on line 5 (the if-err-nil line) should be suppressed
	// because the nolint on line 8 is within the same block body.
	assert.True(
		t,
		engine.ShouldSuppress(types.ErrorTypeSilentSwallow, filePath, 5, ""),
		"violation on block-opening line should be suppressed by nolint in block body",
	)
}

func TestBuildEngineFromFiles_NolintOutsideBlockDoesNotAffectDistantLine(t *testing.T) {
	dir := t.TempDir()
	filePath := filepath.Join(dir, "test.go")
	content := "package main\n\n" +
		"func foo() error {\n" +
		"\terr := bar()\n" +
		"\tif err != nil {\n" + // line 5 — violation reported here
		"\t\treturn err\n" + // line 6
		"\t}\n" + // line 7
		"\treturn nil //nolint:erraudit\n" + // line 8 — nolint on different statement
		"}\n"
	require.NoError(t, os.WriteFile(filePath, []byte(content), 0o644))

	engine := BuildEngineFromFiles([]string{filePath})
	require.Greater(t, engine.RuleCount(), 0)

	// Violation on line 5 should NOT be suppressed — the nolint on line 8
	// is outside the if-block body (the block closed on line 7).
	assert.False(
		t,
		engine.ShouldSuppress(types.ErrorTypeSilentSwallow, filePath, 5, ""),
		"violation should not be suppressed by nolint outside block body",
	)
}

func TestFindEnclosingBlockStart(t *testing.T) {
	tests := []struct {
		name       string
		lines      []string
		nolintLine int
		want       int
	}{
		{
			name: "finds if-block opening",
			lines: []string{
				"func foo() {",       // line 1
				"\tif err != nil {",  // line 2
				"\tlog.Println(err)", // line 3
				"\t\treturn",         // line 4
				"\t}",                // line 5
			},
			nolintLine: 4,
			want:       2,
		},
		{
			name: "skips closing brace of nested block",
			lines: []string{
				"func foo() {",      // line 1
				"\tif err != nil {", // line 2
				"\t\treturn err",    // line 3
				"\t}",               // line 4
				"\treturn nil",      // line 5 (nolint here, outside if-block)
			},
			nolintLine: 5,
			want:       1, // enclosing block is the func body, not the if
		},
		{
			name: "no block opener within range returns nolintLine",
			lines: []string{
				"package main",      // line 1
				"",                  // line 2
				"//nolint:erraudit", // line 3
			},
			nolintLine: 3,
			want:       3,
		},
		{
			name: "respects maxBlockScanBack limit",
			lines: func() []string {
				l := []string{"func foo() {"} // line 1
				for range maxBlockScanBack + 5 {
					l = append(l, "\tx := 1") // lines 2..maxBlockScanBack+6
				}
				return l
			}(),
			nolintLine: maxBlockScanBack + 6,
			want:       maxBlockScanBack + 6, // too far back, returns nolintLine
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := findEnclosingBlockStart(tt.lines, tt.nolintLine)
			assert.Equal(t, tt.want, got)
		})
	}
}

func TestEngine_RuleCount(t *testing.T) {
	engine := NewEngine()
	assert.Equal(t, 0, engine.RuleCount())

	engine.AddRule(Rule{Type: types.ErrorTypePanic})
	assert.Equal(t, 1, engine.RuleCount())
}

func TestEngine_AddRule_WithFunctionPattern(t *testing.T) {
	engine := NewEngine()
	engine.AddRule(Rule{
		Type:            types.ErrorTypePanic,
		FilePattern:     "*.go",
		FunctionPattern: "main.*",
		LineStart:       1,
		LineEnd:         10,
	})
	assert.Equal(t, 1, engine.RuleCount())
	assert.True(t, engine.ShouldSuppress(types.ErrorTypePanic, "test.go", 5, "main.foo"))
	assert.False(t, engine.ShouldSuppress(types.ErrorTypePanic, "test.go", 5, "other"))
}

func TestEngine_AddRule_WithInvalidFunctionPattern(t *testing.T) {
	engine := NewEngine()
	engine.AddRule(Rule{
		Type:            types.ErrorTypePanic,
		FunctionPattern: "[invalid(",
	})
	// Invalid regex → compiledRe won't have entry → FunctionPattern check fails
	assert.False(t, engine.ShouldSuppress(types.ErrorTypePanic, "test.go", 1, "anything"))
}

func TestRule_Match_FunctionPatternWithoutRegex(t *testing.T) {
	r := Rule{
		FunctionPattern: "test",
	}
	// funcRe is nil → FunctionPattern check should fail
	assert.False(t, r.Match("panic", "test.go", 1, "testFunc", nil))
}

func TestMatchGlob_QuestionMark(t *testing.T) {
	assert.True(t, matchGlob("?.go", "a.go"))
	assert.False(t, matchGlob("?.go", "ab.go"))
}

func TestMatchGlob_DoubleStarSlash(t *testing.T) {
	assert.True(t, matchGlob("pkg/**/*.go", "pkg/internal/file.go"))
}

func TestMatchGlob_BracketPattern(t *testing.T) {
	assert.True(t, matchGlob("[abc].go", "a.go"))
	assert.False(t, matchGlob("[abc].go", "d.go"))
}
