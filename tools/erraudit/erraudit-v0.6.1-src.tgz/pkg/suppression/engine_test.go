package suppression

import (
	"regexp"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// TestRule_Match is a table-driven test where each entry varies by Rule shape
// and expected result. The repeated struct-literal shape is intentional: every
// case must be self-documenting because Rule.Matches is the public API under
// test, and a helper would only obscure which fields are exercised.
func TestRule_Match(t *testing.T) {
	tests := []struct {
		name          string
		rule          Rule
		violationType types.ErrorType
		file          string
		line          int
		function      string
		want          bool
	}{
		{
			name:          "match all (empty rule)",
			rule:          Rule{},
			violationType: "generic_return",
			file:          "main.go",
			line:          10,
			function:      "main",
			want:          true,
		},
		{
			name: "match by type",
			rule: Rule{
				Type: "generic_return",
			},
			violationType: "generic_return",
			file:          "main.go",
			line:          10,
			function:      "main",
			want:          true,
		},
		{
			name: "type mismatch",
			rule: Rule{
				Type: "generic_return",
			},
			violationType: "legacy_as",
			file:          "main.go",
			line:          10,
			function:      "main",
			want:          false,
		},
		{
			name: "match by file pattern",
			rule: Rule{
				FilePattern: "*_test.go",
			},
			violationType: "generic_return",
			file:          "main_test.go",
			line:          10,
			function:      "main",
			want:          true,
		},
		{
			name: "file pattern mismatch",
			rule: Rule{
				FilePattern: "*_test.go",
			},
			violationType: "generic_return",
			file:          "main.go",
			line:          10,
			function:      "main",
			want:          false,
		},
		{
			name: "match by line range",
			rule: Rule{
				LineStart: 5,
				LineEnd:   15,
			},
			violationType: "generic_return",
			file:          "main.go",
			line:          10,
			function:      "main",
			want:          true,
		},
		{
			name: "line out of range",
			rule: Rule{
				LineStart: 5,
				LineEnd:   15,
			},
			violationType: "generic_return",
			file:          "main.go",
			line:          20,
			function:      "main",
			want:          false,
		},
		{
			name: "match by function pattern",
			rule: Rule{
				FunctionPattern: "^Test.*",
			},
			violationType: "generic_return",
			file:          "main.go",
			line:          10,
			function:      "TestMain",
			want:          true,
		},
		{
			name: "multiple criteria (all match)",
			rule: Rule{
				Type:        "generic_return",
				FilePattern: "*_test.go",
				LineStart:   5,
				LineEnd:     15,
			},
			violationType: "generic_return",
			file:          "main_test.go",
			line:          10,
			function:      "main",
			want:          true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			var funcRe *regexp.Regexp
			if tt.rule.FunctionPattern != "" {
				var err error
				funcRe, err = regexp.Compile(tt.rule.FunctionPattern)
				require.NoError(t, err)
			}
			got := tt.rule.Match(tt.violationType, tt.file, tt.line, tt.function, funcRe)
			assert.Equal(t, tt.want, got)
		})
	}
}

func TestEngine_ShouldSuppress(t *testing.T) {
	engine := NewEngine()

	// Add some rules
	engine.AddRule(Rule{
		Type:        "generic_return",
		FilePattern: "*_test.go",
	})
	engine.AddRule(Rule{
		Type: "legacy_as",
	})

	tests := []struct {
		violationType types.ErrorType
		file          string
		line          int
		function      string
		want          bool
	}{
		{
			violationType: "generic_return",
			file:          "main_test.go",
			line:          10,
			function:      "main",
			want:          true,
		},
		{
			violationType: "generic_return",
			file:          "main.go",
			line:          10,
			function:      "main",
			want:          false,
		},
		{
			violationType: "legacy_as",
			file:          "main.go",
			line:          10,
			function:      "main",
			want:          true,
		},
		{
			violationType: "panic",
			file:          "main.go",
			line:          10,
			function:      "main",
			want:          false,
		},
	}

	for _, tt := range tests {
		t.Run(string(tt.violationType)+"_"+tt.file, func(t *testing.T) {
			got := engine.ShouldSuppress(tt.violationType, tt.file, tt.line, tt.function)
			assert.Equal(t, tt.want, got)
		})
	}
}

func TestMatchGlob(t *testing.T) {
	tests := []struct {
		pattern string
		path    string
		want    bool
	}{
		{"*.go", "main.go", true},
		{"*.go", "main_test.go", true},
		{"*_test.go", "main_test.go", true},
		{"*_test.go", "main.go", false},
		{"pkg/**/*.go", "pkg/suppression/engine.go", true},
		{"pkg/**/*.go", "cmd/main.go", false},
		{"cmd/*.go", "cmd/main.go", true},
		{"cmd/*.go", "cmd/sub/cmd.go", false},
		{"?.go", "a.go", true},
		{"?.go", "ab.go", false},
	}

	for _, tt := range tests {
		t.Run(tt.pattern+"_"+tt.path, func(t *testing.T) {
			got := matchGlob(tt.pattern, tt.path)
			assert.Equal(t, tt.want, got)
		})
	}
}
