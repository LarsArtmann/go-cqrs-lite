package suppression

import "strings"

// EffectiveDirectiveLines returns the set of source-code line numbers that a
// //nolint directive at nolintLine (1-based) effectively suppresses violations on.
//
// A single directive can cover up to three lines:
//   - The directive line itself (always included).
//   - The enclosing block's opening line (e.g. "if err != nil {").
//   - The multi-line statement's opening line (e.g. "return apierrors.Wrap(").
//
// Duplicates are removed. This is the public wrapper over the same
// effectiveDirectiveLines core that BuildEngineFromFiles uses to register
// rules, so the audit tool and the engine always agree on which lines a
// directive covers.
func EffectiveDirectiveLines(fileContent string, nolintLine int) []int {
	return effectiveDirectiveLines(strings.Split(fileContent, "\n"), nolintLine)
}

// effectiveDirectiveLines is the line-slice core of EffectiveDirectiveLines,
// shared with BuildEngineFromFiles so the engine registers rules from the
// exact same line set the audit tool reasons about.
func effectiveDirectiveLines(lines []string, nolintLine int) []int {
	seen := map[int]struct{}{}

	var result []int

	add := func(n int) {
		if _, dup := seen[n]; dup {
			return
		}

		seen[n] = struct{}{}
		result = append(result, n)
	}

	add(nolintLine)

	if blockStart := findEnclosingBlockStart(lines, nolintLine); blockStart != nolintLine {
		add(blockStart)
	}

	if stmtStart := findStatementStart(lines, nolintLine); stmtStart != nolintLine {
		add(stmtStart)
	}

	return result
}
