package suppression

import (
	"bufio"
	"regexp"
	"strings"

	"github.com/larsartmann/erraudit/pkg/types"
)

// nolintSpecPartCount is the expected number of parts in a nolint specifier
// when it contains both linter and rule (e.g., "linter:rule").
const nolintSpecPartCount = 2

// CommentParser parses suppression comments from source code.
type CommentParser struct {
	// nolintPattern matches //nolint and /*nolint*/ style comments
	nolintPattern *regexp.Regexp
}

// NewCommentParser creates a new comment parser.
func NewCommentParser() *CommentParser {
	return &CommentParser{
		// Match //nolint, // nolint, //nolint:rule, // nolint:rule, etc.
		// The capture group gets the optional rule/linter specification.
		// Commas are allowed in the linter list (e.g. //nolint:wrapcheck,erraudit).
		nolintPattern: regexp.MustCompile(`(?i)//\s*nolint(?::\s*([\w,-]+(?:\s*:\s*[\w-]+)?))?`),
	}
}

// scanNolintLines scans fileContent line-by-line and invokes fn for each
// suppression comment found, passing the line number and the trimmed rule
// spec (empty if no spec was given). Multiple comments on the same line
// each invoke fn separately (e.g. //nolint:wrapcheck //nolint:erraudit).
func (p *CommentParser) scanNolintLines(fileContent string, fn func(lineNum int, spec string)) {
	scanner := bufio.NewScanner(strings.NewReader(fileContent))
	lineNum := 0

	for scanner.Scan() {
		lineNum++
		line := scanner.Text()

		matches := p.nolintPattern.FindAllStringSubmatch(line, -1)
		for _, match := range matches {
			spec := ""
			if len(match) > 1 {
				spec = strings.TrimSpace(match[1])
			}

			fn(lineNum, spec)
		}
	}
}

// ParseNolintComments parses //nolint comments from file content.
// Returns a map of line numbers to suppression rules.
func (p *CommentParser) ParseNolintComments(fileContent string) map[int]Rule {
	suppressions := make(map[int]Rule)

	p.scanNolintLines(fileContent, func(lineNum int, spec string) {
		rule := Rule{
			Type:            "",
			FilePattern:     "",
			FunctionPattern: "",
			LineStart:       0,
			LineEnd:         0,
		}

		if spec != "" {
			rule.Type = types.ErrorType(spec) // raw spec; validated at match time
		}

		suppressions[lineNum] = rule
	})

	return suppressions
}

// parseNolintSpec parses a nolint specifier string and returns the rule.
// The spec can be in formats: "rule", "linter", "linter:rule", or
// comma-separated linters like "linter1,linter2" or "linter1,linter2:rule".
func parseNolintSpec(spec, linterName string) (Rule, bool) {
	var rule Rule

	parts := strings.Split(spec, ":")

	for i := range parts {
		parts[i] = strings.TrimSpace(parts[i])
	}

	switch len(parts) {
	case 1:
		// "linter" or "linter1,linter2" — check if our linter is in the list
		for l := range strings.SplitSeq(parts[0], ",") {
			if strings.EqualFold(strings.TrimSpace(l), linterName) {
				return rule, true // bare match, suppress all types
			}
		}

		return rule, false
	case nolintSpecPartCount:
		// "linter:rule" or "linter1,linter2:rule"
		for l := range strings.SplitSeq(parts[0], ",") {
			if strings.EqualFold(strings.TrimSpace(l), linterName) {
				rule.Type = types.ErrorType(parts[1]) // raw spec; validated at match time

				return rule, true
			}
		}

		return rule, false
	default:
		return rule, true
	}
}

// ParseNolintCommentsWithLinter parses //nolint:linter:rule comments.
// Returns a map of line numbers to suppression rules with linter and type.
func (p *CommentParser) ParseNolintCommentsWithLinter(fileContent, linterName string) map[int]Rule {
	suppressions := make(map[int]Rule)

	p.scanNolintLines(fileContent, func(lineNum int, spec string) {
		var rule Rule

		matched := true

		if spec != "" {
			rule, matched = parseNolintSpec(spec, linterName)
		}

		if matched {
			suppressions[lineNum] = rule
		}
	})

	return suppressions
}

// IsLineSuppressed checks if a specific line has a nolint comment.
func (p *CommentParser) IsLineSuppressed(fileContent string, lineNum int) bool {
	suppressions := p.ParseNolintComments(fileContent)
	_, exists := suppressions[lineNum]

	return exists
}

// IsLineSuppressedForType checks if a specific line suppresses a specific violation type.
func (p *CommentParser) IsLineSuppressedForType(
	fileContent string,
	lineNum int,
	violationType types.ErrorType,
) bool {
	suppressions := p.ParseNolintComments(fileContent)
	if rule, exists := suppressions[lineNum]; exists {
		// If rule.Type is empty, all violations are suppressed
		// Otherwise, only the specified type is suppressed
		return rule.Type == "" || strings.EqualFold(string(rule.Type), string(violationType))
	}

	return false
}
