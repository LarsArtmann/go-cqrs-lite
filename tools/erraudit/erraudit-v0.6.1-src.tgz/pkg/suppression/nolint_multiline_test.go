package suppression

import (
	"os"
	"path/filepath"
	"testing"
)

// TestFindStatementStart_NolintAfterClosingParen verifies that
// findStatementStart correctly identifies the statement opening line when
// the nolint directive is on the closing `)` line of a multi-line statement.
func TestFindStatementStart_NolintAfterClosingParen(t *testing.T) {
	t.Parallel()

	// lines is 0-indexed: lines[0] = line 1.
	// nolintLine is 1-based.
	lines := []string{
		"\treturn wrap(",        // line 1 — statement start
		"\t    err,",            // line 2
		"\t    \"message\",",    // line 3
		"\t) //nolint:erraudit", // line 4 — nolint here, violation reported at line 1
	}

	result := findStatementStart(lines, 4)
	if result != 1 {
		t.Errorf("expected statement start at line 1, got %d", result)
	}
}

// TestFindStatementStart_NolintInsideMultiLineCall verifies that
// findStatementStart identifies the statement opening line when the nolint
// directive is inside a multi-line call (before the closing `)`).
func TestFindStatementStart_NolintInsideMultiLineCall(t *testing.T) {
	t.Parallel()

	lines := []string{
		"\tpreOutputData, cancelled, _ := hooks.Fire(", // line 1 — statement start
		"\t\tctx,",                 // line 2
		"\t\thooks.HookPreOutput,", // line 3
		"\t\t&hooks.PreOutputData{ //nolint:erraudit", // line 4 — nolint here
		"\t\t\tFormat: outputFmt,",                    // line 5
		"\t\t}",                                       // line 6
		"\t)",                                         // line 7
	}

	result := findStatementStart(lines, 4)
	if result != 1 {
		t.Errorf("expected statement start at line 1, got %d", result)
	}
}

// TestFindStatementStart_SingleLine returns the same line when there's no
// multi-line statement.
func TestFindStatementStart_SingleLine(t *testing.T) {
	t.Parallel()

	lines := []string{
		"\treturn nil //nolint:erraudit", // line 1
	}

	result := findStatementStart(lines, 1)
	if result != 1 {
		t.Errorf("expected same line 1, got %d", result)
	}
}

// TestFindStatementStart_DeepNesting verifies correct behavior when there
// are multiple paren levels.
func TestFindStatementStart_DeepNesting(t *testing.T) {
	t.Parallel()

	lines := []string{
		"\treturn wrap(",           // line 1 — statement start
		"\t\tfmt.Sprintf(",         // line 2
		"\t\t\t\"failed: %s\",",    // line 3
		"\t\t\tpath,",              // line 4
		"\t\t), //nolint:erraudit", // line 5 — nolint on inner closing paren
		"\t)",                      // line 6
	}

	result := findStatementStart(lines, 5)
	// The nolint is on line 5 (inner closing paren). It should trace back
	// to at least line 2 (fmt.Sprintf) where the matching opener is.
	if result >= 5 {
		t.Errorf("expected statement start before line 5, got %d", result)
	}
}

// TestBuildEngineFromFiles_MultiLineStatement verifies that
// BuildEngineFromFiles creates suppression rules that cover the statement
// opening line when a nolint directive is on a multi-line closing paren.
func TestBuildEngineFromFiles_MultiLineStatement(t *testing.T) {
	t.Parallel()

	content := "package main\n" +
		"\n" +
		"import \"fmt\"\n" +
		"\n" +
		"func main() {\n" +
		"\terr := fmt.Errorf(\"boom\")\n" +
		"\tfmt.Println(\n" +
		"\t\terr,\n" +
		"\t) //nolint:erraudit\n" +
		"}\n"

	tmpFile := filepath.Join(t.TempDir(), "multiline_test.go")
	if err := os.WriteFile(tmpFile, []byte(content), 0o644); err != nil {
		t.Fatalf("write temp file: %v", err)
	}

	engine := BuildEngineFromFiles([]string{tmpFile})
	if engine.RuleCount() == 0 {
		t.Fatal("expected at least 1 rule from nolint directive")
	}

	// The nolint is on line 9 (closing `)`). The violation would be
	// reported at line 7 (fmt.Println( — the statement start).
	// The engine should suppress at BOTH line 7 and line 9.
	if !engine.ShouldSuppress("ignored", tmpFile, 9, "") {
		t.Error("expected suppression at line 9 (nolint line)")
	}

	if !engine.ShouldSuppress("ignored", tmpFile, 7, "") {
		t.Error("expected suppression at line 7 (statement start)")
	}
}
