package suppression

import (
	"log"
	"os"
	"regexp"
	"strings"
	"sync"

	"github.com/larsartmann/erraudit/pkg/types"
)

type Rule struct {
	// Type is the violation type to suppress. Empty means suppress all types.
	Type types.ErrorType

	FilePattern string

	FunctionPattern string

	LineStart int
	LineEnd   int
}

func (r *Rule) Match(
	violationType types.ErrorType,
	file string,
	line int,
	function string,
	funcRe *regexp.Regexp,
) bool {
	if r.Type != "" && r.Type != violationType {
		return false
	}

	if r.FilePattern != "" && !matchGlob(r.FilePattern, file) {
		return false
	}

	if r.FunctionPattern != "" {
		if funcRe == nil || !funcRe.MatchString(function) {
			return false
		}
	}

	if r.LineStart > 0 && line < r.LineStart {
		return false
	}

	if r.LineEnd > 0 && line > r.LineEnd {
		return false
	}

	return true
}

type Engine struct {
	rules      []Rule
	compiledRe map[int]*regexp.Regexp
}

func NewEngine() *Engine {
	return &Engine{
		rules:      make([]Rule, 0),
		compiledRe: make(map[int]*regexp.Regexp),
	}
}

func (e *Engine) AddRule(rule Rule) {
	idx := len(e.rules)

	if rule.FunctionPattern != "" {
		re, err := regexp.Compile(rule.FunctionPattern)
		if err == nil {
			e.compiledRe[idx] = re
		}
	}

	e.rules = append(e.rules, rule)
}

func (e *Engine) ShouldSuppress(violationType types.ErrorType, file string, line int, function string) bool {
	for i, rule := range e.rules {
		if rule.Match(violationType, file, line, function, e.compiledRe[i]) {
			return true
		}
	}

	return false
}

func (e *Engine) RuleCount() int {
	return len(e.rules)
}

// BuildEngineFromFiles reads the given source files, parses //nolint comments
// from each, and returns an Engine populated with file-scoped, line-precise
// suppression rules. Files that cannot be read are silently skipped.
//
// Recognizes two linter names so users can suppress with either:
//
//   - //nolint:erraudit (the tool name — suppresses all types)
//   - //nolint:legacyerrors        (the analyzer name — documented in lint help)
//   - //nolint:erraudit:legacy_as (suppresses a specific type)
//   - //nolint:legacyerrors:legacy_as       (same, via analyzer name)
//
// Bare //nolint (no linter spec) always suppresses all types on that line.
//
// This is the bridge between the CommentParser (which works on file content)
// and the Engine (which answers ShouldSuppress queries). It is called by the
// output pipeline so that //nolint comments in analyzed code actually suppress
// violations in SARIF and go-finding-JSON output, and by the lint subcommand
// for its --no-suppress audit path.
func BuildEngineFromFiles(filePaths []string) *Engine {
	// Both linter names are recognized so //nolint:legacyerrors (documented in
	// the lint subcommand help) and //nolint:erraudit (the tool
	// name) both work at the pipeline level.
	linterNames := []string{"erraudit", "legacyerrors"}

	engine := NewEngine()
	parser := NewCommentParser()

	seen := make(map[string]struct{}, len(filePaths))

	for _, path := range filePaths {
		if path == "" {
			continue
		}

		if _, dup := seen[path]; dup {
			continue
		}

		seen[path] = struct{}{}

		content, err := os.ReadFile(path)
		if err != nil { //nolint:erraudit // best-effort load; logs and skips individual file
			log.Printf("warning: skipping suppression file %s: %v",
				path, err)

			continue
		}

		// Merge rules from each recognized linter name. When the same line
		// has rules from multiple names, the later (more specific) one wins
		// because it overwrites the map entry.
		contentStr := string(content)
		lines := strings.Split(contentStr, "\n")

		for _, linterName := range linterNames {
			rules := parser.ParseNolintCommentsWithLinter(contentStr, linterName)
			for lineNum, rule := range rules {
				rule.FilePattern = path

				// One rule per effective line: the directive line itself, the
				// enclosing block's opening line, and the multi-line statement's
				// opening line. effectiveDirectiveLines is the single source of
				// truth for this set — the nolint-audit subcommand (via
				// EffectiveDirectiveLines) shares this core, so the engine and
				// the audit tool can never drift apart.
				for _, line := range effectiveDirectiveLines(lines, lineNum) {
					rule.LineStart = line
					rule.LineEnd = line
					engine.AddRule(rule)
				}
			}
		}
	}

	return engine
}

// maxBlockScanBack limits how far backward findEnclosingBlockStart searches
// for the opening brace of the block containing a //nolint comment. Error
// handling blocks are rarely longer than this.
const maxBlockScanBack = 15

// findEnclosingBlockStart scans backward from nolintLine (1-based) to find the
// nearest line that opens the enclosing code block (if/for/switch/func). It
// tracks brace depth so that closing braces of nested blocks are skipped. This
// allows a //nolint comment placed anywhere inside an error-handling block body
// to suppress a violation reported on the block's opening line (e.g. the
// "if err != nil {" line).
//
// If no block opener is found within maxBlockScanBack lines, the nolintLine
// itself is returned (same-line suppression only).
func findEnclosingBlockStart(lines []string, nolintLine int) int {
	depth := 0

	for i := nolintLine - 1; i >= 1 && i >= nolintLine-maxBlockScanBack; i-- {
		trimmed := strings.TrimSpace(lines[i-1]) // lines is 0-indexed
		opens := strings.Count(trimmed, "{")
		closes := strings.Count(trimmed, "}")
		depth += closes - opens

		if depth < 0 {
			return i // unmatched { — the enclosing block opener
		}
	}

	return nolintLine
}

// findStatementStart scans backward from nolintLine (1-based) to find the
// first line of a multi-line statement. It handles two patterns:
//
//  1. Nolint at the END of a multi-line statement (after the closing `)`):
//     tracks unmatched closers going backward until they balance at the
//     statement's opening line (e.g. the `return ... Wrap(` line).
//
//  2. Nolint INSIDE a multi-line call (before the closing `)`):
//     finds the nearest line above that has an unmatched `(` opener and looks
//     like a statement start (contains `:=` or starts with `return`).
//
// If no statement start is found within maxBlockScanBack lines, nolintLine is
// returned (same-line suppression only).
func findStatementStart(lines []string, nolintLine int) int {
	depth := 0
	seenUnmatchedClosers := false

	for i := nolintLine; i >= 1 && i >= nolintLine-maxBlockScanBack; i-- {
		trimmed := strings.TrimSpace(lines[i-1]) // lines is 0-indexed
		opens := strings.Count(trimmed, "(")
		closes := strings.Count(trimmed, ")")
		depth += closes - opens

		if depth > 0 {
			seenUnmatchedClosers = true
		}

		// Case 1: nolint after closing `)` — unmatched closers balanced out.
		if seenUnmatchedClosers && depth <= 0 {
			return i
		}

		// Case 2: nolint inside a multi-line call — unmatched opener on a
		// statement-start line (contains `:=` or starts with `return`).
		if depth < 0 && looksLikeStatementStart(trimmed) {
			return i
		}
	}

	return nolintLine
}

// looksLikeStatementStart reports whether a line is likely the first line of
// a Go statement (assignment, return, or blank-identifier discard).
func looksLikeStatementStart(line string) bool {
	return strings.HasPrefix(line, "return ") ||
		strings.Contains(line, ":=") ||
		strings.HasPrefix(line, "_") && strings.Contains(line, "=")
}

//nolint:gochecknoglobals // Glob regex cache is intentionally global for reuse across engines
var globCache sync.Map

func matchGlob(pattern, path string) bool {
	compiledRegex, cacheHit := globCache.Load(pattern)
	if !cacheHit {
		regex := globToRegex(pattern)

		compiled, err := regexp.Compile("^" + regex + "$")
		if err != nil {
			log.Printf("warning: invalid glob pattern %q (regex %q): %v",
				pattern, regex, err)

			return false
		}

		actual, loaded := globCache.LoadOrStore(pattern, compiled)
		if loaded {
			compiledRegex = actual
		} else {
			compiledRegex = compiled
		}
	}

	compiled, ok := compiledRegex.(*regexp.Regexp)
	if !ok {
		return false
	}

	return compiled.MatchString(path)
}

func globToRegex(pattern string) string {
	var result strings.Builder
	result.WriteString("(?s)")

	for idx := 0; idx < len(pattern); idx++ {
		char := pattern[idx]
		switch char {
		case '*':
			if idx+1 < len(pattern) && pattern[idx+1] == '*' {
				result.WriteString(".*")

				idx++
			} else {
				result.WriteString("[^/]*")
			}
		case '?':
			result.WriteByte('.')
		case '[':
			closeBracketIdx := idx + 1
			for closeBracketIdx < len(pattern) && pattern[closeBracketIdx] != ']' {
				closeBracketIdx++
			}

			if closeBracketIdx < len(pattern) {
				result.WriteString(pattern[idx : closeBracketIdx+1])
				idx = closeBracketIdx
			} else {
				result.WriteString("\\[")
			}
		case '\\':
			if idx+1 < len(pattern) {
				result.WriteByte('\\')
				result.WriteByte(pattern[idx+1])
				idx++
			}
		case '.', '+', '(', ')', '|', '^', '$':
			result.WriteByte('\\')
			result.WriteByte(char)
		default:
			result.WriteByte(char)
		}
	}

	return result.String()
}
