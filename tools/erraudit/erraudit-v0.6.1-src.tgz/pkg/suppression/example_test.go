package suppression_test

import (
	"fmt"

	"github.com/larsartmann/erraudit/pkg/suppression"
	"github.com/larsartmann/erraudit/pkg/types"
)

func ExampleNewEngine() {
	engine := suppression.NewEngine()
	engine.AddRule(suppression.Rule{
		Type:        types.ErrorTypeLegacyAs,
		FilePattern: "*_generated.go",
	})

	// Generated files are suppressed for legacy_as violations.
	fmt.Println(engine.ShouldSuppress(types.ErrorTypeLegacyAs, "user_generated.go", 10, "MyFunc"))
	fmt.Println(engine.ShouldSuppress(types.ErrorTypeLegacyAs, "main.go", 10, "MyFunc"))
	// Output:
	// true
	// false
}

func ExampleCommentParser_IsLineSuppressed() {
	source := `package main

import "errors"

var _ = errors.As //nolint:erraudit
`

	parser := suppression.NewCommentParser()
	// Line 5 has the //nolint directive.
	fmt.Println(parser.IsLineSuppressed(source, 5))
	fmt.Println(parser.IsLineSuppressed(source, 1))
	// Output:
	// true
	// false
}

func ExampleEngine_RuleCount() {
	engine := suppression.NewEngine()
	engine.AddRule(suppression.Rule{Type: types.ErrorTypeLegacyAs})
	engine.AddRule(suppression.Rule{Type: types.ErrorTypeLegacyIs})

	fmt.Println(engine.RuleCount())
	// Output: 2
}
