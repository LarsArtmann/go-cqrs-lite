package logging

import (
	"log/slog"
	"os"

	charm "charm.land/log/v2"
)

// Setup configures the default slog logger to use charmbracelet/log
// for colorful, structured human-readable output.
func Setup() {
	handler := charm.New(os.Stderr)
	logger := slog.New(handler)
	slog.SetDefault(logger)
}
