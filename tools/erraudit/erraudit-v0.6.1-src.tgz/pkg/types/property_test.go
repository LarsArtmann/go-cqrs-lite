package types

import (
	"encoding/json/v2"
	"testing"

	"pgregory.net/rapid"
)

// Property-based tests for enumerated string types.
// These tests verify that marshal/unmarshal operations are proper round-trips
// and that all valid values are handled correctly.

// assertRoundTrip verifies that a round-trip operation preserves the original value.
// msg describes the type of round-trip being tested.
func assertRoundTrip[T comparable](t *rapid.T, original, parsed T, data []byte, msg string) {
	if parsed != original {
		t.Errorf("%s round-trip failed: %v -> %s -> %v", msg, original, string(data), parsed)
	}
}

// jsonRoundTrip tests JSON marshal/unmarshal round-trip for any type.
func jsonRoundTrip[T comparable](t *rapid.T, gen *rapid.Generator[T], name string) {
	original := gen.Draw(t, name)

	data, err := json.Marshal(original)
	if err != nil {
		t.Fatalf("json.Marshal failed: %v", err)
	}

	var parsed T
	if err := json.Unmarshal(data, &parsed); err != nil {
		t.Fatalf("json.Unmarshal failed: %v", err)
	}

	assertRoundTrip(t, original, parsed, data, "JSON")
}

// textRoundTrip tests text marshal/unmarshal round-trip for types with MarshalText/UnmarshalText.
func textRoundTrip[T interface {
	MarshalText() ([]byte, error)
	comparable
}, PT interface {
	*T
	UnmarshalText([]byte) error
}](t *rapid.T, gen *rapid.Generator[T], name string) {
	original := gen.Draw(t, name)

	data, err := original.MarshalText()
	if err != nil {
		t.Fatalf("MarshalText failed: %v", err)
	}

	var parsed T

	ptr := PT(&parsed)
	if err := ptr.UnmarshalText(data); err != nil {
		t.Fatalf("UnmarshalText failed: %v", err)
	}

	assertRoundTrip(t, original, parsed, data, "text")
}

// parseRoundTrip tests parse function round-trip for string-based types.
func parseRoundTrip[T ~string](
	t *rapid.T,
	gen *rapid.Generator[T],
	parse func(string) (T, error),
	name string,
) {
	original := gen.Draw(t, name)

	parsed, err := parse(string(original))
	if err != nil {
		t.Fatalf("parse failed: %v", err)
	}

	if parsed != original {
		t.Errorf("parse round-trip failed: %v -> %q -> %v", original, string(original), parsed)
	}
}

// validateAll tests IsValid returns true for all generated values.
func validateAll[T interface {
	IsValid() bool
	comparable
	~string
}](t *rapid.T, gen *rapid.Generator[T], name string) {
	value := gen.Draw(t, name)
	if !value.IsValid() {
		t.Errorf("valid %s %q failed IsValid check", name, string(value))
	}
}

// severityGen generates valid Severity values.
func severityGen() *rapid.Generator[Severity] {
	return rapid.SampledFrom(ValidSeverities())
}

// outputFormatGen generates valid OutputFormat values.
func outputFormatGen() *rapid.Generator[OutputFormat] {
	return rapid.SampledFrom(ValidOutputFormats())
}

// errorTypeGen generates valid ErrorType values.
func errorTypeGen() *rapid.Generator[ErrorType] {
	return rapid.SampledFrom(ValidErrorTypes())
}

// errorKindGen generates valid ErrorKind values.
func errorKindGen() *rapid.Generator[ErrorKind] {
	return rapid.SampledFrom(ValidErrorKinds())
}

// relationshipTypeGen generates valid RelationshipType values.
func relationshipTypeGen() *rapid.Generator[RelationshipType] {
	return rapid.SampledFrom(ValidRelationshipTypes())
}

// Property: All enumerated types support round-trip operations

// runPropertyTests runs all property-based tests for an enumerated string type.
// T is the type being tested, PT is a pointer type that implements UnmarshalText.
func runPropertyTests[T interface {
	MarshalText() ([]byte, error)
	IsValid() bool
	comparable
	~string
}, PT interface {
	*T
	UnmarshalText([]byte) error
}](t *testing.T, gen *rapid.Generator[T], parse func(string) (T, error), name string) {
	t.Run("text_round_trip", func(t *testing.T) {
		rapid.Check(t, func(t *rapid.T) {
			textRoundTrip[T, PT](t, gen, name)
		})
	})
	t.Run("json_round_trip", func(t *testing.T) {
		rapid.Check(t, func(t *rapid.T) {
			jsonRoundTrip(t, gen, name)
		})
	})
	t.Run("parse_round_trip", func(t *testing.T) {
		rapid.Check(t, func(t *rapid.T) {
			parseRoundTrip(t, gen, parse, name)
		})
	})
	t.Run("all_valid", func(t *testing.T) {
		rapid.Check(t, func(t *rapid.T) {
			validateAll(t, gen, name)
		})
	})
}

func TestSeverity_Properties(t *testing.T) {
	runPropertyTests(t, severityGen(), ParseSeverity, "severity")
}

func TestOutputFormat_Properties(t *testing.T) {
	runPropertyTests(t, outputFormatGen(), ParseOutputFormat, "format")
}

func TestErrorType_Properties(t *testing.T) {
	runPropertyTests(t, errorTypeGen(), ParseErrorType, "type")
}

func TestErrorKind_Properties(t *testing.T) {
	runPropertyTests(t, errorKindGen(), ParseErrorKind, "kind")
}

func TestRelationshipType_Properties(t *testing.T) {
	runPropertyTests(
		t,
		relationshipTypeGen(),
		ParseRelationshipType,
		"reltype",
	)
}
