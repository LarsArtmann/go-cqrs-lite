package types_test

import (
	"fmt"

	"github.com/larsartmann/erraudit/pkg/types"
)

func ExampleSeverity() {
	sev := types.SeverityHigh

	fmt.Println(sev)
	fmt.Println(sev.IsValid())
	// Output:
	// critical
	// true
}

func ExampleParseSeverity() {
	sev, err := types.ParseSeverity("error")
	if err != nil {
		fmt.Println("error:", err)
		return
	}

	fmt.Println(sev)
	fmt.Println(sev.Ordinal())
	// Output:
	// error
	// 2
}

func ExampleSeverity_AtOrAbove() {
	low := types.SeverityLow
	high := types.SeverityHigh

	fmt.Println(low.AtOrAbove(high))
	fmt.Println(high.AtOrAbove(low))
	// Output:
	// false
	// true
}

func ExampleOutputFormat() {
	format := types.FormatJSON

	fmt.Println(format)
	fmt.Println(format.IsValid())
	// Output:
	// json
	// true
}

func ExampleParseOutputFormat() {
	format, err := types.ParseOutputFormat("sarif")
	if err != nil {
		fmt.Println("error:", err)
		return
	}

	fmt.Println(format)
	// Output: sarif
}

func ExampleConfidence() {
	conf := types.NewConfidence(0.85)

	fmt.Printf("%.2f\n", conf.Float())
	fmt.Println(conf.IsValid())
	// Output:
	// 0.85
	// true
}

func ExampleConfidence_constants() {
	fmt.Println(types.ConfidenceNone)
	fmt.Println(types.ConfidenceLow)
	fmt.Println(types.ConfidenceHigh)
	// Output:
	// 0
	// 0.5
	// 0.95
}

func ExampleErrorType() {
	violationType := types.ErrorTypeLegacyAs

	fmt.Println(violationType)
	fmt.Println(violationType.IsValid())
	// Output:
	// legacy_as
	// true
}
