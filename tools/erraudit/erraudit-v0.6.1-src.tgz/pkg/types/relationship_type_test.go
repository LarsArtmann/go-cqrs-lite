package types

import (
	"encoding/json/v2"
	"testing"
)

// relationshipTypeTestCases is the source of truth for RelationshipType test cases.
var relationshipTypeTestCases = []struct {
	name string
	rt   RelationshipType
}{
	{"Lowercase: wraps", RelationshipTypeWraps},
	{"Lowercase: aliases", RelationshipTypeAliases},
	{"Uppercase: WRAPS", RelationshipTypeWraps},
	{"Uppercase: ALIASES", RelationshipTypeAliases},
	{"Mixed case: Wraps", RelationshipTypeWraps},
	{"Mixed case: Aliases", RelationshipTypeAliases},
	{"Invalid: unknown", RelationshipType("")},
	{"Invalid: empty", RelationshipType("")},
}

func TestRelationshipType_IsValid(t *testing.T) {
	runIsValidGeneratedTests(t, "RelationshipType", relationshipTypeTestCases,
		func(tc struct {
			name string
			rt   RelationshipType
		}) struct {
			name string
			obj  RelationshipType
			want bool
		} {
			return struct {
				name string
				obj  RelationshipType
				want bool
			}{
				name: tc.name,
				obj:  tc.rt,
				want: tc.rt.IsValid(),
			}
		},
		func(r RelationshipType) bool { return r.IsValid() })
}

func TestParseRelationshipType(t *testing.T) {
	runParseGeneratedTests(t, "RelationshipType", relationshipTypeTestCases,
		func(tc struct {
			name string
			rt   RelationshipType
		}) struct {
			name    string
			input   string
			want    RelationshipType
			wantErr bool
		} {
			return struct {
				name    string
				input   string
				want    RelationshipType
				wantErr bool
			}{
				name:    tc.name,
				input:   string(tc.rt),
				want:    tc.rt,
				wantErr: tc.rt == RelationshipType(""),
			}
		},
		ParseRelationshipType)
}

func TestRelationshipType_MarshalJSON(t *testing.T) {
	tests := []JSONMarshalTestCase[RelationshipType]{
		{Name: "wraps", Value: RelationshipTypeWraps, Want: `"wraps"`, WantErr: false},
		{Name: "aliases", Value: RelationshipTypeAliases, Want: `"aliases"`, WantErr: false},
	}

	runMarshalTests(t, "RelationshipType", "MarshalJSON", tests, RelationshipType.MarshalJSON)
}

func TestRelationshipType_UnmarshalJSON(t *testing.T) {
	tests := []struct {
		name    string
		data    string
		want    RelationshipType
		wantErr bool
	}{
		{"Lowercase: wraps", "wraps", RelationshipTypeWraps, false},
		{"Lowercase: aliases", "aliases", RelationshipTypeAliases, false},
		{"Uppercase: WRAPS", "WRAPS", RelationshipTypeWraps, false},
		{"Uppercase: ALIASES", "ALIASES", RelationshipTypeAliases, false},
		{"Mixed case: Wraps", "Wraps", RelationshipTypeWraps, false},
		{"Mixed case: Aliases", "Aliases", RelationshipTypeAliases, false},
		{"Invalid: unknown", "unknown", RelationshipType(""), true},
		{"Invalid: empty", "", RelationshipType(""), true},
	}

	jsonTests := make([]JSONUnmarshalTestCase[RelationshipType], len(tests))
	for i, tc := range tests {
		jsonTests[i] = JSONUnmarshalTestCase[RelationshipType]{
			Name:    tc.name,
			Input:   tc.data,
			Got:     RelationshipType(""),
			Want:    tc.want,
			WantErr: tc.wantErr,
		}
	}

	runJSONUnmarshalTests(
		t, "RelationshipType", jsonTests,
		func(data []byte, rt *RelationshipType) error { return json.Unmarshal(data, rt) },
		QuoteString,
	)
}

func TestRelationshipType_MarshalText(t *testing.T) {
	tests := []MarshalTextTestCase[RelationshipType]{
		{Name: "wraps", Value: RelationshipTypeWraps, Want: "wraps"},
		{Name: "aliases", Value: RelationshipTypeAliases, Want: "aliases"},
	}

	runMarshalTests(t, "RelationshipType", "MarshalText", tests, RelationshipType.MarshalText)
}

func TestRelationshipType_UnmarshalText(t *testing.T) {
	tests := []TextUnmarshalInlineTestCase[RelationshipType]{
		{Name: "Lowercase: wraps", Data: "wraps", Want: RelationshipTypeWraps, WantErr: false},
		{
			Name:    "Lowercase: aliases",
			Data:    "aliases",
			Want:    RelationshipTypeAliases,
			WantErr: false,
		},
		{Name: "Uppercase: WRAPS", Data: "WRAPS", Want: RelationshipTypeWraps, WantErr: false},
		{
			Name:    "Uppercase: ALIASES",
			Data:    "ALIASES",
			Want:    RelationshipTypeAliases,
			WantErr: false,
		},
		{Name: "Mixed case: Wraps", Data: "Wraps", Want: RelationshipTypeWraps, WantErr: false},
		{
			Name:    "Mixed case: Aliases",
			Data:    "Aliases",
			Want:    RelationshipTypeAliases,
			WantErr: false,
		},
		{Name: "Invalid: unknown", Data: "unknown", Want: RelationshipType(""), WantErr: true},
		{Name: "Invalid: empty", Data: "", Want: RelationshipType(""), WantErr: true},
	}

	runTextUnmarshalInlineTests(t, "RelationshipType", tests, (*RelationshipType).UnmarshalText)
}

func TestRelationshipType_RoundTrip(t *testing.T) {
	validTypes := []RelationshipType{
		RelationshipTypeWraps,
		RelationshipTypeAliases,
	}

	runAllValidMarshalersTests(
		t, "RelationshipType", validTypes,
		RelationshipType.IsValid,
		MarshalJSONHelper[RelationshipType],
		(*RelationshipType).UnmarshalJSON,
		RelationshipType.MarshalText,
		(*RelationshipType).UnmarshalText,
	)
}

func TestRelationshipType_PointerSemantics(t *testing.T) {
	validVal := RelationshipTypeWraps
	_ = validVal
	// Test with pointer to valid value
	validPtr := &validVal
	if !validPtr.IsValid() {
		t.Error("Pointer to valid RelationshipType should be valid")
	}
	// Test with pointer to invalid value
	invalidVal := RelationshipType("invalid")

	invalidPtr := &invalidVal
	if invalidPtr.IsValid() {
		t.Error("Pointer to invalid RelationshipType should be invalid")
	}
}

func TestRelationshipType_ZeroValue(t *testing.T) {
	var zero RelationshipType
	if zero.IsValid() {
		t.Error("Zero value should be invalid")
	}
}

func TestRelationshipType_ErrorMessage(t *testing.T) {
	runEnumTypeErrorMessageTests[RelationshipType](t, "RelationshipType")
}
