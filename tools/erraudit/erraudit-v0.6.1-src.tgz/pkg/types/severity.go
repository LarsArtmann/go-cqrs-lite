package types

import (
	"encoding"
	"encoding/json/v2"
)

// Severity represents the severity level of an error violation.
//

type Severity string

const (
	// SeverityLow maps to finding.SeverityWarning.
	SeverityLow Severity = "warning"
	// SeverityMedium maps to finding.SeverityError.
	SeverityMedium Severity = "error"
	// SeverityHigh maps to finding.SeverityCritical.
	SeverityHigh Severity = "critical"
)

// severityRank provides ordinal ranking for severity comparison.
// Order: low(1) < medium(2) < high(3).
//
//nolint:gochecknoglobals // Severity ranking map is intentionally global for comparison
var severityRank = map[Severity]uint{
	SeverityLow:    1,
	SeverityMedium: 2,
	SeverityHigh:   3, //nolint:mnd // Magic number 3 is intentional for severity ranking
}

// Ordinal returns the ordinal rank of the severity for comparison.
// Higher values indicate more severe issues.
func (s Severity) Ordinal() uint {
	if rank, ok := severityRank[s]; ok {
		return rank
	}

	return 0
}

// AtOrAbove returns true if this severity is at or above the threshold.
func (s Severity) AtOrAbove(threshold Severity) bool {
	return s.Ordinal() >= threshold.Ordinal()
}

// validSeverities is the canonical list of valid Severity values.
//
//nolint:gochecknoglobals // Package-level slice avoids per-call heap allocation in IsValid()
var validSeverities = []Severity{SeverityHigh, SeverityMedium, SeverityLow}

// IsValid checks if the severity is valid.
func (s Severity) IsValid() bool {
	return isValidValue(s, validSeverities)
}

// ParseSeverity parses a string into a Severity
// Returns error if string is not a valid severity.
func ParseSeverity(input string) (Severity, error) {
	return parseType[Severity](input, "severity")
}

// ValidSeverities returns list of valid severity values.
func ValidSeverities() []Severity {
	return validSeverities
}

// IsValidSeverity checks if severity is valid (for string input).
func IsValidSeverity(s string) bool {
	sev := Severity(s)

	return sev.IsValid()
}

// MarshalJSON implements json.Marshaler for Severity.
func (s Severity) MarshalJSON() ([]byte, error) {
	//nolint:wrapcheck // json.Marshal on string cannot fail
	return json.Marshal(string(s))
}

// UnmarshalJSON implements json.Unmarshaler for Severity.
func (s *Severity) UnmarshalJSON(data []byte) error {
	return unmarshalJSONAssign(data, "Severity", Severity.IsValid, s)
}

// MarshalText implements encoding.TextMarshaler for Severity.
func (s Severity) MarshalText() ([]byte, error) {
	return []byte(string(s)), nil
}

// UnmarshalText implements encoding.TextUnmarshaler for Severity.
func (s *Severity) UnmarshalText(data []byte) error {
	return unmarshalTextAssign(data, "Severity", Severity.IsValid, s)
}

var (
	_ encoding.TextMarshaler   = Severity("")
	_ encoding.TextUnmarshaler = (*Severity)(nil)
)
