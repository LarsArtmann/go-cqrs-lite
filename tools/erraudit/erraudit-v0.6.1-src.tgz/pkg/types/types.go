// Package types provides core domain types for the erraudit analyzer.
package types

import (
	"encoding"
	"encoding/json/v2"
	"fmt"
	"go/token"
	"slices"
	"strings"

	"github.com/larsartmann/erraudit/pkg/errors"
)

// ErrorInfo represents information about an error in the code.
type ErrorInfo struct {
	Position   token.Position `json:"position"`
	Type       ErrorType      `json:"type"`
	Message    string         `json:"message"`
	StackTrace []string       `json:"stackTrace,omitempty"`
	Context    ErrorContext   `json:"context"`
}

// ErrorType represents the type of error found.
//

type ErrorType string

const (
	ErrorTypeReturn               ErrorType = "return"
	ErrorTypeAssignment           ErrorType = "assignment"
	ErrorTypeWrapping             ErrorType = "wrapping"
	ErrorTypeUnwrapped            ErrorType = "unwrapped"
	ErrorTypeCheck                ErrorType = "check"
	ErrorTypePropagation          ErrorType = "propagation"
	ErrorTypePanic                ErrorType = "panic"
	ErrorTypeSilentSwallow        ErrorType = "silent_swallow"
	ErrorTypeIgnored              ErrorType = "ignored"
	ErrorTypeGenericReturn        ErrorType = "generic_return"      // Function returns bare error interface instead of specific type
	ErrorTypeLegacyAs             ErrorType = "legacy_as"           // Using errors.As instead of modern errors.AsType (Go 1.26+)
	ErrorTypeLegacyIs             ErrorType = "legacy_is"           // Advisory: errors.Is may benefit from errors.AsType if matching by type
	ErrorTypeContextLoss          ErrorType = "context_loss"        // Function drops meaningful context variables on error paths
	ErrorTypeStdlibConstructor    ErrorType = "stdlib_constructor"  // Opt-in: stdlib constructor used where a target error library is enforced
	ErrorTypeUncodedConstructor   ErrorType = "uncoded_constructor" // Opt-in: go-error-family constructor called with an empty ("") error code
	ErrorTypeOopsRedundantGuard   ErrorType = "oops_redundant_guard"
	ErrorTypeOopsMisusedW         ErrorType = "oops_misused_w"         // Opt-in: redundant nil guard before oops.Wrap/Wrapf
	ErrorTypeDeferredCloseIgnored ErrorType = "deferred_close_ignored" // defer f.Close() discards Close error
	ErrorTypeSentinelConcreteType ErrorType = "sentinel_concrete_type" // Package-level Err*/err* sentinel var has a concrete type instead of the error interface
)

// String implements fmt.Stringer for ErrorType.
func (t ErrorType) String() string {
	return string(t)
}

// validErrorTypes is the canonical list of valid ErrorType values.
// Package-level to avoid per-call heap allocation in IsValid().
//
//nolint:gochecknoglobals // Immutable enum registry, not configuration
var validErrorTypes = []ErrorType{
	ErrorTypeReturn, ErrorTypeAssignment, ErrorTypeWrapping,
	ErrorTypeUnwrapped, ErrorTypeCheck, ErrorTypePropagation,
	ErrorTypePanic, ErrorTypeSilentSwallow, ErrorTypeIgnored,
	ErrorTypeGenericReturn,
	ErrorTypeLegacyAs,
	ErrorTypeLegacyIs,
	ErrorTypeContextLoss,
	ErrorTypeStdlibConstructor,
	ErrorTypeUncodedConstructor,
	ErrorTypeOopsRedundantGuard,
	ErrorTypeOopsMisusedW,
	ErrorTypeDeferredCloseIgnored,
	ErrorTypeSentinelConcreteType,
}

// IsValid checks if the error type is valid.
func (t ErrorType) IsValid() bool {
	return slices.Contains(validErrorTypes, t)
}

// ValidErrorTypes returns list of valid error type values.
func ValidErrorTypes() []ErrorType {
	return validErrorTypes
}

// validatable is a constraint for string-based types with an IsValid method.
type validatable interface {
	~string
	IsValid() bool
}

// parseType validates and converts a string into a typed string enum.
func parseType[T validatable](input, typeName string) (T, error) {
	parsed := T(strings.ToLower(input))
	if parsed.IsValid() {
		return parsed, nil
	}

	var zero T

	return zero, errors.Wrap(errors.ErrValueInvalid, "invalid %s: %q", typeName, input)
}

// isValidValue checks whether value appears in validValues using a generic
// linear scan. For small enum slices (2–11 elements) this is as fast as a
// switch statement and eliminates duplicated constant lists.
func isValidValue[T ~string](value T, validValues []T) bool {
	return slices.Contains(validValues, value)
}

// ParseErrorType parses a string into an ErrorType
// Returns error if string is not a valid error type.
func ParseErrorType(s string) (ErrorType, error) {
	return parseType[ErrorType](s, "error type")
}

// MarshalJSON implements json.Marshaler for ErrorType.
func (t ErrorType) MarshalJSON() ([]byte, error) {
	//nolint:wrapcheck // json.Marshal on string cannot fail
	return json.Marshal(string(t))
}

// UnmarshalJSON implements json.Unmarshaler for ErrorType.
func (t *ErrorType) UnmarshalJSON(data []byte) error {
	return unmarshalJSONAssign(data, "ErrorType", ErrorType.IsValid, t)
}

// MarshalText implements encoding.TextMarshaler for ErrorType.
func (t ErrorType) MarshalText() ([]byte, error) {
	return []byte(string(t)), nil
}

// UnmarshalText implements encoding.TextUnmarshaler for ErrorType.
func (t *ErrorType) UnmarshalText(data []byte) error {
	return unmarshalTextAssign(data, "ErrorType", ErrorType.IsValid, t)
}

// ErrorContext provides context about the error location.
type ErrorContext struct {
	FunctionName string   `json:"functionName"`
	PackageName  string   `json:"packageName"`
	FileName     string   `json:"fileName"`
	LineNumber   int      `json:"lineNumber"`
	Vars         []string `json:"vars,omitempty"`
}

// String implements fmt.Stringer for ErrorViolation.
func (v ErrorViolation) String() string {
	return fmt.Sprintf(
		"%s:%d:%d [%s] %s: %s",
		v.Position.Filename, v.Position.Line, v.Position.Column,
		strings.ToUpper(string(v.Severity)),
		v.Type, v.Message,
	)
}

type ErrorViolation struct {
	Position    token.Position     `json:"position"`
	EndPosition token.Position     `json:"endPosition"`
	Type        ErrorType          `json:"type"`
	Severity    Severity           `json:"severity"`
	Message     string             `json:"message"`
	Suggestion  string             `json:"suggestion,omitempty"`
	Explanation string             `json:"explanation,omitempty"` // Populated when --explain is active
	SnippetPos  token.Pos          `json:"-"`                     // Position for snippet extraction
	CodeSnippet string             `json:"codeSnippet,omitempty"`
	Confidence  Confidence         `json:"confidence,omitempty"`
	ErrorName   string             `json:"errorName,omitempty"`   // Name of the error variable involved, if known
	ContextLoss *ContextLossDetail `json:"contextLoss,omitempty"` // Populated for ErrorTypeContextLoss violations
}

// NewErrorViolation creates a new ErrorViolation with the required fields.
// Pass node.Pos() and node.End() for startPos and endPos.
// Confidence is set by violation type.
// CodeSnippet is populated later by AddCodeSnippetsToViolations.
func NewErrorViolation(
	fset *token.FileSet,
	startPos token.Pos,
	endPos token.Pos,
	violationType ErrorType,
	severity Severity,
	message string,
	suggestion string,
	errorName string,
	confidence Confidence,
) ErrorViolation {
	return ErrorViolation{
		Position:    fset.Position(startPos),
		EndPosition: fset.Position(endPos),
		Type:        violationType,
		Severity:    severity,
		Message:     message,
		Suggestion:  suggestion,
		SnippetPos:  startPos,
		Confidence:  confidence,
		ErrorName:   errorName,
	}
}

// IsValid returns true if the violation has required fields set.
func (v ErrorViolation) IsValid() bool {
	return v.Position.Filename != "" && v.Type.IsValid() && v.Message != "" && v.Severity.IsValid()
}

// Key returns a stable deduplication key for the violation, built from
// file, type, and position. This is the domain-side identity; the go-finding
// side (pkg/finding) produces an equivalent key via Finding.Key() (which
// returns the auto-generated ID "tool:rule:file:line:col"). The two are kept
// in agreement by TestViolationKeyEquivalenceToFindingKey in pkg/finding —
// any future divergence will fail that test.
func (v ErrorViolation) Key() string {
	return fmt.Sprintf(
		"%s\x00%s\x00%d\x00%d\x00%s",
		v.Position.Filename, v.Type, v.Position.Line, v.Position.Column, v.ErrorName,
	)
}

// ErrorGraph represents the complete error graph for analysis.
type ErrorGraph struct {
	Package    string           `json:"package"`
	Errors     []ErrorInfo      `json:"errors"`
	Violations []ErrorViolation `json:"violations"`
	Metrics    ErrorMetrics     `json:"metrics"`
	Hierarchy  *ErrorHierarchy  `json:"hierarchy,omitempty"` // Hierarchical error relationships
	// FilesScanned is the number of .go files analyzed. Always emitted (no
	// omitempty): "filesScanned": 0 in the JSON is load-bearing coverage
	// evidence — without it, a 0-file scan is indistinguishable from a clean
	// full-module scan (the 2026-09-11 monorepo-coverage finding).
	FilesScanned int `json:"filesScanned"`

	// SkippedModules lists the nested go.mod modules under the analysis
	// target that were NOT analyzed (module boundaries for go tooling).
	// Empty when the target has no nested modules or when --modules=all
	// analyzed them.
	SkippedModules []string `json:"skippedModules,omitempty"`

	// PackagesScanned is the number of distinct Go packages analyzed. Set in
	// package/pattern mode (one per package graph, summed on merge); zero in
	// directory/file mode where the analysis is not package-partitioned.
	PackagesScanned int `json:"packagesScanned,omitempty"`
}

// ErrorMetrics provides metrics about errors in the codebase.
type ErrorMetrics struct {
	TotalErrors      uint            `json:"totalErrors"`
	WrapDepth        uint            `json:"maxWrapDepth"`
	ErrorReturns     uint            `json:"errorReturns"`
	ErrorWraps       uint            `json:"errorWraps"`
	SilentSwallows   uint            `json:"silentSwallows"`
	PanicsOnErrors   uint            `json:"panicsOnErrors"`
	IgnoredErrors    uint            `json:"ignoredErrors"`
	MostCommonErrors map[string]uint `json:"mostCommonErrors"`
}

// Merge returns the result of combining this metrics with other, summing
// counters, taking the max of WrapDepth, and merging MostCommonErrors per key.
// This is the single canonical aggregation rule — the analyzer merger calls it
// so adding a new field only requires updating it here, not in the merger.
func (m ErrorMetrics) Merge(other ErrorMetrics) ErrorMetrics {
	result := m
	result.TotalErrors += other.TotalErrors
	result.WrapDepth = max(result.WrapDepth, other.WrapDepth)
	result.ErrorReturns += other.ErrorReturns
	result.ErrorWraps += other.ErrorWraps
	result.SilentSwallows += other.SilentSwallows
	result.PanicsOnErrors += other.PanicsOnErrors
	result.IgnoredErrors += other.IgnoredErrors

	if result.MostCommonErrors == nil {
		result.MostCommonErrors = make(map[string]uint, len(other.MostCommonErrors))
	}

	for k, v := range other.MostCommonErrors {
		result.MostCommonErrors[k] += v
	}

	return result
}

// NamedError represents a named error definition (var ErrFoo = errors.New("...")).
type NamedError struct {
	Name       string         `json:"name"`
	Kind       ErrorKind      `json:"kind"` // errors.New, fmt.Errorf, custom type, sentinel
	Message    string         `json:"message,omitempty"`
	Position   token.Position `json:"position"`
	FileName   string         `json:"fileName"`
	Function   string         `json:"function,omitempty"`
	ParentName string         `json:"parentName,omitempty"` // Name of error this wraps (if any)
}

// ErrorKind represents the kind of error definition.
//

type ErrorKind string

const (
	ErrorKindNew        ErrorKind = "errors.new"
	ErrorKindErrorf     ErrorKind = "fmt.errorf"
	ErrorKindJoin       ErrorKind = "errors.join"
	ErrorKindSentinel   ErrorKind = "sentinel"    // var ErrFoo = ...
	ErrorKindCustom     ErrorKind = "custom_type" // &MyError{}, MyError("msg")
	ErrorKindWrap       ErrorKind = "wrapped"     // var ErrFoo = fmt.Errorf("%w", ErrBar)
	ErrorKindFamilyNew  ErrorKind = "family.new"  // errorfamily.New/Newf/NewRejection/...
	ErrorKindFamilyWrap ErrorKind = "family.wrap" // errorfamily.Wrap/Wrapf/WrapOnce/WrapRejection/...
	ErrorKindOopsErrorf ErrorKind = "oops.errorf" // oops.Errorf/oops.New
	ErrorKindOopsWrap   ErrorKind = "oops.wrap"   // oops.Wrap/oops.Wrapf
)

// String implements fmt.Stringer for ErrorKind.
func (k ErrorKind) String() string {
	return string(k)
}

// validErrorKinds is the canonical list of valid ErrorKind values.
//
//nolint:gochecknoglobals // Immutable enum registry, not configuration
var validErrorKinds = []ErrorKind{
	ErrorKindNew, ErrorKindErrorf, ErrorKindJoin, ErrorKindSentinel,
	ErrorKindCustom, ErrorKindWrap,
	ErrorKindFamilyNew, ErrorKindFamilyWrap,
	ErrorKindOopsErrorf, ErrorKindOopsWrap,
}

// IsValid checks if the error kind is valid.
func (k ErrorKind) IsValid() bool {
	return slices.Contains(validErrorKinds, k)
}

// ValidErrorKinds returns list of valid error kind values.
func ValidErrorKinds() []ErrorKind {
	return validErrorKinds
}

// ParseErrorKind parses a string into an ErrorKind
// Returns error if string is not a valid error kind.
func ParseErrorKind(s string) (ErrorKind, error) {
	return parseType[ErrorKind](s, "error kind")
}

// MarshalJSON implements json.Marshaler for ErrorKind.
func (k ErrorKind) MarshalJSON() ([]byte, error) {
	//nolint:wrapcheck // json.Marshal on string cannot fail
	return json.Marshal(string(k))
}

// UnmarshalJSON implements json.Unmarshaler for ErrorKind.
func (k *ErrorKind) UnmarshalJSON(data []byte) error {
	return unmarshalJSONAssign(data, "ErrorKind", ErrorKind.IsValid, k)
}

// MarshalText implements encoding.TextMarshaler for ErrorKind.
func (k ErrorKind) MarshalText() ([]byte, error) {
	return []byte(string(k)), nil
}

// UnmarshalText implements encoding.TextUnmarshaler for ErrorKind.
func (k *ErrorKind) UnmarshalText(data []byte) error {
	return unmarshalTextAssign(data, "ErrorKind", ErrorKind.IsValid, k)
}

// RelationshipType represents the type of relationship between errors.
//

type RelationshipType string

const (
	RelationshipTypeWraps   RelationshipType = "wraps"   // Parent wraps child using %w
	RelationshipTypeAliases RelationshipType = "aliases" // Parent is an alias/assignment of child
)

// String implements fmt.Stringer for RelationshipType.
func (t RelationshipType) String() string {
	return string(t)
}

// IsValid checks if the relationship type is valid.
func (t RelationshipType) IsValid() bool {
	return slices.Contains(ValidRelationshipTypes(), t)
}

// validRelationshipTypes is the canonical list of valid RelationshipType values.
//
//nolint:gochecknoglobals // Immutable enum registry, not configuration
var validRelationshipTypes = []RelationshipType{RelationshipTypeWraps, RelationshipTypeAliases}

// ValidRelationshipTypes returns list of valid relationship type values.
func ValidRelationshipTypes() []RelationshipType {
	return validRelationshipTypes
}

// ParseRelationshipType parses a string into a RelationshipType
// Returns error if string is not a valid relationship type.
func ParseRelationshipType(s string) (RelationshipType, error) {
	return parseType[RelationshipType](s, "relationship type")
}

// MarshalJSON implements json.Marshaler for RelationshipType.
func (t RelationshipType) MarshalJSON() ([]byte, error) {
	//nolint:wrapcheck // json.Marshal on string cannot fail
	return json.Marshal(string(t))
}

// UnmarshalJSON implements json.Unmarshaler for RelationshipType.
func (t *RelationshipType) UnmarshalJSON(data []byte) error {
	return unmarshalJSONAssign(data, "RelationshipType", RelationshipType.IsValid, t)
}

// MarshalText implements encoding.TextMarshaler for RelationshipType.
func (t RelationshipType) MarshalText() ([]byte, error) {
	return []byte(string(t)), nil
}

// UnmarshalText implements encoding.TextUnmarshaler for RelationshipType.
func (t *RelationshipType) UnmarshalText(data []byte) error {
	return unmarshalTextAssign(data, "RelationshipType", RelationshipType.IsValid, t)
}

// ErrorNode represents a node in the error hierarchy tree.
type ErrorNode struct {
	Name        string         `json:"name"`
	Message     string         `json:"message"`
	Kind        ErrorKind      `json:"kind"`
	Position    token.Position `json:"position"`
	Children    []*ErrorNode   `json:"children"`
	Depth       uint           `json:"depth"`
	Occurrences uint           `json:"occurrences"`
	Violations  uint           `json:"violations"`

	// Reference-site counts for this error, copied from the hierarchy metrics
	// after the final graph is assembled (buildHierarchy and FinalizeHierarchy).
	// InlineWraps counts function-body wrap sites referencing this error;
	// Checks counts errors.Is references to it. Zero when unreferenced.
	InlineWraps uint `json:"inlineWraps,omitempty"`
	Checks      uint `json:"checks,omitempty"`
}

// ErrorSiteRef identifies one inline reference site (function-body wrap or
// errors.Is check) to a named error: the call position plus the enclosing
// function name. The usage tracker records these so renderers can show WHERE
// an error is wrapped or checked, not just how often.
type ErrorSiteRef struct {
	Position token.Position `json:"position"`
	Function string         `json:"function,omitempty"`
}

// ErrorRelationship represents a relationship between two errors.
type ErrorRelationship struct {
	Parent           string           `json:"parent"`           // Parent error name
	Child            string           `json:"child"`            // Child error name
	RelationshipType RelationshipType `json:"relationshipType"` // Type of relationship
	Depth            uint             `json:"depth"`
	Position         token.Position   `json:"position"`
	CodeSnippet      string           `json:"codeSnippet,omitempty"`
}

// ErrorHierarchy represents the complete error hierarchy for analysis.
type ErrorHierarchy struct {
	RootErrors    []*ErrorNode          `json:"rootErrors"`    // Errors with no parent
	AllNodes      map[string]*ErrorNode `json:"allNodes"`      // Map of all nodes by name
	Relationships []ErrorRelationship   `json:"relationships"` // All relationships
	NamedErrors   []NamedError          `json:"namedErrors"`   // All named errors
	Metrics       HierarchyMetrics      `json:"metrics"`
}

// HierarchyMetrics provides metrics about the error hierarchy.
type HierarchyMetrics struct {
	TotalNamedErrors            uint            `json:"totalNamedErrors"`
	TotalRelationships          uint            `json:"totalRelationships"`
	MaxDepth                    uint            `json:"maxDepth"`
	DeepestError                string          `json:"deepestError,omitempty"`
	MostWrappedError            string          `json:"mostWrappedError,omitempty"`
	MostWrappedErrorOccurrences uint            `json:"mostWrappedErrorOccurrences"`
	WrapCount                   map[string]uint `json:"wrapCount"`
	SentinelErrors              uint            `json:"sentinelErrors"`
	CustomErrorTypes            uint            `json:"customErrorTypes"`

	// Branching and chain metrics. Computed per-file by the RelationshipTracker
	// (via GetHierarchySummary) and recomputed post-merge by FinalizeHierarchy.
	// Not summable across files — always derived from the final relationship set.
	AvgBranchingFactor float64 `json:"avgBranchingFactor,omitempty"`
	MaxBranchingParent string  `json:"maxBranchingParent,omitempty"`
	MaxBranchingCount  uint    `json:"maxBranchingCount"`
	LongestChainLength uint    `json:"longestChainLength"`
	LongestChainRoot   string  `json:"longestChainRoot,omitempty"`

	// Reference-site annotations. Unlike the branching metrics above, these
	// ARE summable across files — each site belongs to exactly one file.
	// InlineWrapSites counts fmt.Errorf %w / errors.Join / errorfamily.Wrap*
	// / oops.Wrap* call sites inside function bodies regardless of the
	// wrapped operand (runtime `err` or a named error). WrapSitesByError and
	// CheckSitesByError count, per named error, the inline wrap sites and
	// errors.Is references that mention it (identifier references within
	// the analyzed package only). TypeCheckSites counts errors.As call
	// sites; their target operand is a type, so attribution needs type
	// information and AST mode records the total only.
	InlineWrapSites   uint            `json:"inlineWrapSites,omitempty"`
	WrapSitesByError  map[string]uint `json:"wrapSitesByError,omitempty"`
	CheckSitesByError map[string]uint `json:"checkSitesByError,omitempty"`
	TypeCheckSites    uint            `json:"typeCheckSites,omitempty"`

	// Detail maps behind WrapSitesByError / CheckSitesByError: one ErrorSiteRef
	// per identifier reference, carrying call position and enclosing function.
	// len(WrapSiteRefs[name]) equals WrapSitesByError[name] for identifier
	// references; FinalizeHierarchy appends resolved selector references to
	// these maps alongside the counts. Summable via Merge (concat per key).
	WrapSiteRefs  map[string][]ErrorSiteRef `json:"wrapSiteRefs,omitempty"`
	CheckSiteRefs map[string][]ErrorSiteRef `json:"checkSiteRefs,omitempty"`

	// Qualified (pkg.Sel) reference SITES, keyed "pkg.Sel". TRANSIENT plumbing:
	// recorded during per-file analysis, concatenated by the merger, then
	// resolved by FinalizeHierarchy into WrapSiteRefs / CheckSiteRefs (same
	// qualifier-to-package-dir match as the counts) and cleared. Never
	// meaningful in a finalized hierarchy.
	SelectorWrapSiteRefs  map[string][]ErrorSiteRef `json:"selectorWrapSiteRefs,omitempty"`
	SelectorCheckSiteRefs map[string][]ErrorSiteRef `json:"selectorCheckSiteRefs,omitempty"`

	// Qualified (pkg.Sel) reference COUNTS, keyed "pkg.Sel". TRANSIENT plumbing:
	// recorded during per-file analysis, summed by the merger, then resolved
	// into WrapSitesByError / CheckSitesByError by FinalizeHierarchy (matching
	// the qualifier against the declaring package directory of discovered named
	// errors) and cleared. Never meaningful in a finalized hierarchy.
	SelectorWrapSites  map[string]uint `json:"selectorWrapSites,omitempty"`
	SelectorCheckSites map[string]uint `json:"selectorCheckSites,omitempty"`
}

// TotalCheckSites sums the per-error errors.Is reference counts.

// Merge returns the result of combining this hierarchy metrics with other,
// summing counters, taking the max depth (carrying DeepestError), merging
// WrapCount per key, and tracking the MostWrappedError. This is the single
// canonical aggregation rule used by the analyzer merger.
func (m HierarchyMetrics) Merge(other HierarchyMetrics) HierarchyMetrics {
	result := m
	result.TotalNamedErrors += other.TotalNamedErrors
	result.TotalRelationships += other.TotalRelationships

	if other.MaxDepth > result.MaxDepth {
		result.MaxDepth = other.MaxDepth
		if other.DeepestError != "" {
			result.DeepestError = other.DeepestError
		}
	}

	result.SentinelErrors += other.SentinelErrors
	result.CustomErrorTypes += other.CustomErrorTypes

	if result.WrapCount == nil {
		result.WrapCount = make(map[string]uint, len(other.WrapCount))
	}

	for k, v := range other.WrapCount {
		result.WrapCount[k] += v
	}

	result.InlineWrapSites += other.InlineWrapSites
	result.TypeCheckSites += other.TypeCheckSites

	result.WrapSitesByError = mergeCountMap(result.WrapSitesByError, other.WrapSitesByError)
	result.CheckSitesByError = mergeCountMap(result.CheckSitesByError, other.CheckSitesByError)
	result.SelectorWrapSites = mergeCountMap(result.SelectorWrapSites, other.SelectorWrapSites)
	result.SelectorCheckSites = mergeCountMap(result.SelectorCheckSites, other.SelectorCheckSites)

	result.WrapSiteRefs = mergeSiteRefMap(result.WrapSiteRefs, other.WrapSiteRefs)
	result.CheckSiteRefs = mergeSiteRefMap(result.CheckSiteRefs, other.CheckSiteRefs)
	result.SelectorWrapSiteRefs = mergeSiteRefMap(result.SelectorWrapSiteRefs, other.SelectorWrapSiteRefs)
	result.SelectorCheckSiteRefs = mergeSiteRefMap(result.SelectorCheckSiteRefs, other.SelectorCheckSiteRefs)

	result.MostWrappedError, result.MostWrappedErrorOccurrences = MostWrappedFromCounts(result.WrapCount)

	return result
}

// TotalCheckSites sums the per-error errors.Is reference counts.
func (m HierarchyMetrics) TotalCheckSites() uint {
	var total uint

	for _, count := range m.CheckSitesByError {
		total += count
	}

	return total
}

// mergeCountMap sums the per-key counts of src into dst, initializing dst
// when nil. Shared by HierarchyMetrics.Merge for the reference-site maps.
func mergeCountMap(dst, src map[string]uint) map[string]uint {
	if len(src) == 0 {
		return dst
	}

	if dst == nil {
		dst = make(map[string]uint, len(src))
	}

	for k, v := range src {
		dst[k] += v
	}

	return dst
}

// mergeSiteRefMap appends the per-key ErrorSiteRef slices of src onto dst,
// initializing dst when nil. Concatenation preserves per-file recording
// order; renderers sort before display. Shared by HierarchyMetrics.Merge.
func mergeSiteRefMap(dst, src map[string][]ErrorSiteRef) map[string][]ErrorSiteRef {
	if len(src) == 0 {
		return dst
	}

	if dst == nil {
		dst = make(map[string][]ErrorSiteRef, len(src))
	}

	for k, refs := range src {
		dst[k] = append(dst[k], refs...)
	}

	return dst
}

// MostWrappedFromCounts returns the error name with the highest wrap count
// and that count, breaking ties lexicographically (smallest name wins) for
// deterministic output. Centralizes the MostWrappedError selection so that
// HierarchyMetrics.Merge, HierarchyBuilder.Build, and FinalizeHierarchy all
// agree on tie-breaking — previously each ran a nondeterministic running-max
// whose winner depended on map/slice iteration order.
func MostWrappedFromCounts(wrapCount map[string]uint) (string, uint) {
	names := make([]string, 0, len(wrapCount))
	for n := range wrapCount {
		names = append(names, n)
	}

	slices.Sort(names)

	var mostWrapped string

	var mostWrappedCount uint

	for _, n := range names {
		if wrapCount[n] > mostWrappedCount {
			mostWrapped = n
			mostWrappedCount = wrapCount[n]
		}
	}

	return mostWrapped, mostWrappedCount
}

// Compile-time interface assertions for types defined in this file.
var (
	_ fmt.Stringer             = ErrorType("")
	_ encoding.TextMarshaler   = ErrorType("")
	_ encoding.TextUnmarshaler = (*ErrorType)(nil)
	_ json.Marshaler           = ErrorType("")
	_ json.Unmarshaler         = (*ErrorType)(nil)

	_ fmt.Stringer             = ErrorKind("")
	_ encoding.TextMarshaler   = ErrorKind("")
	_ encoding.TextUnmarshaler = (*ErrorKind)(nil)
	_ json.Marshaler           = ErrorKind("")
	_ json.Unmarshaler         = (*ErrorKind)(nil)

	_ fmt.Stringer             = RelationshipType("")
	_ encoding.TextMarshaler   = RelationshipType("")
	_ encoding.TextUnmarshaler = (*RelationshipType)(nil)
	_ json.Marshaler           = RelationshipType("")
	_ json.Unmarshaler         = (*RelationshipType)(nil)
)

// ContextLossSubtype classifies how a context variable is lost on an error
// return path. Maps to the loss-type taxonomy from the branching-flow tracker.
type ContextLossSubtype string

const (
	// ContextLossImmediate: bare return err drops all context variables.
	// Unrecoverable — the error chain is preserved but all business context is lost.
	ContextLossImmediate ContextLossSubtype = "immediate"

	// ContextLossDelayed: error created/wrapped without including context vars.
	// Recoverable — add the variable to the error message.
	ContextLossDelayed ContextLossSubtype = "delayed_recovery"

	// ContextLossWrapping: fmt.Errorf wrapping without context var inclusion.
	// Recoverable — add the variable to the format string.
	ContextLossWrapping ContextLossSubtype = "wrapping"

	// ContextLossUnwrapped: return err without wrapping, breaking the error chain.
	// Recoverable — wrap with fmt.Errorf("%w", err) or errorfamily.Wrap.
	ContextLossUnwrapped ContextLossSubtype = "unwrapped_return"
)

// ContextLossDetail carries the classification metadata for a context-loss
// violation. Populated on ErrorViolation.ContextLoss when Type ==
// ErrorTypeContextLoss. Allows output formatters and fix engine to render
// subtype-specific suggestions without re-parsing the message.
type ContextLossDetail struct {
	Subtype      ContextLossSubtype `json:"subtype"`
	VariableType string             `json:"variableType,omitempty"` // Go type string (e.g. "string", "int", "UserID")
	Recoverable  bool               `json:"recoverable"`            // Whether the loss can be fixed by including the variable
}
