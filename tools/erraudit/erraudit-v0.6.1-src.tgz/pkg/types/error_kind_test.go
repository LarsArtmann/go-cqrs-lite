package types

import (
	"encoding/json/v2"
	"testing"
)

var sharedErrorKindUnmarshalTestCases = []struct {
	name    string
	data    string
	want    ErrorKind
	wantErr bool
}{
	{"Lowercase: errors.new", "errors.new", ErrorKindNew, false},
	{"Lowercase: fmt.errorf", "fmt.errorf", ErrorKindErrorf, false},
	{"Lowercase: errors.join", "errors.join", ErrorKindJoin, false},
	{"Lowercase: sentinel", "sentinel", ErrorKindSentinel, false},
	{"Lowercase: custom_type", "custom_type", ErrorKindCustom, false},
	{"Lowercase: wrapped", "wrapped", ErrorKindWrap, false},
	{"Uppercase: ERRORS.NEW", "ERRORS.NEW", ErrorKindNew, false},
	{"Uppercase: FMT.ERRORF", "FMT.ERRORF", ErrorKindErrorf, false},
	{"Uppercase: ERRORS.JOIN", "ERRORS.JOIN", ErrorKindJoin, false},
	{"Uppercase: SENTINEL", "SENTINEL", ErrorKindSentinel, false},
	{"Uppercase: CUSTOM_TYPE", "CUSTOM_TYPE", ErrorKindCustom, false},
	{"Uppercase: WRAPPED", "WRAPPED", ErrorKindWrap, false},
	{"Mixed case: errors.new", "errors.new", ErrorKindNew, false},
	{"Mixed case: fmt.errorf", "fmt.errorf", ErrorKindErrorf, false},
	{"Mixed case: Errors.Join", "Errors.Join", ErrorKindJoin, false},
	{"Mixed case: Sentinel", "Sentinel", ErrorKindSentinel, false},
	{"Mixed case: Custom_Type", "Custom_Type", ErrorKindCustom, false},
	{"Mixed case: Wrapped", "Wrapped", ErrorKindWrap, false},
	{"Invalid: unknown", "unknown", ErrorKind(""), true},
	{"Invalid: empty", "", ErrorKind(""), true},
}

var sharedErrorKindMarshalTestCases = []struct {
	name string
	kind ErrorKind
}{
	{"errors.new", ErrorKindNew},
	{"fmt.errorf", ErrorKindErrorf},
	{"errors.join", ErrorKindJoin},
	{"sentinel", ErrorKindSentinel},
	{"custom_type", ErrorKindCustom},
	{"wrapped", ErrorKindWrap},
}

// errorKindTestCaseAdapter adapts sharedErrorKindUnmarshalTestCases for UnmarshalTextTestCaseGetter.
type errorKindTestCaseAdapter struct {
	name    string
	data    string
	want    ErrorKind
	wantErr bool
}

func (a errorKindTestCaseAdapter) GetName() string  { return a.name }
func (a errorKindTestCaseAdapter) GetInput() string { return a.data }
func (a errorKindTestCaseAdapter) GetWant() string  { return string(a.want) }
func (a errorKindTestCaseAdapter) GetWantErr() bool { return a.wantErr }

// unmarshalTestCasesJSON generates test cases for JSON unmarshaling.
func unmarshalTestCasesJSONErrorKind() []JSONUnmarshalTestCase[ErrorKind] {
	tests := make([]JSONUnmarshalTestCase[ErrorKind], len(sharedErrorKindUnmarshalTestCases))
	for i, tc := range sharedErrorKindUnmarshalTestCases {
		tests[i] = JSONUnmarshalTestCase[ErrorKind]{
			Name:    tc.name,
			Input:   tc.data,
			Got:     ErrorKind(""),
			Want:    tc.want,
			WantErr: tc.wantErr,
		}
	}

	return tests
}

func TestErrorKind_IsValid(t *testing.T) {
	tests := []struct {
		name string
		obj  ErrorKind
		want bool
	}{
		{"Valid: errors.new", ErrorKindNew, true},
		{"Valid: fmt.errorf", ErrorKindErrorf, true},
		{"Valid: errors.join", ErrorKindJoin, true},
		{"Valid: sentinel", ErrorKindSentinel, true},
		{"Valid: custom_type", ErrorKindCustom, true},
		{"Valid: wrapped", ErrorKindWrap, true},
		{"Invalid: unknown", ErrorKind("unknown"), false},
		{"Invalid: empty", ErrorKind(""), false},
	}

	runIsValidTests(t, "ErrorKind", tests, func(e ErrorKind) bool { return e.IsValid() })
}

func TestParseErrorKind(t *testing.T) {
	tests := []struct {
		name    string
		input   string
		want    ErrorKind
		wantErr bool
	}{
		{"Valid: errors.new", "errors.new", ErrorKindNew, false},
		{"Valid: fmt.errorf", "fmt.errorf", ErrorKindErrorf, false},
		{"Valid: errors.join", "errors.join", ErrorKindJoin, false},
		{"Valid: sentinel", "sentinel", ErrorKindSentinel, false},
		{"Valid: custom_type", "custom_type", ErrorKindCustom, false},
		{"Valid: wrapped", "wrapped", ErrorKindWrap, false},
		{"Invalid: unknown", "unknown", ErrorKind(""), true},
		{"Invalid: empty", "", ErrorKind(""), true},
	}

	runParseTests(t, "ErrorKind", tests, ParseErrorKind)
}

func TestErrorKind_MarshalJSON(t *testing.T) {
	tests := make([]JSONMarshalTestCase[ErrorKind], len(sharedErrorKindMarshalTestCases))
	for i, tc := range sharedErrorKindMarshalTestCases {
		tests[i] = JSONMarshalTestCase[ErrorKind]{
			Name:    tc.name,
			Value:   tc.kind,
			Want:    `"` + tc.name + `"`,
			WantErr: false,
		}
	}

	runMarshalTests(t, "ErrorKind", "MarshalJSON", tests, ErrorKind.MarshalJSON)
}

func TestErrorKind_UnmarshalJSON(t *testing.T) {
	tests := unmarshalTestCasesJSONErrorKind()

	runJSONUnmarshalTests(
		t, "ErrorKind", tests,
		func(data []byte, ek *ErrorKind) error { return json.Unmarshal(data, ek) },
		QuoteString,
	)
}

func TestErrorKind_MarshalText(t *testing.T) {
	tests := ConvertToMarshalTextTestCases(sharedErrorKindMarshalTestCases, func(tc struct {
		name string
		kind ErrorKind
	},
	) MarshalTextTestCase[ErrorKind] {
		return MarshalTextTestCase[ErrorKind]{
			Name:    tc.name,
			Value:   tc.kind,
			Want:    tc.name,
			WantErr: false,
		}
	})

	runMarshalTests(t, "ErrorKind", "MarshalText", tests, ErrorKind.MarshalText)
}

func TestErrorKind_UnmarshalText(t *testing.T) {
	tests := sharedErrorKindUnmarshalTestCases

	adapterTests := make([]UnmarshalTextTestCaseGetter, len(tests))
	for i, tc := range tests {
		adapterTests[i] = errorKindTestCaseAdapter{
			name:    tc.name,
			data:    tc.data,
			want:    tc.want,
			wantErr: tc.wantErr,
		}
	}

	runUnmarshalTextGetterTests(t, adapterTests, func(input []byte) error {
		var got ErrorKind

		return got.UnmarshalText(input)
	})
}

func TestErrorKind_RoundTrip(t *testing.T) {
	validKinds := []ErrorKind{
		ErrorKindNew,
		ErrorKindErrorf,
		ErrorKindJoin,
		ErrorKindSentinel,
		ErrorKindCustom,
		ErrorKindWrap,
	}

	for _, tt := range validKinds {
		t.Run(string(tt), func(t *testing.T) {
			// JSON round-trip
			jsonData, err := json.Marshal(tt)
			if err != nil {
				t.Fatalf("MarshalJSON() error = %v", err)
			}

			var unmarshaled ErrorKind
			if err := json.Unmarshal(jsonData, &unmarshaled); err != nil {
				t.Fatalf("UnmarshalJSON() error = %v", err)
			}

			if unmarshaled != tt {
				t.Errorf("JSON round-trip: got %v, want %v", unmarshaled, tt)
			}

			// Text round-trip
			textData, err := tt.MarshalText()
			if err != nil {
				t.Fatalf("MarshalText() error = %v", err)
			}

			var textUnmarshaled ErrorKind
			if err := textUnmarshaled.UnmarshalText(textData); err != nil {
				t.Fatalf("UnmarshalText() error = %v", err)
			}

			if textUnmarshaled != tt {
				t.Errorf("Text round-trip: got %v, want %v", textUnmarshaled, tt)
			}
		})
	}
}

func TestErrorKind_PointerSemantics(t *testing.T) {
	validVal := ErrorKindNew
	_ = validVal
	// Test with pointer to valid value
	validPtr := &validVal
	if !validPtr.IsValid() {
		t.Error("Pointer to valid ErrorKind should be valid")
	}
	// Test with pointer to invalid value
	invalidVal := ErrorKind("invalid")

	invalidPtr := &invalidVal
	if invalidPtr.IsValid() {
		t.Error("Pointer to invalid ErrorKind should be invalid")
	}
}

func TestErrorKind_ZeroValue(t *testing.T) {
	var zero ErrorKind
	if zero.IsValid() {
		t.Error("Zero value should be invalid")
	}
}

func TestErrorKind_ErrorMessage(t *testing.T) {
	runEnumTypeErrorMessageTests[ErrorKind](t, "ErrorKind")
}
