package types

import (
	"encoding/json/v2"
	"fmt"
	"math"

	apierrors "github.com/larsartmann/erraudit/pkg/errors"
)

// Confidence represents a confidence score in the range [0.0, 1.0].
// Use NewConfidence to construct; the zero value is valid and represents 0.0.
//

type Confidence float64

const (
	ConfidenceNone Confidence = 0.0
	ConfidenceLow  Confidence = 0.5
	ConfidenceHigh Confidence = 0.95
)

// NewConfidence creates a Confidence from a float64.
// Panics if the value is NaN, negative, or greater than 1.0.
func NewConfidence(value float64) Confidence {
	if math.IsNaN(value) {
		panic("confidence must not be NaN")
	}

	if value < 0.0 {
		panic(fmt.Sprintf("confidence must be >= 0.0, got %f", value))
	}

	if value > 1.0 {
		panic(fmt.Sprintf("confidence must be <= 1.0, got %f", value))
	}

	return Confidence(value)
}

// Float returns the underlying float64 value.
func (c Confidence) Float() float64 {
	return float64(c)
}

// IsValid checks if the confidence is in the valid range [0.0, 1.0].
func (c Confidence) IsValid() bool {
	val := float64(c)

	return !math.IsNaN(val) && !math.IsInf(val, 0) && val >= 0.0 && val <= 1.0
}

// MarshalJSON implements json.Marshaler for Confidence.
func (c Confidence) MarshalJSON() ([]byte, error) {
	//nolint:wrapcheck // json.Marshal on float64 cannot fail
	return json.Marshal(float64(c))
}

// ErrConfidenceOutOfRange is returned when a confidence value is outside [0.0, 1.0].
var ErrConfidenceOutOfRange = apierrors.New("confidence value is outside valid range [0.0, 1.0]")

// UnmarshalJSON implements json.Unmarshaler for Confidence.
func (c *Confidence) UnmarshalJSON(data []byte) error {
	var value float64

	err := json.Unmarshal(data, &value)
	if err != nil {
		return apierrors.Wrap(err, "unmarshal confidence from %q", string(data))
	}

	result := Confidence(value)
	if !result.IsValid() {
		return apierrors.Wrap(ErrConfidenceOutOfRange, "got %f", value)
	}

	*c = result

	return nil
}
