package types

import (
	"go/token"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// TestErrorMetricsMerge is the regression guard for SPLIT-BRAIN finding #8:
// the combination rule for ErrorMetrics must live on the type itself so that
// adding a new field only requires updating it here, not in the analyzer merger.
func TestErrorMetricsMerge(t *testing.T) {
	a := ErrorMetrics{
		TotalErrors:    5,
		WrapDepth:      3,
		ErrorReturns:   10,
		ErrorWraps:     2,
		SilentSwallows: 1,
		PanicsOnErrors: 4,
		IgnoredErrors:  6,
		MostCommonErrors: map[string]uint{
			"errFoo": 3,
			"errBar": 1,
		},
	}

	b := ErrorMetrics{
		TotalErrors:    7,
		WrapDepth:      9, // max wins
		ErrorReturns:   20,
		ErrorWraps:     5,
		SilentSwallows: 2,
		PanicsOnErrors: 0,
		IgnoredErrors:  1,
		MostCommonErrors: map[string]uint{
			"errFoo": 2,
			"errBaz": 4,
		},
	}

	merged := a.Merge(b)

	assert.Equal(t, uint(12), merged.TotalErrors, "TotalErrors must sum")
	assert.Equal(t, uint(9), merged.WrapDepth, "WrapDepth must take max")
	assert.Equal(t, uint(30), merged.ErrorReturns, "ErrorReturns must sum")
	assert.Equal(t, uint(7), merged.ErrorWraps, "ErrorWraps must sum")
	assert.Equal(t, uint(3), merged.SilentSwallows, "SilentSwallows must sum")
	assert.Equal(t, uint(4), merged.PanicsOnErrors, "PanicsOnErrors must sum")
	assert.Equal(t, uint(7), merged.IgnoredErrors, "IgnoredErrors must sum")

	assert.Equal(t, uint(5), merged.MostCommonErrors["errFoo"], "errFoo must sum across both")
	assert.Equal(t, uint(1), merged.MostCommonErrors["errBar"], "errBar preserved from a")
	assert.Equal(t, uint(4), merged.MostCommonErrors["errBaz"], "errBaz preserved from b")

	// Merging into a zero-value must not panic on nil map.
	var zero ErrorMetrics
	zeroMerged := zero.Merge(b)
	assert.Equal(t, uint(7), zeroMerged.TotalErrors)
	assert.Equal(t, uint(2), zeroMerged.MostCommonErrors["errFoo"])
}

// TestHierarchyMetricsMerge is the regression guard for SPLIT-BRAIN finding #8:
// the combination rule for HierarchyMetrics must live on the type itself.
func TestHierarchyMetricsMerge(t *testing.T) {
	a := HierarchyMetrics{
		TotalNamedErrors:   5,
		TotalRelationships: 3,
		MaxDepth:           2,
		DeepestError:       "errShallow",
		SentinelErrors:     4,
		CustomErrorTypes:   1,
		WrapCount: map[string]uint{
			"errA": 3,
			"errB": 1,
		},
		MostWrappedError:            "errA",
		MostWrappedErrorOccurrences: 3,
		InlineWrapSites:             7,
		WrapSitesByError:            map[string]uint{"errA": 2},
		CheckSitesByError:           map[string]uint{"errA": 1},
		TypeCheckSites:              5,
		SelectorWrapSites:           map[string]uint{"pkg.errA": 4},
	}

	b := HierarchyMetrics{
		TotalNamedErrors:   8,
		TotalRelationships: 6,
		MaxDepth:           7, // max wins, carries DeepestError
		DeepestError:       "errDeep",
		SentinelErrors:     2,
		CustomErrorTypes:   3,
		WrapCount: map[string]uint{
			"errA": 1, // total 4, still most wrapped
			"errC": 9, // becomes most wrapped
		},
		InlineWrapSites:    3,
		WrapSitesByError:   map[string]uint{"errC": 5},
		CheckSitesByError:  map[string]uint{"errA": 6},
		TypeCheckSites:     4,
		SelectorCheckSites: map[string]uint{"pkg.errA": 2},
	}

	merged := a.Merge(b)

	assert.Equal(t, uint(13), merged.TotalNamedErrors, "TotalNamedErrors must sum")
	assert.Equal(t, uint(9), merged.TotalRelationships, "TotalRelationships must sum")
	assert.Equal(t, uint(7), merged.MaxDepth, "MaxDepth must take max")
	assert.Equal(t, "errDeep", merged.DeepestError, "DeepestError must carry from the deeper side")
	assert.Equal(t, uint(6), merged.SentinelErrors, "SentinelErrors must sum")
	assert.Equal(t, uint(4), merged.CustomErrorTypes, "CustomErrorTypes must sum")

	assert.Equal(t, uint(4), merged.WrapCount["errA"], "errA must sum")
	assert.Equal(t, uint(1), merged.WrapCount["errB"], "errB preserved from a")
	assert.Equal(t, uint(9), merged.WrapCount["errC"], "errC preserved from b")
	assert.Equal(t, "errC", merged.MostWrappedError, "MostWrappedError must track the new leader")
	assert.Equal(
		t,
		uint(9),
		merged.MostWrappedErrorOccurrences,
		"MostWrappedErrorOccurrences must track the new leader",
	)

	assert.Equal(t, uint(10), merged.InlineWrapSites, "InlineWrapSites must sum")
	assert.Equal(t, uint(9), merged.TypeCheckSites, "TypeCheckSites must sum")
	assert.Equal(t, uint(2), merged.WrapSitesByError["errA"], "WrapSitesByError must merge per key")
	assert.Equal(t, uint(5), merged.WrapSitesByError["errC"], "WrapSitesByError preserved from b")
	assert.Equal(t, uint(7), merged.CheckSitesByError["errA"], "CheckSitesByError must sum per key")
	assert.Equal(t, uint(4), merged.SelectorWrapSites["pkg.errA"], "SelectorWrapSites must merge per key")
	assert.Equal(t, uint(2), merged.SelectorCheckSites["pkg.errA"], "SelectorCheckSites must merge per key")
	assert.Equal(t, uint(7), merged.TotalCheckSites(), "TotalCheckSites must sum the per-error counts")

	// Merging into a zero-value must not panic on nil map.
	var zero HierarchyMetrics
	zeroMerged := zero.Merge(b)
	assert.Equal(t, uint(8), zeroMerged.TotalNamedErrors)
	assert.Equal(t, "errC", zeroMerged.MostWrappedError)
	assert.Equal(t, uint(5), zeroMerged.WrapSitesByError["errC"], "nil maps must be initialized on merge")
	assert.Equal(t, uint(2), zeroMerged.SelectorCheckSites["pkg.errA"])
}

// TestMostWrappedFromCounts_TieBreakIsLexicographic is the regression guard for
// the MostWrappedError determinism bug: a running-max over map iteration order
// made the winner depend on which key Go visited first. Ties must now break to
// the lexicographically smallest name, deterministically.
func TestMostWrappedFromCounts_TieBreakIsLexicographic(t *testing.T) {
	counts := map[string]uint{
		"ZebraError": 5,
		"AlphaError": 5,
		"MidError":   3,
	}
	name, count := MostWrappedFromCounts(counts)
	assert.Equal(t, "AlphaError", name, "ties must break to the smallest name")
	assert.Equal(t, uint(5), count)
}

// TestHierarchyMetricsMergeSiteRefs pins the detail-map aggregation: wrap
// and check site refs concat per key in merge order (a's refs first), and
// the transient selector ref maps merge the same way as their counts.
func TestHierarchyMetricsMergeSiteRefs(t *testing.T) {
	a := HierarchyMetrics{
		WrapSiteRefs: map[string][]ErrorSiteRef{
			"errA": {{Position: token.Position{Filename: "a.go", Line: 1}, Function: "fa"}},
		},
		SelectorWrapSiteRefs: map[string][]ErrorSiteRef{
			"pkg.errA": {{Position: token.Position{Filename: "s1.go", Line: 5}}},
		},
	}

	b := HierarchyMetrics{
		WrapSiteRefs: map[string][]ErrorSiteRef{
			"errA": {{Position: token.Position{Filename: "b.go", Line: 2}, Function: "fb"}},
		},
		CheckSiteRefs: map[string][]ErrorSiteRef{
			"errA": {{Position: token.Position{Filename: "b.go", Line: 3}}},
		},
		SelectorCheckSiteRefs: map[string][]ErrorSiteRef{
			"pkg.errA": {{Position: token.Position{Filename: "s2.go", Line: 6}}},
		},
	}

	merged := a.Merge(b)

	wraps := merged.WrapSiteRefs["errA"]
	require.Len(t, wraps, 2, "wrap site refs must concat per key")
	assert.Equal(t, "a.go", wraps[0].Position.Filename, "a's refs come first")
	assert.Equal(t, "b.go", wraps[1].Position.Filename, "b's refs appended")

	checks := merged.CheckSiteRefs["errA"]
	require.Len(t, checks, 1)
	assert.Equal(t, "b.go", checks[0].Position.Filename)

	selWraps := merged.SelectorWrapSiteRefs["pkg.errA"]
	require.Len(t, selWraps, 1)
	assert.Equal(t, "s1.go", selWraps[0].Position.Filename)

	selChecks := merged.SelectorCheckSiteRefs["pkg.errA"]
	require.Len(t, selChecks, 1)
	assert.Equal(t, "s2.go", selChecks[0].Position.Filename)
}
