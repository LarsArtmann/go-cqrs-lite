package types

import (
	"go/token"
	"testing"
)

func FuzzKey(f *testing.F) {
	f.Add("main.go", "panic", 1, 1)
	f.Add("", "", 0, 0)
	f.Add("file.go", "ignored", 999, 0)

	f.Fuzz(func(t *testing.T, file string, vtype string, line, col int) {
		v := ErrorViolation{
			Type: ErrorType(vtype),
			Position: token.Position{
				Filename: file,
				Line:     line,
				Column:   col,
			},
		}
		_ = v.Key()
		// Test passes if no panic
	})
}
