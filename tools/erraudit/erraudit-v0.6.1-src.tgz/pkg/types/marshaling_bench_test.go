package types

import (
	"encoding/json/v2"
	"testing"
)

var (
	severityValues = []Severity{SeverityHigh, SeverityMedium, SeverityLow}
	severityJSON   = []string{`"critical"`, `"error"`, `"warning"`}
)

func BenchmarkSeverity_MarshalJSON(b *testing.B) {
	b.ReportAllocs()
	for b.Loop() {
		for _, s := range severityValues {
			data, _ := json.Marshal(s)
			_ = data
		}
	}
}

func BenchmarkSeverity_UnmarshalJSON(b *testing.B) {
	b.ReportAllocs()
	for b.Loop() {
		for _, raw := range severityJSON {
			var s Severity
			_ = json.Unmarshal([]byte(raw), &s)
		}
	}
}

func BenchmarkSeverity_TextRoundTrip(b *testing.B) {
	b.ReportAllocs()
	for b.Loop() {
		for _, s := range severityValues {
			text, _ := s.MarshalText()
			var out Severity
			_ = out.UnmarshalText(text)
		}
	}
}

var errorTypeValues = []ErrorType{
	ErrorTypeReturn,
	ErrorTypeAssignment,
	ErrorTypeWrapping,
	ErrorTypeSilentSwallow,
	ErrorTypeContextLoss,
	ErrorTypeStdlibConstructor,
}

var errorTypeJSON = []string{
	`"error_return"`,
	`"error_assignment"`,
	`"error_wrapping"`,
	`"silent_swallow"`,
	`"context_loss"`,
	`"stdlib_constructor"`,
}

func BenchmarkErrorType_MarshalJSON(b *testing.B) {
	b.ReportAllocs()
	for b.Loop() {
		for _, t := range errorTypeValues {
			data, _ := json.Marshal(t)
			_ = data
		}
	}
}

func BenchmarkErrorType_UnmarshalJSON(b *testing.B) {
	b.ReportAllocs()
	for b.Loop() {
		for _, raw := range errorTypeJSON {
			var t ErrorType
			_ = json.Unmarshal([]byte(raw), &t)
		}
	}
}

func BenchmarkErrorType_TextRoundTrip(b *testing.B) {
	b.ReportAllocs()
	for b.Loop() {
		for _, t := range errorTypeValues {
			text, _ := t.MarshalText()
			var out ErrorType
			_ = out.UnmarshalText(text)
		}
	}
}

var confidenceValues = []Confidence{ConfidenceNone, ConfidenceLow, ConfidenceHigh}

func BenchmarkConfidence_MarshalJSON(b *testing.B) {
	b.ReportAllocs()
	for b.Loop() {
		for _, c := range confidenceValues {
			data, _ := json.Marshal(c)
			_ = data
		}
	}
}

func BenchmarkConfidence_UnmarshalJSON(b *testing.B) {
	b.ReportAllocs()
	for b.Loop() {
		for _, c := range confidenceValues {
			data, _ := json.Marshal(c)
			var out Confidence
			_ = json.Unmarshal(data, &out)
		}
	}
}
