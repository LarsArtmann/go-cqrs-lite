package types

import (
	"encoding/json/v2"
	"strings"

	"github.com/larsartmann/erraudit/pkg/errors"
)

// parseTextUnmarshaler is a generic helper for implementing encoding.TextUnmarshaler.
// It handles the common pattern of:
//   - Converting input to lowercase
//   - Validating against a predicate function
//   - Returning a descriptive error message
//
// Usage:
//
//	func (t *MyType) UnmarshalText(data []byte) error {
//		parsed, err := parseTextUnmarshaler(data, "MyType", MyType.IsValid)
//		if err != nil {
//			return err
//		}
//		*t = parsed
//		return nil
//	}
func parseTextUnmarshaler[T ~string](
	data []byte,
	typeName string,
	isValid func(T) bool,
) (T, error) {
	parsed := T(strings.ToLower(string(data)))
	if !isValid(parsed) {
		return "", errors.Wrap(
			errors.ErrValueInvalid,
			"invalid %s: %q is not a valid value",
			typeName,
			string(data),
		)
	}

	return parsed, nil
}

// unmarshalTextAssign is a generic helper that parses text and assigns it to the target.
// Combines parseTextUnmarshaler with assignment for cleaner UnmarshalText implementations.
//
// Note: the signature intentionally mirrors unmarshalJSONAssign below; the bodies
// diverge because TextUnmarshaler and JSONUnmarshaler parse from different wire
// formats (UTF-8 text vs JSON string). Unifying them would require a parser
// parameter that is more complex than the duplication it would remove.
func unmarshalTextAssign[T ~string](
	data []byte,
	typeName string,
	isValid func(T) bool,
	target *T,
) error {
	parsed, parseErr := parseTextUnmarshaler(data, typeName, isValid)
	if parseErr != nil {
		return errors.Wrap(parseErr, "failed to parse %s from text %q", typeName, string(data))
	}

	return validateAndAssign(parsed, typeName, isValid, target)
}

// unmarshalJSONAssign is a generic helper for implementing json.Unmarshaler.
// It handles the common pattern of:
//   - Unmarshaling JSON string data
//   - Converting to lowercase
//   - Validating against a predicate function
//   - Assigning to target pointer
//
// Usage:
//
//	func (t *MyType) UnmarshalJSON(data []byte) error {
//		return unmarshalJSONAssign(data, "MyType", MyType.IsValid, t)
//	}
func unmarshalJSONAssign[T ~string](
	data []byte,
	typeName string,
	isValid func(T) bool,
	target *T,
) error {
	var str string

	jsonErr := json.Unmarshal(data, &str)
	if jsonErr != nil {
		return errors.Wrap(
			jsonErr,
			"failed to unmarshal JSON for %s from %q",
			typeName,
			string(data),
		)
	}

	return validateAndAssign(T(strings.ToLower(str)), typeName, isValid, target)
}

// validateAndAssign validates a parsed value and assigns it to target.
func validateAndAssign[T ~string](
	parsed T,
	typeName string,
	isValid func(T) bool,
	target *T,
) error {
	if !isValid(parsed) {
		return errors.Wrap(
			errors.ErrValueInvalid,
			"invalid %s: %q is not a valid value",
			typeName,
			parsed,
		)
	}

	*target = parsed

	return nil
}
