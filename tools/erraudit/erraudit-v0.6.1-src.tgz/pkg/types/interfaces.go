package types

import (
	"go/ast"
)

// ViolationDetector defines the interface for detecting error handling violations.
// Implementations: internal/ast.ViolationDetector.
type ViolationDetector interface {
	// DetectViolationsInFunction analyzes a function for error violations
	DetectViolationsInFunction(fn *ast.FuncDecl)

	// DetectViolationsInReturnStmt analyzes return statements for violations
	DetectViolationsInReturnStmt(ret *ast.ReturnStmt)

	// AddCodeSnippetsToViolations adds code snippets to all violations
	AddCodeSnippetsToViolations()
}

// NamedErrorDiscoverer defines the interface for discovering named errors.
// Implementations: internal/ast.NamedErrorDiscoverer.
type NamedErrorDiscoverer interface {
	// DiscoverNamedErrors discovers all named error variables in a declaration
	DiscoverNamedErrors(decl *ast.GenDecl)
}

// RelationshipTracker defines the interface for tracking error relationships.
// Implementations: internal/ast.RelationshipTracker.
type RelationshipTracker interface {
	// GetRelationshipDepth calculates the depth of an error in the hierarchy
	GetRelationshipDepth(errorName string) uint

	// HasCyclicDependency checks if adding a relationship would create a cycle
	HasCyclicDependency(parent, child string, existingRelationships []ErrorRelationship) bool

	// GetErrorChain returns the complete chain from root to the error
	GetErrorChain(errorName string) []string

	// GetRootErrors returns all root errors (those without parents)
	GetRootErrors() []string

	// RemoveCyclicRelationships drops relationships that would create cycles
	RemoveCyclicRelationships()

	// ConsolidateDuplicateRelationships removes duplicate parent→child pairs
	ConsolidateDuplicateRelationships()
}

// Analyzer defines the interface for the main analyzer.
// Implementations: internal/ast.Analyzer.
type Analyzer interface {
	// Analyze runs the analysis on the given AST node
	Analyze(node ast.Node) *ErrorGraph
}

// HierarchyBuilder defines the interface for building error hierarchies.
// Implementations: internal/ast.HierarchyBuilder.
type HierarchyBuilder interface {
	// Build constructs the error hierarchy
	Build() *ErrorHierarchy
}

// MetricsCalculator defines the interface for calculating metrics.
// Implementations: internal/ast.MetricsCalculator.
type MetricsCalculator interface {
	// Calculate computes the error metrics
	Calculate() ErrorMetrics
}
