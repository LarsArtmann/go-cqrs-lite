package types

import (
	"encoding/json/v2"
	"fmt"
	"strings"
	"testing"

	apierrors "github.com/larsartmann/erraudit/pkg/errors"
)

const (
	testInvalid       = "invalid"
	testInvalidQuoted = `"invalid"`
)

// ErrorMessageTestCase represents a test case for error message validation.
type ErrorMessageTestCase struct {
	Name           string
	Input          string
	ExpectedSubstr string
}

// UnmarshalTextTestCase represents a test case for UnmarshalText validation.
type UnmarshalTextTestCase struct {
	Name    string
	Input   string
	Want    string
	WantErr bool
}

// JSONUnmarshalTestCase represents a test case for JSON unmarshal validation.
type JSONUnmarshalTestCase[T any] struct {
	Name    string
	Input   string
	Got     T
	Want    T
	WantErr bool
}

// QuoteString wraps a string in quotes, useful for JSON string representation.
// This helper function eliminates duplicate code in test cases that need
// JSON-formatted string values.
func QuoteString(input string) string {
	return `"` + input + `"`
}

// ErrorMessageTestCases creates standardized error message test cases for enumerated types.
// This eliminates duplicate code by parameterizing the type-specific strings.
// The typeName should be lowercase (e.g., "severity", "error action").
// The typeNameDisplay should be the proper case version (e.g., "Severity", "ErrorAction").
func ErrorMessageTestCases(typeName, typeNameDisplay string) []ErrorMessageTestCase {
	return []ErrorMessageTestCase{
		{
			Name:           fmt.Sprintf("Parse%s error message", typeNameDisplay),
			Input:          testInvalid,
			ExpectedSubstr: "invalid " + typeName,
		},
		{
			Name:           "UnmarshalJSON error message",
			Input:          testInvalidQuoted,
			ExpectedSubstr: "invalid " + typeNameDisplay,
		},
		{
			Name:           "UnmarshalText error message",
			Input:          testInvalid,
			ExpectedSubstr: "invalid " + typeNameDisplay,
		},
	}
}

// checkUnmarshalError checks if the unmarshal error matches the expected error status.
// This helper eliminates duplicate error checking code across different unmarshal test functions.
func checkUnmarshalError(t *testing.T, typeName, methodName string, err error, wantErr bool) bool {
	t.Helper()

	if (err != nil) != wantErr {
		t.Errorf("%s.%s() error = %v, wantErr %v", typeName, methodName, err, wantErr)

		return true
	}

	return false
}

// checkErrorMessageContains checks if the error message contains the expected substring.
// This helper eliminates duplicate error message checking code across test functions.
// Returns true if the check passes (error contains substring), false otherwise.
func checkErrorMessageContains(t *testing.T, err error, expectedSubstr string) bool {
	t.Helper()

	if err == nil {
		return true
	}

	errStr := err.Error()
	if !strings.Contains(errStr, expectedSubstr) {
		t.Errorf("Error = %v, expected substring %q", err, expectedSubstr)

		return false
	}

	return true
}

// runJSONUnmarshalTests runs a parameterized JSON Unmarshal test loop.
// This eliminates duplicate code by parameterizing the type-specific logic.
// The inputFn allows transforming raw test data to JSON format (e.g., adding quotes).
func runJSONUnmarshalTests[T comparable](
	t *testing.T,
	typeName string,
	tests []JSONUnmarshalTestCase[T],
	unmarshalFn func([]byte, *T) error,
	inputFn func(string) string,
) {
	const methodName = "UnmarshalJSON"

	for _, testCase := range tests {
		t.Run(testCase.Name, func(t *testing.T) {
			jsonInput := []byte(inputFn(testCase.Input))

			err := unmarshalFn(jsonInput, &testCase.Got)
			if checkUnmarshalError(t, typeName, methodName, err, testCase.WantErr) {
				return
			}

			if !testCase.WantErr && testCase.Got != testCase.Want {
				t.Errorf("%s.%s() = %v, want %v", typeName, methodName, testCase.Got, testCase.Want)
			}
		})
	}
}

// UnmarshalResult holds the result of an unmarshal operation.
type UnmarshalResult struct {
	Value string
	Error error
}

// UnmarshalerTester provides generic methods for testing unmarshal error messages.
// This eliminates duplicate code by parameterizing the type-specific logic.
type UnmarshalerTester[T any] struct{}

// testUnmarshalErrorMessages is the internal implementation for testing unmarshal error messages.
// This eliminates duplicate code by parameterizing the method name.
func (u *UnmarshalerTester[T]) testUnmarshalErrorMessages(
	t *testing.T,
	methodName string,
	tests []ErrorMessageTestCase,
	newT func() *T,
	unmarshalFn func(*T, []byte) error,
) {
	t.Helper()
	runUnmarshalErrorMessageLoop(
		t,
		"T",
		methodName,
		tests,
		func(tc ErrorMessageTestCase) error {
			instance := newT()

			return unmarshalFn(instance, []byte(tc.Input))
		},
	)
}

// runUnmarshalErrorMessageTests tests that error messages are produced correctly
// when the named unmarshal method fails. This is a generic implementation that eliminates
// duplicate code across ErrorActionTester, SeverityTester, etc.
func (u *UnmarshalerTester[T]) runUnmarshalErrorMessageTests(
	test *testing.T,
	methodName string,
	tests []ErrorMessageTestCase,
	newT func() *T,
	unmarshalFn func(*T, []byte) error,
) {
	u.testUnmarshalErrorMessages(test, methodName, tests, newT, unmarshalFn)
}

// runParseErrorMessageTests tests that error messages are produced correctly
// when Parse function fails. This is a generic implementation that eliminates
// duplicate code across different enum types.
func (u *UnmarshalerTester[T]) runParseErrorMessageTests(
	test *testing.T,
	typeName string,
	tests []ErrorMessageTestCase,
	parseFn func(string) error,
) {
	runParseErrorMessageTests(test, typeName, tests, parseFn)
}

// runAllErrorMessageTests is a convenience method that tests all error message patterns
// for Parse, UnmarshalJSON, and UnmarshalText in one call. This eliminates duplicate
// code by combining three separate test calls into a single method.
// The typeName should be lowercase (e.g., "severity", "error action").
// The typeNameDisplay should be the proper case version (e.g., "Severity", "ErrorAction").
func (u *UnmarshalerTester[T]) runAllErrorMessageTests(
	test *testing.T,
	typeName string,
	typeNameDisplay string,
	parseFn func(string) error,
	unmarshalJSONFn func(*T, []byte) error,
	unmarshalTextFn func(*T, []byte) error,
) {
	tests := ErrorMessageTestCases(typeName, typeNameDisplay)

	u.runParseErrorMessageTests(test, typeNameDisplay, tests[:1], parseFn)
	u.runUnmarshalErrorMessageTests(test, "UnmarshalJSON", tests[1:2], func() *T {
		var instance T

		return &instance
	}, unmarshalJSONFn)
	u.runUnmarshalErrorMessageTests(test, "UnmarshalText", tests[2:], func() *T {
		var instance T

		return &instance
	}, unmarshalTextFn)
}

// runPointerSemanticsTests tests pointer unmarshaling semantics for an enumerated type.
// This is a standalone helper function that eliminates duplicate test code across types.
func runPointerSemanticsTests[T comparable](
	t *testing.T,
	typeName string,
	value T,
	unmarshalFn func([]byte, *T) error,
) {
	copied := value
	ptr := &copied

	err := unmarshalFn(fmt.Appendf(nil, "%v", value), ptr)
	if err != nil {
		t.Errorf("%s.UnmarshalText() on pointer failed: %v", typeName, err)
	}
}

// MarshalJSONHelper is a generic helper for JSON marshaling that wraps json.Marshal.
// This eliminates the need for duplicate lambda functions like:
//
//	func(e ErrorType) ([]byte, error) { return json.Marshal(e) }
func MarshalJSONHelper[T any](value T) ([]byte, error) {
	b, err := json.Marshal(value)
	if err != nil {
		return nil, fmt.Errorf("failed to marshal value of type %T: %w", value, err)
	}

	return b, nil
}

// UnmarshalJSONHelper is a generic helper for JSON unmarshaling that wraps json.Unmarshal.
// This eliminates the need for duplicate lambda functions like:
//
//	func(e *ErrorType, data []byte) error { return json.Unmarshal(data, e) }
func UnmarshalJSONHelper[T any](target *T, data []byte) error {
	//nolint:wrapcheck // json.Unmarshal with proper error handling at call site
	return json.Unmarshal(data, target)
}

// runAllValidMarshalersTests is a simplified version of TestAllValidMarshalers that accepts
// method values directly. This eliminates the need for lambda functions at each call site.
// Usage:
//
//	runAllValidMarshalersTests(t, "Severity", severities,
//	    Severity.IsValid,
//	    MarshalJSONHelper[Severity],
//	    (*Severity).UnmarshalJSON,
//	    Severity.MarshalText,
//	    (*Severity).UnmarshalText,
//	)
func runAllValidMarshalersTests[T comparable](
	t *testing.T,
	typeName string,
	values []T,
	isValidFn func(T) bool,
	marshalJSONFn func(T) ([]byte, error),
	unmarshalJSONFn func(*T, []byte) error,
	marshalTextFn func(T) ([]byte, error),
	unmarshalTextFn func(*T, []byte) error,
) {
	for _, value := range values {
		t.Run(fmt.Sprintf("%v", value), func(t *testing.T) {
			// Test IsValid
			if !isValidFn(value) {
				t.Errorf("%s %v should be valid but IsValid() returned false", typeName, value)
			}

			// Test JSON round-trip
			jsonData, err := marshalJSONFn(value)
			if err != nil {
				t.Errorf("%s.MarshalJSON() error = %v", typeName, err)

				return
			}

			var unmarshaled T

			err = unmarshalJSONFn(&unmarshaled, jsonData)
			if err != nil {
				t.Errorf("%s.UnmarshalJSON() error = %v", typeName, err)

				return
			}

			if unmarshaled != value {
				t.Errorf("JSON round trip failed: got %v, want %v", unmarshaled, value)
			}

			// Test text round-trip
			textData, err := marshalTextFn(value)
			if err != nil {
				t.Errorf("%s.MarshalText() error = %v", typeName, err)

				return
			}

			var unmarshaledText T

			err = unmarshalTextFn(&unmarshaledText, textData)
			if err != nil {
				t.Errorf("%s.UnmarshalText() error = %v", typeName, err)

				return
			}

			if unmarshaledText != value {
				t.Errorf("Text round trip failed: got %v, want %v", unmarshaledText, value)
			}
		})
	}
}

// ErrorMessageUnmarshalTestCase represents a test case for error message validation during unmarshal operations.
type ErrorMessageUnmarshalTestCase struct {
	Name           string
	Input          string
	WantError      bool
	ExpectedSubstr string
}

// runUnmarshalErrorMessageTests runs a parameterized test for error messages during JSON and Text unmarshal operations.
// This eliminates duplicate test code for testing error messages across different enumerated types.
func runUnmarshalErrorMessageTests[T any](
	t *testing.T,
	typeName string,
	tests []ErrorMessageUnmarshalTestCase,
	jsonUnmarshalFn func([]byte, *T) error,
	textUnmarshalFn func([]byte, *T) error,
) {
	for _, testCase := range tests {
		t.Run(testCase.Name, func(t *testing.T) {
			var err error

			if strings.Contains(testCase.Name, "JSON") {
				var got T

				err = jsonUnmarshalFn([]byte(testCase.Input), &got)
			} else {
				var got T

				err = textUnmarshalFn([]byte(testCase.Input), &got)
			}

			if (err != nil) != testCase.WantError {
				t.Errorf(
					"%s: expected error = %v, got error = %v",
					typeName,
					testCase.WantError,
					err,
				)

				return
			}

			if checkErrorMessageContains(t, err, testCase.ExpectedSubstr) {
				return
			}
		})
	}
}

// runUnmarshalErrorMessageLoop runs a parameterized test for error messages during unmarshal operations.
// This eliminates duplicate test code by extracting the common loop pattern used across
// ErrorActionTester and SeverityTester's runUnmarshalJSONErrorMessageTests and runUnmarshalTextErrorMessageTests methods.
func runUnmarshalErrorMessageLoop(
	t *testing.T,
	typeName string,
	methodName string,
	tests []ErrorMessageTestCase,
	unmarshalFn func(ErrorMessageTestCase) error,
) {
	for _, testCase := range tests {
		t.Run(testCase.Name, func(t *testing.T) {
			err := unmarshalFn(testCase)
			if err == nil {
				t.Errorf("%s.%s() expected error but got nil", typeName, methodName)

				return
			}

			if !checkErrorMessageContains(t, err, testCase.ExpectedSubstr) {
				return
			}
		})
	}
}

// runParseErrorMessageTests is a generic helper for testing parse error messages.
// This eliminates duplicate code by parameterizing the type-specific parsing logic.
func runParseErrorMessageTests(
	t *testing.T,
	typeName string,
	tests []ErrorMessageTestCase,
	parseFn func(string) error,
) {
	for _, testCase := range tests {
		t.Run(testCase.Name, func(t *testing.T) {
			err := parseFn(testCase.Input)
			if err == nil {
				t.Errorf("Parse%s() expected error but got nil", typeName)

				return
			}

			if !checkErrorMessageContains(t, err, testCase.ExpectedSubstr) {
				return
			}
		})
	}
}

// UnmarshalTextTestCaseGetter is an interface for extracting data from test cases.
// This enables a generic test helper that works with different test struct field names.
type UnmarshalTextTestCaseGetter interface {
	GetName() string
	GetInput() string
	GetWant() string
	GetWantErr() bool
}

// runUnmarshalTextGetterTests runs a parameterized UnmarshalText test using the getter interface.
// This eliminates duplicate test code by providing a common pattern for UnmarshalText tests.
func runUnmarshalTextGetterTests(
	t *testing.T,
	tests []UnmarshalTextTestCaseGetter,
	unmarshalFn func([]byte) error,
) {
	for _, testCase := range tests {
		t.Run(testCase.GetName(), func(t *testing.T) {
			err := unmarshalFn([]byte(testCase.GetInput()))
			if (err != nil) != testCase.GetWantErr() {
				t.Errorf("UnmarshalText() error = %v, wantErr %v", err, testCase.GetWantErr())

				return
			}

			if !testCase.GetWantErr() && err != nil {
				t.Errorf("UnmarshalText() = %v, want %v", err, testCase.GetInput())
			}
		})
	}
}

// runParseTests is a generic helper for testing parsing functions.
// This eliminates duplicate code by parameterizing the type-specific parsing logic.
func runParseTests[T comparable](
	t *testing.T,
	typeName string,
	tests []struct {
		name    string
		input   string
		want    T
		wantErr bool
	},
	parseFn func(string) (T, error),
) {
	for _, testCase := range tests {
		t.Run(testCase.name, func(t *testing.T) {
			got, err := parseFn(testCase.input)
			if (err != nil) != testCase.wantErr {
				t.Errorf("Parse%s() error = %v, wantErr %v", typeName, err, testCase.wantErr)

				return
			}

			if got != testCase.want {
				t.Errorf("Parse%s() = %v, want %v", typeName, got, testCase.want)
			}
		})
	}
}

// runParseGeneratedTests is a generic helper for testing parse functions with generated test cases.
// This eliminates duplicate test runner code when test cases are generated from source lists.
// The sourceToParseTestCaseFn transforms each source item into a parse test case.
func runParseGeneratedTests[T comparable, Source any](
	t *testing.T,
	typeName string,
	sources []Source,
	sourceToParseTestCaseFn func(Source) struct {
		name    string
		input   string
		want    T
		wantErr bool
	},
	parseFn func(string) (T, error),
) {
	for _, src := range sources {
		test := sourceToParseTestCaseFn(src)
		t.Run(test.name, func(t *testing.T) {
			got, err := parseFn(test.input)
			if (err != nil) != test.wantErr {
				t.Errorf("Parse%s() error = %v, wantErr %v", typeName, err, test.wantErr)

				return
			}

			if got != test.want {
				t.Errorf("Parse%s() = %v, want %v", typeName, got, test.want)
			}
		})
	}
}

// runIsValidTests is a generic helper for testing IsValid methods.
// This eliminates duplicate code by parameterizing the type-specific validation logic.
func runIsValidTests[T comparable](
	t *testing.T,
	typeName string,
	tests []struct {
		name string
		obj  T
		want bool
	},
	isValidFn func(T) bool,
) {
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := isValidFn(tt.obj); got != tt.want {
				t.Errorf("%s.IsValid() = %v, want %v", typeName, got, tt.want)
			}
		})
	}
}

// runIsValidGeneratedTests is a generic helper for testing IsValid methods with generated test cases.
// This eliminates duplicate test runner code when test cases are generated from source lists.
// The sourceToIsValidTestCaseFn transforms each source item into an IsValid test case.
func runIsValidGeneratedTests[T comparable, Source any](
	t *testing.T,
	typeName string,
	sources []Source,
	sourceToIsValidTestCaseFn func(Source) struct {
		name string
		obj  T
		want bool
	},
	isValidFn func(T) bool,
) {
	for _, src := range sources {
		test := sourceToIsValidTestCaseFn(src)
		t.Run(test.name, func(t *testing.T) {
			if got := isValidFn(test.obj); got != test.want {
				t.Errorf("%s.IsValid() = %v, want %v", typeName, got, test.want)
			}
		})
	}
}

// runMarshalTests runs a parameterized marshal test for generic types.
// This eliminates duplicate test code by extracting the common test loop pattern
// used across different marshal methods (MarshalJSON, MarshalText, etc.).
// The marshalFn should be a method value like T.MarshalJSON or T.MarshalText.
// The methodName parameter should be the name of the marshal method for error messages.
func runMarshalTests[T comparable](
	t *testing.T,
	typeName string,
	methodName string,
	tests []MarshalTestCase[T],
	marshalFn func(T) ([]byte, error),
) {
	t.Helper()

	for _, testCase := range tests {
		t.Run(testCase.Name, func(t *testing.T) {
			got, err := marshalFn(testCase.Value)
			if (err != nil) != testCase.WantErr {
				t.Errorf(
					"%s.%s() error = %v, wantErr %v",
					typeName,
					methodName,
					err,
					testCase.WantErr,
				)

				return
			}

			if string(got) != testCase.Want {
				t.Errorf("%s.%s() = %s, want %s", typeName, methodName, string(got), testCase.Want)
			}
		})
	}
}

// MarshalTestCase represents test cases for the generic marshal test helper.
// This is the common type used by runMarshalTests.
type MarshalTestCase[T comparable] struct {
	Name    string
	Value   T
	Want    string
	WantErr bool
}

// JSONMarshalTestCase is a type alias for MarshalTestCase for JSON marshaling tests.
// Both types have identical structure.
type JSONMarshalTestCase[T comparable] = MarshalTestCase[T]

// MarshalTextTestCase is a type alias for MarshalTestCase for text marshaling tests.
// Both types have identical structure.
type MarshalTextTestCase[T comparable] = MarshalTestCase[T]

// ConvertToMarshalTextTestCases converts a slice of test cases to MarshalTextTestCase format.
// This eliminates duplicate conversion loops by providing a generic transformation function.
// The convertFn maps each source case to a MarshalTextTestCase.
func ConvertToMarshalTextTestCases[T comparable, U any](
	cases []U,
	convertFn func(U) MarshalTextTestCase[T],
) []MarshalTextTestCase[T] {
	result := make([]MarshalTextTestCase[T], len(cases))
	for i, c := range cases {
		result[i] = convertFn(c)
	}

	return result
}

type GenericUnmarshalTestCase[T comparable] struct {
	Name       string
	Input      string
	Want       T
	WantErr    bool
	ValidateFn func(got, want T) bool
}

// runTextUnmarshalTests runs a parameterized UnmarshalText test.
// This eliminates duplicate code by extracting the common test loop pattern
// used across different types' UnmarshalText tests.
// When ValidateFn is nil, direct comparison is used.
func runTextUnmarshalTests[T comparable](
	t *testing.T,
	typeName string,
	tests []GenericUnmarshalTestCase[T],
	unmarshalFn func(*T, []byte) error,
) {
	const methodName = "UnmarshalText"

	for _, testCase := range tests {
		t.Run(testCase.Name, func(t *testing.T) {
			var got T

			err := unmarshalFn(&got, []byte(testCase.Input))
			if checkUnmarshalError(t, typeName, methodName, err, testCase.WantErr) {
				return
			}

			if !testCase.WantErr {
				if testCase.ValidateFn != nil {
					if !testCase.ValidateFn(got, testCase.Want) {
						t.Errorf("%s.%s() = %v, want %v", typeName, methodName, got, testCase.Want)
					}
				} else if got != testCase.Want {
					t.Errorf("%s.%s() = %v, want %v", typeName, methodName, got, testCase.Want)
				}
			}
		})
	}
}

// TextUnmarshalInlineTestCase represents test cases for inline UnmarshalText tests.
// This enables extracting duplicate inline test loops to reusable helpers.
type TextUnmarshalInlineTestCase[T comparable] struct {
	Name    string
	Data    string
	Want    T
	WantErr bool
}

// runTextUnmarshalInlineTests runs a parameterized inline UnmarshalText test loop.
// This eliminates duplicate code by extracting the common test loop pattern
// used across different types' UnmarshalText tests.
func runTextUnmarshalInlineTests[T comparable](
	t *testing.T,
	typeName string,
	tests []TextUnmarshalInlineTestCase[T],
	unmarshalFn func(*T, []byte) error,
) {
	cases := make([]GenericUnmarshalTestCase[T], len(tests))
	for i, tc := range tests {
		cases[i] = GenericUnmarshalTestCase[T]{
			Name:    tc.Name,
			Input:   tc.Data,
			Want:    tc.Want,
			WantErr: tc.WantErr,
		}
	}

	runTextUnmarshalTests(t, typeName, cases, unmarshalFn)
}

// runUnmarshalTextWithStringResultTests runs a parameterized UnmarshalText test where the result
// is converted to string for comparison. This eliminates duplicate code by extracting the
// common test loop pattern used across different types' UnmarshalText tests.
func runUnmarshalTextWithStringResultTests[T comparable](
	t *testing.T,
	typeName string,
	tests []struct {
		Name    string
		Input   string
		Want    string
		WantErr bool
	},
	unmarshalFn func(*T, []byte) error,
) {
	const methodName = "UnmarshalText"

	for _, testCase := range tests {
		t.Run(testCase.Name, func(t *testing.T) {
			var got T

			err := unmarshalFn(&got, []byte(testCase.Input))
			if checkUnmarshalError(t, typeName, methodName, err, testCase.WantErr) {
				return
			}

			if !testCase.WantErr {
				gotStr := fmt.Sprintf("%v", got)
				if gotStr != testCase.Want {
					t.Errorf("%s.%s() = %v, want %v", typeName, methodName, gotStr, testCase.Want)
				}
			}
		})
	}
}

// EnumTypeConstraint is a type alias for validatable for backward compatibility.
type EnumTypeConstraint = validatable

// runEnumTypeErrorMessageTests tests error messages for invalid enum values during unmarshal operations.
// This eliminates duplicate test code across ErrorKind, ErrorType, and RelationshipType.
// The typeName should match the type name used in error messages (e.g., "ErrorKind", "ErrorType").
func runEnumTypeErrorMessageTests[T EnumTypeConstraint](t *testing.T, typeName string) {
	tests := []ErrorMessageUnmarshalTestCase{
		{
			"Invalid via JSON",
			testInvalidQuoted,
			true,
			fmt.Sprintf("invalid %s: \"invalid\"", typeName),
		},
		{
			"Invalid via Text",
			testInvalid,
			true,
			fmt.Sprintf("invalid %s: \"invalid\"", typeName),
		},
	}

	runUnmarshalErrorMessageTests(
		t, typeName, tests,
		func(data []byte, target *T) error {
			return json.Unmarshal(data, target)
		},
		func(data []byte, target *T) error {
			// Use type assertion to call the appropriate UnmarshalText method
			switch ptr := any(target).(type) {
			case *ErrorType:
				return ptr.UnmarshalText(data)
			case *ErrorKind:
				return ptr.UnmarshalText(data)
			case *RelationshipType:
				return ptr.UnmarshalText(data)
			default:
				return fmt.Errorf(
					"%w: target type %T (typeName=%s)",
					apierrors.ErrUnsupportedType,
					target,
					typeName,
				)
			}
		},
	)
}
