package types

import (
	"encoding/json/v2"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// unmarshalTextTestCase represents a test case for UnmarshalText testing.
type unmarshalTextTestCase[T any] struct {
	name      string
	input     []byte
	expected  T
	wantError bool
}

// textUnmarshaler is the interface for types that implement UnmarshalText.
type textUnmarshaler interface {
	UnmarshalText(data []byte) error
}

// textMarshaler is the interface for types that implement MarshalText.
type textMarshaler interface {
	MarshalText() ([]byte, error)
}

// jsonUnmarshaler is the interface for types that implement UnmarshalJSON.
type jsonUnmarshaler interface {
	UnmarshalJSON(data []byte) error
}

// parseResult is a type constraint for types that can be parsed from string.
type parseResult interface {
	~string
}

// isValidTestCase represents a test case for IsValid testing.
type isValidTestCase[T validatable] struct {
	name  string
	value T
	valid bool
}

// parseTestCase represents a test case for parse function testing.
type parseTestCase[T parseResult] struct {
	name      string
	input     string
	expected  T
	wantError bool
}

// unmarshalJSONTestCase represents a test case for UnmarshalJSON testing.
type unmarshalJSONTestCase[T any] struct {
	name      string
	input     string
	expected  T
	wantError bool
}

// testUnmarshalJSON is a helper for testing JSON unmarshaler implementations.
func testUnmarshalJSON[T any](
	t *testing.T,
	tests []unmarshalJSONTestCase[T],
	newFunc func() (jsonUnmarshaler, *T),
) {
	t.Helper()

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			unmarshaler, ptr := newFunc()

			assertUnmarshalResult(t, unmarshaler.UnmarshalJSON, []byte(tt.input), tt.wantError, tt.expected, ptr)
		})
	}
}

// testUnmarshalText is a helper for testing TextUnmarshaler implementations.
func testUnmarshalText[T any](
	t *testing.T,
	tests []unmarshalTextTestCase[T],
	newFunc func() (textUnmarshaler, *T),
) {
	t.Helper()

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			unmarshaler, ptr := newFunc()

			assertUnmarshalResult(t, unmarshaler.UnmarshalText, tt.input, tt.wantError, tt.expected, ptr)
		})
	}
}

// assertUnmarshalResult runs the unmarshal fn on the input and asserts the expected
// error/equality state for both JSON and text unmarshalers.
func assertUnmarshalResult[T any](
	t *testing.T,
	unmarshal func([]byte) error,
	input []byte,
	wantError bool,
	expected T,
	got *T,
) {
	t.Helper()

	err := unmarshal(input)
	if wantError {
		assert.Error(t, err)
	} else {
		require.NoError(t, err)
		assert.Equal(t, expected, *got)
	}
}

// marshalTextTestCase represents a test case for MarshalText testing.
type marshalTextTestCase[T any] struct {
	name     string
	value    T
	expected []byte
}

// testMarshalText is a helper for testing TextMarshaler implementations.
func testMarshalText[T textMarshaler](t *testing.T, tests []marshalTextTestCase[T]) {
	t.Helper()

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result, err := tt.value.MarshalText()
			require.NoError(t, err)
			assert.Equal(t, tt.expected, result)
		})
	}
}

// marshalJSONTestCase represents a test case for MarshalJSON testing.
type marshalJSONTestCase[T any] struct {
	name     string
	value    T
	expected string
}

// testMarshalJSON is a helper for testing JSON marshaling.
type jsonMarshaler interface {
	any
}

func testMarshalJSON[T jsonMarshaler](t *testing.T, tests []marshalJSONTestCase[T]) {
	t.Helper()

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result, err := json.Marshal(tt.value)
			require.NoError(t, err)
			assert.JSONEq(t, tt.expected, string(result))
		})
	}
}

// testIsValid is a helper for testing IsValid implementations.
func testIsValid[T validatable](t *testing.T, tests []isValidTestCase[T]) {
	t.Helper()

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result := tt.value.IsValid()
			assert.Equal(t, tt.valid, result)
		})
	}
}

// testParse is a helper for testing parse function implementations.
func testParse[T parseResult](
	t *testing.T,
	tests []parseTestCase[T],
	parseFunc func(string) (T, error),
) {
	t.Helper()

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result, err := parseFunc(tt.input)
			if tt.wantError {
				assert.Error(t, err)
				assert.Empty(t, result)
			} else {
				require.NoError(t, err)
				assert.Equal(t, tt.expected, result)
			}
		})
	}
}
