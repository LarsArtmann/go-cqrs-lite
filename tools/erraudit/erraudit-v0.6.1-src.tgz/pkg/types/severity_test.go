package types

import (
	"encoding/json/v2"
	"slices"
	"testing"
)

// severityParseTestCases provides shared test cases for ParseSeverity and UnmarshalText tests.
// This eliminates duplicate code across test functions while maintaining test isolation.
func severityParseTestCases() []struct {
	name    string
	input   string
	want    Severity
	wantStr string // String representation for UnmarshalText comparison
	wantErr bool
} {
	return []struct {
		name    string
		input   string
		want    Severity
		wantStr string
		wantErr bool
	}{
		{
			name:    "parse high (lowercase)",
			input:   "critical",
			want:    SeverityHigh,
			wantStr: "critical",
			wantErr: false,
		},
		{
			name:    "parse high (uppercase)",
			input:   "CRITICAL",
			want:    SeverityHigh,
			wantStr: "critical",
			wantErr: false,
		},
		{
			name:    "parse high (mixed case)",
			input:   "CrItIcAl",
			want:    SeverityHigh,
			wantStr: "critical",
			wantErr: false,
		},
		{
			name:    "parse medium",
			input:   "error",
			want:    SeverityMedium,
			wantStr: "error",
			wantErr: false,
		},
		{
			name:    "parse low",
			input:   "warning",
			want:    SeverityLow,
			wantStr: "warning",
			wantErr: false,
		},
		{
			name:    "invalid severity",
			input:   "invalid",
			want:    "",
			wantStr: "",
			wantErr: true,
		},
		{
			name:    "empty severity",
			input:   "",
			want:    "",
			wantStr: "",
			wantErr: true,
		},
	}
}

// severityMarshalTestCases provides shared test cases for MarshalJSON and MarshalText tests.
func severityMarshalTestCases() []MarshalTextTestCase[Severity] {
	return []MarshalTextTestCase[Severity]{
		{Name: "marshal high", Value: SeverityHigh, Want: "critical"},
		{Name: "marshal medium", Value: SeverityMedium, Want: "error"},
		{Name: "marshal low", Value: SeverityLow, Want: "warning"},
	}
}

func severityJSONMarshalTestCases() []MarshalTestCase[Severity] {
	return []MarshalTestCase[Severity]{
		{Name: "marshal high", Value: SeverityHigh, Want: `"critical"`},
		{Name: "marshal medium", Value: SeverityMedium, Want: `"error"`},
		{Name: "marshal low", Value: SeverityLow, Want: `"warning"`},
	}
}

func TestSeverity_IsValid(t *testing.T) {
	tests := []struct {
		name string
		obj  Severity
		want bool
	}{
		{
			name: "valid high",
			obj:  SeverityHigh,
			want: true,
		},
		{
			name: "valid medium",
			obj:  SeverityMedium,
			want: true,
		},
		{
			name: "valid low",
			obj:  SeverityLow,
			want: true,
		},
		{
			name: "invalid severity",
			obj:  Severity("invalid"),
			want: false,
		},
		{
			name: "empty severity",
			obj:  Severity(""),
			want: false,
		},
	}

	runIsValidTests(t, "Severity", tests, func(s Severity) bool { return s.IsValid() })
}

func TestParseSeverity(t *testing.T) {
	tests := []struct {
		name    string
		input   string
		want    Severity
		wantErr bool
	}{
		{name: "parse high (lowercase)", input: "critical", want: SeverityHigh, wantErr: false},
		{name: "parse high (uppercase)", input: "CRITICAL", want: SeverityHigh, wantErr: false},
		{name: "parse high (mixed case)", input: "CrItIcAl", want: SeverityHigh, wantErr: false},
		{name: "parse medium", input: "error", want: SeverityMedium, wantErr: false},
		{name: "parse low", input: "warning", want: SeverityLow, wantErr: false},
		{name: "invalid severity", input: "invalid", want: "", wantErr: true},
		{name: "empty severity", input: "", want: "", wantErr: true},
	}

	runParseTests(t, "Severity", tests, ParseSeverity)
}

func TestValidSeverities(t *testing.T) {
	severities := ValidSeverities()

	expectedSeverities := []Severity{
		SeverityHigh,
		SeverityMedium,
		SeverityLow,
	}

	if len(severities) != len(expectedSeverities) {
		t.Errorf(
			"ValidSeverities() returned %d severities, want %d",
			len(severities),
			len(expectedSeverities),
		)
	}

	for _, expected := range expectedSeverities {
		found := slices.Contains(severities, expected)
		if !found {
			t.Errorf("ValidSeverities() missing severity: %v", expected)
		}
	}
}

func TestIsValidSeverity(t *testing.T) {
	tests := []struct {
		name string
		obj  string
		want bool
	}{
		{
			name: "valid high string",
			obj:  "critical",
			want: true,
		},
		{
			name: "valid medium string",
			obj:  "error",
			want: true,
		},
		{
			name: "valid low string",
			obj:  "warning",
			want: true,
		},
		{
			name: "invalid string",
			obj:  "invalid",
			want: false,
		},
		{
			name: "empty string",
			obj:  "",
			want: false,
		},
	}

	runIsValidTests(t, "Severity", tests, func(s string) bool { return IsValidSeverity(s) })
}

func TestSeverity_MarshalJSON(t *testing.T) {
	tests := severityJSONMarshalTestCases()

	runMarshalTests(
		t,
		"Severity",
		"MarshalJSON",
		tests,
		func(s Severity) ([]byte, error) { return json.Marshal(s) },
	)
}

func TestSeverity_UnmarshalJSON(t *testing.T) {
	tests := []JSONUnmarshalTestCase[Severity]{
		{
			Name:    "unmarshal high (lowercase)",
			Input:   `"critical"`,
			Want:    SeverityHigh,
			WantErr: false,
		},
		{
			Name:    "unmarshal high (uppercase)",
			Input:   `"CRITICAL"`,
			Want:    SeverityHigh,
			WantErr: false,
		},
		{
			Name:    "unmarshal high (mixed case)",
			Input:   `"CrItIcAl"`,
			Want:    SeverityHigh,
			WantErr: false,
		},
		{
			Name:    "unmarshal medium",
			Input:   `"error"`,
			Want:    SeverityMedium,
			WantErr: false,
		},
		{
			Name:    "unmarshal low",
			Input:   `"warning"`,
			Want:    SeverityLow,
			WantErr: false,
		},
		{
			Name:    "unmarshal invalid",
			Input:   `"invalid"`,
			Want:    "",
			WantErr: true,
		},
		{
			Name:    "unmarshal empty",
			Input:   `""`,
			Want:    "",
			WantErr: true,
		},
		{
			Name:    "unmarshal invalid JSON",
			Input:   `not json`,
			Want:    "",
			WantErr: true,
		},
	}

	runJSONUnmarshalTests(
		t, "Severity", tests,
		func(input []byte, got *Severity) error {
			return json.Unmarshal(input, got)
		},
		func(s string) string { return s },
	)
}

func TestSeverity_MarshalText(t *testing.T) {
	tests := severityMarshalTestCases()
	for i := range tests {
		tests[i].Name = "marshal text " + tests[i].Name[7:] // skip "marshal " prefix
	}

	runMarshalTests(
		t,
		"Severity",
		"MarshalText",
		tests,
		func(s Severity) ([]byte, error) { return s.MarshalText() },
	)
}

func TestSeverity_UnmarshalText(t *testing.T) {
	tests := severityParseTestCases()

	stringTests := make([]struct {
		Name    string
		Input   string
		Want    string
		WantErr bool
	}, len(tests))
	for i, tc := range tests {
		stringTests[i] = struct {
			Name    string
			Input   string
			Want    string
			WantErr bool
		}{
			Name:    tc.name,
			Input:   tc.input,
			Want:    tc.wantStr,
			WantErr: tc.wantErr,
		}
	}

	runUnmarshalTextWithStringResultTests(t, "Severity", stringTests, (*Severity).UnmarshalText)
}

func TestSeverity_ErrorMessages(t *testing.T) {
	tester := UnmarshalerTester[Severity]{}
	tester.runAllErrorMessageTests(t, "severity", "Severity", func(input string) error {
		_, err := ParseSeverity(input)

		return err
	}, (*Severity).UnmarshalJSON, (*Severity).UnmarshalText)
}

func TestSeverity_AllValidSeverities(t *testing.T) {
	severities := []Severity{
		SeverityHigh,
		SeverityMedium,
		SeverityLow,
	}

	runAllValidMarshalersTests(
		t, "Severity", severities,
		Severity.IsValid,
		MarshalJSONHelper[Severity],
		(*Severity).UnmarshalJSON,
		Severity.MarshalText,
		(*Severity).UnmarshalText,
	)
}

func TestSeverity_PointerSemantics(t *testing.T) {
	runPointerSemanticsTests(
		t,
		"Severity",
		SeverityHigh,
		func(data []byte, v *Severity) error { return v.UnmarshalText(data) },
	)
}

func TestSeverity_ZeroValue(t *testing.T) {
	var zero Severity

	if zero.IsValid() {
		t.Errorf("Zero value of Severity should not be valid")
	}

	_, err := ParseSeverity("")
	if err == nil {
		t.Errorf("Parsing empty string should return error")
	}

	var unmarshaled Severity

	err = unmarshaled.UnmarshalText([]byte(""))
	if err == nil {
		t.Errorf("Unmarshaling empty bytes should return error")
	}
}

func TestSeverity_Ordinal(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name     string
		severity Severity
		want     uint
	}{
		{
			name:     "low has ordinal 1",
			severity: SeverityLow,
			want:     1,
		},
		{
			name:     "medium has ordinal 2",
			severity: SeverityMedium,
			want:     2,
		},
		{
			name:     "high has ordinal 3",
			severity: SeverityHigh,
			want:     3,
		},
		{
			name:     "invalid severity has ordinal 0",
			severity: Severity("invalid"),
			want:     0,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			got := tt.severity.Ordinal()
			if got != tt.want {
				t.Errorf("Severity.Ordinal() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestSeverity_AtOrAbove(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name      string
		severity  Severity
		threshold Severity
		want      bool
	}{
		// High severity tests
		{
			name:      "high at high threshold",
			severity:  SeverityHigh,
			threshold: SeverityHigh,
			want:      true,
		},
		{
			name:      "high at medium threshold",
			severity:  SeverityHigh,
			threshold: SeverityMedium,
			want:      true,
		},
		{
			name:      "high at low threshold",
			severity:  SeverityHigh,
			threshold: SeverityLow,
			want:      true,
		},
		// Medium severity tests
		{
			name:      "medium at high threshold",
			severity:  SeverityMedium,
			threshold: SeverityHigh,
			want:      false,
		},
		{
			name:      "medium at medium threshold",
			severity:  SeverityMedium,
			threshold: SeverityMedium,
			want:      true,
		},
		{
			name:      "medium at low threshold",
			severity:  SeverityMedium,
			threshold: SeverityLow,
			want:      true,
		},
		// Low severity tests
		{
			name:      "low at high threshold",
			severity:  SeverityLow,
			threshold: SeverityHigh,
			want:      false,
		},
		{
			name:      "low at medium threshold",
			severity:  SeverityLow,
			threshold: SeverityMedium,
			want:      false,
		},
		{
			name:      "low at low threshold",
			severity:  SeverityLow,
			threshold: SeverityLow,
			want:      true,
		},
		// Invalid severity
		{
			name:      "invalid severity at low threshold",
			severity:  Severity("invalid"),
			threshold: SeverityLow,
			want:      false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			got := tt.severity.AtOrAbove(tt.threshold)
			if got != tt.want {
				t.Errorf("Severity.AtOrAbove() = %v, want %v", got, tt.want)
			}
		})
	}
}
