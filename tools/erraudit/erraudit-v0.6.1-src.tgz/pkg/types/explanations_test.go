package types

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestExplanationForType_AllTypesHaveExplanation(t *testing.T) {
	t.Parallel()

	for _, et := range ValidErrorTypes() {
		explanation := explanationForType(et)
		assert.NotEmpty(t, explanation, "violation type %s should have an explanation", et)
	}
}

func TestExplanationForType_UnknownType(t *testing.T) {
	t.Parallel()

	assert.Empty(t, explanationForType(ErrorType("nonexistent")))
}

func TestPopulateExplanations_FillsAll(t *testing.T) {
	t.Parallel()

	violations := []ErrorViolation{
		{Type: ErrorTypeIgnored, Message: "test"},
		{Type: ErrorTypePanic, Message: "test"},
		{Type: ErrorTypeSilentSwallow, Message: "test"},
	}

	PopulateExplanations(violations)

	for _, v := range violations {
		assert.NotEmpty(t, v.Explanation, "violation type %s should have explanation populated", v.Type)
	}
}

func TestPopulateExplanations_PreservesExistingExplanation(t *testing.T) {
	t.Parallel()

	custom := "custom explanation"
	violations := []ErrorViolation{
		{Type: ErrorTypeIgnored, Message: "test", Explanation: custom},
	}

	PopulateExplanations(violations)

	assert.Equal(t, custom, violations[0].Explanation)
}

func TestPopulateExplanations_EmptySlice(t *testing.T) {
	t.Parallel()

	PopulateExplanations(nil)
	PopulateExplanations([]ErrorViolation{})
}

func TestPopulateExplanations_KeyContent(t *testing.T) {
	t.Parallel()

	violations := []ErrorViolation{
		{Type: ErrorTypeContextLoss, Message: "test"},
	}

	PopulateExplanations(violations)

	require.NotEmpty(t, violations[0].Explanation)
	assert.Contains(t, violations[0].Explanation, "diagnostic context")
}
