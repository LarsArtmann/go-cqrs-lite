package types

import (
	"encoding/json/v2"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestValidOutputFormats(t *testing.T) {
	formats := ValidOutputFormats()
	expected := []OutputFormat{
		FormatTree,
		FormatJSON,
		FormatHTML,
		FormatFull,
		FormatHierarchy,
		FormatDOT,
		FormatMermaid,
		FormatAgent,
		FormatSARIF,
		FormatGoFindingSARIF,
		FormatGoFindingJSON,
		FormatCSV,
		FormatTSV,
		FormatMarkdown,
		FormatYAML,
		FormatXML,
		FormatD2,
		FormatJSONL,
		FormatAsciiDoc,
		FormatTOML,
		FormatPlantUML,
		FormatTable,
	}
	assert.Equal(t, expected, formats)
	assert.Len(t, formats, 22)
}

func TestOutputFormat_IsValid(t *testing.T) {
	tests := []isValidTestCase[OutputFormat]{
		{"tree is valid", FormatTree, true},
		{"json is valid", FormatJSON, true},
		{"html is valid", FormatHTML, true},
		{"full is valid", FormatFull, true},
		{"hierarchy is valid", FormatHierarchy, true},
		{"dot is valid", FormatDOT, true},
		{"mermaid is valid", FormatMermaid, true},
		{"invalid is invalid", OutputFormat("invalid"), false},
		{"empty is invalid", OutputFormat(""), false},
		{"xml is valid", FormatXML, true},
		{"yaml is valid", FormatYAML, true},
	}
	testIsValid(t, tests)
}

func TestParseOutputFormat(t *testing.T) {
	tests := []parseTestCase[OutputFormat]{
		{"parse tree", "tree", FormatTree, false},
		{"parse json", "json", FormatJSON, false},
		{"parse html", "html", FormatHTML, false},
		{"parse full", "full", FormatFull, false},
		{"parse hierarchy", "hierarchy", FormatHierarchy, false},
		{"parse dot", "dot", FormatDOT, false},
		{"parse mermaid", "mermaid", FormatMermaid, false},
		{"parse uppercase TREE", "TREE", FormatTree, false},
		{"parse uppercase JSON", "JSON", FormatJSON, false},
		{"parse uppercase HTML", "HTML", FormatHTML, false},
		{"parse mixed case Dot", "Dot", FormatDOT, false},
		{"parse invalid", "invalid", "", true},
		{"parse empty", "", "", true},
		{"parse xml", "xml", FormatXML, false},
	}
	testParse(t, tests, ParseOutputFormat)
}

func TestOutputFormat_MarshalJSON(t *testing.T) {
	tests := []marshalJSONTestCase[OutputFormat]{
		{"marshal tree", FormatTree, `"tree"`},
		{"marshal json", FormatJSON, `"json"`},
		{"marshal html", FormatHTML, `"html"`},
		{"marshal dot", FormatDOT, `"dot"`},
		{"marshal mermaid", FormatMermaid, `"mermaid"`},
	}
	testMarshalJSON(t, tests)
}

func TestOutputFormat_UnmarshalJSON(t *testing.T) {
	tests := []unmarshalJSONTestCase[OutputFormat]{
		{"unmarshal tree", `"tree"`, FormatTree, false},
		{"unmarshal json", `"json"`, FormatJSON, false},
		{"unmarshal html", `"html"`, FormatHTML, false},
		{"unmarshal dot", `"dot"`, FormatDOT, false},
		{"unmarshal uppercase", `"JSON"`, FormatJSON, false},
		{"unmarshal mixed case", `"Html"`, FormatHTML, false},
		{"unmarshal invalid", `"invalid"`, OutputFormat(""), true},
		{"unmarshal empty string", `""`, OutputFormat(""), true},
		{"invalid JSON - missing quotes", `tree`, OutputFormat(""), true},
		{"invalid JSON - single quote", `'tree'`, OutputFormat(""), true},
	}
	testUnmarshalJSON(t, tests, func() (jsonUnmarshaler, *OutputFormat) {
		ptr := new(OutputFormat)

		return ptr, ptr
	})
}

func TestOutputFormat_MarshalText(t *testing.T) {
	tests := []marshalTextTestCase[OutputFormat]{
		{"marshal tree", FormatTree, []byte("tree")},
		{"marshal json", FormatJSON, []byte("json")},
		{"marshal html", FormatHTML, []byte("html")},
		{"marshal dot", FormatDOT, []byte("dot")},
		{"marshal mermaid", FormatMermaid, []byte("mermaid")},
	}
	testMarshalText(t, tests)
}

func TestOutputFormat_UnmarshalText(t *testing.T) {
	tests := []unmarshalTextTestCase[OutputFormat]{
		{"unmarshal tree", []byte("tree"), FormatTree, false},
		{"unmarshal json", []byte("json"), FormatJSON, false},
		{"unmarshal html", []byte("html"), FormatHTML, false},
		{"unmarshal dot", []byte("dot"), FormatDOT, false},
		{"unmarshal uppercase", []byte("JSON"), FormatJSON, false},
		{"unmarshal mixed case", []byte("Html"), FormatHTML, false},
		{"unmarshal invalid", []byte("invalid"), OutputFormat(""), true},
		{"unmarshal empty", []byte(""), OutputFormat(""), true},
	}
	testUnmarshalText(t, tests, func() (textUnmarshaler, *OutputFormat) {
		ptr := new(OutputFormat)

		return ptr, ptr
	})
}

func TestOutputFormat_RoundTrip(t *testing.T) {
	formats := ValidOutputFormats()
	for _, format := range formats {
		t.Run(string(format), func(t *testing.T) {
			// JSON round-trip
			jsonData, err := json.Marshal(format)
			require.NoError(t, err)

			var unmarshaled OutputFormat

			err = json.Unmarshal(jsonData, &unmarshaled)
			require.NoError(t, err)
			assert.Equal(t, format, unmarshaled)

			// Text round-trip
			textData, err := format.MarshalText()
			require.NoError(t, err)

			var textUnmarshaled OutputFormat

			err = textUnmarshaled.UnmarshalText(textData)
			require.NoError(t, err)
			assert.Equal(t, format, textUnmarshaled)
		})
	}
}
