package types

import (
	"encoding"
	"encoding/json/v2"
)

// OutputFormat represents the output format type for analysis results.
//

type OutputFormat string

const (
	// FormatTree displays results in a tree structure.
	FormatTree OutputFormat = "tree"
	// FormatJSON outputs results as JSON via the go-finding standardized format.
	// This is an alias for FormatGoFindingJSON — both produce identical output.
	FormatJSON OutputFormat = "json"
	// FormatHTML generates an HTML report.
	FormatHTML OutputFormat = "html"
	// FormatFull shows comprehensive output.
	FormatFull OutputFormat = "full"
	// FormatHierarchy displays error hierarchy.
	FormatHierarchy OutputFormat = "hierarchy"
	// FormatDOT generates Graphviz DOT format.
	FormatDOT OutputFormat = "dot"
	// FormatMermaid generates Mermaid diagram format.
	FormatMermaid OutputFormat = "mermaid"
	// FormatAgent generates token-efficient output optimized for AI coding agents.
	FormatAgent OutputFormat = "agent"
	// FormatSARIF generates SARIF 2.1.0 JSON for static analysis tool integration.
	FormatSARIF OutputFormat = "sarif"
	// FormatGoFindingSARIF generates standardized SARIF via go-finding library.
	FormatGoFindingSARIF OutputFormat = "go-finding-sarif"
	// FormatGoFindingJSON generates standardized JSON via go-finding library.
	FormatGoFindingJSON OutputFormat = "go-finding-json"

	// FormatCSV generates CSV output via the go-output library.
	FormatCSV      OutputFormat = "csv"
	FormatTSV      OutputFormat = "tsv"
	FormatMarkdown OutputFormat = "markdown"
	FormatYAML     OutputFormat = "yaml"
	FormatXML      OutputFormat = "xml"
	FormatD2       OutputFormat = "d2"
	FormatJSONL    OutputFormat = "jsonl"
	FormatAsciiDoc OutputFormat = "asciidoc"
	FormatTOML     OutputFormat = "toml"
	FormatPlantUML OutputFormat = "plantuml"
	FormatTable    OutputFormat = "table"
)

// ValidOutputFormats returns all valid output format values.
// validOutputFormats is the canonical list of valid OutputFormat values.
//
//nolint:gochecknoglobals // Package-level slice avoids per-call heap allocation in IsValid()
var validOutputFormats = []OutputFormat{
	FormatTree,
	FormatJSON,
	FormatHTML,
	FormatFull,
	FormatHierarchy,
	FormatDOT,
	FormatMermaid,
	FormatAgent,
	FormatSARIF,
	FormatGoFindingSARIF,
	FormatGoFindingJSON,
	FormatCSV,
	FormatTSV,
	FormatMarkdown,
	FormatYAML,
	FormatXML,
	FormatD2,
	FormatJSONL,
	FormatAsciiDoc,
	FormatTOML,
	FormatPlantUML,
	FormatTable,
}

// ValidOutputFormats returns list of valid output format values.
func ValidOutputFormats() []OutputFormat {
	return validOutputFormats
}

// IsValid checks if the output format is valid.
func (of OutputFormat) IsValid() bool {
	return isValidValue(of, validOutputFormats)
}

// ParseOutputFormat parses a string into an OutputFormat.
func ParseOutputFormat(input string) (OutputFormat, error) {
	return parseType[OutputFormat](input, "output format")
}

// MarshalJSON implements json.Marshaler for OutputFormat.
func (of OutputFormat) MarshalJSON() ([]byte, error) {
	//nolint:wrapcheck // json.Marshal on string cannot fail
	return json.Marshal(string(of))
}

// UnmarshalJSON implements json.Unmarshaler for OutputFormat.
func (of *OutputFormat) UnmarshalJSON(data []byte) error {
	return unmarshalJSONAssign(data, "OutputFormat", OutputFormat.IsValid, of)
}

// MarshalText implements encoding.TextMarshaler for OutputFormat.
func (of OutputFormat) MarshalText() ([]byte, error) {
	return []byte(string(of)), nil
}

// UnmarshalText implements encoding.TextUnmarshaler for OutputFormat.
func (of *OutputFormat) UnmarshalText(data []byte) error {
	return unmarshalTextAssign(data, "OutputFormat", OutputFormat.IsValid, of)
}

var (
	_ encoding.TextMarshaler   = FormatTree
	_ encoding.TextUnmarshaler = (*OutputFormat)(nil)
)
