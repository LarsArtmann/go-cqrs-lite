package types

import "go/token"

// MakeTestViolation creates an ErrorViolation with the given fields for use in tests.
func MakeTestViolation(
	filename string,
	line int,
	errType ErrorType,
	severity Severity,
	msg string,
) ErrorViolation {
	return ErrorViolation{
		Position: token.Position{Filename: filename, Line: line},
		Type:     errType,
		Severity: severity,
		Message:  msg,
	}
}

// AllSeverities returns a slice of all valid Severity values.
// This helper function is used across multiple test files to get the complete
// set of severity types for validation and testing purposes.
func AllSeverities() []Severity {
	return []Severity{
		SeverityHigh,
		SeverityMedium,
		SeverityLow,
	}
}
