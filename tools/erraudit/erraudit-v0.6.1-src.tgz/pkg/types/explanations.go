package types

// explanationForType returns a human-readable explanation of WHY a violation
// of the given type was flagged, what pattern was matched, and how to think
// about fixing it. This is more detailed than the per-violation Suggestion field
// (which gives a specific fix) — it explains the detector reasoning itself.
func explanationForType(t ErrorType) string {
	switch t {
	case ErrorTypeReturn:
		return "The function returns an error created by a function call without wrapping it. " +
			"The caller receives the raw error with no context about which operation failed."
	case ErrorTypeAssignment:
		return "An error from a function call is assigned to a variable. " +
			"The error should be checked (if err != nil) before continuing with the next operation."
	case ErrorTypeWrapping:
		return "fmt.Errorf wraps an error using the %w verb. " +
			"This creates an error chain that preserves the original error while adding context. " +
			"This is informational — wrapping is good practice."
	case ErrorTypeUnwrapped:
		return "fmt.Errorf creates a new error without wrapping the original. " +
			"The original error chain is lost. Consider using %w to preserve the cause."
	case ErrorTypeCheck:
		return "An error check (if err != nil) is present. " +
			"This is informational — the error is handled."
	case ErrorTypePropagation:
		return "An error variable is returned directly without wrapping. " +
			"Consider adding context about the current operation to help callers diagnose failures."
	case ErrorTypePanic:
		return "panic() is called with an error value inside a function that could return error. " +
			"Panicking crashes the entire program instead of propagating the error to the caller. " +
			"Return the error instead, unless the function follows the MustXxx naming convention."
	case ErrorTypeSilentSwallow:
		return "An if err != nil block is empty or does not handle the error. " +
			"The error is silently swallowed — the program continues as if nothing went wrong. " +
			"Either handle the error (log, return, wrap) or explicitly document why it is safe to ignore."
	case ErrorTypeIgnored:
		return "An error from a function call is discarded using the blank identifier (_). " +
			"The error is never checked. If the error matters, capture and handle it."
	case ErrorTypeGenericReturn:
		return "The function creates errors internally but returns the bare error interface. " +
			"Returning a concrete error type enables callers to use type-safe error matching " +
			"(e.g., errors.AsType in Go 1.26+) instead of string comparison."
	case ErrorTypeLegacyAs:
		return "Uses errors.As with a pointer-to-pointer target type. " +
			"In Go 1.26+, errors.AsType provides type-safe generic error unwrapping without manual pointer plumbing."
	case ErrorTypeLegacyIs:
		return "Uses errors.Is for error comparison. " +
			"This is advisory — consider using typed error sentinels or a custom error type for compile-time safety."
	case ErrorTypeContextLoss:
		return "Variables in scope at the error-return site are not included in the error message. " +
			"These variables (e.g., IDs, paths, addresses) provide diagnostic context that would help " +
			"debuggers trace the root cause. Include them in the error message or wrap with context."
	case ErrorTypeStdlibConstructor:
		return "Uses stdlib error constructors (errors.New, fmt.Errorf) instead of the enforced error library. " +
			"Switch to the project's error library for consistent error classification, context, and codes."
	case ErrorTypeUncodedConstructor:
		return "go-error-family constructor is called with an empty (\"\") error code. " +
			"Empty-code errors lose their What/Why/Fix message template and suggested fix at the CLI boundary. " +
			"Pass a stable dotted code and register a template for it."
	case ErrorTypeSentinelConcreteType:
		return "Package-level sentinel var (Err*/err*) has a concrete type instead of the error interface. " +
			"Concrete-typed sentinels make every errors.Is(err, Sentinel) call site a legacy_is finding, " +
			"because the sentinel guard only exempts vars whose declared type is the error interface. " +
			"Fix the declaration: var ErrX error = ..."
	case ErrorTypeOopsRedundantGuard:
		return "Redundant nil guard before oops.Wrap/Wrapf. " +
			"Since oops.Wrap returns nil for nil input, the if err != nil check is unnecessary. " +
			"Replace the guard and trailing return nil with a single return oops.Wrap(err)."
	case ErrorTypeOopsMisusedW:
		return "Potentially misused %w verb in an oops.Errorf format string. " +
			"Check that the %w verb corresponds to the error argument position."
	case ErrorTypeDeferredCloseIgnored:
		return "defer f.Close() discards the error returned by Close. " +
			"For buffered writers (e.g., *bufio.Writer), Close flushes pending data — " +
			"ignoring its error can silently lose writes. " +
			"Consider capturing the error or using a wrapper that handles it."
	default:
		return ""
	}
}

// PopulateExplanations fills the Explanation field on each violation based on
// its Type. This is a post-processing step called when the --explain flag is
// active. Violations whose Explanation is already set are left unchanged.
func PopulateExplanations(violations []ErrorViolation) {
	for i := range violations {
		if violations[i].Explanation != "" {
			continue
		}

		violations[i].Explanation = explanationForType(violations[i].Type)
	}
}
