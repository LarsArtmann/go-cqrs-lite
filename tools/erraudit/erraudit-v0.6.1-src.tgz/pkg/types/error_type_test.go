package types

import (
	"encoding/json/v2"
	"testing"
)

// errorTypeTestCase defines a test case with name and expected ErrorType.
// This is used as the source of truth for all unmarshal test cases.
type errorTypeTestCase struct {
	name string
	want ErrorType
}

var errorTypeTestCases = []errorTypeTestCase{
	{"Lowercase: return", ErrorTypeReturn},
	{"Lowercase: assignment", ErrorTypeAssignment},
	{"Lowercase: wrapping", ErrorTypeWrapping},
	{"Lowercase: unwrapped", ErrorTypeUnwrapped},
	{"Lowercase: check", ErrorTypeCheck},
	{"Lowercase: propagation", ErrorTypePropagation},
	{"Lowercase: panic", ErrorTypePanic},
	{"Lowercase: silent_swallow", ErrorTypeSilentSwallow},
	{"Lowercase: ignored", ErrorTypeIgnored},
	{"Uppercase: RETURN", ErrorTypeReturn},
	{"Uppercase: ASSIGNMENT", ErrorTypeAssignment},
	{"Uppercase: WRAPPING", ErrorTypeWrapping},
	{"Uppercase: UNWRAPPED", ErrorTypeUnwrapped},
	{"Uppercase: CHECK", ErrorTypeCheck},
	{"Uppercase: PROPAGATION", ErrorTypePropagation},
	{"Uppercase: PANIC", ErrorTypePanic},
	{"Uppercase: SILENT_SWALLOW", ErrorTypeSilentSwallow},
	{"Uppercase: IGNORED", ErrorTypeIgnored},
	{"Mixed case: Return", ErrorTypeReturn},
	{"Mixed case: Assignment", ErrorTypeAssignment},
	{"Mixed case: Wrapping", ErrorTypeWrapping},
	{"Mixed case: Unwrapped", ErrorTypeUnwrapped},
	{"Mixed case: Check", ErrorTypeCheck},
	{"Mixed case: Propagation", ErrorTypePropagation},
	{"Mixed case: Panic", ErrorTypePanic},
	{"Mixed case: Silent_Swallow", ErrorTypeSilentSwallow},
	{"Mixed case: Ignored", ErrorTypeIgnored},
	{"Invalid: unknown", ErrorType("")},
	{"Invalid: empty", ErrorType("")},
}

// unmarshalTestCasesJSON generates test cases for JSON unmarshaling with quoted data.
func unmarshalTestCasesJSON() []JSONUnmarshalTestCase[ErrorType] {
	tests := make([]JSONUnmarshalTestCase[ErrorType], len(errorTypeTestCases))
	for i, tc := range errorTypeTestCases {
		tests[i] = JSONUnmarshalTestCase[ErrorType]{
			Name:    tc.name,
			Input:   string(tc.want),
			Got:     ErrorType(""),
			Want:    tc.want,
			WantErr: tc.want == ErrorType(""),
		}
	}

	return tests
}

// isValidTestCases generates test cases for IsValid testing.
func isValidTestCases() []struct {
	name string
	typ  ErrorType
	want bool
} {
	tests := make([]struct {
		name string
		typ  ErrorType
		want bool
	}, len(errorTypeTestCases))
	for i, tc := range errorTypeTestCases {
		isValid := tc.want != ErrorType("")
		tests[i] = struct {
			name string
			typ  ErrorType
			want bool
		}{
			name: tc.name,
			typ:  tc.want,
			want: isValid,
		}
	}

	return tests
}

// unmarshalTestCasesText generates test cases for Text unmarshaling with unquoted data.
func unmarshalTestCasesText() []TextUnmarshalInlineTestCase[ErrorType] {
	tests := make([]TextUnmarshalInlineTestCase[ErrorType], len(errorTypeTestCases))
	for i, tc := range errorTypeTestCases {
		tests[i] = TextUnmarshalInlineTestCase[ErrorType]{
			Name:    tc.name,
			Data:    string(tc.want),
			Want:    tc.want,
			WantErr: tc.want == ErrorType(""),
		}
	}

	return tests
}

// marshalTestCasesJSON generates test cases for JSON marshaling.
// quote indicates whether the expected output should be quoted (JSON) or unquoted (Text).
// Only generates cases for valid ErrorTypes.
func marshalTestCasesJSON() []JSONMarshalTestCase[ErrorType] {
	tests := make([]JSONMarshalTestCase[ErrorType], 0, len(errorTypeTestCases))
	for _, tc := range errorTypeTestCases {
		if !tc.want.IsValid() {
			continue
		}

		tests = append(tests, JSONMarshalTestCase[ErrorType]{
			Name:    string(tc.want),
			Value:   tc.want,
			Want:    `"` + string(tc.want) + `"`,
			WantErr: false,
		})
	}

	return tests
}

func TestErrorType_IsValid(t *testing.T) {
	tests := isValidTestCases()

	runIsValidGeneratedTests(t, "ErrorType", tests, func(tc struct {
		name string
		typ  ErrorType
		want bool
	}) struct {
		name string
		obj  ErrorType
		want bool
	} {
		return struct {
			name string
			obj  ErrorType
			want bool
		}{name: tc.name, obj: tc.typ, want: tc.want}
	}, func(e ErrorType) bool { return e.IsValid() })
}

func TestParseErrorType(t *testing.T) {
	runParseGeneratedTests(t, "ErrorType", errorTypeTestCases,
		func(tc errorTypeTestCase) struct {
			name    string
			input   string
			want    ErrorType
			wantErr bool
		} {
			return struct {
				name    string
				input   string
				want    ErrorType
				wantErr bool
			}{
				name:    tc.name,
				input:   string(tc.want),
				want:    tc.want,
				wantErr: tc.want == ErrorType(""),
			}
		},
		ParseErrorType)
}

func TestErrorType_MarshalJSON(t *testing.T) {
	tests := marshalTestCasesJSON()

	runMarshalTests(t, "ErrorType", "MarshalJSON", tests, ErrorType.MarshalJSON)
}

func TestErrorType_UnmarshalJSON(t *testing.T) {
	tests := unmarshalTestCasesJSON()

	runJSONUnmarshalTests(
		t, "ErrorType", tests,
		func(data []byte, et *ErrorType) error { return json.Unmarshal(data, et) },
		QuoteString,
	)
}

// marshalTestCasesText generates test cases for Text marshaling.
// Only generates cases for valid ErrorTypes.
func marshalTestCasesText() []MarshalTextTestCase[ErrorType] {
	tests := make([]MarshalTextTestCase[ErrorType], 0, len(errorTypeTestCases))
	for _, tc := range errorTypeTestCases {
		if !tc.want.IsValid() {
			continue
		}

		tests = append(tests, MarshalTextTestCase[ErrorType]{
			Name:    string(tc.want),
			Value:   tc.want,
			Want:    string(tc.want),
			WantErr: false,
		})
	}

	return tests
}

func TestErrorType_MarshalText(t *testing.T) {
	tests := marshalTestCasesText()

	runMarshalTests(t, "ErrorType", "MarshalText", tests, ErrorType.MarshalText)
}

func TestErrorType_UnmarshalText(t *testing.T) {
	tests := unmarshalTestCasesText()

	runTextUnmarshalInlineTests(t, "ErrorType", tests, (*ErrorType).UnmarshalText)
}

func TestErrorType_RoundTrip(t *testing.T) {
	validTypes := []ErrorType{
		ErrorTypeReturn,
		ErrorTypeAssignment,
		ErrorTypeWrapping,
		ErrorTypeUnwrapped,
		ErrorTypeCheck,
		ErrorTypePropagation,
		ErrorTypePanic,
		ErrorTypeSilentSwallow,
		ErrorTypeIgnored,
	}

	runAllValidMarshalersTests(
		t, "ErrorType", validTypes,
		ErrorType.IsValid,
		MarshalJSONHelper[ErrorType],
		UnmarshalJSONHelper[ErrorType],
		ErrorType.MarshalText,
		(*ErrorType).UnmarshalText,
	)
}

func TestErrorType_PointerSemantics(t *testing.T) {
	validVal := ErrorTypeReturn
	_ = validVal
	// Test with pointer to valid value
	validPtr := &validVal
	if !validPtr.IsValid() {
		t.Error("Pointer to valid ErrorType should be valid")
	}
	// Test with pointer to invalid value
	invalidVal := ErrorType("invalid")

	invalidPtr := &invalidVal
	if invalidPtr.IsValid() {
		t.Error("Pointer to invalid ErrorType should be invalid")
	}
}

func TestErrorType_ZeroValue(t *testing.T) {
	var zero ErrorType
	if zero.IsValid() {
		t.Error("Zero value should be invalid")
	}
}

func TestErrorType_ErrorMessage(t *testing.T) {
	runEnumTypeErrorMessageTests[ErrorType](t, "ErrorType")
}
