package main

import (
	"github.com/larsartmann/erraudit/cmd/erraudit/cmd"
	"github.com/larsartmann/erraudit/pkg/logging"
	"github.com/larsartmann/erraudit/pkg/version"
)

func main() {
	logging.Setup()
	cmd.Execute(version.Version)
}
