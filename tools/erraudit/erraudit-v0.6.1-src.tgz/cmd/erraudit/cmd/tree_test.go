package cmd

import (
	"testing"

	output "github.com/larsartmann/go-output"
)

// TestResolveColorMode covers all code paths in resolveColorMode:
// 1. Explicit flag with no output file → use flag value
// 2. Explicit flag with output file and non-always mode → forced off
// 3. Explicit flag with output file and always mode → honored
// 4. No flag, output file → auto-off
// 5. No flag, no output file → auto
func TestResolveColorMode(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name       string
		colorFlag  string
		outputFile string
		want       output.ColorMode
	}{
		{
			name:       "auto no output",
			colorFlag:  "",
			outputFile: "",
			want:       output.ColorModeAuto,
		},
		{
			name:       "auto with output file forces never",
			colorFlag:  "",
			outputFile: "report.txt",
			want:       output.ColorModeNever,
		},
		{
			name:       "explicit always honored with output",
			colorFlag:  "always",
			outputFile: "report.txt",
			want:       output.ColorModeAlways,
		},
		{
			name:       "explicit always honored without output",
			colorFlag:  "always",
			outputFile: "",
			want:       output.ColorModeAlways,
		},
		{
			name:       "explicit never with output",
			colorFlag:  "never",
			outputFile: "report.txt",
			want:       output.ColorModeNever,
		},
		{
			name:       "explicit never without output",
			colorFlag:  "never",
			outputFile: "",
			want:       output.ColorModeNever,
		},
		{
			name:       "explicit auto without output",
			colorFlag:  "auto",
			outputFile: "",
			want:       output.ColorModeAuto,
		},
		{
			name:       "explicit auto with output forces never",
			colorFlag:  "auto",
			outputFile: "report.txt",
			want:       output.ColorModeNever,
		},
		{
			name:       "invalid flag falls through to auto",
			colorFlag:  "invalid",
			outputFile: "",
			want:       output.ColorModeAuto,
		},
		{
			name:       "invalid flag with output forces never",
			colorFlag:  "invalid",
			outputFile: "report.txt",
			want:       output.ColorModeNever,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			got := resolveColorMode(tt.colorFlag, tt.outputFile)
			if got != tt.want {
				t.Errorf("resolveColorMode(%q, %q) = %v, want %v",
					tt.colorFlag, tt.outputFile, got, tt.want)
			}
		})
	}
}
