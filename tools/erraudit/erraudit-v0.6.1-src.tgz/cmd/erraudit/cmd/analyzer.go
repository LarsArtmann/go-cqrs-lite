package cmd

import (
	"context"
	"errors"
	"fmt"
	"io"
	"os"

	"github.com/larsartmann/erraudit/cmd/erraudit/cmd/output"
	"github.com/larsartmann/erraudit/cmd/erraudit/cmd/pipeline"
	apierrors "github.com/larsartmann/erraudit/pkg/errors"
	"github.com/larsartmann/erraudit/pkg/extension/hooks"
	"github.com/larsartmann/erraudit/pkg/finding"
	"github.com/larsartmann/erraudit/pkg/types"
	errorfamily "github.com/larsartmann/go-error-family"
	"github.com/spf13/cobra"
)

// Exit codes for the analyzer.
const (
	ExitSuccess         = 0 // No violations found
	ExitError           = 1 // Analysis error
	ExitViolationsFound = 2 // Violations found (used for CI/CD integration)
)

// ErrViolationsFound is returned when violations are detected during analysis.
// The caller should exit with ExitViolationsFound (2) instead of ExitError (1).
// Declared as the error interface (stdlib sentinel convention) so
// errors.Is(err, ErrViolationsFound) call sites pass the legacyerrors
// sentinel guard and satisfy the sentinel_concrete_type rule.
var ErrViolationsFound error = errorfamily.NewRejection("violations.found", "violations found")

// violationsFoundError returns ErrViolationsFound when count > 0, nil otherwise.
// Encapsulates the "found nothing" / "found something" exit-code contract shared
// by the main analyze command, the pipeline path, and the lint subcommand.
func violationsFoundError(count int) error {
	if count > 0 {
		return ErrViolationsFound
	}

	return nil
}

// File permissions for output files (read/write for owner only).
const outputFileMode = 0o600

// Analyzer handles the analysis execution.
type Analyzer struct {
	path string
	cmd  *cobra.Command
}

// printAuditModeBanner warns that suppression is bypassed so a
// suppression-free report reads as the audit it is instead of a regression
// (shared by the default and --pipeline paths).
func printAuditModeBanner(cfg *AppConfig) {
	if cfg.NoSuppress {
		fmt.Fprintln(
			os.Stderr,
			"erraudit: AUDIT MODE — //nolint suppression and AST false-positive heuristics are BYPASSED; listed findings include intentional patterns",
		)
	}
}

// NewAnalyzer creates a new analyzer instance.
//
//nolint:exhaustruct_v5 // cmd field is set in Run() method
func NewAnalyzer(path string) *Analyzer {
	return &Analyzer{
		path: path,
	}
}

// Run executes the analysis using the provided configuration.
// Signal handling is provided by cmdguard's WithSignalHandling option.
func (a *Analyzer) Run(cmd *cobra.Command, cfg *AppConfig) error {
	a.cmd = cmd

	ctx := cmd.Context()

	printAuditModeBanner(cfg)

	// Pipeline mode: run through go-finding ecosystem pipeline
	if cfg.Pipeline {
		return a.runPipeline(cmd, cfg)
	}

	// Run analysis
	a.logVerbosef(cmd, cfg, "Analyzing: %s\n", a.path)

	// Suppress/Explain stay false: this path finalizes violations itself (via
	// FinalizeViolations below) AFTER filtering, so the spec choke point must
	// not pre-empt it.
	graph, violations, err := pipeline.PerformAnalysisWithSpec(ctx, pipeline.AnalysisSpec{
		Path:                 a.path,
		ExcludedPaths:        cfg.Exclude,
		TypeAware:            cfg.TypeAware,
		EnforceErrorFamily:   cfg.EnforceErrorFamily,
		EnforceSamberOops:    cfg.EnforceSamberOops,
		EnforceGenericReturn: cfg.EnforceGenericReturn,
		EnforceDeferredClose: cfg.EnforceDeferredClose,
		EnforceCodedErrors:   cfg.EnforceCodedErrors,
		NoSuppress:           cfg.NoSuppress,
		ModulesAll:           cfg.Modules == ModulesAllMode,
		Progress:             cfg.Progress,
		Suppress:             false,
		Explain:              false,
	})
	if err != nil {
		if errors.Is(err, context.Canceled) {
			return apierrors.Wrap(err,
				"analysis of %s cancelled (excludedPaths=%v)",
				a.path, cfg.Exclude)
		}

		return apierrors.Wrap(err,
			"error during analysis of %s (excludedPaths=%v)",
			a.path, cfg.Exclude)
	}

	// Warn loudly when the pattern matched nothing — an empty result is
	// otherwise indistinguishable from a clean codebase.
	if graph.FilesScanned == 0 {
		fmt.Fprintf(os.Stderr, "Warning: no Go source files found for %q (scanned 0 files).\n", a.path)
		fmt.Fprintln(os.Stderr, "A bare directory only matches a package if it directly contains .go files.")
		fmt.Fprintln(os.Stderr, `Hint: use "./..." to analyze a whole module, or pass a package directory.`)
	}

	// Apply filters
	violations = pipeline.FilterViolations(
		violations,
		cfg.SeverityFilterPtr(),
		cfg.TypeFilterPtr(),
		cfg.SeverityThresholdPtr(),
		cfg.DisabledTypesSet(),
	)

	// Suppression + explanations via the shared finishing step so this path
	// cannot disagree with watch/lint/--pipeline/LSP on what is suppressed.
	violations = pipeline.FinalizeViolations(
		violations,
		pipeline.SourceFilesFromGraph(graph),
		cfg.NoSuppress,
		cfg.Explain,
	)
	graph.Violations = violations

	// Generate output
	err = a.generateAndWriteOutput(ctx, cmd, cfg, graph, violations)
	if err != nil {
		return err
	}

	// Exit with violations-found status if violations found
	if len(violations) > 0 {
		return ErrViolationsFound
	}

	return nil
}

// runPipeline executes analysis through the go-finding pipeline, producing
// standardized Finding values with ecosystem-native suppression. Output is
// serialized as JSON (default) or SARIF (--format sarif).
func (a *Analyzer) runPipeline(cmd *cobra.Command, cfg *AppConfig) error {
	ctx := cmd.Context()
	if ctx == nil {
		ctx = context.Background()
	}

	if cfg.NoSuppress {
		fmt.Fprintln(
			os.Stderr,
			"erraudit: AUDIT MODE — //nolint suppression and AST false-positive heuristics are BYPASSED; listed findings include intentional patterns",
		)
	}

	a.logVerbosef(cmd, cfg, "Analyzing (pipeline mode): %s\n", a.path)

	// ModulesAll stays false: --pipeline resolves the target as one pattern
	// (fan-out parity with --modules=all is a documented open item).
	spec := pipeline.AnalysisSpec{
		Path:                 a.path,
		ExcludedPaths:        cfg.Exclude,
		TypeAware:            cfg.TypeAware,
		EnforceErrorFamily:   cfg.EnforceErrorFamily,
		EnforceSamberOops:    cfg.EnforceSamberOops,
		EnforceGenericReturn: cfg.EnforceGenericReturn,
		EnforceDeferredClose: cfg.EnforceDeferredClose,
		EnforceCodedErrors:   cfg.EnforceCodedErrors,
		NoSuppress:           cfg.NoSuppress,
		ModulesAll:           false,
		Progress:             false,
		Suppress:             !cfg.NoSuppress,
		Explain:              cfg.Explain,
	}

	findings, filesScanned, err := pipeline.RunFindingPipeline(ctx, spec)
	if err != nil {
		return apierrors.Wrap(err, "pipeline execution failed for %s", a.path)
	}

	report := finding.NewToolReport()
	report.AddFindings(findings)
	report.ComputeSummary()
	report.Summary.FilesScanned = filesScanned

	if err := withOutputWriter(
		func() (io.Writer, func(), error) { return a.outputWriter(cmd, cfg) },
		func(writer io.Writer) error {
			outputFmt := cfg.OutputFormatType()
			if outputFmt == types.FormatSARIF || outputFmt == types.FormatGoFindingSARIF {
				if err := report.WriteSARIF(ctx, writer); err != nil {
					return apierrors.Wrap(err, "failed to write SARIF output")
				}
			} else {
				if err := report.WriteJSON(writer); err != nil {
					return apierrors.Wrap(err, "failed to write JSON output")
				}
			}

			return nil
		},
	); err != nil {
		return err
	}

	return violationsFoundError(len(findings))
}

// outputWriter returns a writer for stdout or a file based on config.
func (a *Analyzer) outputWriter(cmd *cobra.Command, cfg *AppConfig) (io.Writer, func(), error) {
	return newOutputWriter(cfg.Output, cmd.OutOrStdout())
}

// logVerbosef prints a formatted message when verbose mode is enabled.
// Consolidates the verbose-guard + Printf boilerplate shared between the
// regular analysis path and the pipeline-mode path.
func (a *Analyzer) logVerbosef(cmd *cobra.Command, cfg *AppConfig, format string, args ...any) {
	if cfg.Verbose {
		cmd.Printf(format, args...)
	}
}

// generateAndWriteOutput generates the output and writes it to the appropriate destination.
func (a *Analyzer) generateAndWriteOutput(
	ctx context.Context,
	cmd *cobra.Command,
	cfg *AppConfig,
	graph *types.ErrorGraph,
	violations []types.ErrorViolation,
) error {
	outputFmt := cfg.OutputFormatType()

	// Execute pre-output hook
	preOutputData, cancelled, _ := hooks.Fire( //nolint:erraudit // hook errors are non-fatal by design
		ctx,
		hooks.HookPreOutput,
		&hooks.PreOutputData{
			Format:     string(outputFmt),
			Graph:      graph,
			Violations: violations,
		},
	)

	// Check if hook cancelled output generation
	if cancelled {
		return nil
	}

	// Allow hook to modify violations (via in-place pointer modification)
	if modified, ok := preOutputData.Violations.([]types.ErrorViolation); ok {
		violations = modified
	}

	registry := output.NewStrategyRegistry(cfg.DOTTheme, cfg.ViolationsOnly)

	strategy, err := registry.Get(outputFmt)
	if err != nil {
		return apierrors.Wrap(
			err,
			"error getting output strategy for format %s (output=%s, violations=%d)",
			outputFmt,
			cfg.Output,
			len(violations),
		)
	}

	outputStr, err := strategy.Generate(graph, violations)
	if err != nil {
		return apierrors.Wrap(
			err,
			"error generating %s output (output=%s, violations=%d)",
			outputFmt,
			cfg.Output,
			len(violations),
		)
	}

	// Execute post-output hook
	hooks.Notify(ctx, hooks.HookPostOutput, &hooks.PostOutputData{
		Format: string(outputFmt),
		Output: outputStr,
	})

	// Write output via the shared outputWriter (handles stdout vs file)
	if err := withOutputWriter(
		func() (io.Writer, func(), error) { return a.outputWriter(cmd, cfg) },
		func(writer io.Writer) error {
			_, err := io.WriteString(writer, outputStr)
			if err != nil {
				target := "stdout"
				if cfg.Output != "" {
					target = cfg.Output
				}

				return apierrors.Wrap(
					err,
					"error writing output to %s (size=%d bytes)",
					target,
					len(outputStr),
				)
			}

			return nil
		},
	); err != nil {
		return err
	}

	if cfg.Output != "" && cfg.Verbose {
		a.cmd.Printf("Output written to: %s\n", cfg.Output)
	}

	return nil
}
