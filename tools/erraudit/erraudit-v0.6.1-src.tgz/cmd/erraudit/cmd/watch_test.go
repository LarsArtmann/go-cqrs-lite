package cmd

import (
	"bytes"
	"context"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// writeWatchFixture creates a temporary Go module with the given source and
// returns the directory path. It mirrors the integration test fixture pattern.
func writeWatchFixture(t *testing.T, source string) string {
	t.Helper()

	dir := t.TempDir()

	require.NoError(t, os.WriteFile(filepath.Join(dir, "go.mod"), []byte("module watchtest\n\ngo 1.26\n"), 0o644))
	require.NoError(t, os.WriteFile(filepath.Join(dir, "main.go"), []byte(source), 0o644))

	return dir
}

// newTestWatcher creates a Watcher with output directed to a buffer for testing.
func newTestWatcher(dir string) (*Watcher, *bytes.Buffer) {
	w := NewWatcher(dir, DefaultWatchConfig)
	buf := &bytes.Buffer{}
	w.out = buf

	return w, buf
}

// sourceWithPanicViolation uses panic(err) which erraudit detects as a panic
// violation in default (non-type-aware) mode.
const sourceWithPanicViolation = `package main

func process(err error) {
	panic(err)
}
`

// sourceWithPanicViolationNolint is the same as sourceWithPanicViolation but
// with a //nolint:erraudit directive that suppresses the violation.
const sourceWithPanicViolationNolint = `package main

func process(err error) {
	panic(err) //nolint:erraudit // deliberate
}
`

// sourceClean has no error-handling violations.
const sourceClean = `package main

func doSomething() error {
	return nil
}

func process() error {
	if err := doSomething(); err != nil {
		return err
	}
	return nil
}
`

// TestWatcher_runAnalysis_DetectsViolations verifies that runAnalysis produces
// output containing violation information for code with error-handling issues.
func TestWatcher_runAnalysis_DetectsViolations(t *testing.T) {
	t.Parallel()

	dir := writeWatchFixture(t, sourceWithPanicViolation)
	w, buf := newTestWatcher(dir)
	w.config = &AppConfig{Format: "full"}

	err := w.runAnalysis(context.Background())
	require.NoError(t, err)

	output := buf.String()
	assert.Contains(t, output, "Found", "output should report violations found")
}

// TestWatcher_runAnalysis_NoViolationsForCleanCode verifies that runAnalysis
// reports no violations when the source is clean.
func TestWatcher_runAnalysis_NoViolationsForCleanCode(t *testing.T) {
	t.Parallel()

	dir := writeWatchFixture(t, sourceClean)
	w, buf := newTestWatcher(dir)
	w.config = &AppConfig{Format: "full"}

	err := w.runAnalysis(context.Background())
	require.NoError(t, err)

	output := buf.String()
	assert.Contains(t, output, "No violations", "clean code should report no violations")
}

// TestWatcher_runAnalysis_SuppressWithNolint verifies that //nolint:erraudit
// comments suppress violations in watch mode output. This is the key
// suppression-wiring test — the 2026-08-05 suppression wiring was previously
// unverified beyond compilation.
func TestWatcher_runAnalysis_SuppressWithNolint(t *testing.T) {
	t.Parallel()

	dir := writeWatchFixture(t, sourceWithPanicViolationNolint)
	w, buf := newTestWatcher(dir)
	w.config = &AppConfig{Format: "full"}

	err := w.runAnalysis(context.Background())
	require.NoError(t, err)

	output := buf.String()
	assert.Contains(t, output, "No violations",
		"//nolint:erraudit should suppress the violation in watch mode")
}

// TestWatcher_runAnalysis_NoSuppressShowsViolations verifies that
// NoSuppress=true bypasses //nolint directives in watch mode.
func TestWatcher_runAnalysis_NoSuppressShowsViolations(t *testing.T) {
	t.Parallel()

	dir := writeWatchFixture(t, sourceWithPanicViolationNolint)
	w, buf := newTestWatcher(dir)
	w.config = &AppConfig{Format: "full", NoSuppress: true}

	err := w.runAnalysis(context.Background())
	require.NoError(t, err)

	output := buf.String()
	assert.Contains(t, output, "Found",
		"--no-suppress should reveal violations hidden by //nolint")
}

// TestWatcher_runAnalysis_JSONFormat verifies that JSON output format
// works correctly through the watch pipeline.
func TestWatcher_runAnalysis_JSONFormat(t *testing.T) {
	t.Parallel()

	dir := writeWatchFixture(t, sourceWithPanicViolation)
	w, buf := newTestWatcher(dir)
	w.config = &AppConfig{Format: "json"}

	err := w.runAnalysis(context.Background())
	require.NoError(t, err)

	output := buf.String()
	assert.Contains(t, output, "Found", "JSON format should still report violation count")
}

// TestWatcher_runAnalysis_NonexistentPath verifies that runAnalysis returns
// an error for a path that does not exist.
func TestWatcher_runAnalysis_NonexistentPath(t *testing.T) {
	t.Parallel()

	w, _ := newTestWatcher("/nonexistent/path/that/should/not/exist")
	w.config = &AppConfig{Format: "full"}

	err := w.runAnalysis(context.Background())
	assert.Error(t, err, "should error on nonexistent path")
}

// TestNewWatcher_DefaultOutput verifies that NewWriter defaults to os.Stdout.
func TestNewWatcher_DefaultOutput(t *testing.T) {
	t.Parallel()

	w := NewWatcher(".", DefaultWatchConfig)
	assert.NotNil(t, w.out, "NewWatcher should default output to non-nil (os.Stdout)")
}

// TestWatcher_runAnalysis_ViolationSummaryFormat verifies that the violation
// summary line uses the correct format.
func TestWatcher_runAnalysis_ViolationSummaryFormat(t *testing.T) {
	t.Parallel()

	dir := writeWatchFixture(t, sourceWithPanicViolation)
	w, buf := newTestWatcher(dir)
	w.config = &AppConfig{Format: "full"}

	err := w.runAnalysis(context.Background())
	require.NoError(t, err)

	output := buf.String()

	// The summary should contain "--- Found N violation(s) at HH:MM:SS ---"
	lines := strings.Split(output, "\n")
	found := false
	for _, line := range lines {
		if strings.Contains(line, "--- Found") && strings.Contains(line, "violation(s)") {
			found = true
			break
		}
	}
	assert.True(t, found, "output should contain a violation summary line, got:\n%s", output)
}
