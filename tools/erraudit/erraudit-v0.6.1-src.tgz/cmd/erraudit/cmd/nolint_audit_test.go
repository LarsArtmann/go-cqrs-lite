package cmd

import (
	"bytes"
	"encoding/json/v2"
	"go/token"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestExtractReason(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name string
		line string
		want string
	}{
		{
			name: "reason present",
			line: "//nolint:erraudit // hook errors are non-fatal",
			want: "hook errors are non-fatal",
		},
		{
			name: "no reason",
			line: "//nolint:erraudit",
			want: "",
		},
		{
			name: "reason after code",
			line: "return err //nolint:erraudit // genuine issue",
			want: "genuine issue",
		},
		{
			name: "no nolint at all",
			line: "return err",
			want: "",
		},
		{
			name: "nolint with linter list and reason",
			line: "//nolint:wrapcheck,erraudit // both linters suppress this",
			want: "both linters suppress this",
		},
		{
			name: "nolint with colon rule and reason",
			line: "//nolint:erraudit:legacy_as // historical pattern",
			want: "historical pattern",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			got := extractReason(tt.line)
			assert.Equal(t, tt.want, got)
		})
	}
}

func TestCollectDirectives(t *testing.T) {
	t.Parallel()

	dir := t.TempDir()

	goFile := filepath.Join(dir, "example.go")
	content := `package main

import "errors"

var ErrA = errors.New("a") //nolint:erraudit // test reason
var ErrB = errors.New("b") //nolint:legacyerrors
`
	require.NoError(t, os.WriteFile(goFile, []byte(content), 0o644))

	directives, err := collectDirectives(dir)
	require.NoError(t, err)

	// Should find 2 directives: one for erraudit, one for legacyerrors
	assert.Len(t, directives, 2, "expected 2 directives")

	// Verify the first directive (erraudit)
	var errauditDir, legacyDir *nolintDirective
	for i := range directives {
		switch {
		case directives[i].Line == 5 && directives[i].Reason == "test reason":
			errauditDir = &directives[i]
		case directives[i].Line == 6:
			legacyDir = &directives[i]
		}
	}

	if assert.NotNil(t, errauditDir, "erraudit directive not found") {
		assert.Contains(t, errauditDir.File, "example.go")
		assert.Equal(t, "test reason", errauditDir.Reason)
	}

	assert.NotNil(t, legacyDir, "legacyerrors directive not found")
}

func TestCollectDirectives_EmptyDir(t *testing.T) {
	t.Parallel()

	dir := t.TempDir()

	directives, err := collectDirectives(dir)
	require.NoError(t, err)
	assert.Empty(t, directives)
}

func TestCollectDirectives_SkipsTestdata(t *testing.T) {
	t.Parallel()

	dir := t.TempDir()

	fixtureDir := filepath.Join(dir, "testdata", "src", "fixture")
	require.NoError(t, os.MkdirAll(fixtureDir, 0o755))

	fixtureFile := filepath.Join(fixtureDir, "fixture.go")
	fixtureContent := `package fixture

//nolint:legacyerrors
var Suppressed = newFake("quiet")
`
	require.NoError(t, os.WriteFile(fixtureFile, []byte(fixtureContent), 0o644))

	directives, err := collectDirectives(dir)
	require.NoError(t, err)
	assert.Empty(t, directives, "testdata fixtures (analysistest //nolint directives) must be skipped")
}

func TestCollectDirectives_NonGoFiles(t *testing.T) {
	t.Parallel()

	dir := t.TempDir()

	txtFile := filepath.Join(dir, "readme.txt")
	require.NoError(t, os.WriteFile(txtFile, []byte("//nolint:erraudit"), 0o644))

	directives, err := collectDirectives(dir)
	require.NoError(t, err)
	assert.Empty(t, directives, "non-.go files must be ignored")
}

func TestAuditDirectives_NeededAndStale(t *testing.T) {
	t.Parallel()

	dir := t.TempDir()
	goFile := filepath.Join(dir, "test.go")
	absFile, err := filepath.Abs(goFile)
	require.NoError(t, err)

	fileContent := "package main\n" +
		"\n" +
		"var ErrA = errors.New(\"a\") //nolint:erraudit // needed\n" +
		"var ErrB = errors.New(\"b\") //nolint:erraudit // stale\n"
	require.NoError(t, os.WriteFile(goFile, []byte(fileContent), 0o644))

	directives := []nolintDirective{
		{File: absFile, Line: 3, Content: "var ErrA = errors.New(\"a\") //nolint:erraudit // needed"},
		{File: absFile, Line: 4, Content: "var ErrB = errors.New(\"b\") //nolint:erraudit // stale"},
	}

	// Violation only on line 3 — line 4 directive is stale
	violations := []types.ErrorViolation{
		{
			Position: token.Position{Filename: absFile, Line: 3, Column: 1},
			Type:     types.ErrorTypeStdlibConstructor,
			Severity: types.SeverityMedium,
			Message:  "errors.New used",
		},
	}

	statuses := auditDirectives(directives, violations)

	require.Len(t, statuses, 2)

	assert.True(t, statuses[0].Needed, "line 3 directive should be needed")
	if assert.NotNil(t, statuses[0].Violation) {
		assert.Equal(t, 3, statuses[0].Violation.Position.Line)
	}

	assert.False(t, statuses[1].Needed, "line 4 directive should be stale")
	assert.Nil(t, statuses[1].Violation)
}

func TestAuditDirectives_UnreadableFile(t *testing.T) {
	t.Parallel()

	directives := []nolintDirective{
		{File: "/nonexistent/file.go", Line: 1},
	}

	statuses := auditDirectives(directives, nil)

	require.Len(t, statuses, 1)
	assert.True(t, statuses[0].Needed, "unreadable file should default to needed (safe)")
}

func TestIsNolintDirective(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name string
		text string
		want bool
	}{
		{"erraudit", "//nolint:erraudit", true},
		{"legacyerrors", "//nolint:legacyerrors", true},
		{"erraudit with reason", "//nolint:erraudit // false positive", true},
		{"erraudit with rule", "//nolint:erraudit:legacy_as", true},
		{"multi-linter includes erraudit", "//nolint:wrapcheck,erraudit", true},
		{"multi-linter includes legacyerrors", "//nolint:erraudit,wrapcheck", true},
		{"bare nolint matches all", "//nolint", true},
		{"bare nolint with space", "// nolint", true},
		{"uppercase", "//NOLINT:ERRAUDIT", true},
		{"other linter excluded", "//nolint:wrapcheck", false},
		{"doc comment about nolint", "// nolintDirective is a type", false},
		{"doc comment mentioning nolint", "// FilterSuppressed drops //nolint:erraudit fixes", false},
		{"regular comment", "// this is a normal comment", false},
		{"block comment", "/*nolint:erraudit*/", false},
		{"code not comment", "return err", false},
		{"empty string", "", false},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			assert.Equal(t, tt.want, isNolintDirective(tt.text))
		})
	}
}

func TestCollectDirectives_NoStringLiteralFalsePositives(t *testing.T) {
	t.Parallel()

	dir := t.TempDir()

	goFile := filepath.Join(dir, "example.go")
	content := `package main

import "fmt"

func main() {
	msg := "//nolint:erraudit // this is inside a string literal"
	fmt.Println(msg)
}`
	require.NoError(t, os.WriteFile(goFile, []byte(content), 0o644))

	directives, err := collectDirectives(dir)
	require.NoError(t, err)
	assert.Empty(t, directives, "string literal //nolint must NOT be detected")
}

func TestCollectDirectives_NoDocCommentFalsePositives(t *testing.T) {
	t.Parallel()

	dir := t.TempDir()

	goFile := filepath.Join(dir, "example.go")
	content := `package main

// FilterSuppressed drops fixes whose source location carries a //nolint:erraudit
// directive. This doc comment mentions //nolint:legacyerrors too.
func FilterSuppressed() {}`
	require.NoError(t, os.WriteFile(goFile, []byte(content), 0o644))

	directives, err := collectDirectives(dir)
	require.NoError(t, err)
	assert.Empty(t, directives, "doc comments mentioning //nolint must NOT be detected")
}

func TestCollectDirectives_RealDirectives(t *testing.T) {
	t.Parallel()

	dir := t.TempDir()

	goFile := filepath.Join(dir, "example.go")
	content := `package main

import "errors"

// This is a doc comment about //nolint:erraudit (should NOT match).
var ErrA = errors.New("a") //nolint:erraudit // real directive
var ErrB = errors.New("b") //nolint:legacyerrors // another real one
var ErrC = errors.New("c") //nolint:wrapcheck // not our linter (should NOT match)

const msg = "//nolint:erraudit in a string (should NOT match)"
`
	require.NoError(t, os.WriteFile(goFile, []byte(content), 0o644))

	directives, err := collectDirectives(dir)
	require.NoError(t, err)

	// Only 2 real directives: erraudit (line 6) and legacyerrors (line 7)
	// Line 5 doc comment, line 8 wrapcheck, line 10 string literal = all excluded
	assert.Len(t, directives, 2, "expected exactly 2 real directives")

	var foundErraudit, foundLegacy bool

	for _, d := range directives {
		switch d.Line {
		case 6:
			foundErraudit = true
			assert.Equal(t, "real directive", d.Reason)
		case 7:
			foundLegacy = true
		}
	}

	assert.True(t, foundErraudit, "erraudit directive on line 6 not found")
	assert.True(t, foundLegacy, "legacyerrors directive on line 7 not found")
}

func TestIsRemovableDirective(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name string
		line string
		want bool
	}{
		{"erraudit standalone", "//nolint:erraudit", true},
		{"erraudit trailing", "return err //nolint:erraudit", true},
		{"erraudit with reason", "return err //nolint:erraudit // reason", true},
		{"legacyerrors", "//nolint:legacyerrors", true},
		{"erraudit with rule", "//nolint:erraudit:legacy_as // reason", true},
		{"bare nolint not removable", "//nolint", false},
		{"multi-linter not removable", "//nolint:wrapcheck,erraudit", false},
		{"other linter not removable", "//nolint:wrapcheck", false},
		{"no directive", "return err", false},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			assert.Equal(t, tt.want, isRemovableDirective(tt.line))
		})
	}
}

func TestRemoveNolintFromLine(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name      string
		line      string
		wantNew   string
		wantFound bool
	}{
		{"trailing comment", "return err //nolint:erraudit", "return err", true},
		{"trailing with reason", "return err //nolint:erraudit // FP", "return err", true},
		{"standalone comment", "//nolint:erraudit", "", true},
		{"standalone with reason", "//nolint:erraudit // reason", "", true},
		{"no directive", "return err", "return err", false},
		{"code with other comment", "x := 1 // regular comment", "x := 1 // regular comment", false},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			gotNew, gotFound := removeNolintFromLine(tt.line)
			assert.Equal(t, tt.wantNew, gotNew)
			assert.Equal(t, tt.wantFound, gotFound)
		})
	}
}

func TestApplyFix_RemovesStaleDirectives(t *testing.T) {
	t.Parallel()

	dir := t.TempDir()

	goFile := filepath.Join(dir, "test.go")
	absFile, err := filepath.Abs(goFile)
	require.NoError(t, err)

	content := "package main\n" +
		"\n" +
		"var A = 1 //nolint:erraudit // stale\n" +
		"var B = 2 //nolint:erraudit // also stale\n"
	require.NoError(t, os.WriteFile(goFile, []byte(content), 0o644))

	statuses := []directiveStatus{
		{Directive: nolintDirective{File: absFile, Line: 3, Content: "var A = 1 //nolint:erraudit // stale"}},
		{Directive: nolintDirective{File: absFile, Line: 4, Content: "var B = 2 //nolint:erraudit // also stale"}},
	}

	removed, _, err := applyFix(statuses)
	require.NoError(t, err)
	assert.Equal(t, 2, removed)

	fixed, err := os.ReadFile(goFile)
	require.NoError(t, err)

	fixedStr := string(fixed)
	assert.NotContains(t, fixedStr, "//nolint:erraudit", "all directives should be removed")
	assert.Contains(t, fixedStr, "var A = 1", "code should remain")
	assert.Contains(t, fixedStr, "var B = 2", "code should remain")
}

func TestApplyFix_PreservesNeededDirectives(t *testing.T) {
	t.Parallel()

	dir := t.TempDir()

	goFile := filepath.Join(dir, "test.go")
	absFile, err := filepath.Abs(goFile)
	require.NoError(t, err)

	content := "package main\n" +
		"\n" +
		"var A = 1 //nolint:erraudit // needed\n" +
		"var B = 2 //nolint:erraudit // stale\n"
	require.NoError(t, os.WriteFile(goFile, []byte(content), 0o644))

	statuses := []directiveStatus{
		{
			Directive: nolintDirective{File: absFile, Line: 3, Content: "var A = 1 //nolint:erraudit // needed"},
			Needed:    true,
		},
		{Directive: nolintDirective{File: absFile, Line: 4, Content: "var B = 2 //nolint:erraudit // stale"}},
	}

	removed, _, err := applyFix(statuses)
	require.NoError(t, err)
	assert.Equal(t, 1, removed, "only the stale directive should be removed")

	fixed, err := os.ReadFile(goFile)
	require.NoError(t, err)

	lines := strings.Split(string(fixed), "\n")
	// Line 3 should still have the directive
	assert.Contains(t, lines[2], "//nolint:erraudit", "needed directive on line 3 should remain")
	// Line 4 should not
	assert.NotContains(t, lines[3], "//nolint", "stale directive on line 4 should be removed")
}

func TestApplyFix_SkipsMultiLinterDirectives(t *testing.T) {
	t.Parallel()

	dir := t.TempDir()

	goFile := filepath.Join(dir, "test.go")
	absFile, err := filepath.Abs(goFile)
	require.NoError(t, err)

	content := "package main\n" +
		"\n" +
		"var A = 1 //nolint:wrapcheck,erraudit // stale but multi-linter\n"
	require.NoError(t, os.WriteFile(goFile, []byte(content), 0o644))

	statuses := []directiveStatus{
		{
			Directive: nolintDirective{
				File:    absFile,
				Line:    3,
				Content: "var A = 1 //nolint:wrapcheck,erraudit // stale but multi-linter",
			},
		},
	}

	removed, _, err := applyFix(statuses)
	require.NoError(t, err)
	assert.Equal(t, 0, removed, "multi-linter directives must not be auto-removed")

	fixed, err := os.ReadFile(goFile)
	require.NoError(t, err)
	assert.Contains(t, string(fixed), "//nolint:wrapcheck,erraudit", "directive should be untouched")
}

func TestValidateAuditFormat(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		format  string
		wantErr bool
	}{
		{name: "text is valid", format: "text", wantErr: false},
		{name: "json is valid", format: "json", wantErr: false},
		{name: "xml is invalid", format: "xml", wantErr: true},
		{name: "csv is invalid", format: "csv", wantErr: true},
		{name: "yaml is invalid", format: "yaml", wantErr: true},
		{name: "uppercase JSON is invalid", format: "JSON", wantErr: true},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			err := validateAuditFormat(tt.format)
			if tt.wantErr {
				assert.Error(t, err, "format %q should be rejected", tt.format)
			} else {
				assert.NoError(t, err, "format %q should be accepted", tt.format)
			}
		})
	}
}

func TestPrintJSONOutput_Structure(t *testing.T) {
	t.Parallel()

	statuses := []directiveStatus{
		{
			Directive: nolintDirective{
				File:    "main.go",
				Line:    10,
				Content: "//nolint:erraudit",
				Reason:  "false positive",
			},
			Needed: true,
			Violation: &types.ErrorViolation{
				Type:    types.ErrorTypeIgnored,
				Message: "error from foo() is discarded",
			},
		},
		{
			Directive: nolintDirective{File: "util.go", Line: 5, Content: "//nolint:erraudit", Reason: ""},
			Needed:    false,
		},
	}

	var buf bytes.Buffer

	err := printJSONOutput(&buf, statuses, 1)
	require.NoError(t, err)

	var report auditReport

	err = json.Unmarshal(buf.Bytes(), &report)
	require.NoError(t, err, "output must be valid JSON")

	assert.Equal(t, 2, report.Summary.Total, "summary total should match number of statuses")
	assert.Equal(t, 1, report.Summary.Needed, "one needed directive")
	assert.Equal(t, 1, report.Summary.Stale, "one stale directive")
	assert.Equal(t, 1, report.Summary.Removed, "removed count should match input")

	require.Len(t, report.Directives, 2, "should have two directive entries")

	d0 := report.Directives[0]
	assert.Equal(t, "needed", d0.Status, "first directive should be needed")
	assert.NotEmpty(t, d0.File, "file should be set")
	assert.Equal(t, 10, d0.Line, "line should match")
	assert.Equal(t, "false positive", d0.Reason, "reason should match")
	require.NotNil(t, d0.Suppresses, "needed directive should have suppresses info")
	assert.Equal(t, string(types.ErrorTypeIgnored), d0.Suppresses.Type, "suppresses type should match violation")
	assert.NotEmpty(t, d0.Suppresses.Message, "suppresses message should be non-empty")

	d1 := report.Directives[1]
	assert.Equal(t, "stale", d1.Status, "second directive should be stale")
	assert.Nil(t, d1.Suppresses, "stale directive should not have suppresses info")
}

func TestPrintJSONOutput_Empty(t *testing.T) {
	t.Parallel()

	var buf bytes.Buffer

	err := printJSONOutput(&buf, nil, 0)
	require.NoError(t, err)

	var report auditReport

	err = json.Unmarshal(buf.Bytes(), &report)
	require.NoError(t, err)

	assert.Equal(t, 0, report.Summary.Total)
	assert.Equal(t, 0, report.Summary.Needed)
	assert.Equal(t, 0, report.Summary.Stale)
	assert.Equal(t, 0, report.Summary.Removed)
	assert.Empty(t, report.Directives)
}

func TestApplyFix_MultiFile(t *testing.T) {
	t.Parallel()

	dir := t.TempDir()

	fileA := filepath.Join(dir, "a.go")
	fileB := filepath.Join(dir, "b.go")

	sourceA := "package main\n\nvar _ = 1 //nolint:erraudit // stale\nvar _ = 2\n"
	sourceB := "package main\n\nvar _ = 3 //nolint:erraudit // stale\nvar _ = 4\n"

	require.NoError(t, os.WriteFile(fileA, []byte(sourceA), 0o644))
	require.NoError(t, os.WriteFile(fileB, []byte(sourceB), 0o644))

	statuses := []directiveStatus{
		{Directive: nolintDirective{File: fileA, Line: 3, Content: "//nolint:erraudit"}},
		{Directive: nolintDirective{File: fileB, Line: 3, Content: "//nolint:erraudit"}},
	}

	removed, filesFixed, err := applyFix(statuses)
	require.NoError(t, err)
	assert.Equal(t, 2, removed, "should remove 2 directives total")
	assert.Equal(t, 2, filesFixed, "should modify 2 files")

	fixedA, err := os.ReadFile(fileA)
	require.NoError(t, err)
	assert.NotContains(t, string(fixedA), "//nolint:erraudit", "file A should have directive removed")

	fixedB, err := os.ReadFile(fileB)
	require.NoError(t, err)
	assert.NotContains(t, string(fixedB), "//nolint:erraudit", "file B should have directive removed")
}

func TestPreviewFix(t *testing.T) {
	t.Parallel()

	dir := t.TempDir()
	goFile := filepath.Join(dir, "stale.go")

	require.NoError(t, os.WriteFile(goFile, []byte("package main\n\nvar _ = 1 //nolint:erraudit // stale\n"), 0o644))

	statuses := []directiveStatus{
		{Directive: nolintDirective{File: goFile, Line: 3, Content: "//nolint:erraudit // stale"}},
		{Directive: nolintDirective{File: goFile, Line: 5, Content: "//nolint:wrapcheck,erraudit"}, Needed: true},
	}

	var buf bytes.Buffer

	previewFix(&buf, statuses)

	output := buf.String()
	assert.Contains(t, output, "Would remove:", "should show preview of what would be removed")
	assert.Contains(t, output, "stale.go:3", "should reference the file and line")
	assert.Contains(t, output, "1 directive(s) would be removed", "should count removable directives")
	assert.NotContains(t, output, "stale.go:5", "should not list needed directives")

	originalContent, err := os.ReadFile(goFile)
	require.NoError(t, err)
	assert.Contains(t, string(originalContent), "//nolint:erraudit", "file must NOT be modified during dry-run")
}

func TestPreviewFix_NoStale(t *testing.T) {
	t.Parallel()

	statuses := []directiveStatus{
		{Directive: nolintDirective{File: "a.go", Line: 1, Content: "//nolint:erraudit"}, Needed: true},
	}

	var buf bytes.Buffer

	previewFix(&buf, statuses)

	assert.Contains(t, buf.String(), "no removable stale directives found")
}
