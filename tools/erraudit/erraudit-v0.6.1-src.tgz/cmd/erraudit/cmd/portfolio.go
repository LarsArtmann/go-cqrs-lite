//go:build portfolio

package cmd

import (
	"context"
	"encoding/json/v2"
	"fmt"
	"os"
	"path/filepath"
	"time"

	v4 "github.com/larsartmann/cmdguard/v4/pkg/cmdguard/v4"
	"github.com/larsartmann/erraudit/internal/portfolio"
	apierrors "github.com/larsartmann/erraudit/pkg/errors"
	"github.com/larsartmann/erraudit/pkg/types"
	gooutput "github.com/larsartmann/go-output"
	"github.com/spf13/cobra"
)

// defaultPortfolioSearchPaths mirrors the projects-management-automation
// defaults so both tools sweep the same fleet out of the box. A function, not
// a var: callers must never mutate a shared default slice.
func defaultPortfolioSearchPaths() []string {
	return []string{
		"~/projects",
		"~/GolandProjects",
		"~/IdeaProjects",
		"~/WebStormProjects",
	}
}

// defaultPortfolioFormat is the report format when --format was not set
// explicitly (the inherited default "tree" means nothing for a report).
const defaultPortfolioFormat = "table"

func registerPortfolioCommand(cli *v4.CLI[AppConfig]) error {
	cmd, err := v4.NewCommand[AppConfig, PortfolioFlags](
		"portfolio",
		PortfolioFlags{
			SearchPaths: nil,
			SortBy:      string(portfolio.DefaultSortBy),
			ShowAll:     false,
			Concurrency: portfolio.DefaultConcurrency,
		},
		runPortfolioHandler,
		v4.WithShort("Audit every discovered Go project and aggregate the results"),
		v4.WithLong(`Run the full erraudit analysis across every Go project discovered
under the search paths and report one aggregated row per project — the
fleet-wide counterpart to running erraudit manually in each repository.

Each project is analyzed by re-invoking this binary with the audit flags
you set (--type-aware, --enforce-*, --no-suppress, --explain, ...), so a
fleet run behaves exactly like your manual per-project runs. Nested
go.mod modules are covered by forwarding --modules=all.

Discovery uses project-discovery-sdk (Go projects, cached). Positional
arguments bypass discovery and audit exactly those directories instead.

Report formats: --format table (default), json, csv, tsv, markdown, yaml.
Exit codes follow the analyze contract: 0 clean, 2 violations found,
1 error (e.g. discovery failed).`),
		v4.WithExample(`  # Fleet audit with the aggressive flag set
  erraudit portfolio --type-aware --enforce-go-error-family --no-suppress \\
  --enforce-samber-oops --enforce-generic-return --explain

  # Audit two specific projects, sorted by critical findings
  erraudit portfolio ~/projects/erraudit ~/projects/go-ndjson --sort-by critical

  # Machine-readable report
  erraudit portfolio -f json > portfolio.json`),
		v4.WithArgs(cobra.ArbitraryArgs),
	)

	return registerCommand(cli, "portfolio", cmd, err)
}

func runPortfolioHandler(ctx context.Context, cfg *AppConfig, flags PortfolioFlags) error {
	sortBy, err := portfolio.ParseSortBy(flags.SortBy)
	if err != nil {
		return apierrors.Wrap(apierrors.ErrConfigInvalid, "%s", err.Error())
	}

	refs, err := portfolioRefs(ctx, flags)
	if err != nil {
		return err
	}

	if len(refs) == 0 {
		fmt.Fprintln(os.Stderr, "No Go projects found under the configured search paths.")
		fmt.Fprintln(os.Stderr, "Hint: pass --search-path or explicit project directories as arguments.")

		return nil
	}

	if cfg.TypeAware {
		fmt.Fprintln(os.Stderr, "portfolio: type-aware analysis is on — full sweeps may take several minutes.")
	}

	auditCfg := portfolio.AuditConfig{
		TypeAware:            cfg.TypeAware,
		EnforceErrorFamily:   cfg.EnforceErrorFamily,
		EnforceSamberOops:    cfg.EnforceSamberOops,
		EnforceGenericReturn: cfg.EnforceGenericReturn,
		EnforceDeferredClose: cfg.EnforceDeferredClose,
		EnforceCodedErrors:   cfg.EnforceCodedErrors,
		NoSuppress:           cfg.NoSuppress,
		Explain:              cfg.Explain,
		DisableExtensions:    true,
		Disable:              cfg.Disable,
		Exclude:              cfg.Exclude,
		ModulesAll:           cfg.Modules == ModulesAllMode,
		Severity:             cfg.Severity,
		Type:                 cfg.Type,
		SeverityThreshold:    cfg.SeverityThreshold,
	}

	orchestrator := &portfolio.Orchestrator{
		Runner:      portfolio.NewSelfExecRunner(),
		Concurrency: flags.Concurrency,
		OnProgress:  portfolioProgressPrinter(cfg),
	}

	report := orchestrator.Run(ctx, refs, auditCfg)

	if !flags.ShowAll {
		portfolio.HideZeroViolations(report)
	}

	portfolio.SortResults(report.Projects, sortBy)

	if writeErr := writePortfolioReport(ctx, cfg, report); writeErr != nil {
		return writeErr
	}

	if report.Summary.Violations > 0 {
		return ErrViolationsFound
	}

	return nil
}

// portfolioRefs resolves the audit targets: explicit positional directories
// when given, otherwise SDK discovery over the (defaulted) search paths.
func portfolioRefs(ctx context.Context, flags PortfolioFlags) ([]portfolio.ProjectRef, error) {
	if args := argsFromContext(ctx); len(args) > 0 {
		return explicitProjectRefs(args)
	}

	paths := flags.SearchPaths
	if len(paths) == 0 {
		paths = defaultPortfolioSearchPaths()
	}

	expanded := make([]string, 0, len(paths))
	for _, candidate := range paths {
		resolved, err := portfolio.ExpandPath(candidate)
		if err != nil {
			return nil, apierrors.Wrap(err, "resolve search path %q", candidate)
		}

		expanded = append(expanded, resolved)
	}

	refs, err := portfolio.SDKDiscoverer{}.DiscoverProjects(ctx, portfolio.SearchConfig{Paths: expanded})
	if err != nil {
		return nil, apierrors.Wrap(err, "discover fleet projects")
	}

	return refs, nil
}

// explicitProjectRefs turns positional arguments into project refs, one per
// directory (the argument itself, not its children — argument means "this
// project").
func explicitProjectRefs(args []string) ([]portfolio.ProjectRef, error) {
	refs := make([]portfolio.ProjectRef, 0, len(args))

	for _, arg := range args {
		resolved, err := portfolio.ExpandPath(arg)
		if err != nil {
			return nil, apierrors.Wrap(err, "resolve project directory %q", arg)
		}

		absolute, err := filepath.Abs(resolved)
		if err != nil {
			return nil, apierrors.Wrap(err, "absolutize project directory %q", resolved)
		}

		refs = append(refs, portfolio.ProjectRef{Name: filepath.Base(absolute), Path: absolute})
	}

	return refs, nil
}

// portfolioProgressPrinter streams per-project progress on stderr unless
// quiet. Simple line updates: the fleet report is the product, not the
// progress display.
func portfolioProgressPrinter(cfg *AppConfig) func(done, total int) {
	if cfg.Quiet {
		return nil
	}

	started := time.Now()

	return func(done, total int) {
		fmt.Fprintf(
			os.Stderr,
			"portfolio: %d/%d projects analyzed (%.0fs elapsed)\r",
			done,
			total,
			time.Since(started).Seconds(),
		)
	}
}

// writePortfolioReport renders the report in the requested format: json is
// the full structured report, every other supported go-output format renders
// the tabular view plus the summary and failures sections. An unset --format
// defaults to table (the inherited default "tree" means nothing here).
func writePortfolioReport(ctx context.Context, cfg *AppConfig, report *portfolio.Report) error {
	format := cfg.Format
	if explicitlySet, ok := ctx.Value(formatChangedKey{}).(bool); !ok || !explicitlySet {
		format = defaultPortfolioFormat
	}

	writer, closer, err := newOutputWriter(cfg.Output, os.Stdout)
	if err != nil {
		return apierrors.Wrap(err, "open portfolio output")
	}

	defer closer()

	if format == string(types.FormatJSON) {
		encoded, err := json.Marshal(report)
		if err != nil {
			return apierrors.Wrap(err, "encode portfolio report")
		}

		if _, err := fmt.Fprintln(writer, string(encoded)); err != nil {
			return apierrors.Wrap(err, "write portfolio report")
		}

		return nil
	}

	if err := gooutput.RenderTable(portfolio.ReportTable(report), gooutput.Format(format), gooutput.RenderOptions{
		Title:  "Error-Handling Portfolio Audit",
		Writer: writer,
	}); err != nil {
		return apierrors.Wrap(apierrors.ErrOutput, "render portfolio report: %s", err.Error())
	}

	portfolio.WriteHiddenNotice(writer, report.Summary.ProjectsHidden)
	portfolio.WriteSummary(writer, report.Summary)
	portfolio.WriteFailures(writer, report.Failures)

	return nil
}
