package cmd

import (
	"bytes"
	"os"
	"testing"

	"github.com/larsartmann/erraudit/cmd/erraudit/cmd/pipeline"
	"github.com/larsartmann/erraudit/internal/fix"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestResolveFixTarget_Directory(t *testing.T) {
	t.Parallel()

	tmpDir := t.TempDir()

	dir, patterns, err := pipeline.ResolveTarget([]string{tmpDir})
	require.NoError(t, err)
	assert.Equal(t, tmpDir, dir)
	assert.Equal(t, []string{"."}, patterns)
}

func TestResolveFixTarget_File(t *testing.T) {
	t.Parallel()

	tmpDir := t.TempDir()
	path := tmpDir + "/main.go"
	require.NoError(t, os.WriteFile(path, []byte("package main"), 0o644))

	dir, patterns, err := pipeline.ResolveTarget([]string{path})
	require.NoError(t, err)
	assert.Empty(t, dir)
	assert.Equal(t, []string{path}, patterns)
}

func TestResolveFixTarget_MultipleArgs(t *testing.T) {
	t.Parallel()

	args := []string{"./...", "./pkg/..."}
	dir, patterns, err := pipeline.ResolveTarget(args)
	require.NoError(t, err)
	assert.Empty(t, dir)
	assert.Equal(t, args, patterns)
}

func TestResolveFixTarget_MissingPath(t *testing.T) {
	t.Parallel()

	_, _, err := pipeline.ResolveTarget([]string{"/does/not/exist"})
	require.Error(t, err)
}

func TestPrintNoFixesMessage_ZeroDiagnostics(t *testing.T) {
	t.Parallel()

	var buf bytes.Buffer
	printNoFixesMessage(&buf, fix.Summary{})

	output := buf.String()
	assert.Contains(t, output, "No fixes found.")
	assert.NotContains(t, output, "diagnostic")
}

func TestPrintNoFixesMessage_AdvisoryOnly(t *testing.T) {
	t.Parallel()

	var buf bytes.Buffer
	printNoFixesMessage(&buf, fix.Summary{
		TotalDiagnostics: 5,
		AdvisoryCount:    5,
	})

	output := buf.String()
	assert.Contains(t, output, "5 diagnostic(s) detected")
	assert.Contains(t, output, "5 advisory-only")
	assert.Contains(t, output, "errors.Is")
}

func TestPrintNoFixesMessage_UnsupportedPatterns(t *testing.T) {
	t.Parallel()

	var buf bytes.Buffer
	printNoFixesMessage(&buf, fix.Summary{
		TotalDiagnostics: 3,
		FixableCount:     0,
		AdvisoryCount:    0,
	})

	output := buf.String()
	assert.Contains(t, output, "3 diagnostic(s) detected")
	assert.Contains(t, output, "3 in unsupported patterns")
	assert.Contains(t, output, "return statements")
}

func TestPrintNoFixesMessage_MixedCounts(t *testing.T) {
	t.Parallel()

	var buf bytes.Buffer
	printNoFixesMessage(&buf, fix.Summary{
		TotalDiagnostics: 10,
		FixableCount:     3,
		AdvisoryCount:    2,
	})

	output := buf.String()
	assert.Contains(t, output, "10 diagnostic(s) detected")
	assert.Contains(t, output, "2 advisory-only")
	// 10 - 3 - 2 = 5 unfixable
	assert.Contains(t, output, "5 in unsupported patterns")
	// Should mention running lint for details
	assert.Contains(t, output, "lint")
}
