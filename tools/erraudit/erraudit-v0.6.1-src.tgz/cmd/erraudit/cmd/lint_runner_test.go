package cmd

import (
	"bytes"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestWriteLintPlainText_Empty(t *testing.T) {
	t.Parallel()

	var buf bytes.Buffer
	writeLintPlainText(&buf, nil)
	assert.Empty(t, buf.String())
}

func TestWriteLintPlainText_WithoutSuggestion(t *testing.T) {
	t.Parallel()

	violations := []types.ErrorViolation{
		{
			Message: "error returned without wrapping",
			Position: struct {
				Filename string
				Offset   int
				Line     int
				Column   int
			}{
				Filename: "main.go",
				Line:     42,
				Column:   10,
			},
		},
	}

	var buf bytes.Buffer
	writeLintPlainText(&buf, violations)

	assert.Equal(t, "main.go:42:10: error returned without wrapping\n", buf.String())
}

func TestWriteLintPlainText_WithSuggestion(t *testing.T) {
	t.Parallel()

	violations := []types.ErrorViolation{
		{
			Message:    "error returned without wrapping",
			Suggestion: "use fmt.Errorf with %w",
			Position: struct {
				Filename string
				Offset   int
				Line     int
				Column   int
			}{
				Filename: "main.go",
				Line:     42,
				Column:   10,
			},
		},
	}

	var buf bytes.Buffer
	writeLintPlainText(&buf, violations)

	expected := "main.go:42:10: error returned without wrapping (use fmt.Errorf with %w)\n"
	assert.Equal(t, expected, buf.String())
}

func TestWriteLintPlainText_MultilineSuggestion(t *testing.T) {
	t.Parallel()

	violations := []types.ErrorViolation{
		{
			Message:    "error returned without wrapping",
			Suggestion: "use fmt.Errorf\nwith %w\nto wrap",
			Position: struct {
				Filename string
				Offset   int
				Line     int
				Column   int
			}{
				Filename: "main.go",
				Line:     42,
				Column:   10,
			},
		},
	}

	var buf bytes.Buffer
	writeLintPlainText(&buf, violations)

	output := buf.String()
	assert.Contains(t, output, "main.go:42:10:")
	assert.NotContains(t, output, "\nwith")
	assert.Contains(t, output, "use fmt.Errorf with %w to wrap")
}

func TestGetExitCodeForLegacyerrorsLint(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name string
		err  error
		want int
	}{
		{"nil error returns 0", nil, 0},
		{"violations found returns 2", ErrViolationsFound, ExitViolationsFound},
		{"wrapped violations found returns 2", fmt.Errorf("context: %w", ErrViolationsFound), ExitViolationsFound},
		{"other error returns 1", errors.New("infrastructure failure"), ExitError},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			assert.Equal(t, tt.want, GetExitCodeForLegacyerrorsLint(tt.err))
		})
	}
}

func TestLintOutputWriter_Stdout(t *testing.T) {
	t.Parallel()

	cfg := &AppConfig{Output: ""}

	writer, closeFn, err := lintOutputWriter(cfg)
	require.NoError(t, err)
	assert.NotNil(t, writer)
	closeFn()
}

func TestLintOutputWriter_File(t *testing.T) {
	t.Parallel()

	tmpFile := filepath.Join(t.TempDir(), "lint-output.txt")
	cfg := &AppConfig{Output: tmpFile}

	writer, closeFn, err := lintOutputWriter(cfg)
	require.NoError(t, err)
	assert.NotNil(t, writer)

	_, writeErr := writer.Write([]byte("test output\n"))
	require.NoError(t, writeErr)
	closeFn()

	content, err := os.ReadFile(tmpFile)
	require.NoError(t, err)
	assert.Equal(t, "test output\n", string(content))
}

func TestLintOutputWriter_InvalidPath(t *testing.T) {
	t.Parallel()

	cfg := &AppConfig{Output: "/nonexistent/dir/output.txt"}

	_, _, err := lintOutputWriter(cfg)
	require.Error(t, err)
	assert.Contains(t, err.Error(), "failed to create output file")
}
