package cmd

import (
	"context"
	"fmt"
	"io"
	"os"

	v4 "github.com/larsartmann/cmdguard/v4/pkg/cmdguard/v4"
	"github.com/larsartmann/erraudit/cmd/erraudit/cmd/pipeline"
	"github.com/larsartmann/erraudit/internal/fix"
	apierrors "github.com/larsartmann/erraudit/pkg/errors"
	"github.com/larsartmann/erraudit/pkg/extension/hooks"
	"github.com/larsartmann/erraudit/pkg/lint/legacyerrors"
	"github.com/larsartmann/erraudit/pkg/lint/oopsfix"
	"github.com/spf13/cobra"
)

func registerFixCommand(cli *v4.CLI[AppConfig]) error {
	cmd, err := v4.NewCommand[AppConfig, FixFlags](
		"fix [path]",
		FixFlags{},
		runFixHandler,
		v4.WithShort("Auto-fix legacy error handling patterns in Go code"),
		v4.WithLong(`Automatically fix legacy error handling patterns in Go source files.

Currently supports:
  - errors.As(err, &target) → target, _ = errors.AsType[TargetType](err)
    (standalone expression; only when target is used afterward)
  - if errors.As(err, &target) { → if target, ok := errors.AsType[TargetType](err); ok {
  - if !errors.As(err, &target) { → target, ok := errors.AsType[TargetType](err); if !ok {
  - ok := errors.As(err, &target) → target, ok := errors.AsType[TargetType](err)
  - Redundant nil guard before oops.Wrap/Wrapf:
    if err != nil { return oops.Wrap(err) }; return nil → return oops.Wrap(err)

All patterns remove the redundant var declaration when safe (scope analysis prevents
unsafe removals). errors.Is is advisory-only (not auto-fixable) because it matches
by value, not type.

Dry-run is the default. Use -w to apply changes.`),
		v4.WithExample(`  # Preview fixes (dry-run)
  erraudit fix ./...

  # Apply fixes
  erraudit fix ./... -w`),
		v4.WithArgs(cobra.MinimumNArgs(1)),
	)

	return registerCommand(cli, "fix", cmd, err)
}

func runFixHandler(ctx context.Context, cfg *AppConfig, flags FixFlags) error {
	args := argsFromContext(ctx)

	dir, patterns, err := pipeline.ResolveTarget(args)
	if err != nil {
		return apierrors.Wrap(err, "resolve fix target")
	}

	runner := fix.NewRunner(legacyerrors.Analyzer, oopsfix.Analyzer)

	fixes, summary, err := runner.Run(ctx, dir, patterns)
	if err != nil {
		return apierrors.Wrap(err, "run fix analysis")
	}

	if len(fixes) == 0 {
		printNoFixesMessage(os.Stdout, summary)

		return nil
	}

	// Filter out fixes for excluded paths.
	fixes = fix.FilterExcluded(fixes, cfg.Exclude)

	// Respect //nolint:erraudit (and //nolint:legacyerrors / bare //nolint)
	// directives so the fix command does not auto-fix code the user explicitly
	// suppressed. Bypassed by --no-suppress, consistent with the other commands.
	if !cfg.NoSuppress {
		fixes = fix.FilterSuppressed(fixes)
	}

	if len(fixes) == 0 {
		fmt.Fprintln(os.Stdout, "No fixes found after applying exclusions.")

		return nil
	}

	applier := fix.NewApplier()
	if flags.NoBackup {
		applier.WithNoBackup()
	}

	changes, err := applier.Apply(fixes)
	if err != nil {
		return apierrors.Wrap(err, "apply fixes")
	}

	var changedCount int

	for _, c := range changes {
		if c.Changed() {
			changedCount++
		}
	}

	if changedCount == 0 {
		fmt.Fprintln(os.Stdout, "No changes needed.")

		return nil
	}

	if flags.Write {
		return applyFixes(ctx, applier, changes, changedCount)
	}

	diff := fix.FormatDiff(changes)
	if diff != "" {
		fmt.Fprintln(os.Stdout, diff)
	}

	fmt.Fprintf(
		os.Stdout,
		"%d file(s) would be changed. Run with -w to apply.\n",
		changedCount,
	)

	return ErrViolationsFound
}

// applyFixes writes changes to disk and executes pre/post hooks.
func applyFixes(
	ctx context.Context,
	applier *fix.Applier,
	changes []fix.FileChange,
	changedCount int,
) error {
	fixPaths := make([]string, 0, len(changes))
	for _, c := range changes {
		if c.Changed() {
			fixPaths = append(fixPaths, c.Path)
		}
	}

	_, cancelled, err := hooks.Fire(ctx, hooks.HookPreFix, &hooks.PreFixData{Fixes: fixPaths})
	if err != nil {
		return apierrors.Wrap(err, "pre-fix hook failed (fixes=%d)", changedCount)
	}

	if cancelled {
		return apierrors.ErrFixCancelledByHook
	}

	err = applier.Write(changes)
	if err != nil {
		return apierrors.Wrap(err, "write fixes (files=%d)", changedCount)
	}

	hooks.Notify(ctx, hooks.HookPostFix, &hooks.PostFixData{
		Fixes:       fixPaths,
		ChangeCount: changedCount,
	})

	fmt.Fprintf(os.Stdout, "Applied fixes to %d file(s).\n", changedCount)

	return ErrViolationsFound
}

// printNoFixesMessage explains why no fixes were found.
func printNoFixesMessage(writer io.Writer, summary fix.Summary) {
	if summary.TotalDiagnostics == 0 {
		fmt.Fprintln(writer, "No fixes found.")

		return
	}

	fmt.Fprintf(writer, "No auto-fixable violations found (%d diagnostic(s) detected).\n", summary.TotalDiagnostics)

	if summary.AdvisoryCount > 0 {
		fmt.Fprintf(
			writer,
			"  %d advisory-only: errors.Is is not auto-fixable (value matching vs type matching).\n",
			summary.AdvisoryCount,
		)
	}

	unfixable := summary.TotalDiagnostics - summary.FixableCount - summary.AdvisoryCount
	if unfixable > 0 {
		fmt.Fprintf(
			writer,
			"  %d in unsupported patterns: errors.As in return statements, compound conditions, or with unused targets.\n",
			unfixable,
		)
	}

	fmt.Fprintln(writer, "\nRun 'erraudit lint' to see all violations with details.")
}
