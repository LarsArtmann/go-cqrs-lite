package cmd

// type_help_test.go guards the --type help generation (2026-09-22): the flag
// help is generated from types.ValidErrorTypes at CLI construction instead of
// a hand-maintained list in the AppConfig struct tag. The hand-maintained
// version had already drifted (sentinel_concrete_type shipped without a help
// update). These tests fail when either the generator or the wiring breaks.

import (
	"strings"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestTypeFilterHelpText_ListsEveryRegisteredType(t *testing.T) {
	help := typeFilterHelpText()

	for _, et := range types.ValidErrorTypes() {
		assert.Contains(t, help, string(et), "type %q must appear in the generated --type help", et)
	}

	assert.True(t, strings.HasPrefix(help, "Filter violations by type ("),
		"help must keep its user-facing prefix, got: %q", help)
}

func TestTypeFilterHelpText_WiredOntoRootFlag(t *testing.T) {
	cli, err := buildCLI("test", nil)
	require.NoError(t, err)

	typeFlag := cli.RootCommand().PersistentFlags().Lookup("type")
	require.NotNil(t, typeFlag, "--type must be a persistent root flag")

	assert.Equal(t, typeFilterHelpText(), typeFlag.Usage,
		"the root --type flag help must be the registry-generated text (wiring lives in buildCLI)")
}
