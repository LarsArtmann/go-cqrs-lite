package cmd

import (
	"context"
	"errors"
	"fmt"
	"io"
	"os"
	"strings"

	v4 "github.com/larsartmann/cmdguard/v4/pkg/cmdguard/v4"
	"github.com/larsartmann/erraudit/cmd/erraudit/cmd/pipeline"
	"github.com/larsartmann/erraudit/internal/analyzer"
	apierrors "github.com/larsartmann/erraudit/pkg/errors"
	"github.com/larsartmann/erraudit/pkg/types"
)

func runLintHandler(ctx context.Context, cfg *AppConfig, _ v4.NoFlags) error {
	args := argsFromContext(ctx)
	if len(args) == 0 {
		args = []string{defaultLintPattern}
	}

	if cfg.Verbose {
		fmt.Fprintf(os.Stdout, "Linting: %v\n", args)
	}

	result, err := analyzer.RunLegacyerrorsForPatterns(args)
	if err != nil {
		return apierrors.Wrap(err, "legacyerrors analysis failed")
	}

	violations := result.Violations

	// When --enforce-generic-return is active, also run the AST-based
	// analyzer to detect generic_return violations. The legacyerrors path
	// (go/analysis) does not produce these; only the AST ViolationDetector does.
	if cfg.EnforceGenericReturn {
		for _, arg := range args {
			// EnforceGenericReturn is forced on: the legacyerrors path
			// (go/analysis) does not produce these; only the AST
			// ViolationDetector does. ModulesAll/Progress stay false (lint
			// resolves patterns per-argument, quiet path); Suppress/Explain
			// stay false: the merged violation set is finalized (suppressed +
			// explained) further down.
			spec := pipeline.AnalysisSpec{
				Path:                 arg,
				ExcludedPaths:        cfg.Exclude,
				TypeAware:            cfg.TypeAware,
				EnforceErrorFamily:   cfg.EnforceErrorFamily,
				EnforceSamberOops:    cfg.EnforceSamberOops,
				EnforceGenericReturn: true,
				EnforceDeferredClose: cfg.EnforceDeferredClose,
				EnforceCodedErrors:   cfg.EnforceCodedErrors,
				NoSuppress:           cfg.NoSuppress,
				ModulesAll:           false,
				Progress:             false,
				Suppress:             false,
				Explain:              false,
			}

			_, astViolations, astErr := pipeline.PerformAnalysisWithSpec(ctx, spec)
			if astErr != nil {
				if cfg.Verbose {
					fmt.Fprintf(os.Stderr, "Warning: generic_return analysis failed for %s: %v\n", arg, astErr)
				}

				continue
			}

			for _, v := range astViolations {
				if v.Type == types.ErrorTypeGenericReturn {
					violations = append(violations, v)
				}
			}
		}
	}

	// Apply severity / type / severity-threshold filters
	violations = pipeline.FilterViolations(
		violations,
		cfg.SeverityFilterPtr(),
		cfg.TypeFilterPtr(),
		cfg.SeverityThresholdPtr(),
		cfg.DisabledTypesSet(),
	)

	// Suppression + explanations via the shared finishing step so the lint
	// path cannot disagree with analyze/watch/--pipeline.
	violations = pipeline.FinalizeViolations(violations, result.SourceFiles, cfg.NoSuppress, cfg.Explain)

	// Build a minimal graph for output strategies
	graph := &types.ErrorGraph{Violations: violations}

	// Determine output
	if err := withOutputWriter(
		func() (io.Writer, func(), error) { return lintOutputWriter(cfg) },
		func(writer io.Writer) error {
			if formatExplicitlySet(ctx) {
				outputStr, err := pipeline.GenerateOutputString(
					cfg.OutputFormatType(), cfg.DOTTheme, cfg.ViolationsOnly,
					graph, violations,
				)
				if err != nil {
					return apierrors.Wrap(err, "generate %s output", cfg.OutputFormatType())
				}

				if _, err := io.WriteString(writer, outputStr); err != nil {
					return apierrors.Wrap(err, "write output")
				}
			} else {
				writeLintPlainText(writer, violations)
			}

			return nil
		},
	); err != nil {
		return err
	}

	if cfg.Verbose {
		fmt.Fprintf(os.Stdout, "Found %d violation(s).\n", len(violations))
	}

	return violationsFoundError(len(violations))
}

func writeLintPlainText(writer io.Writer, violations []types.ErrorViolation) {
	for _, v := range violations {
		pos := v.Position
		fmt.Fprintf(writer, "%s:%d:%d: %s", pos.Filename, pos.Line, pos.Column, v.Message)

		if v.Suggestion != "" {
			suggestion := strings.ReplaceAll(v.Suggestion, "\n", " ")
			fmt.Fprintf(writer, " (%s)", suggestion)
		}

		fmt.Fprintln(writer)
	}
}

func lintOutputWriter(cfg *AppConfig) (io.Writer, func(), error) {
	return newOutputWriter(cfg.Output, os.Stdout)
}

func GetExitCodeForLegacyerrorsLint(err error) int {
	if err == nil {
		return 0
	}

	if errors.Is(err, ErrViolationsFound) {
		return ExitViolationsFound
	}

	return ExitError
}
