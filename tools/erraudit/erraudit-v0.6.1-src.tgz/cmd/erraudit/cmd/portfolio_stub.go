//go:build !portfolio

package cmd

import (
	v4 "github.com/larsartmann/cmdguard/v4/pkg/cmdguard/v4"
)

// registerPortfolioCommand is a no-op in builds without the `portfolio` tag:
// the real subcommand requires the private project-discovery-sdk, which
// credential-free CI cannot fetch. Produced by scripts/make-ci-tarball.sh.
func registerPortfolioCommand(cli *v4.CLI[AppConfig]) error {
	_ = cli
	return nil
}
