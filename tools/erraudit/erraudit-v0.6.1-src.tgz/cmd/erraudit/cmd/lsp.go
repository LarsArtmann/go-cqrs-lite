package cmd

import (
	"context"
	"fmt"
	"net"
	"os"
	"os/signal"
	"syscall"

	v4 "github.com/larsartmann/cmdguard/v4/pkg/cmdguard/v4"
	"github.com/larsartmann/erraudit/internal/lsp"
	apierrors "github.com/larsartmann/erraudit/pkg/errors"
	"github.com/sourcegraph/jsonrpc2"
)

func registerLSPCommand(cli *v4.CLI[AppConfig]) error {
	cmd, err := v4.NewCommand[AppConfig, LSPFlags](
		"lsp",
		LSPFlags{},
		runLSPHandler,
		v4.WithShort("Start the LSP server for editor integration"),
		v4.WithLong(`Start the Erraudit LSP server.

The server communicates via stdio by default. Use --socket to listen on a TCP port.

Examples:
  # Start LSP server on stdio (for editor integration)
  erraudit lsp

  # Start LSP server on TCP port 4389
  erraudit lsp --socket :4389`),
		v4.WithNoArgs(),
	)

	return registerCommand(cli, "lsp", cmd, err)
}

func runLSPHandler(ctx context.Context, _ *AppConfig, flags LSPFlags) error {
	ctx, cancel := context.WithCancel(ctx)
	defer cancel()

	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)

	go func() {
		<-sigChan
		cancel()
	}()

	server := lsp.NewServer()

	if flags.Socket != "" {
		return serveTCP(ctx, server, flags.Socket)
	}

	return serveStdio(ctx, server)
}

// serveStdio runs the LSP server over stdin/stdout.
func serveStdio(ctx context.Context, server *lsp.Server) error {
	stream := jsonrpc2.NewBufferedStream(stdioRWC{}, jsonrpc2.VSCodeObjectCodec{})

	err := server.Serve(ctx, stream)
	if err != nil {
		return apierrors.Wrap(err, "failed to serve stdio")
	}

	return nil
}

// serveTCP runs the LSP server on a TCP socket.
func serveTCP(ctx context.Context, server *lsp.Server, addr string) error {
	listener, err := net.Listen("tcp", addr) //nolint:noctx // intentional: TCP listener does not need context
	if err != nil {
		return apierrors.Wrap(
			err,
			"failed to listen on TCP socket %s (ctx=%v, server=%T)",
			addr, ctx.Err() != nil, server,
		)
	}

	defer func() { _ = listener.Close() }() //nolint:erraudit // deferred cleanup

	fmt.Fprintf(os.Stderr, "LSP server listening on %s\n", addr)

	for {
		select {
		case <-ctx.Done():
			return nil
		default:
		}

		conn, err := listener.Accept()
		if err != nil {
			select {
			case <-ctx.Done():
				return nil
			default:
				return apierrors.Wrap(
					err,
					"failed to accept connection on %s (ctx=%v, server=%T)",
					addr, ctx.Err() != nil, server,
				)
			}
		}

		go func() {
			stream := jsonrpc2.NewBufferedStream(conn, jsonrpc2.VSCodeObjectCodec{})

			err := server.Serve(ctx, stream)
			if err != nil {
				fmt.Fprintf(os.Stderr, "LSP connection error: %v\n", err)
			}
		}()
	}
}

// stdioRWC implements io.ReadWriteCloser using os.Stdin and os.Stdout.
type stdioRWC struct{}

func (stdioRWC) Read(p []byte) (int, error) {
	return stdioOp("read stdin", func() (int, error) {
		return os.Stdin.Read(p)
	})
}

func (stdioRWC) Write(p []byte) (int, error) {
	return stdioOp("write stdout", func() (int, error) {
		return os.Stdout.Write(p)
	})
}

func stdioOp(label string, read func() (int, error)) (int, error) {
	n, err := read()
	if err != nil {
		return 0, apierrors.Wrap(err, "failed to %s", label)
	}

	return n, nil
}

func (stdioRWC) Close() error {
	return nil
}
