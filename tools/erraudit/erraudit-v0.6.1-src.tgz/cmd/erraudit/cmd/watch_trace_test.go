package cmd

import (
	"os"
	"path/filepath"
	"runtime/trace"
	"strings"
	"testing"
	"time"

	"github.com/stretchr/testify/require"
)

func TestFlightRecorderSpike_DumpTrace(t *testing.T) {
	t.Setenv("ERRAUDIT_TRACE", "1")

	recorder := newFlightRecorderSpike(os.Stderr, false)
	require.NotNil(t, recorder, "ERRAUDIT_TRACE=1 must enable the recorder")
	defer recorder.Stop()

	w := &Watcher{out: os.Stdout, flightRecorder: recorder}

	tmp := t.TempDir()
	t.Chdir(tmp)

	w.dumpTrace()

	entries, err := os.ReadDir(tmp)
	require.NoError(t, err)

	var traceFile string

	for _, e := range entries {
		if strings.HasSuffix(e.Name(), ".trace") {
			traceFile = e.Name()
		}
	}

	require.NotEmpty(t, traceFile, "dumpTrace must write a .trace file")

	info, err := os.Stat(filepath.Join(tmp, traceFile))
	require.NoError(t, err)
	require.Positive(t, info.Size(), "trace dump must contain bytes")
}

func TestFlightRecorderSpike_DisabledByDefault(t *testing.T) {
	t.Setenv("ERRAUDIT_TRACE", "")

	require.Nil(t, newFlightRecorderSpike(os.Stderr, false), "recorder must be opt-in")
}

func TestFlightRecorderSpike_EnabledByFlag(t *testing.T) {
	t.Setenv("ERRAUDIT_TRACE", "")

	recorder := newFlightRecorderSpike(os.Stderr, true)
	require.NotNil(t, recorder, "--trace-on-error must enable the recorder")
	defer recorder.Stop()

	require.True(t, recorder.Enabled())
}

// Compile-time guard: the recorder type must satisfy the shape we rely on.
var _ = trace.FlightRecorderConfig{MinAge: time.Second}
