package cmd

import (
	"io"
	"os"

	apierrors "github.com/larsartmann/erraudit/pkg/errors"
)

// newOutputWriter returns a writer for the given output path, or the fallback
// writer if path is empty. When path points to a file, the returned closeFn
// must be called when writing is complete.
//
// This is the shared output-writer factory used by the root analyzer, lint,
// and extension handlers to respect the --output flag consistently.
func newOutputWriter(path string, fallback io.Writer) (io.Writer, func(), error) {
	if path == "" {
		return fallback, func() {}, nil
	}

	file, err := os.OpenFile(path, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, outputFileMode)
	if err != nil {
		return nil, func() {}, apierrors.Wrap(err, "failed to create output file %s", path)
	}

	return file, func() { _ = file.Close() }, nil //nolint:erraudit // deferred cleanup
}

// withOutputWriter acquires an output writer via the supplied acquire function,
// defers its cleanup until fn returns, and invokes fn with the writer. If
// acquire fails, fn is not invoked and the acquisition error is returned.
// Consolidates the acquire-check-defer boilerplate that otherwise repeats
// across the analyze, generate-output, and lint paths.
func withOutputWriter(
	acquire func() (io.Writer, func(), error),
	fn func(io.Writer) error,
) error {
	writer, closeFn, err := acquire()
	if err != nil {
		return err
	}
	defer closeFn()

	return fn(writer)
}
