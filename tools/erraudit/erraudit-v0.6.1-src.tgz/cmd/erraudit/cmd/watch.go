package cmd

import (
	"context"
	"fmt"
	"io"
	"os"
	"os/signal"
	"path/filepath"
	"runtime/trace"
	"sync"
	"syscall"
	"time"

	v4 "github.com/larsartmann/cmdguard/v4/pkg/cmdguard/v4"
	"github.com/larsartmann/erraudit/cmd/erraudit/cmd/pipeline"
	apierrors "github.com/larsartmann/erraudit/pkg/errors"
	"github.com/larsartmann/go-filewatcher/v2"
	"github.com/spf13/cobra"
)

const (
	DefaultDebounceDuration = 500 * time.Millisecond
	vendorDir               = "vendor"
)

type WatchConfig struct {
	DebounceDuration time.Duration
	IgnorePatterns   []string
}

type Watcher struct {
	path         string
	config       *AppConfig
	watchConfig  WatchConfig
	out          io.Writer
	mu           sync.Mutex
	lastAnalysis time.Time

	// traceOnError enables the execution-trace flight recorder via the
	// --trace-on-error flag (the ERRAUDIT_TRACE=1 env remains as an
	// alternative switch for environments where the flag is hard to pass).
	traceOnError bool

	// flightRecorder, when non-nil, keeps a moving execution-trace window
	// and dumps it to a .trace file when an analysis errors (see
	// newFlightRecorderSpike).
	flightRecorder *trace.FlightRecorder
}

const (
	traceRingMinAge   = 30 * time.Second
	traceRingMaxBytes = 8 << 20
)

//nolint:gochecknoglobals // Constant default configuration for watch mode
var DefaultWatchConfig = WatchConfig{
	DebounceDuration: DefaultDebounceDuration,
	IgnorePatterns:   []string{".git", vendorDir, "node_modules", "bin", "tmp"},
}

func registerWatchCommand(cli *v4.CLI[AppConfig]) error {
	cmd, err := v4.NewCommand[AppConfig, WatchFlags](
		"watch [path]",
		WatchFlags{TraceOnError: false},
		runWatchHandler,
		v4.WithShort("Watch for file changes and re-analyze"),
		v4.WithLong(`Watch mode continuously monitors Go files for changes and re-runs
analysis when modifications are detected.

This is useful during development to get immediate feedback on error
handling patterns as you edit your code.

With --trace-on-error, a moving execution-trace window is kept and dumped
to a timestamped .trace file next to an analysis failure, for hindsight
debugging of watch-mode errors (go tool trace <file>).`),
		v4.WithExample(`  # Watch current directory
  erraudit watch

  # Watch specific directory
  erraudit watch ./pkg/errors

  # Watch with JSON output
  erraudit watch . --format json

  # Dump an execution trace when an analysis errors
  erraudit watch . --trace-on-error`),
		v4.WithArgs(cobra.MaximumNArgs(1)),
	)

	return registerCommand(cli, "watch", cmd, err)
}

func runWatchHandler(ctx context.Context, cfg *AppConfig, flags WatchFlags) error {
	args := argsFromContext(ctx)
	w := NewWatcher(pathFromArgs(args), DefaultWatchConfig)
	w.traceOnError = flags.TraceOnError

	return w.Run(ctx, cfg)
}

func NewWatcher(path string, watchConfig WatchConfig) *Watcher {
	return &Watcher{
		path:        path,
		watchConfig: watchConfig,
		out:         os.Stdout,
	}
}

func (w *Watcher) Run(ctx context.Context, cfg *AppConfig) error {
	w.config = cfg
	if w.out == nil {
		w.out = os.Stdout
	}

	absPath, err := filepath.Abs(w.path)
	if err != nil {
		return apierrors.Wrap(err, "failed to resolve path %s", w.path)
	}

	fileWatcher, err := filewatcher.New(
		[]string{absPath},
		filewatcher.WithDebounce(w.watchConfig.DebounceDuration),
		filewatcher.WithExtensions(".go"),
		filewatcher.WithIgnoreDirs(w.watchConfig.IgnorePatterns...),
		filewatcher.WithIgnoreHidden(),
		filewatcher.WithFilter(filewatcher.FilterOperations(
			filewatcher.Write, filewatcher.Create, filewatcher.Rename,
		)),
	)
	if err != nil {
		return apierrors.Wrap(err, "failed to create file watcher for %s", w.path)
	}

	defer func() { _ = fileWatcher.Close() }() //nolint:erraudit // deferred cleanup

	watchCtx, cancel := context.WithCancel(ctx)
	defer cancel()

	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, os.Interrupt, syscall.SIGTERM)

	go func() {
		<-sigCh
		fmt.Fprintf(w.out, "\nReceived interrupt signal, stopping watch mode...\n")
		cancel()
	}()

	if w.flightRecorder == nil {
		w.flightRecorder = newFlightRecorderSpike(w.out, w.traceOnError)
	}

	fmt.Fprintf(w.out, "Watching: %s\n", w.path)
	fmt.Fprintln(w.out, "Press Ctrl+C to stop")
	fmt.Fprintln(w.out)

	err = w.runAnalysis(watchCtx)
	if err != nil {
		fmt.Fprintf(w.out, "Initial analysis error: %v\n", err)
	}

	events, err := fileWatcher.Watch(watchCtx)
	if err != nil {
		return apierrors.Wrap(err, "failed to start watching %s", w.path)
	}

	for range events {
		if cfg.Verbose {
			fmt.Fprintln(w.out, "\n--- Change detected, re-analyzing... ---")
		} else {
			fmt.Fprint(w.out, "\n--- Re-analyzing... ---\n\n")
		}

		err := w.runAnalysis(watchCtx)
		if err != nil {
			fmt.Fprintf(w.out, "Analysis error: %v\n", err)
			w.dumpTrace()
		}
	}

	w.stopTrace()

	return nil
}

// newFlightRecorderSpike starts an execution-trace ring buffer when enabled
// via --trace-on-error (or the ERRAUDIT_TRACE=1 env), for hindsight debugging
// of watch-mode analysis failures. Returns nil (disabled) otherwise.
func newFlightRecorderSpike(out io.Writer, traceOnError bool) *trace.FlightRecorder {
	if !traceOnError && os.Getenv("ERRAUDIT_TRACE") != "1" {
		return nil
	}

	recorder := trace.NewFlightRecorder(trace.FlightRecorderConfig{
		MinAge:   traceRingMinAge,
		MaxBytes: traceRingMaxBytes,
	})
	if err := recorder.Start(); err != nil {
		fmt.Fprintf(out, "trace: flight recorder unavailable: %v\n", err)

		return nil
	}

	fmt.Fprintln(out, "trace: flight recording enabled (--trace-on-error); dump on analysis error")

	return recorder
}

// dumpTrace snapshots the ring buffer to a timestamped .trace file.
func (w *Watcher) dumpTrace() {
	if w.flightRecorder == nil || !w.flightRecorder.Enabled() {
		return
	}

	path := fmt.Sprintf("erraudit-watch-%s.trace", time.Now().Format("20060102-150405"))

	file, err := os.Create(path)
	if err != nil {
		fmt.Fprintf(w.out, "trace: cannot create %s: %v\n", path, err)

		return
	}

	defer file.Close()

	n, err := w.flightRecorder.WriteTo(file)
	if err != nil {
		fmt.Fprintf(w.out, "trace: dump failed: %v\n", err)

		return
	}

	fmt.Fprintf(w.out, "trace: wrote %d bytes to %s (go tool trace %s)\n", n, path, path)
}

func (w *Watcher) stopTrace() {
	if w.flightRecorder != nil {
		w.flightRecorder.Stop()
	}
}

func (w *Watcher) runAnalysis(ctx context.Context) error {
	w.mu.Lock()
	defer w.mu.Unlock()

	w.lastAnalysis = time.Now()

	// Suppress/Explain stay false: this path finalizes violations itself (via
	// FinalizeViolations below) AFTER filtering, so the spec choke point must
	// not pre-empt it.
	graph, violations, err := pipeline.PerformAnalysisWithSpec(ctx, pipeline.AnalysisSpec{
		Path:                 w.path,
		ExcludedPaths:        w.config.Exclude,
		TypeAware:            w.config.TypeAware,
		EnforceErrorFamily:   w.config.EnforceErrorFamily,
		EnforceSamberOops:    w.config.EnforceSamberOops,
		EnforceGenericReturn: w.config.EnforceGenericReturn,
		EnforceDeferredClose: w.config.EnforceDeferredClose,
		EnforceCodedErrors:   w.config.EnforceCodedErrors,
		NoSuppress:           w.config.NoSuppress,
		ModulesAll:           w.config.Modules == ModulesAllMode,
		Progress:             w.config.Progress,
		Suppress:             false,
		Explain:              false,
	})
	if err != nil {
		return apierrors.Wrap(
			err,
			"analysis failed for %s (ctx=%v, exclusions=%v)",
			w.path, ctx.Err() != nil, w.config.Exclude,
		)
	}

	violations = pipeline.FilterViolations(
		violations,
		w.config.SeverityFilterPtr(),
		w.config.TypeFilterPtr(),
		w.config.SeverityThresholdPtr(),
		w.config.DisabledTypesSet(),
	)

	// Suppression + explanations via the shared finishing step so watch
	// output matches the other paths exactly.
	violations = pipeline.FinalizeViolations(
		violations,
		pipeline.SourceFilesFromGraph(graph),
		w.config.NoSuppress,
		w.config.Explain,
	)
	graph.Violations = violations

	outputStr, err := pipeline.GenerateOutputString(
		w.config.OutputFormatType(), w.config.DOTTheme, w.config.ViolationsOnly,
		graph, violations,
	)
	if err != nil {
		return apierrors.Wrap(
			err,
			"failed to generate output for %s (ctx=%v, violations=%d, outputFormat=%s)",
			w.path, ctx.Err() != nil, len(violations), w.config.OutputFormatType(),
		)
	}

	fmt.Fprint(w.out, "\n")
	fmt.Fprint(w.out, outputStr)

	violCount := len(violations)
	if violCount > 0 {
		fmt.Fprintf(w.out, "\n--- Found %d violation(s) at %s ---\n", violCount, time.Now().Format("15:04:05"))
	} else {
		fmt.Fprintf(w.out, "\n--- No violations at %s ---\n", time.Now().Format("15:04:05"))
	}

	return nil
}
