package cmd

import (
	v4 "github.com/larsartmann/cmdguard/v4/pkg/cmdguard/v4"
	"github.com/spf13/cobra"
)

const defaultLintPattern = "./..."

func registerLintCommand(cli *v4.CLI[AppConfig]) error {
	cmd, err := v4.NewCommand[AppConfig, v4.NoFlags](
		"lint [packages]",
		v4.NoFlags{},
		runLintHandler,
		v4.WithShort("Run the legacyerrors linter (detect errors.As/Is to errors.AsType)"),
		v4.WithLong(`Run the legacyerrors go/analysis linter to detect uses of the
pre-Go 1.26 errors.As and errors.Is functions that should be replaced
with the modern, generic errors.AsType.

The linter uses go/analysis for accurate type-safe detection and supports
nolint:legacyerrors suppression comments.

Output is plain text (file:line:col: message) by default.
Use --format to select structured output (json, sarif, tree, etc.).`),
		v4.WithExample(`  # Lint entire project
  erraudit lint ./...

  # Lint specific package
  erraudit lint ./pkg/errors

  # Lint with JSON output
  erraudit lint ./... --format json`),
		v4.WithArgs(cobra.ArbitraryArgs),
	)

	return registerCommand(cli, "lint", cmd, err)
}
