package cmd

import (
	"context"
	"fmt"
	"io"
	"os"
	"text/tabwriter"

	v4 "github.com/larsartmann/cmdguard/v4/pkg/cmdguard/v4"
	apierrors "github.com/larsartmann/erraudit/pkg/errors"
	"github.com/larsartmann/erraudit/pkg/extension/hooks"
	"github.com/larsartmann/erraudit/pkg/extension/registry"
	"github.com/spf13/cobra"
)

// Tabwriter formatting constants.
const (
	tabwriterMinWidth          = 0
	tabwriterTabWidth          = 0
	tabwriterPadding           = 2
	tabwriterPadChar           = ' '
	extensionDescriptionMaxLen = 40
)

// allHookPoints contains all available hook points in execution order.
//
//nolint:gochecknoglobals // Constant slice for hook point iteration
var allHookPoints = []hooks.HookPoint{
	hooks.HookPreAnalysis, hooks.HookPostAnalysis,
	hooks.HookPreFile, hooks.HookPostFile,
	hooks.HookPreViolation, hooks.HookPostViolation,
	hooks.HookPreOutput, hooks.HookPostOutput,
	hooks.HookPreFix, hooks.HookPostFix,
}

func registerExtensionCommand(cli *v4.CLI[AppConfig]) error {
	listCmd, err := v4.NewCommand[AppConfig, v4.NoFlags](
		"list",
		v4.NoFlags{},
		extensionListHandler,
		v4.WithShort("List registered extensions"),
		v4.WithLong("List all extensions currently registered with the analyzer."),
		v4.WithAliases("ls"),
		v4.WithNoArgs(),
	)
	if err != nil {
		return apierrors.Wrap(err, "create extension list command")
	}

	showCmd, err := v4.NewCommand[AppConfig, v4.NoFlags](
		"show <name>",
		v4.NoFlags{},
		extensionShowHandler,
		v4.WithShort("Show extension details"),
		v4.WithLong("Show detailed information about a specific extension."),
		v4.WithArgs(cobra.ExactArgs(1)),
	)
	if err != nil {
		return apierrors.Wrap(err, "create extension show command")
	}

	hooksCmd, err := v4.NewCommand[AppConfig, v4.NoFlags](
		"hooks",
		v4.NoFlags{},
		extensionHooksHandler,
		v4.WithShort("List registered hooks"),
		v4.WithLong("List all hooks registered in the analysis lifecycle."),
		v4.WithNoArgs(),
	)
	if err != nil {
		return apierrors.Wrap(err, "create extension hooks command")
	}

	disableCmd, err := v4.NewCommand[AppConfig, v4.NoFlags](
		"disable <name>",
		v4.NoFlags{},
		extensionDisableHandler,
		v4.WithShort("Disable an extension"),
		v4.WithLong("Disable an extension by name."),
		v4.WithArgs(cobra.ExactArgs(1)),
	)
	if err != nil {
		return apierrors.Wrap(err, "create extension disable command")
	}

	metricsCmd, err := v4.NewCommand[AppConfig, v4.NoFlags](
		"metrics",
		v4.NoFlags{},
		extensionMetricsHandler,
		v4.WithShort("Show extension system metrics"),
		v4.WithLong("Display metrics about registered extensions and hooks."),
		v4.WithNoArgs(),
	)
	if err != nil {
		return apierrors.Wrap(err, "create extension metrics command")
	}

	extensionCmd, err := v4.NewParentCommand[AppConfig](
		"extension",
		`Extension management commands for the erraudit analyzer.

EXTENSIONS AUTO-INITIALIZE

Extensions are automatically initialized when the analyzer starts.
No manual initialization is required. Use 'extension list' to see
which extensions are currently active.

To disable all extensions, use the --disable-extensions flag:
  erraudit ./... --disable-extensions

AVAILABLE COMMANDS
  list      List all registered extensions
  show      Show detailed information about an extension
  hooks     List all registered hook handlers
  disable   Disable a specific extension
  metrics   Show extension system metrics

BUILT-IN EXTENSIONS
  builtin-logger    Logs analysis lifecycle events
  builtin-metrics   Collects analysis performance metrics

Extensions extend the analyzer with custom functionality:
- Custom analyzers for specific frameworks
- Custom visualizers for different output formats
- Custom violation detectors for project-specific rules
- Hooks into the analysis lifecycle (8 hook points)`,
		v4.NoFlags{},
		v4.WithSubcommands(listCmd, showCmd, hooksCmd, disableCmd, metricsCmd),
		v4.WithShort("Manage analyzer extensions"),
	)

	return registerCommand(cli, "extension", extensionCmd, err)
}

func extensionListHandler(_ context.Context, _ *AppConfig, _ v4.NoFlags) error {
	extensions := registry.GlobalRegistry().List()

	if len(extensions) == 0 {
		fmt.Fprintln(os.Stdout, "No extensions registered")

		return nil
	}

	writer := newTabwriter(os.Stdout)
	writeTabln(writer, "NAME\tVERSION\tTYPE\tDESCRIPTION")

	for _, p := range extensions {
		meta := p.Metadata()
		writeTabf(writer, "%s\t%s\t%s\t%s\n",
			meta.Name, meta.Version, meta.Type,
			truncate(meta.Description, extensionDescriptionMaxLen),
		)
	}

	return apierrors.Wrap(
		writer.Flush(),
		"flush tabwriter",
	)
}

// extensionNameFromArgs extracts the single extension name argument from the
// context, returning an error when it is missing.
func extensionNameFromArgs(ctx context.Context) (string, error) {
	args := argsFromContext(ctx)
	if len(args) == 0 {
		return "", apierrors.ErrExtensionNameMissing
	}

	return args[0], nil
}

func extensionShowHandler(ctx context.Context, _ *AppConfig, _ v4.NoFlags) error {
	name, err := extensionNameFromArgs(ctx)
	if err != nil {
		return err
	}

	extensionItem := registry.GlobalRegistry().Get(name)

	if extensionItem == nil {
		return apierrors.Wrap(apierrors.ErrExtensionNotFound, "%q", name)
	}

	meta := extensionItem.Metadata()

	writer := newTabwriter(os.Stdout)
	writeTabf(writer, "Name:\t%s\n", meta.Name)
	writeTabf(writer, "Version:\t%s\n", meta.Version)
	writeTabf(writer, "Type:\t%s\n", meta.Type)
	writeTabf(writer, "Author:\t%s\n", meta.Author)
	writeTabf(writer, "Priority:\t%d\n", meta.Priority)
	writeTabf(writer, "Description:\t%s\n", meta.Description)

	return apierrors.Wrap(writer.Flush(), "flush tabwriter")
}

func extensionHooksHandler(_ context.Context, _ *AppConfig, _ v4.NoFlags) error {
	hookRegistry := hooks.GlobalHookRegistry()
	hasHooks := false

	writer := newTabwriter(os.Stdout)
	writeTabln(writer, "HOOK POINT\tNAME\tPRIORITY")

	for _, point := range allHookPoints {
		hookList := hookRegistry.GetHooks(point)
		for _, h := range hookList {
			hasHooks = true

			writeTabf(writer, "%s\t%s\t%d\n", point, h.Name, h.Priority)
		}
	}

	if !hasHooks {
		fmt.Fprintln(os.Stdout, "No hooks registered")

		return nil
	}

	return apierrors.Wrap(
		writer.Flush(),
		"flush tabwriter",
	)
}

func extensionDisableHandler(ctx context.Context, _ *AppConfig, _ v4.NoFlags) error {
	name, err := extensionNameFromArgs(ctx)
	if err != nil {
		return err
	}

	err = registry.GlobalRegistry().Unregister(ctx, name)
	if err != nil {
		return apierrors.Wrap(err, "failed to unregister feature %q", name)
	}

	fmt.Fprintf(os.Stdout, "Extension %q disabled\n", name)

	return nil
}

func extensionMetricsHandler(_ context.Context, _ *AppConfig, _ v4.NoFlags) error {
	extensions := registry.GlobalRegistry().List()

	hookRegistry := hooks.GlobalHookRegistry()
	totalHooks := 0
	hooksByPoint := make(map[hooks.HookPoint]int)

	for _, point := range allHookPoints {
		count := len(hookRegistry.GetHooks(point))
		hooksByPoint[point] = count
		totalHooks += count
	}

	writer := newTabwriter(os.Stdout)

	writeTabln(writer, "EXTENSION SYSTEM METRICS")
	writeTabln(writer, "======================")
	writeTabf(writer, "Total Extensions:\t%d\n", len(extensions))
	writeTabf(writer, "Total Hooks:\t%d\n", totalHooks)
	writeTabln(writer)

	if len(extensions) > 0 {
		writeTabln(writer, "REGISTERED EXTENSIONS")
		writeTabln(writer, "---------------------")

		for _, p := range extensions {
			meta := p.Metadata()
			writeTabf(writer, "  %s\t%s\t%s\n", meta.Name, meta.Version, meta.Type)
		}

		writeTabln(writer)
	}

	if totalHooks > 0 {
		writeTabln(writer, "HOOKS BY POINT")
		writeTabln(writer, "--------------")

		for _, point := range allHookPoints {
			count := hooksByPoint[point]
			if count > 0 {
				writeTabf(writer, "  %s:\t%d\n", point, count)
			}
		}
	} else {
		writeTabln(writer, "No hooks registered")
	}

	return apierrors.Wrap(
		writer.Flush(),
		"flush tabwriter",
	)
}

// writeTabf writes formatted text to a tabwriter. The tabwriter buffers in
// memory, so individual Write calls cannot fail; only Flush() can.
func writeTabf(w io.Writer, format string, args ...any) {
	_, _ = fmt.Fprintf(w, format, args...) //nolint:erraudit // tabwriter buffer write cannot fail
}

// writeTabln writes a line to a tabwriter. See writeTabf for error rationale.
func writeTabln(w io.Writer, args ...any) {
	_, _ = fmt.Fprintln(w, args...) //nolint:erraudit // tabwriter buffer write cannot fail
}

// newTabwriter creates a tabwriter configured for the given output.
func newTabwriter(output io.Writer) *tabwriter.Writer {
	return tabwriter.NewWriter(
		output,
		tabwriterMinWidth,
		tabwriterTabWidth,
		tabwriterPadding,
		tabwriterPadChar,
		0,
	)
}

// truncate truncates a string to the maximum length specified.
func truncate(s string, maxLen int) string {
	if len(s) <= maxLen {
		return s
	}

	return s[:maxLen-3] + "..."
}
