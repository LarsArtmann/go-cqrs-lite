package output

import (
	"context"
	"flag"
	"go/token"
	"io"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	findingsdk "github.com/larsartmann/go-finding"
)

// sarifUpdate regenerates the SARIF golden file when -update is passed:
//
//	go test ./cmd/erraudit/cmd/output/ -run TestGoldenSARIF -update
var sarifUpdate = flag.Bool("update", false, "rewrite golden files")

// goldenSARIFViolation mirrors internal/viz's golden fixture violation so the
// SARIF snapshot and the viz snapshots describe the same finding set.
func goldenSARIFViolation(name string, line int, errType types.ErrorType, sev types.Severity) types.ErrorViolation {
	return types.ErrorViolation{
		Position: token.Position{Filename: "src/" + name + ".go", Line: line, Column: 3},
		Type:     errType,
		Severity: sev,
		Message:  name + " failed",
	}
}

// TestGoldenSARIF locks the SARIF 2.1.0 render byte-for-byte. SARIF previously
// relied on structural tests only; this catches drift in the go-finding bridge
// mapping (severity names, rule ids, related-location wiring).
func TestGoldenSARIF(t *testing.T) {
	t.Parallel()

	graph := &types.ErrorGraph{
		Package: "golden",
		Violations: []types.ErrorViolation{
			goldenSARIFViolation("alpha", 10, types.ErrorTypeSilentSwallow, types.SeverityHigh),
			goldenSARIFViolation("beta", 20, types.ErrorTypeIgnored, types.SeverityMedium),
		},
	}

	got, err := generateReportFromGraph(
		graph,
		graph.Violations,
		writeReport("writing SARIF", func(ctx context.Context, w io.Writer, r *findingsdk.Report) error {
			return r.WriteSARIF(ctx, w)
		}),
	)
	if err != nil {
		t.Fatalf("generate SARIF: %v", err)
	}

	goldenPath := filepath.Join("testdata", "golden", "report.sarif")

	if *sarifUpdate {
		if err := os.MkdirAll(filepath.Dir(goldenPath), 0o755); err != nil {
			t.Fatalf("mkdir: %v", err)
		}

		if err := os.WriteFile(goldenPath, []byte(got), 0o644); err != nil {
			t.Fatalf("write golden: %v", err)
		}

		return
	}

	want, err := os.ReadFile(goldenPath)
	if err != nil {
		t.Fatalf("golden file missing (run with -update to seed): %v", err)
	}

	if got != string(want) {
		t.Errorf("SARIF render drifted from golden:\n--- golden ---\n%s\n--- got ---\n%s",
			strings.Clone(string(want)), got)
	}
}
