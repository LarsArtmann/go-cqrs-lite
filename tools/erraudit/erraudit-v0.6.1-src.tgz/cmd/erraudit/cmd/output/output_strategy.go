package output

import (
	"bytes"
	"context"
	"io"
	"strings"

	"github.com/larsartmann/erraudit/internal/viz"
	apierrors "github.com/larsartmann/erraudit/pkg/errors"
	findingapi "github.com/larsartmann/erraudit/pkg/finding"
	"github.com/larsartmann/erraudit/pkg/suppression"
	"github.com/larsartmann/erraudit/pkg/types"
	findingsdk "github.com/larsartmann/go-finding"
)

// OutputStrategy generates output in a specific format.
type OutputStrategy interface {
	Format() types.OutputFormat
	Generate(graph *types.ErrorGraph, violations []types.ErrorViolation) (string, error)
}

// StrategyRegistry manages output strategies by format.
type StrategyRegistry struct {
	strategies map[types.OutputFormat]OutputStrategy
}

// NewStrategyRegistry creates a new registry with all available strategies.
// dotTheme selects the theme for DOT/Mermaid output; violationsOnly controls
// whether TreeStrategy suppresses non-violation output.
func NewStrategyRegistry(dotTheme string, violationsOnly bool) *StrategyRegistry {
	registry := &StrategyRegistry{
		strategies: make(map[types.OutputFormat]OutputStrategy),
	}

	registry.strategies[types.FormatJSON] = &GoFindingJSONStrategy{} // alias: json routes to go-finding JSON
	registry.strategies[types.FormatHTML] = &HTMLStrategy{}
	registry.strategies[types.FormatFull] = &FullStrategy{}
	registry.strategies[types.FormatHierarchy] = &HierarchyStrategy{}
	registry.strategies[types.FormatDOT] = &DOTStrategy{
		theme: viz.GetTheme(dotTheme),
	}
	registry.strategies[types.FormatMermaid] = &MermaidStrategy{
		theme: viz.GetTheme(dotTheme),
	}
	registry.strategies[types.FormatTree] = &TreeStrategy{
		violationsOnly: violationsOnly,
	}
	registry.strategies[types.FormatAgent] = &AgentStrategy{}
	registry.strategies[types.FormatSARIF] = &SARIFStrategy{}
	registry.strategies[types.FormatGoFindingSARIF] = &SARIFStrategy{} // alias: identical output via go-finding
	registry.strategies[types.FormatGoFindingJSON] = &GoFindingJSONStrategy{}

	// go-output powered formats — the paired table in gooutput_strategy.go
	// is the single source of truth for this list.
	for _, pair := range goOutputTableFormats {
		registry.strategies[pair.domain] = &GoOutputTableStrategy{
			renderer: pair.renderer,
			domain:   pair.domain,
		}
	}

	return registry
}

// Get retrieves a strategy for the given format.
//
//nolint:ireturn // strategy pattern requires returning the interface abstraction
func (r *StrategyRegistry) Get(format types.OutputFormat) (OutputStrategy, error) {
	strategy, ok := r.strategies[format]
	if !ok {
		return nil, apierrors.Wrap(apierrors.ErrNoStrategyRegistered, "format=%s", format)
	}

	return strategy, nil
}

// HTMLStrategy generates HTML output.
type HTMLStrategy struct{}

// Format returns the output format.
func (s *HTMLStrategy) Format() types.OutputFormat {
	return types.FormatHTML
}

// Generate produces HTML output.
func (s *HTMLStrategy) Generate(
	graph *types.ErrorGraph,
	violations []types.ErrorViolation,
) (string, error) {
	htmlViz := viz.NewHTMLGenerator(graph)

	return htmlViz.GenerateHTML(violations), nil
}

// FullStrategy generates summary-only output (compact statistics, no violation details).
// Note: Despite the name "full", this format produces less output than TreeStrategy.
// The name refers to a "full summary" — all metric categories in one compact view.
type FullStrategy struct{}

// Format returns the output format.
func (s *FullStrategy) Format() types.OutputFormat {
	return types.FormatFull
}

// Generate produces full output.
func (s *FullStrategy) Generate(
	graph *types.ErrorGraph,
	violations []types.ErrorViolation,
) (string, error) {
	treeViz := viz.NewTreeVisualizer(graph)

	return treeViz.GenerateSummary(violations), nil
}

// HierarchyStrategy generates error hierarchy output.
type HierarchyStrategy struct{}

// Format returns the output format.
func (s *HierarchyStrategy) Format() types.OutputFormat {
	return types.FormatHierarchy
}

// Generate produces error hierarchy output.
func (s *HierarchyStrategy) Generate(
	graph *types.ErrorGraph,
	_ []types.ErrorViolation,
) (string, error) {
	treeViz := viz.NewTreeVisualizer(graph)

	return treeViz.GenerateErrorHierarchy(), nil
}

// DOTStrategy generates Graphviz DOT output.
type DOTStrategy struct {
	theme viz.DOTTheme
}

// Format returns the output format.
func (s *DOTStrategy) Format() types.OutputFormat {
	return types.FormatDOT
}

// Generate produces DOT output.
func (s *DOTStrategy) Generate(
	graph *types.ErrorGraph,
	_ []types.ErrorViolation,
) (string, error) {
	dotViz := viz.NewDOTVisualizerWithTheme(graph, s.theme)

	return dotViz.GenerateDOT(), nil
}

// MermaidStrategy generates Mermaid diagram output.
type MermaidStrategy struct {
	theme viz.DOTTheme
}

// Format returns the output format.
func (s *MermaidStrategy) Format() types.OutputFormat {
	return types.FormatMermaid
}

// Generate produces Mermaid output.
func (s *MermaidStrategy) Generate(
	graph *types.ErrorGraph,
	_ []types.ErrorViolation,
) (string, error) {
	dotViz := viz.NewDOTVisualizerWithTheme(graph, s.theme)

	return dotViz.GenerateMermaid(), nil
}

// TreeStrategy generates tree output with optional violations-only mode.
type TreeStrategy struct {
	violationsOnly bool
}

// Format returns the output format.
func (s *TreeStrategy) Format() types.OutputFormat {
	return types.FormatTree
}

// Generate produces tree output.
func (s *TreeStrategy) Generate(
	graph *types.ErrorGraph,
	violations []types.ErrorViolation,
) (string, error) {
	treeViz := viz.NewTreeVisualizer(graph)

	if s.violationsOnly {
		if len(violations) == 0 {
			return "", nil
		}

		return treeViz.GenerateViolations(violations), nil
	}

	var builder strings.Builder
	builder.WriteString(treeViz.GenerateMetrics())
	builder.WriteString("\n")
	builder.WriteString(treeViz.GenerateSummaryStats(violations))
	builder.WriteString(treeViz.GenerateViolations(violations))

	return builder.String(), nil
}

// AgentStrategy generates token-efficient output for AI coding agents.
type AgentStrategy struct{}

func (s *AgentStrategy) Format() types.OutputFormat {
	return types.FormatAgent
}

func (s *AgentStrategy) Generate(
	graph *types.ErrorGraph,
	violations []types.ErrorViolation,
) (string, error) {
	agentViz := viz.NewAgentVisualizer(graph)

	return agentViz.GenerateAgentOutput(violations), nil
}

// SARIFStrategy generates SARIF 2.1.0 JSON output using go-finding.
type SARIFStrategy struct{}

func (s *SARIFStrategy) Format() types.OutputFormat {
	return types.FormatSARIF
}

func (s *SARIFStrategy) Generate(
	graph *types.ErrorGraph,
	violations []types.ErrorViolation,
) (string, error) {
	return generateReportFromGraph(
		graph,
		violations,
		writeReport("writing SARIF", func(ctx context.Context, w io.Writer, r *findingsdk.Report) error {
			return r.WriteSARIF(ctx, w)
		}),
	)
}

// writeReport returns an outputFn for generateReportFromGraph that writes the
// report to a buffer using the given writer, wrapping errors with label.
func writeReport(
	label string,
	writer func(ctx context.Context, w io.Writer, r *findingsdk.Report) error,
) func(*findingsdk.Report) ([]byte, error) {
	return func(report *findingsdk.Report) ([]byte, error) {
		var buf bytes.Buffer

		err := writer(context.Background(), &buf, report)
		if err != nil {
			return nil, apierrors.Wrap(err, "%s", label)
		}

		return buf.Bytes(), nil
	}
}

// generateReportFromGraph builds a go-finding Report from a graph and violations,
// wiring in parent-child error relationships via RelatedRef for SARIF hierarchy.
// Collects ALL violations (from both graph and parameter) into one set, then
// deduplicates, applies //nolint suppressions, and uses ActiveFindings() to
// exclude suppressed findings from output.
func generateReportFromGraph(
	graph *types.ErrorGraph,
	violations []types.ErrorViolation,
	outputFn func(*findingsdk.Report) ([]byte, error),
) (string, error) {
	var relationships []types.ErrorRelationship
	if graph != nil && graph.Hierarchy != nil {
		relationships = graph.Hierarchy.Relationships
	}

	// Merge all violations into one set so dedup and suppression cover everything.
	allViolations := violations
	if graph != nil {
		allViolations = append(allViolations, graph.Violations...)
	}

	report := findingapi.NewToolReport()

	if len(allViolations) > 0 {
		findings := findingapi.ViolationsToFindingsWithRelated(allViolations, relationships)
		findings = findingapi.DeduplicateFindings(findings)
		findings = findingapi.ApplyNolintSuppressions(
			findings,
			suppression.BuildEngineFromFiles(violationFilePaths(allViolations)),
		)
		findingsdk.SortByPosition(findings)
		report.AddFindings(findings)
	}

	report.ComputeSummary()

	if graph != nil {
		report.Summary.FilesScanned = graph.FilesScanned
	}

	active := report.ActiveFindings()
	activeReport := findingsdk.NewReport(report.Tool)
	activeReport.AddFindings(active)
	activeReport.ComputeSummary()

	if graph != nil {
		activeReport.Summary.FilesScanned = graph.FilesScanned
	}

	data, err := outputFn(activeReport)
	if err != nil {
		return "", err
	}

	return string(data), nil
}

// violationFilePaths returns the unique set of source file paths referenced by
// the given violations, used to build the nolint suppression engine.
func violationFilePaths(violations []types.ErrorViolation) []string {
	seen := make(map[string]struct{}, len(violations))
	paths := make([]string, 0, len(violations))

	for _, v := range violations {
		if v.Position.Filename == "" {
			continue
		}

		if _, dup := seen[v.Position.Filename]; dup {
			continue
		}

		seen[v.Position.Filename] = struct{}{}
		paths = append(paths, v.Position.Filename)
	}

	return paths
}

// GoFindingJSONStrategy generates standardized JSON output via the go-finding library.
type GoFindingJSONStrategy struct{}

func (s *GoFindingJSONStrategy) Format() types.OutputFormat {
	return types.FormatGoFindingJSON
}

func (s *GoFindingJSONStrategy) Generate(
	graph *types.ErrorGraph,
	violations []types.ErrorViolation,
) (string, error) {
	return generateReportFromGraph(
		graph,
		violations,
		writeReport("writing JSON", func(_ context.Context, w io.Writer, r *findingsdk.Report) error {
			return r.WriteJSON(w)
		}),
	)
}

// Ensure all strategies implement OutputStrategy.
var (
	_ OutputStrategy = (*GoFindingJSONStrategy)(nil)
	_ OutputStrategy = (*HTMLStrategy)(nil)
	_ OutputStrategy = (*FullStrategy)(nil)
	_ OutputStrategy = (*HierarchyStrategy)(nil)
	_ OutputStrategy = (*DOTStrategy)(nil)
	_ OutputStrategy = (*MermaidStrategy)(nil)
	_ OutputStrategy = (*TreeStrategy)(nil)
	_ OutputStrategy = (*AgentStrategy)(nil)
	_ OutputStrategy = (*SARIFStrategy)(nil)
	_ OutputStrategy = (*GoFindingJSONStrategy)(nil)
)
