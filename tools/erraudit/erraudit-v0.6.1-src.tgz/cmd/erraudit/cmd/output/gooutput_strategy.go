package output

import (
	"bytes"

	"github.com/larsartmann/erraudit/internal/converter"
	apierrors "github.com/larsartmann/erraudit/pkg/errors"
	"github.com/larsartmann/erraudit/pkg/types"
	gooutput "github.com/larsartmann/go-output"
	_ "github.com/larsartmann/go-output/d2"            // register d2 format
	_ "github.com/larsartmann/go-output/delimited"     // register csv, tsv formats
	_ "github.com/larsartmann/go-output/graph"         // register dot, mermaid formats
	_ "github.com/larsartmann/go-output/markdown"      // register markdown format
	_ "github.com/larsartmann/go-output/markup"        // register html, xml, asciidoc formats
	_ "github.com/larsartmann/go-output/plantuml"      // register plantuml format
	_ "github.com/larsartmann/go-output/serialization" // register json, yaml, toml, jsonl formats
	_ "github.com/larsartmann/go-output/table"         // register table format
	_ "github.com/larsartmann/go-output/tree"          // register tree format
)

// goOutputTableFormat pairs a go-output renderer with the domain
// OutputFormat it backs. This table is the SINGLE SOURCE OF TRUTH for the
// go-output-powered formats: the registry registers one strategy per entry,
// and GoOutputTableStrategy reports the paired domain format. Adding a
// go-output-backed format is one new entry here (plus the types constant).
type goOutputTableFormat struct {
	renderer gooutput.Format
	domain   types.OutputFormat
}

// goOutputTableFormats lists every go-output-backed format erraudit exposes.
//
//nolint:gochecknoglobals // static format table, read-only by design
var goOutputTableFormats = []goOutputTableFormat{
	{gooutput.FormatCSV, types.FormatCSV},
	{gooutput.FormatTSV, types.FormatTSV},
	{gooutput.FormatMarkdown, types.FormatMarkdown},
	{gooutput.FormatYAML, types.FormatYAML},
	{gooutput.FormatXML, types.FormatXML},
	{gooutput.FormatD2, types.FormatD2},
	{gooutput.FormatJSONL, types.FormatJSONL},
	{gooutput.FormatAsciiDoc, types.FormatAsciiDoc},
	{gooutput.FormatTOML, types.FormatTOML},
	{gooutput.FormatPlantUML, types.FormatPlantUML},
	{gooutput.FormatTable, types.FormatTable},
}

// GoOutputTableStrategy renders violations as a table in any go-output supported
// format (csv, tsv, markdown, yaml, xml, jsonl, toml, asciidoc, table, etc.).
type GoOutputTableStrategy struct {
	renderer gooutput.Format
	domain   types.OutputFormat
}

// Format returns the erraudit output format constant.
func (s *GoOutputTableStrategy) Format() types.OutputFormat {
	return s.domain
}

// Generate produces table output via go-output's RenderTable.
func (s *GoOutputTableStrategy) Generate(
	_ *types.ErrorGraph,
	violations []types.ErrorViolation,
) (string, error) {
	tableData := converter.ViolationsToTable(violations)

	return renderTableToString(tableData, s.renderer, "go-output render")
}

// renderTableToString renders table data in the given format and returns the
// result. Shared by table and metrics strategies; wraps any render error with
// an action prefix so callers can distinguish "table" vs "metrics" failures
// in diagnostics.
func renderTableToString(
	tableData *gooutput.Table,
	format gooutput.Format,
	errPrefix string,
) (string, error) {
	var buf bytes.Buffer

	err := gooutput.RenderTable(tableData, format, gooutput.RenderOptions{
		Writer: &buf,
	})
	if err != nil {
		return "", apierrors.Wrap(err, "%s %s", errPrefix, format)
	}

	return buf.String(), nil
}

// Compile-time interface compliance checks.
var (
	_ OutputStrategy = (*GoOutputTableStrategy)(nil)
)
