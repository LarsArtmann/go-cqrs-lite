package output

import (
	"fmt"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	findingsdk "github.com/larsartmann/go-finding"
	"github.com/stretchr/testify/assert"
)

// TestStrategyRegistry_Completeness is the registry-completeness guard: every
// valid OutputFormat constant must resolve to a registered strategy. Without
// this test a new constant can ship and only fail at runtime
// (ErrNoStrategyRegistered) when a user picks it.
func TestStrategyRegistry_Completeness(t *testing.T) {
	registry := NewStrategyRegistry("default", false)

	for _, format := range types.ValidOutputFormats() {
		strategy, err := registry.Get(format)
		assert.NoError(t, err, "format %q must have a registered strategy", format)
		assert.NotNil(t, strategy, "format %q must have a registered strategy", format)
	}
}

func TestStrategyRegistry_Get(t *testing.T) {
	tests := []struct {
		name        string
		format      types.OutputFormat
		expectError bool
	}{
		{"JSON format (alias for go-finding-json)", types.FormatJSON, false},
		{"HTML format", types.FormatHTML, false},
		{"Full format", types.FormatFull, false},
		{"Hierarchy format", types.FormatHierarchy, false},
		{"DOT format", types.FormatDOT, false},
		{"Mermaid format", types.FormatMermaid, false},
		{"Tree format", types.FormatTree, false},
		{"Invalid format", types.OutputFormat("invalid"), true},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			registry := NewStrategyRegistry("default", false)

			strategy, err := registry.Get(tt.format)
			if tt.expectError {
				assert.Error(t, err)
				assert.Nil(t, strategy)
			} else {
				assert.NoError(t, err)
				assert.NotNil(t, strategy)
			}
		})
	}
}

func TestHTMLStrategy_Format(t *testing.T) {
	strategy := &HTMLStrategy{}
	assert.Equal(t, types.FormatHTML, strategy.Format())
}

func TestFullStrategy_Format(t *testing.T) {
	strategy := &FullStrategy{}
	assert.Equal(t, types.FormatFull, strategy.Format())
}

func TestHierarchyStrategy_Format(t *testing.T) {
	strategy := &HierarchyStrategy{}
	assert.Equal(t, types.FormatHierarchy, strategy.Format())
}

func TestDOTStrategy_Format(t *testing.T) {
	strategy := &DOTStrategy{}
	assert.Equal(t, types.FormatDOT, strategy.Format())
}

func TestMermaidStrategy_Format(t *testing.T) {
	strategy := &MermaidStrategy{}
	assert.Equal(t, types.FormatMermaid, strategy.Format())
}

func TestTreeStrategy_Format(t *testing.T) {
	strategy := &TreeStrategy{}
	assert.Equal(t, types.FormatTree, strategy.Format())
}

// generateTestCase pairs a strategy with the empty-output expectation for its
// Generate method. The TreeStrategy produces empty output only when
// violationsOnly is true, so its cases carry that flag.
type generateTestCase struct {
	name            string
	newStrategy     func() OutputStrategy
	expectEmptyWhen bool // true → assert.Empty when violationsOnly is true
	expectNonEmpty  bool // true → assert.NotEmpty (default behavior)
	violationsOnly  bool // applied only to strategies that honor the flag
}

func TestStrategy_Generate(t *testing.T) {
	cases := []generateTestCase{
		{
			name:           "GoFindingJSONStrategy",
			newStrategy:    func() OutputStrategy { return &GoFindingJSONStrategy{} },
			expectNonEmpty: true,
		},
		{name: "HTMLStrategy", newStrategy: func() OutputStrategy { return &HTMLStrategy{} }, expectNonEmpty: true},
		{name: "FullStrategy", newStrategy: func() OutputStrategy { return &FullStrategy{} }, expectNonEmpty: true},
		{
			name:           "HierarchyStrategy",
			newStrategy:    func() OutputStrategy { return &HierarchyStrategy{} },
			expectNonEmpty: true,
		},
		{name: "DOTStrategy", newStrategy: func() OutputStrategy { return &DOTStrategy{} }, expectNonEmpty: true},
		{
			name:           "MermaidStrategy",
			newStrategy:    func() OutputStrategy { return &MermaidStrategy{} },
			expectNonEmpty: true,
		},
		{
			name: "TreeStrategy",
			newStrategy: func() OutputStrategy {
				return &TreeStrategy{violationsOnly: false}
			},
			expectNonEmpty: true,
		},
		{
			name: "TreeStrategy_ViolationsOnly",
			newStrategy: func() OutputStrategy {
				return &TreeStrategy{violationsOnly: true}
			},
			expectEmptyWhen: true,
		},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			strategy := tc.newStrategy()
			graph := &types.ErrorGraph{}
			violations := []types.ErrorViolation{}

			output, err := strategy.Generate(graph, violations)
			assert.NoError(t, err)

			if tc.expectEmptyWhen {
				assert.Empty(t, output)
			} else {
				assert.NotEmpty(t, output)
			}
		})
	}
}

// TestGenerateReportFromGraph_NoDoubleAdd is the regression guard for the
// double-add bug fixed in commit 54bca1c. When both graph.Violations and
// the violations parameter contain findings, they must be merged into ONE set
// before dedup/suppression. Before the fix, the function called
// NewReportFromGraphWithRelated (which added graph findings) then added the
// parameter violations as MORE findings → duplicates.
func TestGenerateReportFromGraph_NoDoubleAdd(t *testing.T) {
	v1 := types.MakeTestViolation("a.go", 10, types.ErrorTypePanic, types.SeverityHigh, "panic")
	v2 := types.MakeTestViolation("b.go", 20, types.ErrorTypeIgnored, types.SeverityMedium, "ignored")

	// Same violation in both graph and parameter — should appear once.
	graph := &types.ErrorGraph{Violations: []types.ErrorViolation{v1}}
	extra := []types.ErrorViolation{v1, v2}

	output, err := generateReportFromGraph(
		graph, extra,
		func(r *findingsdk.Report) ([]byte, error) {
			return fmt.Appendf(nil, "count=%d", len(r.FindingsSnapshot())), nil
		},
	)

	assert.NoError(t, err)
	assert.Equal(t, "count=2", output,
		"graph(1) + extra(2) with one duplicate should produce 2 findings, not 3")
}

// TestGenerateReportFromGraph_MergesAllBeforeSuppress is the regression
// guard for the suppression-bypass bug. Suppression must run on the
// UNION of graph.Violations and parameter violations, not just the
// parameter batch.
func TestGenerateReportFromGraph_MergesAllBeforeSuppress(t *testing.T) {
	// This is tested at the integration level (TestCLINolintSuppression).
	// This unit-level guard confirms the merge happens before dedup.
	v1 := types.MakeTestViolation("a.go", 10, types.ErrorTypePanic, types.SeverityHigh, "msg-1")
	v2 := types.MakeTestViolation("a.go", 10, types.ErrorTypePanic, types.SeverityHigh, "msg-2")

	graph := &types.ErrorGraph{Violations: []types.ErrorViolation{v1}}
	extra := []types.ErrorViolation{v2}

	output, err := generateReportFromGraph(
		graph, extra,
		func(r *findingsdk.Report) ([]byte, error) {
			return fmt.Appendf(nil, "count=%d", len(r.FindingsSnapshot())), nil
		},
	)

	assert.NoError(t, err)
	assert.Equal(t, "count=1", output,
		"same position+type from graph and extra should be deduped to 1")
}
