package cmd

import (
	"bytes"
	"strings"
	"testing"
	"text/tabwriter"
)

// TestWriteTabf verifies that writeTabf writes formatted text to the writer.
func TestWriteTabf(t *testing.T) {
	t.Parallel()

	var buf bytes.Buffer
	w := tabwriter.NewWriter(&buf, 0, 0, 2, ' ', 0)

	writeTabf(w, "Name\tValue\n")
	writeTabf(w, "%s\t%d\n", "foo", 42)

	if err := w.Flush(); err != nil {
		t.Fatalf("flush: %v", err)
	}

	output := buf.String()
	if !strings.Contains(output, "Name") {
		t.Errorf("expected output to contain 'Name', got: %q", output)
	}

	if !strings.Contains(output, "foo") {
		t.Errorf("expected output to contain 'foo', got: %q", output)
	}

	if !strings.Contains(output, "42") {
		t.Errorf("expected output to contain '42', got: %q", output)
	}
}

// TestWriteTabln verifies that writeTabln writes a line to the writer.
func TestWriteTabln(t *testing.T) {
	t.Parallel()

	var buf bytes.Buffer
	w := tabwriter.NewWriter(&buf, 0, 0, 2, ' ', 0)

	writeTabln(w, "hello\tworld")
	writeTabln(w, "foo\tbar")

	if err := w.Flush(); err != nil {
		t.Fatalf("flush: %v", err)
	}

	output := buf.String()
	if !strings.Contains(output, "hello") {
		t.Errorf("expected output to contain 'hello', got: %q", output)
	}

	if !strings.Contains(output, "bar") {
		t.Errorf("expected output to contain 'bar', got: %q", output)
	}
}

// TestNewTabwriter verifies that newTabwriter creates a working tabwriter.
func TestNewTabwriter(t *testing.T) {
	t.Parallel()

	var buf bytes.Buffer
	w := newTabwriter(&buf)

	writeTabf(w, "col1\tcol2\n")
	writeTabf(w, "a\tb\n")

	if err := w.Flush(); err != nil {
		t.Fatalf("flush: %v", err)
	}

	if buf.Len() == 0 {
		t.Error("expected non-empty output after flush")
	}
}
