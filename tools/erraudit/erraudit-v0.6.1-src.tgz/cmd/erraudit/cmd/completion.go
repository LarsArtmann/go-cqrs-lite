package cmd

import (
	"github.com/larsartmann/erraudit/internal/viz"
	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/spf13/cobra"
)

// registerFlagCompletions wires shell completion for enum-like flags on the
// root command. cmdguard doesn't provide flag-level completion, so we use
// cobra's RegisterFlagCompletionFunc directly after CLI construction.
func registerFlagCompletions(root *cobra.Command) {
	registerStringSliceCompletion(root, "format", types.ValidOutputFormats())
	registerStringSliceCompletion(root, "severity", types.ValidSeverities())
	registerStringSliceCompletion(root, "type", types.ValidErrorTypes())
	registerStringSliceCompletion(root, "severity-threshold", types.ValidSeverities())
	registerStringCompletion(root, "dot-theme", viz.AvailableThemes())
}

// registerStringCompletion registers a static string completion for a flag.
func registerStringCompletion(root *cobra.Command, flagName string, values []string) {
	_ = root.RegisterFlagCompletionFunc( //nolint:erraudit // shell completion registration is best-effort
		flagName,
		func(_ *cobra.Command, _ []string, _ string) ([]string, cobra.ShellCompDirective) {
			return values, cobra.ShellCompDirectiveNoFileComp
		},
	)
}

// registerStringSliceCompletion registers completion from a slice of types
// that satisfy ~string. It converts each value to its underlying string.
func registerStringSliceCompletion[T ~string](root *cobra.Command, flagName string, values []T) {
	strValues := make([]string, 0, len(values))
	for _, v := range values {
		strValues = append(strValues, string(v))
	}

	registerStringCompletion(root, flagName, strValues)
}
