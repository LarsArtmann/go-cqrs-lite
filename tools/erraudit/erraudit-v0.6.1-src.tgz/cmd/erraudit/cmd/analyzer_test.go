package cmd

import (
	"bytes"
	"os"
	"path/filepath"
	"testing"

	"github.com/larsartmann/erraudit/cmd/erraudit/cmd/pipeline"
	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/spf13/cobra"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestSeverityAtOrAbove(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name      string
		severity  types.Severity
		threshold types.Severity
		expected  bool
	}{
		{
			name:      "high at high threshold",
			severity:  types.SeverityHigh,
			threshold: types.SeverityHigh,
			expected:  true,
		},
		{
			name:      "high at medium threshold",
			severity:  types.SeverityHigh,
			threshold: types.SeverityMedium,
			expected:  true,
		},
		{
			name:      "high at low threshold",
			severity:  types.SeverityHigh,
			threshold: types.SeverityLow,
			expected:  true,
		},
		{
			name:      "medium at high threshold",
			severity:  types.SeverityMedium,
			threshold: types.SeverityHigh,
			expected:  false,
		},
		{
			name:      "medium at medium threshold",
			severity:  types.SeverityMedium,
			threshold: types.SeverityMedium,
			expected:  true,
		},
		{
			name:      "medium at low threshold",
			severity:  types.SeverityMedium,
			threshold: types.SeverityLow,
			expected:  true,
		},
		{
			name:      "low at high threshold",
			severity:  types.SeverityLow,
			threshold: types.SeverityHigh,
			expected:  false,
		},
		{
			name:      "low at medium threshold",
			severity:  types.SeverityLow,
			threshold: types.SeverityMedium,
			expected:  false,
		},
		{
			name:      "low at low threshold",
			severity:  types.SeverityLow,
			threshold: types.SeverityLow,
			expected:  true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			result := tt.severity.AtOrAbove(tt.threshold)
			assert.Equal(t, tt.expected, result)
		})
	}
}

// TestFilterViolations covers six violation permutations exercising every
// Type/Severity combination. The repeated ErrorViolation struct shape is
// intentional: each entry is a distinct test scenario, and a builder would
// obscure which fields drive each branch.
func TestFilterViolations(t *testing.T) {
	t.Parallel()

	violations := []types.ErrorViolation{
		types.MakeTestViolation("test.go", 1, types.ErrorTypeReturn, types.SeverityHigh, "return violation"),
		types.MakeTestViolation("test.go", 2, types.ErrorTypeIgnored, types.SeverityMedium, "ignored error"),
		types.MakeTestViolation("test.go", 3, types.ErrorTypeUnwrapped, types.SeverityLow, "unwrapped error"),
		types.MakeTestViolation("test.go", 4, types.ErrorTypePanic, types.SeverityMedium, "panic violation"),
		types.MakeTestViolation("test.go", 5, types.ErrorTypePanic, types.SeverityHigh, "another panic"),
		types.MakeTestViolation("test.go", 6, types.ErrorTypeSilentSwallow, types.SeverityHigh, "silent swallow"),
	}

	t.Run("no filters returns all", func(t *testing.T) {
		t.Parallel()

		result := pipeline.FilterViolations(violations, nil, nil, nil, nil)
		assert.Len(t, result, 6)
	})

	t.Run("severity filter exact match", func(t *testing.T) {
		t.Parallel()

		severity := types.SeverityHigh
		result := pipeline.FilterViolations(violations, &severity, nil, nil, nil)
		require.Len(t, result, 3)
		assert.Equal(t, types.SeverityHigh, result[0].Severity)
		assert.Equal(t, types.SeverityHigh, result[1].Severity)
		assert.Equal(t, types.SeverityHigh, result[2].Severity)
	})

	t.Run("type filter", func(t *testing.T) {
		t.Parallel()

		errType := types.ErrorTypePanic
		result := pipeline.FilterViolations(violations, nil, &errType, nil, nil)
		require.Len(t, result, 2)
		assert.Equal(t, types.ErrorTypePanic, result[0].Type)
		assert.Equal(t, types.ErrorTypePanic, result[1].Type)
	})

	t.Run("severity threshold", func(t *testing.T) {
		t.Parallel()

		threshold := types.SeverityMedium
		result := pipeline.FilterViolations(violations, nil, nil, &threshold, nil)
		require.Len(t, result, 5)

		for _, v := range result {
			assert.True(t, v.Severity.AtOrAbove(threshold))
		}
	})

	t.Run("combined filters", func(t *testing.T) {
		t.Parallel()

		threshold := types.SeverityMedium
		errType := types.ErrorTypePanic
		result := pipeline.FilterViolations(violations, nil, &errType, &threshold, nil)
		require.Len(t, result, 2)

		for _, v := range result {
			assert.Equal(t, types.ErrorTypePanic, v.Type)
			assert.True(t, v.Severity.AtOrAbove(threshold))
		}
	})

	t.Run("empty violations returns empty", func(t *testing.T) {
		t.Parallel()

		severity := types.SeverityHigh
		result := pipeline.FilterViolations([]types.ErrorViolation{}, &severity, nil, nil, nil)
		assert.Empty(t, result)
	})

	t.Run("no matches returns empty", func(t *testing.T) {
		t.Parallel()

		errType := types.ErrorTypeCheck
		result := pipeline.FilterViolations(violations, nil, &errType, nil, nil)
		assert.Empty(t, result)
	})

	t.Run("disable filter removes specified types", func(t *testing.T) {
		t.Parallel()

		disabled := map[types.ErrorType]bool{types.ErrorTypePanic: true}
		result := pipeline.FilterViolations(violations, nil, nil, nil, disabled)
		require.Len(t, result, 4)

		for _, v := range result {
			assert.NotEqual(t, types.ErrorTypePanic, v.Type)
		}
	})

	t.Run("disable multiple types", func(t *testing.T) {
		t.Parallel()

		disabled := map[types.ErrorType]bool{
			types.ErrorTypePanic:         true,
			types.ErrorTypeSilentSwallow: true,
		}
		result := pipeline.FilterViolations(violations, nil, nil, nil, disabled)
		require.Len(t, result, 3)
	})

	t.Run("disable deferred_close_ignored", func(t *testing.T) {
		t.Parallel()

		deferredViolations := []types.ErrorViolation{
			types.MakeTestViolation("file.go", 10, types.ErrorTypeIgnored, types.SeverityMedium, "ignored error"),
			types.MakeTestViolation(
				"file.go",
				11,
				types.ErrorTypeDeferredCloseIgnored,
				types.SeverityLow,
				"defer f.Close() ignores Close error",
			),
			types.MakeTestViolation("file.go", 12, types.ErrorTypeReturn, types.SeverityHigh, "return violation"),
		}

		disabled := map[types.ErrorType]bool{types.ErrorTypeDeferredCloseIgnored: true}
		result := pipeline.FilterViolations(deferredViolations, nil, nil, nil, disabled)
		require.Len(t, result, 2, "only deferred_close_ignored should be filtered")

		for _, v := range result {
			assert.NotEqual(t, types.ErrorTypeDeferredCloseIgnored, v.Type, "deferred_close_ignored must be removed")
		}
	})

	t.Run("without disable deferred_close_ignored appears", func(t *testing.T) {
		t.Parallel()

		deferredViolations := []types.ErrorViolation{
			types.MakeTestViolation(
				"file.go",
				11,
				types.ErrorTypeDeferredCloseIgnored,
				types.SeverityLow,
				"defer f.Close() ignores Close error",
			),
		}

		result := pipeline.FilterViolations(deferredViolations, nil, nil, nil, nil)
		require.Len(t, result, 1)
		assert.Equal(t, types.ErrorTypeDeferredCloseIgnored, result[0].Type)
	})
}

func TestNewAnalyzer(t *testing.T) {
	t.Parallel()

	t.Run("creates analyzer with path", func(t *testing.T) {
		t.Parallel()

		a := NewAnalyzer("./test/path")
		require.NotNil(t, a)
		assert.Equal(t, "./test/path", a.path)
	})

	t.Run("creates analyzer with empty path", func(t *testing.T) {
		t.Parallel()

		a := NewAnalyzer("")
		require.NotNil(t, a)
		assert.Empty(t, a.path)
	})
}

// --- outputWriter tests ---

func TestOutputWriter_Stdout(t *testing.T) {
	t.Parallel()

	a := NewAnalyzer(".")
	cmd := &cobra.Command{}
	cfg := &AppConfig{Output: ""}

	writer, closeFn, err := a.outputWriter(cmd, cfg)
	require.NoError(t, err)
	assert.NotNil(t, writer)
	closeFn()
}

func TestOutputWriter_File(t *testing.T) {
	t.Parallel()

	a := NewAnalyzer(".")
	cmd := &cobra.Command{}
	tmpFile := filepath.Join(t.TempDir(), "output.txt")
	cfg := &AppConfig{Output: tmpFile}

	writer, closeFn, err := a.outputWriter(cmd, cfg)
	require.NoError(t, err)
	require.NotNil(t, writer)

	_, err = writer.Write([]byte("test data"))
	require.NoError(t, err)
	closeFn()

	data, err := os.ReadFile(tmpFile)
	require.NoError(t, err)
	assert.Equal(t, "test data", string(data))
}

func TestOutputWriter_InvalidPath(t *testing.T) {
	t.Parallel()

	a := NewAnalyzer(".")
	cmd := &cobra.Command{}
	cfg := &AppConfig{Output: "/nonexistent/dir/output.txt"}

	_, _, err := a.outputWriter(cmd, cfg)
	require.Error(t, err)
	assert.Contains(t, err.Error(), "failed to create output file")
}

// --- runPipeline integration tests ---

func TestRunPipeline_JSON(t *testing.T) {
	t.Parallel()

	a := NewAnalyzer("../../../examples/")
	cmd := &cobra.Command{}
	var buf bytes.Buffer
	cmd.SetOut(&buf)

	cfg := &AppConfig{Format: "json"}

	err := a.runPipeline(cmd, cfg)
	assert.ErrorIs(t, err, ErrViolationsFound)

	output := buf.String()
	assert.Contains(t, output, "findings")
	assert.Contains(t, output, "summary")
}

func TestRunPipeline_SARIF(t *testing.T) {
	t.Parallel()

	a := NewAnalyzer("../../../examples/")
	cmd := &cobra.Command{}
	var buf bytes.Buffer
	cmd.SetOut(&buf)

	cfg := &AppConfig{Format: "sarif"}

	err := a.runPipeline(cmd, cfg)
	assert.ErrorIs(t, err, ErrViolationsFound)

	output := buf.String()
	assert.Contains(t, output, "sarif")
	assert.Contains(t, output, "results")
}

func TestRunPipeline_FileOutput(t *testing.T) {
	t.Parallel()

	a := NewAnalyzer("../../../examples/")
	cmd := &cobra.Command{}
	var buf bytes.Buffer
	cmd.SetOut(&buf)

	tmpFile := filepath.Join(t.TempDir(), "pipeline.json")
	cfg := &AppConfig{Format: "json", Output: tmpFile}

	err := a.runPipeline(cmd, cfg)
	assert.ErrorIs(t, err, ErrViolationsFound)

	data, err := os.ReadFile(tmpFile)
	require.NoError(t, err)
	assert.Contains(t, string(data), "findings")
}

func TestRunPipeline_ViolationsFoundExitCode(t *testing.T) {
	t.Parallel()

	a := NewAnalyzer("../../../examples/")
	cmd := &cobra.Command{}
	cfg := &AppConfig{Format: "json"}

	err := a.runPipeline(cmd, cfg)
	assert.ErrorIs(t, err, ErrViolationsFound)
}
