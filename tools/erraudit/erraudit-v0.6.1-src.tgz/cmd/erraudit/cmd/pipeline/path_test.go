package pipeline

import (
	"os"
	"path/filepath"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestResolveTarget_Directory(t *testing.T) {
	t.Parallel()

	tmpDir := t.TempDir()

	dir, patterns, err := ResolveTarget([]string{tmpDir})
	require.NoError(t, err)
	assert.Equal(t, tmpDir, dir)
	assert.Equal(t, []string{"."}, patterns)
}

func TestResolveTarget_File(t *testing.T) {
	t.Parallel()

	tmpDir := t.TempDir()
	path := tmpDir + "/main.go"
	require.NoError(t, os.WriteFile(path, []byte("package main"), 0o644))

	dir, patterns, err := ResolveTarget([]string{path})
	require.NoError(t, err)
	assert.Empty(t, dir)
	assert.Equal(t, []string{path}, patterns)
}

func TestResolveTarget_PackagePattern(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name string
		arg  string
	}{
		{"recursive from cwd", "./..."},
		{"recursive subdirectory", "./pkg/..."},
		{"bare recursive", "..."},
		{"nested recursive", "./cmd/erraudit/..."},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			dir, patterns, err := ResolveTarget([]string{tc.arg})
			require.NoError(t, err)
			assert.Empty(t, dir, "package patterns should not resolve to a working directory")
			assert.Equal(t, []string{tc.arg}, patterns, "pattern should pass through unchanged")
		})
	}
}

func TestResolveTarget_MultipleArgs(t *testing.T) {
	t.Parallel()

	args := []string{"./...", "./pkg/..."}
	dir, patterns, err := ResolveTarget(args)
	require.NoError(t, err)
	assert.Empty(t, dir)
	assert.Equal(t, args, patterns)
}

func TestResolveTarget_MissingPath(t *testing.T) {
	t.Parallel()

	_, _, err := ResolveTarget([]string{"/does/not/exist"})
	require.Error(t, err)
}

func TestEnsureRecursivePattern_BareDirectory(t *testing.T) {
	t.Parallel()

	tmpDir := t.TempDir()
	result := EnsureRecursivePattern(tmpDir)
	assert.Equal(t, tmpDir+"/...", result)
}

func TestEnsureRecursivePattern_DotPath(t *testing.T) {
	t.Parallel()

	result := EnsureRecursivePattern(".")
	assert.Equal(t, "./...", result)
}

func TestEnsureRecursivePattern_RelativeSubdirectory(t *testing.T) {
	tmpDir := t.TempDir()
	t.Chdir(tmpDir)
	require.NoError(t, os.MkdirAll("pkg/errors", 0o755))

	assert.Equal(t, "./pkg/errors/...", EnsureRecursivePattern("pkg/errors"))
	assert.Equal(t, "./pkg/errors/...", EnsureRecursivePattern("./pkg/errors/"))
}

func TestEnsureRecursivePattern_AlreadyRecursive(t *testing.T) {
	t.Parallel()

	tests := []string{"./...", "./pkg/...", "...", "github.com/x/y/..."}
	for _, input := range tests {
		t.Run(input, func(t *testing.T) {
			t.Parallel()
			assert.Equal(t, input, EnsureRecursivePattern(input))
		})
	}
}

func TestEnsureRecursivePattern_NonExistentPath(t *testing.T) {
	t.Parallel()

	result := EnsureRecursivePattern("/does/not/exist")
	assert.Equal(t, "/does/not/exist", result)
}

func TestEnsureRecursivePattern_FilePath(t *testing.T) {
	t.Parallel()

	tmpDir := t.TempDir()
	filePath := tmpDir + "/main.go"
	require.NoError(t, os.WriteFile(filePath, []byte("package main"), 0o644))

	result := EnsureRecursivePattern(filePath)
	assert.Equal(t, filePath, result)
}

func TestIsPackagePattern(t *testing.T) {
	t.Parallel()

	tests := []struct {
		input    string
		expected bool
	}{
		{"./...", true},
		{"./pkg/...", true},
		{"github.com/foo/bar", false},
		{".", true},
		{"/absolute/path", false},
		{"/home/user/project", false},
		{"main.go", true},
		{"./main.go", false},
	}

	for _, tc := range tests {
		t.Run(tc.input, func(t *testing.T) {
			t.Parallel()
			assert.Equal(t, tc.expected, IsPackagePattern(tc.input))
		})
	}
}

func TestNestedModuleDirs(t *testing.T) {
	t.Parallel()

	tmpDir := t.TempDir()

	write := func(rel, content string) {
		t.Helper()

		path := filepath.Join(tmpDir, rel)
		require.NoError(t, os.MkdirAll(filepath.Dir(path), 0o755))
		require.NoError(t, os.WriteFile(path, []byte(content), 0o644))
	}

	write("go.mod", "module root")
	write("internal/app/main.go", "package main")
	write("libs/alpha/go.mod", "module alpha")
	write("libs/beta/nested/go.mod", "module beta-nested")
	write(".hidden/module/go.mod", "module hidden")
	write("vendor/module/go.mod", "module vendored")
	write("testdata/module/go.mod", "module fixture")

	got := NestedModuleDirs(tmpDir)

	assert.Equal(t, []string{"libs/alpha", "libs/beta/nested"}, got)
}

func TestNestedModuleDirs_NoNestedModules(t *testing.T) {
	t.Parallel()

	tmpDir := t.TempDir()
	require.NoError(t, os.WriteFile(filepath.Join(tmpDir, "go.mod"), []byte("module root"), 0o644))
	require.NoError(t, os.MkdirAll(filepath.Join(tmpDir, "pkg"), 0o755))

	assert.Empty(t, NestedModuleDirs(tmpDir))
}
