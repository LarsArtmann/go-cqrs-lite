package pipeline

import (
	"context"
	"os"
	"path/filepath"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

const swallowCode = `package main

import "errors"

func do() error { return errors.New("boom") }

func main() {
	err := do()
	if err != nil {
	}
}
`

func writeModuleFile(t *testing.T, dir, name, code string) {
	t.Helper()
	require.NoError(t, os.WriteFile(filepath.Join(dir, name), []byte(code), 0o644))
}

// TestPerformAnalysis_ModulesAllFansOut pins the --modules=all contract: the
// root module AND every nested go.mod module are analyzed (each from its own
// module root), the graphs merge into one report, and SkippedModules stays
// empty because nothing was skipped.
func TestPerformAnalysis_ModulesAllFansOut(t *testing.T) {
	dir := t.TempDir()
	writeModuleFixture(t, dir, "example.com/root")
	writeModuleFile(t, dir, "main.go", swallowCode)

	sub := filepath.Join(dir, "sub")
	writeModuleFixture(t, sub, "example.com/sub")
	writeModuleFile(t, sub, "sub.go", swallowCode)

	graph, violations, err := PerformAnalysisWithSpec(
		context.Background(),
		AnalysisSpec{Path: dir, ModulesAll: true},
	)
	require.NoError(t, err)
	require.NotNil(t, graph)

	assert.Equal(t, 2, graph.FilesScanned, "both modules must be analyzed")
	assert.Empty(t, graph.SkippedModules, "nothing may be skipped under --modules=all")

	found := 0
	for _, v := range violations {
		if v.Type == types.ErrorTypeSilentSwallow {
			found++
		}
	}
	assert.Equal(t, 2, found, "one silent_swallow per module must survive the merge")
}

// TestPerformAnalysis_ModulesAllSingleModule proves --modules=all is a no-op
// on a single-module repo: same analysis, no skipped modules, no error.
func TestPerformAnalysis_ModulesAllSingleModule(t *testing.T) {
	dir := t.TempDir()
	writeModuleFixture(t, dir, "example.com/root")
	writeModuleFile(t, dir, "main.go", swallowCode)

	graph, _, err := PerformAnalysisWithSpec(
		context.Background(),
		AnalysisSpec{Path: dir, ModulesAll: true},
	)
	require.NoError(t, err)
	require.NotNil(t, graph)

	assert.Equal(t, 1, graph.FilesScanned)
	assert.Empty(t, graph.SkippedModules)
}

// TestPerformAnalysis_SkippedModulesRecorded proves the non-fan-out path
// records which nested modules were NOT analyzed, so JSON consumers see the
// coverage boundary without parsing stderr warnings.
func TestPerformAnalysis_SkippedModulesRecorded(t *testing.T) {
	dir := t.TempDir()
	writeModuleFixture(t, dir, "example.com/root")
	writeModuleFile(t, dir, "main.go", swallowCode)

	sub := filepath.Join(dir, "sub")
	writeModuleFixture(t, sub, "example.com/sub")
	writeModuleFile(t, sub, "sub.go", swallowCode)

	graph, _, err := PerformAnalysisWithSpec(
		context.Background(),
		AnalysisSpec{Path: filepath.Join(dir, "...")},
	)
	require.NoError(t, err)
	require.NotNil(t, graph)

	assert.Equal(t, 1, graph.FilesScanned, "sub-module code must stay unanalyzed")
	assert.Equal(t, []string{"sub"}, graph.SkippedModules)
}

// TestPerformAnalysis_ModulesAllPatternTarget proves fan-out works from a
// recursive package pattern (./...) as well as a bare directory.
func TestPerformAnalysis_ModulesAllPatternTarget(t *testing.T) {
	dir := t.TempDir()
	writeModuleFixture(t, dir, "example.com/root")
	writeModuleFile(t, dir, "main.go", swallowCode)

	sub := filepath.Join(dir, "sub")
	writeModuleFixture(t, sub, "example.com/sub")
	writeModuleFile(t, sub, "sub.go", swallowCode)

	graph, _, err := PerformAnalysisWithSpec(
		context.Background(),
		AnalysisSpec{Path: filepath.Join(dir, "..."), ModulesAll: true},
	)
	require.NoError(t, err)
	require.NotNil(t, graph)

	assert.Equal(t, 2, graph.FilesScanned)
	assert.Empty(t, graph.SkippedModules)
}

// TestModulePattern pins the per-module pattern construction: the root module
// analyzes from the fan-out root, nested modules from their own directory
// (so their go.mod is the module root), and patterns keep the ./ prefix that
// go/packages needs to stay filesystem-anchored. EnsureRecursivePattern only
// rewrites existing directories, so the fixture dirs must exist.
func TestModulePattern(t *testing.T) {
	root := t.TempDir()
	writeModuleFixture(t, root, "example.com/root")

	require.NoError(t, os.MkdirAll(filepath.Join(root, "a", "b"), 0o755))

	tests := []struct {
		name      string
		moduleDir string
		want      string
	}{
		{"root module", ".", filepath.ToSlash(filepath.Join(root, "..."))},
		{"nested module", "a", filepath.ToSlash(filepath.Join(root, "a", "..."))},
		{"nested deep", filepath.Join("a", "b"), filepath.ToSlash(filepath.Join(root, "a", "b", "..."))},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := modulePattern(root, tt.moduleDir)
			assert.Equal(t, tt.want, got)
		})
	}
}
