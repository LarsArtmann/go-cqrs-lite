package pipeline

import (
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// TestFilterViolations exercises the FilterViolations function with three
// severity/type permutations. The repeated ErrorViolation struct shape is
// intentional: each fixture is a distinct violation scenario that the filter
// must handle, and a builder would obscure which fields drive each branch.
func TestFilterViolations(t *testing.T) {
	t.Parallel()

	violations := []types.ErrorViolation{
		types.MakeTestViolation("a.go", 1, types.ErrorTypeReturn, types.SeverityHigh, "high"),
		types.MakeTestViolation("b.go", 2, types.ErrorTypeIgnored, types.SeverityMedium, "med"),
		types.MakeTestViolation("c.go", 3, types.ErrorTypePanic, types.SeverityLow, "low"),
	}

	t.Run("no filters returns all", func(t *testing.T) {
		t.Parallel()

		result := FilterViolations(violations, nil, nil, nil, nil)
		assert.Len(t, result, 3)
	})

	t.Run("severity filter exact match", func(t *testing.T) {
		t.Parallel()

		sev := types.SeverityHigh
		result := FilterViolations(violations, &sev, nil, nil, nil)
		require.Len(t, result, 1)
		assert.Equal(t, types.SeverityHigh, result[0].Severity)
	})

	t.Run("type filter", func(t *testing.T) {
		t.Parallel()

		et := types.ErrorTypePanic
		result := FilterViolations(violations, nil, &et, nil, nil)
		require.Len(t, result, 1)
		assert.Equal(t, types.ErrorTypePanic, result[0].Type)
	})

	t.Run("severity threshold", func(t *testing.T) {
		t.Parallel()

		threshold := types.SeverityMedium
		result := FilterViolations(violations, nil, nil, &threshold, nil)
		require.Len(t, result, 2)

		for _, v := range result {
			assert.True(t, v.Severity.AtOrAbove(threshold), "expected severity >= medium, got %s", v.Severity)
		}
	})

	t.Run("combined filters", func(t *testing.T) {
		t.Parallel()

		sev := types.SeverityHigh
		et := types.ErrorTypeReturn
		result := FilterViolations(violations, &sev, &et, nil, nil)
		require.Len(t, result, 1)
		assert.Equal(t, types.SeverityHigh, result[0].Severity)
		assert.Equal(t, types.ErrorTypeReturn, result[0].Type)
	})

	t.Run("severity filter and threshold together", func(t *testing.T) {
		t.Parallel()

		sev := types.SeverityHigh
		threshold := types.SeverityMedium
		result := FilterViolations(violations, &sev, nil, &threshold, nil)
		require.Len(t, result, 1)
		assert.Equal(t, types.SeverityHigh, result[0].Severity)
	})

	t.Run("empty violations returns empty", func(t *testing.T) {
		t.Parallel()

		sev := types.SeverityHigh
		result := FilterViolations([]types.ErrorViolation{}, &sev, nil, nil, nil)
		assert.Empty(t, result)
	})

	t.Run("no matches returns empty", func(t *testing.T) {
		t.Parallel()

		et := types.ErrorTypeCheck
		result := FilterViolations(violations, nil, &et, nil, nil)
		assert.Empty(t, result)
	})
}

func TestGenerateOutputString(t *testing.T) {
	t.Parallel()

	t.Run("invalid format returns error", func(t *testing.T) {
		t.Parallel()

		_, err := GenerateOutputString(types.OutputFormat("invalid"), "default", false, &types.ErrorGraph{}, nil)
		require.Error(t, err)
		assert.Contains(t, err.Error(), "invalid")
	})
}
