package pipeline

import (
	"go/token"
	"os"
	"path/filepath"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
)

func newPosition(filename string, line int) token.Position {
	return token.Position{Filename: filename, Line: line}
}

func TestSuppressViolations_Empty(t *testing.T) {
	result := SuppressViolations(nil, nil)
	assert.Empty(t, result)
}

func TestSuppressViolations_NoNolintComments(t *testing.T) {
	tmpDir := t.TempDir()
	srcFile := filepath.Join(tmpDir, "main.go")

	err := os.WriteFile(srcFile, []byte("package main\n\nfunc main() {}\n"), 0o600)
	assert.NoError(t, err)

	violations := []types.ErrorViolation{
		{
			Type:     types.ErrorTypePanic,
			Position: newPosition(srcFile, 3),
		},
	}

	result := SuppressViolations(violations, []string{srcFile})
	assert.Len(t, result, 1, "violation should survive when no //nolint exists")
}

func TestSuppressViolations_WithNolint(t *testing.T) {
	tmpDir := t.TempDir()
	srcFile := filepath.Join(tmpDir, "main.go")

	err := os.WriteFile(
		srcFile,
		[]byte("package main\n\nfunc a() { //nolint:erraudit:panic\n	panic(\"x\")\n }\n"),
		0o600,
	)
	assert.NoError(t, err)

	violations := []types.ErrorViolation{
		{
			Type:     types.ErrorTypePanic,
			Position: newPosition(srcFile, 3),
		},
	}

	result := SuppressViolations(violations, []string{srcFile})
	assert.Empty(t, result, "violation on line with //nolint should be suppressed")
}

func TestSuppressViolations_PartialSuppression(t *testing.T) {
	tmpDir := t.TempDir()
	srcFile := filepath.Join(tmpDir, "main.go")

	err := os.WriteFile(
		srcFile,
		[]byte(
			"package main\n\nfunc a() { //nolint:erraudit:panic\n	panic(\"x\")\n }\nfunc b() {\n	panic(\"y\")\n }\n",
		),
		0o600,
	)
	assert.NoError(t, err)

	violations := []types.ErrorViolation{
		{Type: types.ErrorTypePanic, Position: newPosition(srcFile, 3)},
		{Type: types.ErrorTypePanic, Position: newPosition(srcFile, 6)},
	}

	result := SuppressViolations(violations, []string{srcFile})
	assert.Len(t, result, 1, "only non-nolint violation should survive")
	assert.Equal(t, 6, result[0].Position.Line)
}
