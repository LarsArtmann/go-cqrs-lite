package pipeline

import (
	"context"

	apierrors "github.com/larsartmann/erraudit/pkg/errors"
	"github.com/larsartmann/erraudit/pkg/finding"
	"github.com/larsartmann/erraudit/pkg/types"
	findingsdk "github.com/larsartmann/go-finding"
	pipelinesdk "github.com/larsartmann/go-finding/pipeline"
)

// RunFindingPipeline runs the analysis for the given spec through the
// go-finding pipeline.Detect entry point. This is the go-finding ecosystem
// integration path: it produces standardized Finding values that can be used
// with Report.ToSARIF(), finding.Combine(), and other ecosystem tools.
//
// The spec configures the underlying analysis the detector wraps. When
// spec.Suppress is set, //nolint comments in the analyzed source files are
// applied at the domain level so the detector only converts non-suppressed
// violations to findings; spec.NoSuppress bypasses that (and the AST
// false-positive heuristics) for audit mode. pipeline.Detect then returns
// only those active findings. Auto-generated Go files (sqlc, templ, protobuf,
// mockgen, ...) are already skipped by the analyzer itself
// (MainAnalyzer.isGeneratedFile), so no pipeline-level filter is needed.
func RunFindingPipeline(
	ctx context.Context,
	spec AnalysisSpec,
) ([]findingsdk.Finding, int, error) {
	filesScanned := 0

	analyzeGraph := NewDefaultGraphAnalyzer(spec)

	detector := finding.NewErrauditDetector(
		func(ictx context.Context) (*types.ErrorGraph, error) {
			graph, err := analyzeGraph(ictx)
			if graph != nil {
				filesScanned = graph.FilesScanned
			}

			return graph, err
		},
	)

	pipelineFindings, err := pipelinesdk.Detect(ctx, detector)
	if err != nil {
		return nil, 0, apierrors.Wrap(err, "go-finding pipeline detection failed")
	}

	return pipelineFindings, filesScanned, nil
}

// NewDefaultGraphAnalyzer adapts an AnalysisSpec into the finding.GraphAnalyzer
// contract (context → ErrorGraph) shared by the two go-finding detector
// wirings: the CLI --pipeline path (RunFindingPipeline) and the BuildFlow
// toolsdk provider. One implementation means both paths run identical
// analysis for the same spec and cannot drift.
func NewDefaultGraphAnalyzer(spec AnalysisSpec) finding.GraphAnalyzer {
	return func(ctx context.Context) (*types.ErrorGraph, error) {
		graph, _, err := PerformAnalysisWithSpec(ctx, spec)
		if err != nil {
			return nil, err
		}

		return graph, nil
	}
}
