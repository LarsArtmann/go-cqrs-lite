package pipeline

import (
	"context"
	"os"
	"path/filepath"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func writeModuleFixture(t *testing.T, dir, modulePath string) {
	t.Helper()
	require.NoError(t, os.MkdirAll(dir, 0o755))
	require.NoError(t, os.WriteFile(
		filepath.Join(dir, "go.mod"),
		[]byte("module "+modulePath+"\n\ngo 1.26\n"),
		0o644,
	))
}

func TestRecursivePatternRoot(t *testing.T) {
	t.Parallel()

	tests := map[string]string{
		"./...":              ".",
		"./pkg/...":          "./pkg",
		"pkg/...":            "pkg",
		"github.com/x/y/...": "github.com/x/y",
		"...":                "",
		"./pkg":              "",
	}

	for pattern, want := range tests {
		assert.Equal(t, want, recursivePatternRoot(pattern), "pattern %q", pattern)
	}
}

// TestPerformAnalysis_WarnsOnSkippedSubModules pins the monorepo coverage
// contract: a recursive pattern analyzes the root module only (go tooling
// treats nested go.mod files as boundaries), filesScanned proves sub-module
// code was skipped, and the warning tells the user about it.
func TestPerformAnalysis_WarnsOnSkippedSubModules(t *testing.T) {
	dir := t.TempDir()
	writeModuleFixture(t, dir, "example.com/root")
	require.NoError(t, os.WriteFile(
		filepath.Join(dir, "main.go"),
		[]byte("package main\n\nfunc main() {}\n"),
		0o644,
	))

	sub := filepath.Join(dir, "sub")
	writeModuleFixture(t, sub, "example.com/sub")
	require.NoError(t, os.WriteFile(
		filepath.Join(sub, "sub.go"),
		[]byte("package sub\n\nfunc Open() error { return nil }\n"),
		0o644,
	))

	var graph *types.ErrorGraph

	stderr := captureStderr(t, func() {
		var err error

		graph, _, err = PerformAnalysisWithSpec(
			context.Background(),
			AnalysisSpec{Path: filepath.Join(dir, "...")},
		)
		require.NoError(t, err)
	})

	require.NotNil(t, graph)
	assert.Equal(t, 1, graph.FilesScanned, "sub-module code must not be analyzed by the root-module pattern")
	assert.Contains(t, stderr, "nested go.mod")
	assert.Contains(t, stderr, "cd ./sub && erraudit ./...")
}
