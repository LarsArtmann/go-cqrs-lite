package pipeline

import (
	"io/fs"
	"os"
	"path/filepath"
	"sort"
	"strings"

	apierrors "github.com/larsartmann/erraudit/pkg/errors"
)

// ResolveTarget determines the working directory and package patterns from CLI args.
// When a single argument is an existing directory, it returns that directory with ["."]
// as the pattern. For files or multiple arguments, it returns empty dir and the args
// as patterns.
func ResolveTarget(args []string) (string, []string, error) {
	if len(args) != 1 {
		return "", args, nil
	}

	// Handle Go package patterns (./..., ./pkg/...) without trying to stat them.
	// IsPackagePattern also returns true for single-segment names like "main.go"
	// and "." which ARE real filesystem paths and should be statted — only patterns
	// containing "..." are truly non-filesystem package specifiers.
	if IsPackagePattern(args[0]) && strings.Contains(args[0], "...") {
		return "", args, nil
	}

	info, err := os.Stat(args[0])
	if err != nil {
		return "", nil, apierrors.Wrap(err, "stat %s", args[0])
	}

	if !info.IsDir() {
		return "", args, nil
	}

	return args[0], []string{"."}, nil
}

// IsPackagePattern detects whether a path is a Go package pattern (e.g., "./...").
func IsPackagePattern(path string) bool {
	return strings.Contains(path, "...") ||
		(!filepath.IsAbs(path) && !strings.Contains(path, string(filepath.Separator)))
}

// EnsureRecursivePattern converts a bare directory path to a recursive Go
// package pattern. If path is already a package pattern (contains "...") or
// is not a directory, it is returned unchanged. This ensures that directory
// paths like "." or "./examples" are analyzed recursively via AnalyzePackage
// instead of non-recursively via AnalyzeDirectory.
func EnsureRecursivePattern(path string) string {
	if strings.Contains(path, "...") {
		return path
	}

	info, err := os.Stat(path)
	if err != nil || !info.IsDir() {
		return path
	}

	pattern := filepath.ToSlash(filepath.Join(path, "..."))

	// filepath.Join/Clean strips a leading "./", but a bare "pkg/errors/..."
	// is resolved as a module path by go/packages (matching nothing in the
	// main module). Relative patterns must keep the "./" prefix so they stay
	// filesystem-anchored, like the equivalent user-supplied "./pkg/errors/...".
	if !filepath.IsAbs(path) && !strings.HasPrefix(pattern, "./") {
		pattern = "./" + pattern
	}

	return pattern
}

// hasModuleContext reports whether dir is inside a Go module (dir itself or
// an ancestor contains a go.mod), mirroring the go command's module
// discovery. Package-mode analysis needs this context; without it a bare
// directory must stay on file analysis even under --type-aware.
func hasModuleContext(dir string) bool {
	for {
		if _, err := os.Stat(filepath.Join(dir, "go.mod")); err == nil {
			return true
		}

		parent := filepath.Dir(dir)
		if parent == dir {
			return false
		}

		dir = parent
	}
}

// NestedModuleDirs returns the slash-relative paths of directories under dir
// (excluding dir itself) that contain a go.mod file, sorted lexically.
// Nested go.mod files are module boundaries for go tooling, so recursive
// package patterns rooted at dir ("./...") never cross them; callers use
// this to warn about silently skipped sub-modules. Best-effort: unreadable
// subtrees are skipped, and fixture-only trees (dot-dirs, vendor, testdata)
// are not searched.
func NestedModuleDirs(dir string) []string {
	var nested []string

	walkErr := filepath.WalkDir(dir, func(path string, d fs.DirEntry, err error) error {
		if err != nil {
			return nil //nolint:nilerr // best-effort walk; skip unreadable paths
		}

		if !d.IsDir() {
			if d.Name() != "go.mod" {
				return nil
			}

			moduleDir := filepath.Dir(path)

			if rel, relErr := filepath.Rel(dir, moduleDir); relErr == nil && rel != "." {
				nested = append(nested, filepath.ToSlash(rel))
			}

			return nil
		}

		if path != dir {
			name := d.Name()
			if strings.HasPrefix(name, ".") || name == "vendor" || name == "testdata" {
				return filepath.SkipDir
			}
		}

		return nil
	})
	if walkErr != nil {
		return nested
	}

	sort.Strings(nested)

	return nested
}
