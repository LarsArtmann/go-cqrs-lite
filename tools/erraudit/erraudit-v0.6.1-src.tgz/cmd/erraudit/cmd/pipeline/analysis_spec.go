package pipeline

import (
	"context"

	"github.com/larsartmann/erraudit/pkg/types"
)

// AnalysisSpec is the typed configuration for one analysis run. It replaces
// the ten-positional-bool PerformAnalysis signature as the single source of
// truth: the CLI, the go-finding pipeline path, and the BuildFlow toolsdk
// provider all construct one of these, so their defaults can never drift
// apart (the split-brain the provider previously had via a parallel
// hardcoded call).
type AnalysisSpec struct {
	// Path is the analysis target: a directory, a package pattern, or a
	// file. "." means the current directory.
	Path string

	// ExcludedPaths are paths to skip during analysis.
	ExcludedPaths []string

	// TypeAware enables go/types resolution (package mode). Required for
	// the legacy analyzer and type-based false-positive rejection.
	TypeAware bool

	// EnforceErrorFamily flags stdlib error constructors (opt-in check).
	EnforceErrorFamily bool

	// EnforceSamberOops flags stdlib constructors + oops anti-patterns.
	EnforceSamberOops bool

	// EnforceGenericReturn flags functions returning bare error (opt-in).
	EnforceGenericReturn bool

	// EnforceDeferredClose flags defer x.Close() ignoring the error (opt-in).
	EnforceDeferredClose bool

	// EnforceCodedErrors flags go-error-family constructors with empty ("")
	// error codes (opt-in).
	EnforceCodedErrors bool

	// NoSuppress bypasses //nolint comments AND AST false-positive
	// heuristics (audit mode).
	NoSuppress bool

	// ModulesAll fans a multi-module target out into one analysis per
	// nested go.mod module and merges the graphs (--modules=all).
	ModulesAll bool

	// Progress renders analysis progress on stderr.
	Progress bool

	// Suppress applies domain-level //nolint suppression to the returned
	// violations. The CLI analyze path keeps suppression inside the output
	// strategies, so it leaves this false and handles it itself.
	Suppress bool

	// Explain populates per-violation explanations after analysis.
	Explain bool
}

// DefaultAnalysisSpec returns the production defaults for analyzing path:
// type-aware, suppression and explanations on, all enforcement opt-ins off,
// no progress rendering. This is the contract the BuildFlow provider and the
// go-finding pipeline path expose to consumers.
func DefaultAnalysisSpec(path string) AnalysisSpec {
	return AnalysisSpec{
		Path:                 path,
		ExcludedPaths:        nil,
		TypeAware:            true,
		EnforceErrorFamily:   false,
		EnforceSamberOops:    false,
		EnforceGenericReturn: false,
		EnforceDeferredClose: false,
		EnforceCodedErrors:   false,
		NoSuppress:           false,
		ModulesAll:           false,
		Progress:             false,
		Suppress:             true,
		Explain:              true,
	}
}

// FinalizeViolations is the single post-analysis finishing step shared by
// every output path: //nolint suppression (unless audit mode bypasses it)
// followed by per-violation explanations. One implementation means the
// analyze, watch, lint, --pipeline, and LSP paths cannot disagree on what
// is suppressed or why (the suppress+explain choke point).
func FinalizeViolations(
	violations []types.ErrorViolation,
	sourceFiles []string,
	noSuppress bool,
	explain bool,
) []types.ErrorViolation {
	if !noSuppress {
		violations = SuppressViolations(violations, sourceFiles)
	}

	if explain {
		types.PopulateExplanations(violations)
	}

	return violations
}

// PerformAnalysisWithSpec runs the analysis pipeline for the given spec and
// applies the spec's post-processing (suppression, explanations). It is the
// single entry point for every consumer — CLI paths, the go-finding pipeline,
// and the BuildFlow provider — so a new flag threads through one struct
// instead of a positional bool list that drifts per call site.
func PerformAnalysisWithSpec(
	ctx context.Context,
	spec AnalysisSpec,
) (*types.ErrorGraph, []types.ErrorViolation, error) {
	graph, _, err := performAnalysis(ctx, spec)
	if err != nil {
		return nil, nil, err
	}

	if graph == nil {
		return nil, nil, nil
	}

	// Suppression runs only when the spec asks the pipeline to own it
	// (Suppress) and audit mode has not bypassed it (NoSuppress). When the
	// caller handles suppression itself, FinalizeViolations must skip it —
	// same behavior, one choke point.
	bypassSuppression := spec.NoSuppress || !spec.Suppress

	graph.Violations = FinalizeViolations(
		graph.Violations,
		SourceFilesFromGraph(graph),
		bypassSuppression,
		spec.Explain,
	)

	return graph, graph.Violations, nil
}
