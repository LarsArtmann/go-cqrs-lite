package pipeline

import (
	"context"
	"io"
	"os"
	"path/filepath"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

const testGoCode = `package testfixture

import "os"

func helper() {
	file, _ := os.Open("test.txt")
	defer file.Close()
}

func add(a, b int) int {
	return a + b
}
`

func writeTestGoFile(t *testing.T, dir, name string) string {
	t.Helper()
	path := filepath.Join(dir, name)
	require.NoError(t, os.WriteFile(path, []byte(testGoCode), 0o644))
	return path
}

func TestPerformAnalysis_Directory(t *testing.T) {
	dir := t.TempDir()
	writeTestGoFile(t, dir, "main.go")

	graph, violations, err := PerformAnalysisWithSpec(
		context.Background(),
		AnalysisSpec{Path: dir},
	)
	require.NoError(t, err)
	require.NotNil(t, graph)
	// helper() ignores error from os.Open → should detect ignored violation
	assert.NotEmpty(t, violations)
}

func TestPerformAnalysis_SingleFile(t *testing.T) {
	dir := t.TempDir()
	filePath := writeTestGoFile(t, dir, "main.go")

	graph, violations, err := PerformAnalysisWithSpec(
		context.Background(),
		AnalysisSpec{Path: filePath},
	)
	require.NoError(t, err)
	require.NotNil(t, graph)
	assert.NotEmpty(t, violations)
}

func TestPerformAnalysis_NonExistentPath(t *testing.T) {
	_, _, err := PerformAnalysisWithSpec(
		context.Background(),
		AnalysisSpec{Path: "/nonexistent/path/that/does/not/exist"},
	)
	require.Error(t, err)
}

func TestPerformAnalysis_NonGoFile(t *testing.T) {
	dir := t.TempDir()
	filePath := filepath.Join(dir, "test.txt")
	require.NoError(t, os.WriteFile(filePath, []byte("not Go"), 0o644))

	_, _, err := PerformAnalysisWithSpec(
		context.Background(),
		AnalysisSpec{Path: filePath},
	)
	require.Error(t, err)
}

func TestPerformAnalysis_WithExclusions(t *testing.T) {
	dir := t.TempDir()
	writeTestGoFile(t, dir, "included.go")

	excludedDir := filepath.Join(dir, "excluded")
	require.NoError(t, os.Mkdir(excludedDir, 0o755))
	writeTestGoFile(t, excludedDir, "excluded.go")

	graph, _, err := PerformAnalysisWithSpec(
		context.Background(),
		AnalysisSpec{Path: dir, ExcludedPaths: []string{excludedDir}},
	)
	require.NoError(t, err)
	require.NotNil(t, graph)
}

func TestPerformAnalysis_TypeAware(t *testing.T) {
	dir := t.TempDir()
	writeTestGoFile(t, dir, "main.go")

	graph, _, err := PerformAnalysisWithSpec(
		context.Background(),
		AnalysisSpec{Path: dir, TypeAware: true},
	)
	require.NoError(t, err)
	require.NotNil(t, graph)
}

// TestPerformAnalysis_TypeAware_PromotesModuleDirectory asserts the S27 fix:
// a bare directory path with --type-aware inside a module is auto-promoted
// to the recursive package pattern (package mode builds the TypeResolver;
// file mode would silently drop type awareness).
func TestPerformAnalysis_TypeAware_PromotesModuleDirectory(t *testing.T) {
	dir := t.TempDir()
	writeTestGoFile(t, dir, "main.go")
	require.NoError(t, os.WriteFile(filepath.Join(dir, "go.mod"),
		[]byte("module example.com/fixture\n\ngo 1.26\n"), 0o644))

	var graph *types.ErrorGraph

	stderr := captureStderr(t, func() {
		var err error

		graph, _, err = PerformAnalysisWithSpec(
			context.Background(),
			AnalysisSpec{Path: dir, TypeAware: true},
		)
		require.NoError(t, err)
	})

	require.NotNil(t, graph)
	assert.Contains(t, stderr, "promoting directory")
	assert.Contains(t, stderr, dir+"/...")
}

// TestPerformAnalysis_TypeAware_NoModuleFallsBackToFileAnalysis asserts the
// no-module case keeps file analysis (with a warning) instead of failing:
// package mode cannot run without module context.
func TestPerformAnalysis_TypeAware_NoModuleFallsBackToFileAnalysis(t *testing.T) {
	dir := t.TempDir()
	writeTestGoFile(t, dir, "main.go")

	var graph *types.ErrorGraph

	stderr := captureStderr(t, func() {
		var err error

		graph, _, err = PerformAnalysisWithSpec(
			context.Background(),
			AnalysisSpec{Path: dir, TypeAware: true},
		)
		require.NoError(t, err)
	})

	require.NotNil(t, graph)
	assert.Contains(t, stderr, "no module context")
}

// captureStderr runs fn with os.Stderr swapped to a pipe and returns
// everything written during it.
func captureStderr(t *testing.T, fn func()) string {
	t.Helper()

	original := os.Stderr
	r, w, err := os.Pipe()
	require.NoError(t, err)

	t.Cleanup(func() { os.Stderr = original })

	os.Stderr = w
	fn()
	os.Stderr = original
	require.NoError(t, w.Close())

	out, err := io.ReadAll(r)
	require.NoError(t, err)

	return string(out)
}

func TestPerformAnalysis_EnforceSamberOops(t *testing.T) {
	oopsCode := `package testfixture

import (
	"errors"
	"github.com/samber/oops"
)

var ErrSentinel = errors.New("sentinel")

func process() error {
	err := step()
	if err != nil {
		return oops.Wrap(err)
	}
	return nil
}

func step() error { return nil }`

	dir := t.TempDir()
	filePath := filepath.Join(dir, "oops_demo.go")
	require.NoError(t, os.WriteFile(filePath, []byte(oopsCode), 0o644))

	// EnforceSamberOops is a named spec field (the old positional form had it
	// as the 5th bool, which is exactly the drift the spec migration kills).
	graph, violations, err := PerformAnalysisWithSpec(
		context.Background(),
		AnalysisSpec{Path: dir, EnforceSamberOops: true},
	)
	require.NoError(t, err)
	require.NotNil(t, graph)

	// Should flag errors.New (stdlib constructor enforcement)
	var foundStdlib, foundRedundantGuard bool

	for _, v := range violations {
		if v.Type == "stdlib_constructor" {
			foundStdlib = true
			assert.Contains(t, v.Message, "samber/oops")
		}

		if v.Type == "oops_redundant_guard" {
			foundRedundantGuard = true
			assert.NotEmpty(t, v.CodeSnippet, "oops_redundant_guard violation should have a code snippet")
		}
	}

	assert.True(t, foundStdlib, "should flag errors.New via oops enforcement")
	assert.True(t, foundRedundantGuard, "should detect redundant nil guard")
}

// TestPerformAnalysis_NoSuppress threads the --no-suppress flag through the
// full pipeline: PerformAnalysis → MainAnalyzer → AST Analyzer. When
// noSuppress is false, the signature-aware check suppresses blank-identifier
// assignments to same-file functions returning non-error. When true, the
// violation appears.
func TestPerformAnalysis_NoSuppress(t *testing.T) {
	// getCount returns (int, int) — position 0 is int, not error.
	// Without signature-aware suppression this is a false positive.
	sigCode := `package testfixture

func caller() int {
	_, n := getCount()
	return n
}

func getCount() (int, int) { return 0, 0 }
`

	dir := t.TempDir()
	filePath := filepath.Join(dir, "sig.go")
	require.NoError(t, os.WriteFile(filePath, []byte(sigCode), 0o644))

	// Default mode (noSuppress=false): signature-aware check suppresses the
	// false positive — no ErrorTypeIgnored violations.
	_, suppressed, err := PerformAnalysisWithSpec(
		context.Background(), AnalysisSpec{Path: dir},
	)
	require.NoError(t, err)
	for _, v := range suppressed {
		if v.Type == "ignored" {
			t.Fatalf("expected no ignored violations with noSuppress=false, got: %s", v.Message)
		}
	}

	// noSuppress=true: signature-aware check bypassed — the violation appears.
	_, all, err := PerformAnalysisWithSpec(
		context.Background(), AnalysisSpec{Path: dir, NoSuppress: true},
	)
	require.NoError(t, err)

	found := false
	for _, v := range all {
		if v.Type == "ignored" {
			found = true
			break
		}
	}
	assert.True(t, found, "expected an ignored violation with noSuppress=true (signature-aware check bypassed)")
}
