package pipeline

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"

	"github.com/larsartmann/erraudit/cmd/erraudit/cmd/output"
	"github.com/larsartmann/erraudit/internal/analyzer"
	apierrors "github.com/larsartmann/erraudit/pkg/errors"
	"github.com/larsartmann/erraudit/pkg/suppression"
	"github.com/larsartmann/erraudit/pkg/types"
)

// performAnalysis runs the core analysis pipeline: create analyzer → detect
// path type → analyze. It is the shared core behind every entry point (CLI
// analyze/watch/lint/tree/nolint-audit, the go-finding pipeline, and the
// BuildFlow provider); PerformAnalysisWithSpec adds the suppress+explain
// finishing step on top of what this returns.
// With spec.ModulesAll set, a multi-module target is analyzed per module
// (root + every nested go.mod directory, each as its own package pattern) and
// the per-module graphs are merged into one report; without it, nested
// modules are skipped (go tooling module boundaries) and recorded on the
// graph as SkippedModules.
func performAnalysis(
	ctx context.Context,
	spec AnalysisSpec,
) (*types.ErrorGraph, []types.ErrorViolation, error) {
	var progressFn analyzer.ProgressFunc

	printer := analyzer.NewProgressPrinter(os.Stderr)

	if spec.Progress {
		progressFn = printer.Record
	}

	opts := analyzerOptions(spec)
	if progressFn != nil {
		opts = append(opts, analyzer.WithProgress(progressFn))
	}

	mainAnalyzer := analyzer.NewMainAnalyzerWithOptions(opts...)

	// Finish no-ops when nothing was recorded (progress disabled or no work).
	defer printer.Finish()

	// --modules=all fans a multi-module target out into one full analysis per
	// module (each nested go.mod is a hard boundary for go/packages, so a
	// single recursive pattern can never cover them). Single-file targets
	// have nothing to fan out over.
	if spec.ModulesAll {
		if root, ok := modulesFanOutRoot(spec.Path); ok {
			return analyzeAllModules(ctx, mainAnalyzer, root)
		}
	}

	// "." resolves as a single-segment package pattern, but routing it to
	// package mode yields the bare "..." pattern which matches nothing in
	// module mode. Treat it as the directory it is so it gets the same
	// promotion/walk treatment as an explicit directory path.
	if IsPackagePattern(spec.Path) && filepath.Clean(spec.Path) != "." {
		// EnsureRecursivePattern (not hand-built `path + "..."`): a bare
		// relative directory like "sub" matches IsPackagePattern (no
		// separator), and "sub/..." is resolved as a MODULE path by
		// go/packages (matching nothing in the main module). The helper
		// keeps "./" for real directories so the pattern stays
		// filesystem-anchored, while explicit module-path patterns and
		// user-supplied "..."/"pkg/..." forms pass through unchanged.
		pattern := EnsureRecursivePattern(spec.Path)

		graph, err := mainAnalyzer.AnalyzePackage(ctx, pattern)
		if err != nil {
			return nil, nil, wrapPackageAnalysisError(err, spec.Path, spec.TypeAware)
		}

		recordSkippedModules(graph, recursivePatternRoot(pattern))
		warnPartialModuleCoverage(recursivePatternRoot(pattern), graph.FilesScanned)

		return graph, graph.Violations, nil
	}

	fileInfo, err := os.Stat(spec.Path)
	if err != nil {
		return nil, nil, apierrors.Wrap(
			err,
			"failed to stat path %s",
			spec.Path,
		)
	}

	if !fileInfo.IsDir() && !strings.HasSuffix(spec.Path, ".go") {
		return nil, nil, apierrors.Wrap(
			apierrors.ErrNotGoFile,
			"%s",
			spec.Path,
		)
	}

	var graph *types.ErrorGraph

	if fileInfo.IsDir() {
		switch {
		case spec.TypeAware && hasModuleContext(spec.Path):
			// --type-aware only takes effect in package mode: AnalyzeDirectory
			// never builds a TypeResolver, so with a bare directory path the
			// flag would silently not apply (and --no-suppress would then flag
			// every blank identifier, including non-error returns). Promote
			// the directory to a recursive package pattern so the requested
			// type information is actually used.
			promoted := EnsureRecursivePattern(spec.Path)
			fmt.Fprintf(os.Stderr,
				"erraudit: promoting directory %q to package pattern %q (--type-aware requires package mode)\n",
				spec.Path, promoted)

			graph, err = mainAnalyzer.AnalyzePackage(ctx, promoted)
			if err == nil {
				recordSkippedModules(graph, spec.Path)
				warnPartialModuleCoverage(spec.Path, graph.FilesScanned)
			}
		case spec.TypeAware:
			fmt.Fprintf(os.Stderr,
				"erraudit: --type-aware is inactive for %s: no module context (go.mod) found, using file analysis\n",
				spec.Path)

			graph, err = mainAnalyzer.AnalyzeDirectory(ctx, spec.Path)
		default:
			graph, err = mainAnalyzer.AnalyzeDirectory(ctx, spec.Path)
		}
	} else {
		if spec.TypeAware {
			fmt.Fprintf(os.Stderr,
				"erraudit: --type-aware has no effect on single-file analysis (%s)\n", spec.Path)
		}

		graph, err = mainAnalyzer.AnalyzeFile(ctx, spec.Path)
	}

	if err != nil {
		return nil, nil, apierrors.Wrap(
			err,
			"failed to analyze %s",
			spec.Path,
		)
	}

	return graph, graph.Violations, nil
}

// analyzerOptions maps the analysis spec to MainAnalyzer options. Extracted
// from performAnalysis so the path-dispatch logic and the option assembly
// each stay under the complexity budget.
func analyzerOptions(spec AnalysisSpec) []analyzer.MainAnalyzerOption {
	var opts []analyzer.MainAnalyzerOption

	if len(spec.ExcludedPaths) > 0 {
		opts = append(opts, analyzer.WithExclusions(spec.ExcludedPaths))
	}

	if spec.TypeAware {
		opts = append(opts, analyzer.WithTypeInfo(true))
	}

	if spec.EnforceErrorFamily {
		opts = append(opts, analyzer.WithEnforceErrorFamily(true))
	}

	if spec.EnforceSamberOops {
		opts = append(opts, analyzer.WithEnforceSamberOops(true))
	}

	if spec.EnforceGenericReturn {
		opts = append(opts, analyzer.WithEnforceGenericReturn(true))
	}

	if spec.EnforceDeferredClose {
		opts = append(opts, analyzer.WithEnforceDeferredClose(true))
	}

	if spec.EnforceCodedErrors {
		opts = append(opts, analyzer.WithEnforceCodedErrors(true))
	}

	if spec.NoSuppress {
		opts = append(opts, analyzer.WithNoSuppress(true))
	}

	return opts
}

// wrapPackageAnalysisError enriches an analysis failure with the operational
// context (pattern, mode) a debugger needs. Package-local seam: the caller
// stays declarative and the error-construction policy lives in one place.
func wrapPackageAnalysisError(err error, path string, typeAware bool) error {
	return apierrors.WrapContext(
		err,
		map[string]string{"path": path, "type_aware": strconv.FormatBool(typeAware)},
		"failed to analyze package %s",
		path,
	)
}

// recursivePatternRoot maps a recursive package pattern to the directory it
// is rooted at ("./pkg/..." → "./pkg", "./..." → "."). Non-filesystem
// patterns (module paths like "github.com/x/y/...") return "".
func recursivePatternRoot(pattern string) string {
	if before, _, ok := strings.Cut(pattern, "/..."); ok {
		return before
	}

	if before, ok := strings.CutSuffix(pattern, "..."); ok {
		return before
	}

	return ""
}

// modulesFanOutRoot resolves the filesystem directory a --modules=all target
// fans out over: the pattern's root for package patterns (module-path
// patterns like "github.com/x/y/..." have no filesystem root and are
// rejected), or the directory itself. Single files return false (nothing to
// fan out over).
func modulesFanOutRoot(path string) (string, bool) {
	if IsPackagePattern(path) {
		root := recursivePatternRoot(EnsureRecursivePattern(path))

		return root, root != ""
	}

	fileInfo, err := os.Stat(path)
	if err != nil || !fileInfo.IsDir() {
		return "", false
	}

	return path, true
}

// analyzeAllModules runs one full package-mode analysis per module (the root
// module plus every nested go.mod directory under root, each from its own
// module root so go/packages resolves it correctly) and merges the per-module
// graphs into a single report. Merging goes through analyzer.MergeGraphs —
// never inline.
func analyzeAllModules(
	ctx context.Context,
	mainAnalyzer *analyzer.MainAnalyzer,
	root string,
) (*types.ErrorGraph, []types.ErrorViolation, error) {
	moduleDirs := append([]string{"."}, NestedModuleDirs(root)...)

	merged := &types.ErrorGraph{Package: root}

	for _, moduleDir := range moduleDirs {
		pattern := modulePattern(root, moduleDir)

		graph, err := mainAnalyzer.AnalyzePackage(ctx, pattern)
		if err != nil {
			return nil, nil, apierrors.Wrap(
				err,
				"failed to analyze module %s",
				moduleDir,
			)
		}

		analyzer.MergeGraphs(merged, graph)
	}

	return merged, merged.Violations, nil
}

// modulePattern builds the recursive package pattern for one module of a
// fan-out: the root module analyzes from root itself; a nested module from
// its own directory, so its go.mod is the module root go/packages needs.
func modulePattern(root, moduleDir string) string {
	if moduleDir == "." {
		return EnsureRecursivePattern(root)
	}

	return EnsureRecursivePattern(filepath.Join(root, moduleDir))
}

// recordSkippedModules stores the nested modules a non-fan-out run did not
// analyze on the graph, so JSON consumers see coverage boundaries without
// parsing stderr warnings.
func recordSkippedModules(graph *types.ErrorGraph, dir string) {
	if graph == nil || dir == "" {
		return
	}

	graph.SkippedModules = NestedModuleDirs(dir)
}

// warnPartialModuleCoverage reports when a recursive package pattern only
// covered the root module: nested go.mod files are module boundaries for go
// tooling, so "./..." silently skips every sub-module. Without this warning
// a 1%-coverage run is indistinguishable from a full clean analysis.
func warnPartialModuleCoverage(dir string, filesScanned int) {
	if dir == "" {
		return
	}

	nested := NestedModuleDirs(dir)
	if len(nested) == 0 {
		return
	}

	fmt.Fprintf(
		os.Stderr,
		"erraudit: multi-module repo: %d nested go.mod file(s) under %s are module boundaries and were NOT analyzed (scanned %d file(s) of the root module only).\n",
		len(nested),
		dir,
		filesScanned,
	)
	fmt.Fprintf(os.Stderr,
		"erraudit: nested modules: %s\n",
		previewList(nested))
	fmt.Fprintln(
		os.Stderr,
		"erraudit: hint: analyze a sub-module from its own root: cd ./"+nested[0]+" && erraudit ./...",
	)
}

// previewList renders up to 8 entries plus a remainder count.
func previewList(entries []string) string {
	const maxShown = 8

	shown := entries
	if len(shown) > maxShown {
		shown = shown[:maxShown]
	}

	preview := strings.Join(shown, ", ")
	if remainder := len(entries) - len(shown); remainder > 0 {
		preview += fmt.Sprintf(", … +%d more", remainder)
	}

	return preview
}

// FilterViolations filters violations based on severity, type, severity threshold,
// and disabled types. Filters are applied directly on domain types without
// round-tripping through the go-finding bridge, ensuring predictable semantics.
func FilterViolations(
	violations []types.ErrorViolation,
	severityFilter *types.Severity,
	typeFilter *types.ErrorType,
	severityThreshold *types.Severity,
	disabledTypes map[types.ErrorType]bool,
) []types.ErrorViolation {
	if severityFilter == nil && typeFilter == nil && severityThreshold == nil && len(disabledTypes) == 0 {
		return violations
	}

	result := make([]types.ErrorViolation, 0, len(violations))

	for _, v := range violations {
		if disabledTypes[v.Type] {
			continue
		}

		if severityFilter != nil && v.Severity != *severityFilter {
			continue
		}

		if severityThreshold != nil && !v.Severity.AtOrAbove(*severityThreshold) {
			continue
		}

		if typeFilter != nil && v.Type != *typeFilter {
			continue
		}

		result = append(result, v)
	}

	return result
}

// SourceFilesFromGraph collects unique source file paths from the ErrorGraph's
// violations and errors, used for //nolint suppression matching. This is the
// shared extraction point used by the default analysis path, the pipeline path,
// and watch mode so all three respect //nolint suppression consistently.
func SourceFilesFromGraph(graph *types.ErrorGraph) []string {
	seen := make(map[string]struct{})

	for _, v := range graph.Violations {
		if v.Position.Filename != "" {
			seen[v.Position.Filename] = struct{}{}
		}
	}

	for _, e := range graph.Errors {
		if e.Position.Filename != "" {
			seen[e.Position.Filename] = struct{}{}
		}
	}

	result := make([]string, 0, len(seen))
	for f := range seen {
		result = append(result, f)
	}

	return result
}

// SuppressViolations filters out violations that have a matching //nolint comment
// in the source files. This operates on domain types before any output strategy
// runs, so all output formats respect //nolint suppression.
//
// Suppression architecture (consolidated 2026-08-05):
//
//  1. PRIMARY (this function): Removes suppressed violations from the domain
//     slice. Called by all four analysis paths — default (analyzer.go), watch
//     (watch.go), pipeline (finding_pipeline.go), and lint (lint_runner.go) —
//     BEFORE any output strategy runs. Format-agnostic; one application point.
//
//  2. DEFENSE-IN-DEPTH: finding.ApplyNolintSuppressions marks (does not remove)
//     findings as suppressed in the SARIF/JSON output strategy. Redundant with
//     the primary layer by design — a safety net if a future path forgets to
//     call SuppressViolations. Excluded findings via Report.ActiveFindings().
//
//  3. SEPARATE LAYER: legacyerrors.hasSuppressComment skips diagnostic emission
//     inside the go/analysis-based linter (`erraudit lint`). This is a distinct
//     code path (the legacyerrors analyzer, not the violation pipeline) and
//     cannot share the domain-level mechanism.
//
// --no-suppress bypasses layer 1 and 2 (legacyerrors uses DisableNolintSuppression).
func SuppressViolations(
	violations []types.ErrorViolation,
	sourceFiles []string,
) []types.ErrorViolation {
	if len(violations) == 0 {
		return violations
	}

	engine := suppression.BuildEngineFromFiles(sourceFiles)
	if engine.RuleCount() == 0 {
		return violations
	}

	result := make([]types.ErrorViolation, 0, len(violations))

	for _, v := range violations {
		if !engine.ShouldSuppress(v.Type, v.Position.Filename, v.Position.Line, "") {
			result = append(result, v)
		}
	}

	return result
}

// GenerateOutputString creates output using the strategy registry.
func GenerateOutputString(
	outputFormat types.OutputFormat,
	dotTheme string,
	violationsOnly bool,
	graph *types.ErrorGraph,
	violations []types.ErrorViolation,
) (string, error) {
	registry := output.NewStrategyRegistry(dotTheme, violationsOnly)

	strategy, err := registry.Get(outputFormat)
	if err != nil {
		return "", apierrors.Wrap(err,
			"error getting output strategy for format %s (violations=%d)",
			outputFormat, len(violations))
	}

	outputStr, err := strategy.Generate(graph, violations)
	if err != nil {
		return "", apierrors.Wrap(err,
			"error generating %s output (violations=%d)",
			outputFormat, len(violations))
	}

	return outputStr, nil
}
