package pipeline

import (
	"go/token"
	"os"
	"path/filepath"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// TestFinalizeViolationsChokePoint pins the shared finishing step's contract:
// //nolint suppression removes the suppressed violation and keeps the rest,
// explanations are populated only when asked, and audit mode (noSuppress)
// bypasses suppression. Every output path routes through this function, so
// this test guards all of them at once.
func TestFinalizeViolationsChokePoint(t *testing.T) {
	dir := t.TempDir()
	file := filepath.Join(dir, "sample.go")
	source := "package sample\n\nvar _ = 1 //nolint:erraudit // intentional suppression fixture\n"
	require.NoError(t, os.WriteFile(file, []byte(source), 0o600))

	suppressed := types.ErrorViolation{
		Type:     types.ErrorTypeIgnored,
		Severity: types.SeverityHigh,
		Position: token.Position{Filename: file, Line: 3},
	}
	kept := types.ErrorViolation{
		Type:     types.ErrorTypeSilentSwallow,
		Severity: types.SeverityHigh,
		Position: token.Position{Filename: file, Line: 4},
	}

	t.Run("suppression removes nolinted violations", func(t *testing.T) {
		got := FinalizeViolations(
			[]types.ErrorViolation{suppressed, kept},
			[]string{file},
			false,
			false,
		)
		require.Len(t, got, 1)
		assert.Equal(t, types.ErrorTypeSilentSwallow, got[0].Type)
	})

	t.Run("explanations populate only when asked", func(t *testing.T) {
		without := FinalizeViolations([]types.ErrorViolation{kept}, []string{file}, true, false)
		assert.Empty(t, without[0].Explanation)

		with := FinalizeViolations([]types.ErrorViolation{kept}, []string{file}, true, true)
		assert.NotEmpty(t, with[0].Explanation)
	})

	t.Run("audit mode bypasses suppression", func(t *testing.T) {
		got := FinalizeViolations(
			[]types.ErrorViolation{suppressed, kept},
			[]string{file},
			true,
			false,
		)
		assert.Len(t, got, 2)
	})
}
