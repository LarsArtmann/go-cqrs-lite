package pipeline

import (
	"go/token"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"pgregory.net/rapid"
)

// violationGen generates random ErrorViolation values.
func violationGen() *rapid.Generator[types.ErrorViolation] {
	return rapid.Custom(func(rt *rapid.T) types.ErrorViolation {
		return types.ErrorViolation{
			Position: token.Position{
				Filename: rapid.StringMatching(`[a-z]+\.go`).Draw(rt, "filename"),
				Line:     rapid.IntRange(1, 9999).Draw(rt, "line"),
				Column:   rapid.IntRange(1, 200).Draw(rt, "column"),
			},
			Type:     rapid.SampledFrom(types.ValidErrorTypes()).Draw(rt, "errorType"),
			Severity: rapid.SampledFrom(types.ValidSeverities()).Draw(rt, "severity"),
			Message:  rapid.StringMatching(`[a-zA-Z ]{5,30}`).Draw(rt, "message"),
		}
	})
}

// severityPtrGen generates a *Severity (nil or valid value).
func severityPtrGen() *rapid.Generator[*types.Severity] {
	return rapid.Custom(func(rt *rapid.T) *types.Severity {
		if rapid.Bool().Draw(rt, "hasSeverity") {
			s := rapid.SampledFrom(types.ValidSeverities()).Draw(rt, "severity")

			return &s
		}

		return nil
	})
}

// typePtrGen generates a *ErrorType (nil or valid value).
func typePtrGen() *rapid.Generator[*types.ErrorType] {
	return rapid.Custom(func(rt *rapid.T) *types.ErrorType {
		if rapid.Bool().Draw(rt, "hasType") {
			et := rapid.SampledFrom(types.ValidErrorTypes()).Draw(rt, "errorType")

			return &et
		}

		return nil
	})
}

// containsViolation reports whether violations contains an entry whose Key
// matches want. Used by property tests to assert that a filtered result still
// contains violations that should have survived the filter.
func containsViolation(violations []types.ErrorViolation, want types.ErrorViolation) bool {
	for _, v := range violations {
		if v.Key() == want.Key() {
			return true
		}
	}

	return false
}

func TestFilterViolations_NilFiltersReturnsAll(t *testing.T) {
	t.Parallel()

	rapid.Check(t, func(rt *rapid.T) {
		violations := rapid.SliceOf(violationGen()).Draw(rt, "violations")

		result := FilterViolations(violations, nil, nil, nil, nil)

		if len(result) != len(violations) {
			t.Fatalf("expected %d violations, got %d", len(violations), len(result))
		}
	})
}

func TestFilterViolations_SeverityFilterExact(t *testing.T) {
	t.Parallel()

	rapid.Check(t, func(rt *rapid.T) {
		violations := rapid.SliceOf(violationGen()).Draw(rt, "violations")
		sevFilter := rapid.SampledFrom(types.ValidSeverities()).Draw(rt, "severityFilter")

		result := FilterViolations(violations, &sevFilter, nil, nil, nil)

		for _, v := range result {
			if v.Severity != sevFilter {
				t.Fatalf("filtered result contains violation with severity %s, expected %s", v.Severity, sevFilter)
			}
		}

		// Verify no false negatives
		for _, v := range violations {
			if v.Severity == sevFilter {
				if !containsViolation(result, v) {
					t.Fatalf("violation with matching severity %s was incorrectly filtered out", v.Severity)
				}
			}
		}
	})
}

func TestFilterViolations_TypeFilterExact(t *testing.T) {
	t.Parallel()

	rapid.Check(t, func(rt *rapid.T) {
		violations := rapid.SliceOf(violationGen()).Draw(rt, "violations")
		typeFilter := rapid.SampledFrom(types.ValidErrorTypes()).Draw(rt, "typeFilter")

		result := FilterViolations(violations, nil, &typeFilter, nil, nil)

		for _, v := range result {
			if v.Type != typeFilter {
				t.Fatalf("filtered result contains violation with type %s, expected %s", v.Type, typeFilter)
			}
		}

		// Verify no false negatives
		for _, v := range violations {
			if v.Type == typeFilter {
				if !containsViolation(result, v) {
					t.Fatalf("violation with matching type %s was incorrectly filtered out", v.Type)
				}
			}
		}
	})
}

func TestFilterViolations_SeverityThreshold(t *testing.T) {
	t.Parallel()

	rapid.Check(t, func(rt *rapid.T) {
		violations := rapid.SliceOf(violationGen()).Draw(rt, "violations")
		threshold := rapid.SampledFrom(types.ValidSeverities()).Draw(rt, "threshold")

		result := FilterViolations(violations, nil, nil, &threshold, nil)

		for _, v := range result {
			if !v.Severity.AtOrAbove(threshold) {
				t.Fatalf(
					"filtered result contains violation with severity %s (ordinal %d), below threshold %s (ordinal %d)",
					v.Severity, v.Severity.Ordinal(), threshold, threshold.Ordinal(),
				)
			}
		}

		// Verify no false negatives
		for _, v := range violations {
			if v.Severity.AtOrAbove(threshold) {
				if !containsViolation(result, v) {
					t.Fatalf(
						"violation with severity %s (at/above threshold %s) was incorrectly filtered out",
						v.Severity, threshold,
					)
				}
			}
		}
	})
}

func TestFilterViolations_CombinedFilters(t *testing.T) {
	t.Parallel()

	rapid.Check(t, func(rt *rapid.T) {
		violations := rapid.SliceOf(violationGen()).Draw(rt, "violations")
		sevFilter := severityPtrGen().Draw(rt, "severityFilter")
		typFilter := typePtrGen().Draw(rt, "typeFilter")
		threshold := severityPtrGen().Draw(rt, "threshold")

		result := FilterViolations(violations, sevFilter, typFilter, threshold, nil)

		// All results must satisfy all active filters
		for _, v := range result {
			if sevFilter != nil && v.Severity != *sevFilter {
				t.Fatalf("severity mismatch: got %s, want %s", v.Severity, *sevFilter)
			}
			if typFilter != nil && v.Type != *typFilter {
				t.Fatalf("type mismatch: got %s, want %s", v.Type, *typFilter)
			}
			if threshold != nil && !v.Severity.AtOrAbove(*threshold) {
				t.Fatalf("threshold mismatch: %s is below %s", v.Severity, *threshold)
			}
		}

		// No false negatives
		for _, v := range violations {
			matches := true
			if sevFilter != nil && v.Severity != *sevFilter {
				matches = false
			}
			if typFilter != nil && v.Type != *typFilter {
				matches = false
			}
			if threshold != nil && !v.Severity.AtOrAbove(*threshold) {
				matches = false
			}

			if matches {
				if !containsViolation(result, v) {
					t.Fatalf("violation matching all filters was incorrectly excluded")
				}
			}
		}
	})
}

func TestFilterViolations_OutputNotLargerThanInput(t *testing.T) {
	t.Parallel()

	rapid.Check(t, func(rt *rapid.T) {
		violations := rapid.SliceOf(violationGen()).Draw(rt, "violations")
		sevFilter := severityPtrGen().Draw(rt, "severityFilter")
		typFilter := typePtrGen().Draw(rt, "typeFilter")
		threshold := severityPtrGen().Draw(rt, "threshold")

		result := FilterViolations(violations, sevFilter, typFilter, threshold, nil)

		if len(result) > len(violations) {
			t.Fatalf("output length %d exceeds input length %d", len(result), len(violations))
		}
	})
}

func TestFilterViolations_EmptyInput(t *testing.T) {
	t.Parallel()

	rapid.Check(t, func(rt *rapid.T) {
		sevFilter := severityPtrGen().Draw(rt, "severityFilter")
		typFilter := typePtrGen().Draw(rt, "typeFilter")
		threshold := severityPtrGen().Draw(rt, "threshold")

		result := FilterViolations(nil, sevFilter, typFilter, threshold, nil)

		if len(result) != 0 {
			t.Fatalf("expected empty result for nil input, got %d", len(result))
		}
	})
}
