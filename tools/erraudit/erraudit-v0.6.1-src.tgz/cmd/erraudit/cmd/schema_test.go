package cmd

import (
	"encoding/json/v2"
	"os"
	"path/filepath"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// TestConfigSchema_EnforcementFields verifies the JSON schema documents both
// enforcement flags as boolean properties. This prevents schema drift when new
// flags are added to AppConfig.
func TestConfigSchema_EnforcementFields(t *testing.T) {
	schemaPath := filepath.Join("..", "..", "..", "docs", "schema", "erraudit-config.schema.json")

	data, err := os.ReadFile(schemaPath)
	require.NoError(t, err, "schema file must exist at docs/schema/erraudit-config.schema.json")

	var schema struct {
		Properties map[string]struct {
			Type string `json:"type"`
		} `json:"properties"`
	}

	err = json.Unmarshal(data, &schema)
	require.NoError(t, err, "schema must be valid JSON")

	for _, field := range []string{"enforce_go_error_family", "enforce_samber_oops"} {
		prop, ok := schema.Properties[field]
		require.True(t, ok, "schema must contain %q property", field)
		assert.Equal(t, "boolean", prop.Type, "%q must be type boolean", field)
	}
}
