package cmd

import (
	"context"
	"fmt"
	"io"
	"os"
	"strings"

	v4 "github.com/larsartmann/cmdguard/v4/pkg/cmdguard/v4"
	"github.com/larsartmann/erraudit/cmd/erraudit/cmd/pipeline"
	"github.com/larsartmann/erraudit/internal/converter"
	apierrors "github.com/larsartmann/erraudit/pkg/errors"
	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/larsartmann/go-output"
	"github.com/spf13/cobra"
)

func registerTreeCommand(cli *v4.CLI[AppConfig]) error {
	cmd, err := v4.NewCommand[AppConfig, TreeFlags](
		"tree",
		TreeFlags{
			Markdown: false,
		},
		runTreeHandler,
		v4.WithShort("Render the error hierarchy as a styled ASCII tree"),
		v4.WithLong(`Render the error hierarchy as a visual ASCII tree with colored
segments: error names, kind badges, source positions, and violation counts
each get distinct colors for scannability.

This shows how your package-level error variables relate to each other
(wrapping via %w, aliasing via assignment). Each node displays the error
name, kind, source location, occurrence count, and violation count.

Use --type-aware for the most accurate hierarchy (requires go/types).
Use --markdown for a Markdown bullet-list variant.
Use --no-position / --no-kind for cleaner trees.
Use --max-depth N to limit tree depth.
Use --inline-wraps to render function-body wrap sites and errors.Is
checks as child lines under each error (the runtime side of the
hierarchy, invisible to package-level declarations).
Use --sort wraps to surface the most-referenced errors first (auto
does this whenever the hierarchy is flat).
Use --group to bucket root errors by package directory.

Color legend:
  white bold   error name
  blue         sentinel / errors.New
  yellow       fmt.Errorf / wrapping
  magenta      custom error type / errors.Join
  green        go-error-family constructors
  cyan         samber/oops constructors
  dim          positions, package, stats footer, inline sites
  bold red     violation count (when > 1)`),
		v4.WithExample(`  # Show error tree for current directory
  erraudit tree .

  # Show error tree for a package
  erraudit tree ./pkg/errors

  # Render as Markdown
  erraudit tree ./... --markdown

  # Show where each error is wrapped and checked (function bodies)
  erraudit tree ./... --inline-wraps

  # Surface the most-referenced errors first
  erraudit tree ./... --sort wraps

  # Group roots by package directory
  erraudit tree ./... --group

  # Save to file (color disabled automatically)
  erraudit tree . --output error-tree.txt

  # Limit depth for large hierarchies
  erraudit tree . --max-depth 2

  # Force color when piping
  erraudit tree . --color always | less -R`),
		v4.WithArgs(cobra.MaximumNArgs(1)),
	)

	return registerCommand(cli, "tree", cmd, err)
}

func runTreeHandler(ctx context.Context, cfg *AppConfig, flags TreeFlags) error {
	path := pathFromArgs(argsFromContext(ctx))

	if !converter.IsValidTreeSortMode(flags.Sort) {
		return apierrors.Wrap(
			apierrors.ErrConfigInvalid,
			"invalid --sort value %q (valid: auto, wraps, name)",
			flags.Sort,
		)
	}

	if cfg.Verbose {
		fmt.Fprintf(os.Stderr, "Building error tree: %s\n", path)
	}

	// Suppress/Explain stay false: tree renders the hierarchy only and never
	// applies domain suppression to violations. Progress stays false: the
	// tree path is quiet.
	graph, _, err := pipeline.PerformAnalysisWithSpec(ctx, pipeline.AnalysisSpec{
		Path:                 path,
		ExcludedPaths:        cfg.Exclude,
		TypeAware:            cfg.TypeAware,
		EnforceErrorFamily:   cfg.EnforceErrorFamily,
		EnforceSamberOops:    cfg.EnforceSamberOops,
		EnforceGenericReturn: cfg.EnforceGenericReturn,
		EnforceDeferredClose: cfg.EnforceDeferredClose,
		EnforceCodedErrors:   cfg.EnforceCodedErrors,
		NoSuppress:           cfg.NoSuppress,
		ModulesAll:           cfg.Modules == ModulesAllMode,
		Progress:             false,
		Suppress:             false,
		Explain:              false,
	})
	if err != nil {
		return apierrors.Wrap(err, "analysis of %s failed", path)
	}

	if graph.FilesScanned == 0 {
		fmt.Fprintf(os.Stderr, "No Go source files found for %q (scanned 0 files).\n", path)
		fmt.Fprintln(
			os.Stderr,
			"A bare directory only matches a package if it directly contains .go files.",
		)
		fmt.Fprintln(
			os.Stderr,
			`Hint: use "./..." to analyze a whole module, or pass a package directory.`,
		)

		return nil
	}

	if graph.Hierarchy == nil || len(graph.Hierarchy.RootErrors) == 0 {
		fmt.Fprintln(os.Stderr, "No error hierarchy found.")

		if !cfg.TypeAware {
			fmt.Fprintln(os.Stderr, "Tip: use --type-aware for deeper analysis.")
		} else {
			fmt.Fprintln(os.Stderr, "The hierarchy tracks package-level error wrapping relationships")
			fmt.Fprintln(os.Stderr, `(e.g. var ErrFoo = fmt.Errorf("...: %w", ErrBar)).`)
			fmt.Fprintln(os.Stderr, "None were found in the analyzed code.")
		}

		return nil
	}

	if graph.Hierarchy.Metrics.TotalRelationships == 0 {
		reportFlatHierarchy(graph.Hierarchy.Metrics)
	}

	opts := converter.TreeOptions{
		NoPosition:     flags.NoPosition,
		NoKind:         flags.NoKind,
		MaxDepth:       flags.MaxDepth,
		ShowWrapSites:  flags.InlineWraps,
		Sort:           converter.TreeSortMode(flags.Sort),
		GroupByPackage: flags.Group,
		MaxSites:       flags.MaxSites,
	}

	rootLabel := hierarchyRootLabel(graph)
	useColor := resolveColorEnabled(flags.Color, cfg.Output)

	return withOutputWriter(
		func() (io.Writer, func(), error) { return newOutputWriter(cfg.Output, os.Stdout) },
		func(writer io.Writer) error {
			if flags.Markdown {
				if err := converter.WriteHierarchyMarkdown(writer, rootLabel, graph.Hierarchy, opts); err != nil {
					return apierrors.Wrap(err, "render markdown tree")
				}

				return nil
			}

			if err := converter.WriteHierarchyTree(writer, rootLabel, graph.Hierarchy, opts, useColor); err != nil {
				return apierrors.Wrap(err, "render ascii tree")
			}

			return nil
		},
	)
}

// hierarchyRootLabel derives the root label from the analysis target. A raw
// pattern ("./...") carries no identity, so the label reports the analyzed
// scale instead (packages and files); a plain package path drops the "./"
// noise. Empty when the graph has no package identity at all.
func hierarchyRootLabel(graph *types.ErrorGraph) string {
	pkg := graph.Package
	if pkg == "" {
		return ""
	}

	if !strings.Contains(pkg, "...") {
		return strings.TrimPrefix(pkg, "./")
	}

	var parts []string

	if graph.PackagesScanned > 0 {
		parts = append(parts, fmt.Sprintf("%d packages", graph.PackagesScanned))
	}

	if graph.FilesScanned > 0 {
		parts = append(parts, fmt.Sprintf("%d files", graph.FilesScanned))
	}

	if len(parts) == 0 {
		return pkg
	}

	return strings.Join(parts, " · ")
}

// reportFlatHierarchy explains a hierarchy with named errors but no wrapping
// relationships. When the codebase shows inline error activity (function-body
// wrap sites or errors.Is checks), the notice cites those counts — "flat"
// then reads as "the wrapping lives outside the declared hierarchy", not as
// "this codebase has no error handling".
func reportFlatHierarchy(metrics types.HierarchyMetrics) {
	fmt.Fprintf(
		os.Stderr,
		"erraudit: flat hierarchy — %d named error(s), 0 wrapping relationships.\n",
		metrics.TotalNamedErrors,
	)

	inlineWraps := metrics.InlineWrapSites
	checks := metrics.TotalCheckSites()

	if inlineWraps > 0 || checks > 0 {
		fmt.Fprintf(
			os.Stderr,
			"erraudit: %d inline wrap site(s) and %d sentinel check(s) exist in function bodies — only package-level declarations (var ErrB = fmt.Errorf(\"...: %%w\", ErrA)) become hierarchy edges.\n",
			inlineWraps,
			checks,
		)
		fmt.Fprintln(
			os.Stderr,
			"erraudit: run with --inline-wraps to render these sites as tree children, and --sort wraps to surface the most-referenced errors first.",
		)

		return
	}

	fmt.Fprintln(
		os.Stderr,
		"erraudit: only package-level wrapping is tracked: var ErrB = fmt.Errorf(\"...: %w\", ErrA) or errorfamily.WrapRejection(ErrA, ...) declared outside functions.",
	)
	fmt.Fprintln(
		os.Stderr,
		"erraudit: wrapping inside function bodies is runtime behavior and does not appear in the hierarchy.",
	)
}

// resolveColorMode maps the --color flag to an output.ColorMode. When --output
// is set (writing to a file), color is forced off unless the user explicitly
// requests --color always.
func resolveColorMode(colorFlag, outputFile string) output.ColorMode {
	if colorFlag != "" {
		if mode, err := output.ParseColorMode(colorFlag); err == nil {
			if outputFile != "" && mode != output.ColorModeAlways {
				return output.ColorModeNever
			}

			return mode
		}
	}

	if outputFile != "" {
		return output.ColorModeNever
	}

	return output.ColorModeAuto
}

// resolveColorEnabled is a convenience wrapper that returns the boolean
// decision for the tree renderer.
func resolveColorEnabled(colorFlag, outputFile string) bool {
	return resolveColorMode(colorFlag, outputFile).ShouldColor()
}
