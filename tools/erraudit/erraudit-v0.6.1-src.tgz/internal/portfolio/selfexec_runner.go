package portfolio

import (
	"bytes"
	"context"
	"encoding/json/v2"
	"errors"
	"os"
	"os/exec"
	"strings"

	apierrors "github.com/larsartmann/erraudit/pkg/errors"
	findingsdk "github.com/larsartmann/go-finding"
)

// stderrTailLimit bounds how much child stderr is embedded in a failure
// record: enough to diagnose, not enough to flood the report.
const stderrTailLimit = 200

// SelfExecRunner analyzes projects by re-executing the running erraudit
// binary with --format json in the project directory. One process per
// project gives crash isolation, exact flag parity with manual runs, and the
// CLI's full behavior (empty-scan hints, monorepo module fan-out) for free.
type SelfExecRunner struct {
	// Executable resolves the erraudit binary to invoke. Defaults to
	// os.Executable; overridable to point tests at a stub binary.
	Executable func() (string, error)
}

// NewSelfExecRunner returns the production runner re-invoking the current
// binary.
func NewSelfExecRunner() *SelfExecRunner {
	return &SelfExecRunner{Executable: os.Executable}
}

// Analyze runs one child analysis and parses its go-finding report JSON. A
// child exit code of 0 or 2 (violations found) yields a report; every other
// outcome yields an error describing the failure.
func (r *SelfExecRunner) Analyze(
	ctx context.Context,
	ref ProjectRef,
	cfg AuditConfig,
) (*findingsdk.Report, error) {
	bin, err := r.Executable()
	if err != nil {
		return nil, apierrors.Wrap(err, "resolve erraudit binary for %s", ref.Name)
	}

	args := AuditArgs(cfg)

	var stdout, stderr bytes.Buffer

	cmd := exec.CommandContext(ctx, bin, args...)
	cmd.Dir = ref.Path
	cmd.Env = childEnv()

	cmd.Stdout = &stdout
	cmd.Stderr = &stderr

	if runErr := cmd.Run(); runErr != nil {
		exitErr, ok := errors.AsType[*exec.ExitError](runErr)
		if !ok {
			return nil, apierrors.Wrap(runErr, "spawn erraudit for %s", ref.Name)
		}

		if exitErr.ExitCode() != childExitViolationsFound {
			return nil, apierrors.New(
				"erraudit exited %d for %s: %s",
				exitErr.ExitCode(), ref.Name, stderrTail(stderr.String()),
			)
		}

		// Exit code 2: violations found — the JSON below is the result.
	}

	graph, err := parseChildReport(stdout.Bytes())
	if err != nil {
		return nil, apierrors.Wrap(err, "parse erraudit output for %s", ref.Name)
	}

	return graph, nil
}

// parseChildReport decodes the child's stdout as a go-finding Report — the
// ecosystem interchange format the --format json output strategy emits.
// Unmarshaling into the upstream type (rather than a local mirror struct)
// means the child output contract cannot drift from the aggregator.
func parseChildReport(data []byte) (*findingsdk.Report, error) {
	if len(bytes.TrimSpace(data)) == 0 {
		return nil, apierrors.New("empty output")
	}

	var report findingsdk.Report
	if err := json.Unmarshal(data, &report); err != nil {
		return nil, apierrors.Wrap(err, "decode go-finding report")
	}

	return &report, nil
}

// stderrTail returns the last stderrTailLimit characters of a child's stderr,
// collapsed to a single line for table embedding.
func stderrTail(stderr string) string {
	tail := stderr
	if len(tail) > stderrTailLimit {
		tail = tail[len(tail)-stderrTailLimit:]
	}

	return strings.TrimSpace(strings.ReplaceAll(tail, "\n", " | "))
}

// childEnv builds the child process environment: the caller's environment
// with workspace/module interference removed and the jsonv2 experiment forced.
//
//   - GOWORK=off: a parent ~/projects/go.work must not bleed into foreign
//     module trees (AGENTS.md monorepo rules).
//   - GOEXPERIMENT=jsonv2: without it, targets importing encoding/json/v2
//     silently yield zero findings (AGENTS.md portfolio-audit rules).
//   - GOFLAGS -mod flags stripped: direnv shells here export -mod=mod, which
//     breaks workspace-mode targets and overrides vendor projects.
func childEnv() []string {
	env := os.Environ()

	sanitized := make([]string, 0, len(env)+2)

	sawExperiment := false

	for _, entry := range env {
		switch {
		case strings.HasPrefix(entry, "GOWORK="):
			continue
		case strings.HasPrefix(entry, "GOEXPERIMENT="):
			sanitized = append(sanitized, "GOEXPERIMENT=jsonv2")
			sawExperiment = true
		case strings.HasPrefix(entry, "GOFLAGS="):
			value := SanitizeGOFLAGS(strings.TrimPrefix(entry, "GOFLAGS="))
			if value != "" {
				sanitized = append(sanitized, "GOFLAGS="+value)
			}
		default:
			sanitized = append(sanitized, entry)
		}
	}

	if !sawExperiment {
		sanitized = append(sanitized, "GOEXPERIMENT=jsonv2")
	}

	return append(sanitized, "GOWORK=off")
}
