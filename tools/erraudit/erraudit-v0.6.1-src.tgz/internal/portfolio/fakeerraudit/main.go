// Command fakeerraudit is a test double for the portfolio self-exec runner.
// It speaks just enough of the erraudit child contract for the unit and BDD
// suites to exercise spawning, environment sanitation, exit-code handling,
// and ErrorGraph parsing without running real analyses: canned graphs keyed
// by the working directory's base name, plus --dump-argv/--dump-env probes.
package main

import (
	"encoding/json/v2"
	"fmt"
	"os"
	"path/filepath"
)

// The canned reports speak the same go-finding JSON envelope the real
// erraudit --format json output emits: findings[] with rule + severity, and
// a summary[] with total, bySeverity, and filesScanned.
const violationsReport = `{"findings":[` +
	`{"rule":"silent_swallow","severity":"critical","message":"swallowed"},` +
	`{"rule":"ignored","severity":"error","message":"ignored error"},` +
	`{"rule":"ignored","severity":"error","message":"ignored again"},` +
	`{"rule":"context_loss","severity":"warning","message":"lost userID"}` +
	`],"summary":{"total":4,"bySeverity":{"critical":1,"error":2,"warning":1},` +
	`"filesScanned":5,"filesAffected":3}}`

const cleanReport = `{"findings":[],"summary":{"total":0,"bySeverity":{},"filesScanned":3}}`

const emptyScanReport = `{"findings":[],"summary":{"total":0,"bySeverity":{},"filesScanned":0}}`

func main() {
	args := os.Args[1:]

	if len(args) > 0 && args[0] == "--dump-env" {
		for _, entry := range os.Environ() {
			fmt.Println(entry) //nolint:forbidigo // stdout printing is this stub's entire purpose
		}

		os.Exit(0)
	}

	if len(args) > 0 && args[0] == "--dump-argv" {
		encoded, err := json.Marshal(args)
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}

		fmt.Println( //nolint:forbidigo // stdout printing is this stub's entire purpose
			string(encoded),
		)
		os.Exit(0)
	}

	dir, err := os.Getwd()
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}

	switch filepath.Base(dir) {
	case "broken-project":
		fmt.Fprintln(os.Stderr, "fakeerraudit: simulated analysis failure")
		os.Exit(1)
	case "violations-project":
		writeReport(violationsReport)
		os.Exit(2)
	case "clean-project":
		writeReport(cleanReport)
		os.Exit(0)
	default:
		writeReport(emptyScanReport)
		os.Exit(0)
	}
}

func writeReport(report string) {
	if _, err := fmt.Fprintln(os.Stdout, report); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
