package portfolio

import (
	"fmt"
	"io"
	"sort"
	"strconv"
	"strings"

	apierrors "github.com/larsartmann/erraudit/pkg/errors"
	gooutput "github.com/larsartmann/go-output"
)

// SortBy selects the column portfolio results are ordered by.
type SortBy string

// Supported sort keys. Metrics sort descending; name sorts ascending.
const (
	SortByName       SortBy = "name"
	SortByViolations SortBy = "violations"
	SortByCritical   SortBy = "critical"
	SortByError      SortBy = "error"
	SortByWarning    SortBy = "warning"
	SortByFiles      SortBy = "files"
)

// DefaultSortBy orders by total violations descending: the noisiest project
// first, matching the stats command the portfolio report was modeled on.
const DefaultSortBy = SortByViolations

// ParseSortBy resolves a case-insensitive sort key.
func ParseSortBy(value string) (SortBy, error) {
	normalized := strings.ToLower(strings.TrimSpace(value))

	switch SortBy(normalized) {
	case SortByName, SortByViolations, SortByCritical, SortByError, SortByWarning, SortByFiles:
		return SortBy(normalized), nil
	default:
		return "", apierrors.Wrap(
			apierrors.ErrConfigInvalid,
			"invalid --sort-by %q (valid: name, violations, critical, error, warning, files)",
			value,
		)
	}
}

// SortResults orders results in place: metric keys descending (name
// ascending), ties broken by project name for deterministic output.
func SortResults(results []ProjectResult, sortBy SortBy) {
	if sortBy == SortByName {
		sort.SliceStable(results, func(current, next int) bool {
			return results[current].Name < results[next].Name
		})

		return
	}

	key := func(result ProjectResult) int {
		switch sortBy {
		case SortByName:
			return 0
		case SortByCritical:
			return result.Critical
		case SortByError:
			return result.Errors
		case SortByWarning:
			return result.Warnings
		case SortByFiles:
			return result.FilesScanned
		case SortByViolations:
			return result.Violations
		default:
			return result.Violations
		}
	}

	sort.SliceStable(results, func(current, next int) bool {
		left, right := key(results[current]), key(results[next])
		if left != right {
			return left > right
		}

		return results[current].Name < results[next].Name
	})
}

// HideZeroViolations filters projects without findings out of the table
// rows while keeping the summary computed over the FULL sweep — coverage
// (files scanned, projects analyzed) must not shrink just because clean
// projects are hidden. --show-all restores the full picture.
func HideZeroViolations(report *Report) {
	visible := make([]ProjectResult, 0, len(report.Projects))
	hidden := 0

	for i := range report.Projects {
		if report.Projects[i].Violations == 0 {
			hidden++

			continue
		}

		visible = append(visible, report.Projects[i])
	}

	if hidden == 0 {
		return
	}

	report.Projects = visible
	report.Summary.ProjectsHidden = hidden
	report.Summary.ProjectsAnalyzed = len(visible) + hidden
}

// ReportTable converts the report into go-output tabular data. One row per
// project plus a TOTAL footer; failures and the summary block are separate
// sections rendered by WriteSummary and WriteFailures.
func ReportTable(report *Report) *gooutput.Table {
	table := gooutput.NewTable(
		[]string{"Project", "Files", "Critical", "Error", "Warning", "Total", "Skipped"},
	)

	for i := range report.Projects {
		result := &report.Projects[i]

		table.AddRow([]string{
			result.Name,
			strconv.Itoa(result.FilesScanned),
			strconv.Itoa(result.Critical),
			strconv.Itoa(result.Errors),
			strconv.Itoa(result.Warnings),
			strconv.Itoa(result.Violations),
			strconv.Itoa(result.SkippedModules),
		})
	}

	table.Footer = []string{
		"TOTAL",
		strconv.Itoa(report.Summary.FilesScanned),
		strconv.Itoa(report.Summary.Critical),
		strconv.Itoa(report.Summary.Errors),
		strconv.Itoa(report.Summary.Warnings),
		strconv.Itoa(report.Summary.Violations),
		"",
	}

	return table
}

// WriteSummary renders the aggregate block: project counts, coverage, and
// violation totals across the whole sweep.
func WriteSummary(writer io.Writer, summary Summary) {
	fmt.Fprintln(writer, "📈 Summary")
	fmt.Fprintf(writer, "  Projects analyzed:  %d\n", summary.ProjectsAnalyzed)
	fmt.Fprintf(writer, "  Projects failed:    %d\n", summary.ProjectsFailed)

	if summary.ProjectsHidden > 0 {
		fmt.Fprintf(writer, "  Projects hidden:    %d (zero violations; --show-all to display)\n",
			summary.ProjectsHidden)
	}

	fmt.Fprintf(writer, "  Files scanned:      %d\n", summary.FilesScanned)
	fmt.Fprintf(writer, "  Violations:         %d (critical %d · error %d · warning %d)\n",
		summary.Violations, summary.Critical, summary.Errors, summary.Warnings)
}

// WriteFailures renders the per-project failures section so a broken
// repository is diagnosable from the report alone.
func WriteFailures(writer io.Writer, failures []ProjectFailure) {
	if len(failures) == 0 {
		return
	}

	fmt.Fprintln(writer, "⚠️  Failed analyses")

	for i := range failures {
		fmt.Fprintf(writer, "  %s: %s\n", failures[i].Name, failures[i].Error)
	}
}

// WriteHiddenNotice explains why the table may be shorter than the fleet.
func WriteHiddenNotice(writer io.Writer, hidden int) {
	if hidden > 0 {
		fmt.Fprintf(writer, "🔍 Hidden: %d projects with zero violations (--show-all to display)\n", hidden)
	}
}
