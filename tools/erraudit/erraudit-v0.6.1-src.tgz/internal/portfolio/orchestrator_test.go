package portfolio_test

import (
	"context"
	"errors"
	"sync"
	"testing"

	"github.com/larsartmann/erraudit/internal/portfolio"
	findingsdk "github.com/larsartmann/go-finding"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// fakeRunner maps project names to canned outcomes. Calls are recorded
// mutex-guarded: the orchestrator invokes Analyze from worker goroutines.
type fakeRunner struct {
	reports map[string]*findingsdk.Report
	failing map[string]error

	mu    sync.Mutex
	calls []string
}

func (f *fakeRunner) Analyze(
	_ context.Context,
	ref portfolio.ProjectRef,
	_ portfolio.AuditConfig,
) (*findingsdk.Report, error) {
	f.mu.Lock()
	f.calls = append(f.calls, ref.Name)
	f.mu.Unlock()

	if err, failed := f.failing[ref.Name]; failed {
		return nil, err
	}

	report, found := f.reports[ref.Name]
	if !found {
		report = &findingsdk.Report{}
	}

	return report, nil
}

func refs(names ...string) []portfolio.ProjectRef {
	all := make([]portfolio.ProjectRef, 0, len(names))
	for _, name := range names {
		all = append(all, portfolio.ProjectRef{Name: name, Path: "/tmp/" + name})
	}

	return all
}

// reportWithFindings builds a report carrying filesScanned and findings,
// with the summary computed the way real children emit it.
func reportWithFindings(filesScanned int, findings ...findingsdk.Finding) *findingsdk.Report {
	report := findingsdk.NewReport(findingsdk.ToolInfo{Name: "test"})
	report.AddFindings(findings)
	report.ComputeSummary()
	report.Summary.FilesScanned = filesScanned

	return report
}

func TestOrchestrator_CollectsResultsAndFailures(t *testing.T) {
	runner := &fakeRunner{
		reports: map[string]*findingsdk.Report{
			"clean": {Summary: findingsdk.Summary{FilesScanned: 4}},
			"dirty": reportWithFindings(6, findingsdk.Finding{
				Rule: "ignored", Severity: findingsdk.SeverityCritical,
			}),
		},
		failing: map[string]error{"broken": errors.New("child exited 1")},
	}

	orchestrator := &portfolio.Orchestrator{Runner: runner}

	report := orchestrator.Run(
		context.Background(),
		refs("clean", "broken", "dirty"),
		portfolio.AuditConfig{},
	)

	require.Len(t, report.Projects, 2)
	require.Len(t, report.Failures, 1)

	assert.Equal(t, "broken", report.Failures[0].Name)
	assert.Contains(t, report.Failures[0].Error, "child exited 1")

	assert.Equal(t, 2, report.Summary.ProjectsAnalyzed)
	assert.Equal(t, 1, report.Summary.ProjectsFailed)
	assert.Equal(t, 10, report.Summary.FilesScanned)
	assert.Equal(t, 1, report.Summary.Violations)
}

func TestOrchestrator_PreservesInputOrder(t *testing.T) {
	orchestrator := &portfolio.Orchestrator{Runner: &fakeRunner{}}

	report := orchestrator.Run(context.Background(), refs("zeta", "alpha", "mid"), portfolio.AuditConfig{})

	require.Len(t, report.Projects, 3)
	assert.Equal(t, "zeta", report.Projects[0].Name)
	assert.Equal(t, "alpha", report.Projects[1].Name)
	assert.Equal(t, "mid", report.Projects[2].Name)
}

func TestOrchestrator_ConcurrentRunKeepsEveryResult(t *testing.T) {
	names := make([]string, 0, 24)
	for i := range 24 {
		switch i % 3 {
		case 0:
			names = append(names, "clean")
		case 1:
			names = append(names, "dirty")
		default:
			names = append(names, "broken")
		}
	}

	runner := &fakeRunner{
		reports: map[string]*findingsdk.Report{
			"clean": {Summary: findingsdk.Summary{FilesScanned: 1}},
			"dirty": reportWithFindings(2, findingsdk.Finding{
				Rule: "ignored", Severity: findingsdk.SeverityCritical,
			}),
		},
		failing: map[string]error{"broken": errors.New("nope")},
	}

	orchestrator := &portfolio.Orchestrator{Runner: runner, Concurrency: 8}

	report := orchestrator.Run(context.Background(), refs(names...), portfolio.AuditConfig{})

	assert.Len(t, report.Projects, 16)
	assert.Len(t, report.Failures, 8)
	assert.Len(t, runner.calls, 24)
}

func TestOrchestrator_ReportsProgressPerProject(t *testing.T) {
	var observed []int

	orchestrator := &portfolio.Orchestrator{
		Runner:     &fakeRunner{},
		OnProgress: func(done, total int) { observed = append(observed, done) },
	}

	report := orchestrator.Run(context.Background(), refs("a", "b", "c"), portfolio.AuditConfig{})

	require.Len(t, report.Projects, 3)
	require.Len(t, observed, 3)
	assert.ElementsMatch(t, []int{1, 2, 3}, observed)
}
