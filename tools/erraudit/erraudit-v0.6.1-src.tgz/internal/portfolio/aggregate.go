package portfolio

import (
	"sort"
	"time"

	findingsdk "github.com/larsartmann/go-finding"
)

// topTypesLimit caps how many violation types are reported per project —
// enough to triage, small enough to keep rows scannable.
const topTypesLimit = 3

// ResultFromReport folds one child's go-finding report into the aggregated
// row: severity buckets and totals from the report's own query API (the same
// numbers every go-finding consumer sees), per-type counts from finding
// rules, and coverage from the summary.
func ResultFromReport(ref ProjectRef, report *findingsdk.Report, duration time.Duration) ProjectResult {
	result := ProjectResult{
		Name:           ref.Name,
		Path:           ref.Path,
		FilesScanned:   report.Summary.FilesScanned,
		Violations:     report.Len(),
		Critical:       report.CountBySeverity(findingsdk.SeverityCritical),
		Errors:         report.CountBySeverity(findingsdk.SeverityError),
		Warnings:       report.CountBySeverity(findingsdk.SeverityWarning),
		SkippedModules: 0,
		DurationMs:     milliseconds(duration),
		TopTypes:       nil,
	}

	typeCounts := make(map[string]int)
	for finding := range report.All() {
		typeCounts[string(finding.Rule)]++
	}

	result.TopTypes = topTypes(typeCounts)

	return result
}

// topTypes returns the most frequent finding rules, count descending with
// lexicographic order breaking ties (deterministic output).
func topTypes(counts map[string]int) []TypeCount {
	if len(counts) == 0 {
		return nil
	}

	counted := make([]TypeCount, 0, len(counts))
	for rule, count := range counts {
		counted = append(counted, TypeCount{Type: rule, Count: count})
	}

	sort.Slice(counted, func(i, j int) bool {
		if counted[i].Count != counted[j].Count {
			return counted[i].Count > counted[j].Count
		}

		return counted[i].Type < counted[j].Type
	})

	if len(counted) > topTypesLimit {
		counted = counted[:topTypesLimit]
	}

	return counted
}
