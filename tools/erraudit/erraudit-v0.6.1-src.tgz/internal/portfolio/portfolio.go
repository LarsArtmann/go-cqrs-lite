// Package portfolio runs erraudit across every discovered Go project on the
// machine and aggregates the per-project results into one report — the
// fleet-wide counterpart to the single-target analyze command.
//
// The package deliberately contains NO analysis logic of its own: discovery is
// delegated to a ProjectDiscoverer (project-discovery-sdk in production, a
// marker-walking fallback in tests), and each project is analyzed by a
// ProjectRunner that re-executes the erraudit binary itself with
// --format json. The self-exec contract means a fleet run behaves byte-for-byte
// like the user running the analyze command manually in every project — same
// flags, same suppression semantics, same exit-code meaning — with crash
// isolation between projects for free.
package portfolio

import (
	"time"
)

// ProjectRef identifies one discoverable Go project.
type ProjectRef struct {
	// Name is the human-facing project label (directory base name).
	Name string `json:"name"`

	// Path is the absolute project directory the child process runs in.
	Path string `json:"path"`
}

// TypeCount pairs a violation type (go-finding rule name) with how often it
// occurred in one project.
type TypeCount struct {
	Type  string `json:"type"`
	Count int    `json:"count"`
}

// ProjectResult is the aggregated outcome of analyzing one project.
type ProjectResult struct {
	Name           string      `json:"name"`
	Path           string      `json:"path"`
	FilesScanned   int         `json:"filesScanned"`
	Violations     int         `json:"violations"`
	Critical       int         `json:"critical"`
	Errors         int         `json:"error"`
	Warnings       int         `json:"warning"`
	SkippedModules int         `json:"skippedModules"`
	TopTypes       []TypeCount `json:"topTypes,omitempty"`
	DurationMs     int64       `json:"durationMs"`
}

// ProjectFailure records a project whose analysis could not be completed
// (spawn failure, non-violations exit code, unparseable output). Failures
// never abort the sweep; they are reported alongside the results.
type ProjectFailure struct {
	Name  string `json:"name"`
	Path  string `json:"path"`
	Error string `json:"error"`
}

// Summary aggregates the whole sweep.
type Summary struct {
	ProjectsAnalyzed int `json:"projectsAnalyzed"`
	ProjectsFailed   int `json:"projectsFailed"`
	ProjectsHidden   int `json:"projectsHidden"`
	FilesScanned     int `json:"filesScanned"`
	Violations       int `json:"violations"`
	Critical         int `json:"critical"`
	Errors           int `json:"error"`
	Warnings         int `json:"warning"`
}

// Report is the portfolio command's domain output: one row per analyzed
// project, the failures that did not produce a row, and the summary block.
type Report struct {
	Summary  Summary          `json:"summary"`
	Projects []ProjectResult  `json:"projects"`
	Failures []ProjectFailure `json:"failures,omitempty"`
}

// Summarize folds the per-project results and failures into the summary
// block. It is the single place the totals are computed, so table and JSON
// output can never disagree.
func Summarize(results []ProjectResult, failures []ProjectFailure, hidden int) Summary {
	summary := Summary{
		ProjectsAnalyzed: 0,
		ProjectsFailed:   0,
		ProjectsHidden:   0,
		FilesScanned:     0,
		Violations:       0,
		Critical:         0,
		Errors:           0,
		Warnings:         0,
	}

	summary.ProjectsAnalyzed = len(results)
	summary.ProjectsFailed = len(failures)
	summary.ProjectsHidden = hidden

	for i := range results {
		summary.FilesScanned += results[i].FilesScanned
		summary.Violations += results[i].Violations
		summary.Critical += results[i].Critical
		summary.Errors += results[i].Errors
		summary.Warnings += results[i].Warnings
	}

	return summary
}

// milliseconds converts a duration to the report's DurationMs unit without
// leaking time.Duration formatting into every call site.
func milliseconds(d time.Duration) int64 {
	return d.Milliseconds()
}
