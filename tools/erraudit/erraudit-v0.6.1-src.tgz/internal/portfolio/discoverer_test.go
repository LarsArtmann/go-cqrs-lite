package portfolio_test

import (
	"context"
	"os"
	"path/filepath"
	"testing"

	"github.com/larsartmann/erraudit/internal/portfolio"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestMarkerDiscoverer_FindsGoModDirectoriesOnly(t *testing.T) {
	root := t.TempDir()

	withGoMod := filepath.Join(root, "alpha")
	require.NoError(t, os.MkdirAll(withGoMod, 0o755))
	require.NoError(t, os.WriteFile(filepath.Join(withGoMod, "go.mod"), nil, 0o600))

	withoutGoMod := filepath.Join(root, "beta")
	require.NoError(t, os.MkdirAll(withoutGoMod, 0o755))

	hidden := filepath.Join(root, ".hidden")
	require.NoError(t, os.MkdirAll(hidden, 0o755))
	require.NoError(t, os.WriteFile(filepath.Join(hidden, "go.mod"), nil, 0o600))

	require.NoError(t, os.WriteFile(filepath.Join(root, "go.mod-file-go.mod"), nil, 0o600))

	refs, err := portfolio.MarkerDiscoverer{}.DiscoverProjects(
		context.Background(),
		portfolio.SearchConfig{Paths: []string{root}},
	)

	require.NoError(t, err)
	require.Len(t, refs, 1)
	assert.Equal(t, "alpha", refs[0].Name)
	assert.Equal(t, withGoMod, refs[0].Path)
}

func TestMarkerDiscoverer_SkipsUnresolvableSearchPaths(t *testing.T) {
	refs, err := portfolio.MarkerDiscoverer{}.DiscoverProjects(
		context.Background(),
		portfolio.SearchConfig{Paths: []string{"/nonexistent-erraudit-portfolio-dir"}},
	)

	require.NoError(t, err)
	assert.Empty(t, refs)
}

func TestExpandPath(t *testing.T) {
	absolute, err := portfolio.ExpandPath("/abs/path")
	require.NoError(t, err)
	assert.Equal(t, "/abs/path", absolute)

	relative, err := portfolio.ExpandPath("relative")
	require.NoError(t, err)
	assert.Equal(t, "relative", relative)

	home, err := portfolio.ExpandPath("~/projects")
	require.NoError(t, err)

	expectedHome, err := os.UserHomeDir()
	require.NoError(t, err)
	assert.Equal(t, filepath.Join(expectedHome, "projects"), home)
}
