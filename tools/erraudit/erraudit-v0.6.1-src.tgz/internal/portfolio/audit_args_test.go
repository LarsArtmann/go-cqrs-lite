package portfolio_test

import (
	"testing"

	"github.com/larsartmann/erraudit/internal/portfolio"
	"github.com/stretchr/testify/assert"
)

func TestAuditArgs_DefaultsAreJustTargetAndJSON(t *testing.T) {
	args := portfolio.AuditArgs(portfolio.AuditConfig{})

	assert.Equal(t, []string{"./...", "--format", "json"}, args)
}

func TestAuditArgs_ForwardsEveryAuditSemanticsFlag(t *testing.T) {
	args := portfolio.AuditArgs(portfolio.AuditConfig{
		TypeAware:            true,
		EnforceErrorFamily:   true,
		EnforceSamberOops:    true,
		EnforceGenericReturn: true,
		EnforceDeferredClose: true,
		EnforceCodedErrors:   true,
		NoSuppress:           true,
		Explain:              true,
		DisableExtensions:    true,
		ModulesAll:           true,
	})

	expected := []string{
		"./...", "--format", "json",
		"--type-aware",
		"--enforce-go-error-family",
		"--enforce-samber-oops",
		"--enforce-generic-return",
		"--enforce-deferred-close",
		"--enforce-coded-errors",
		"--no-suppress",
		"--explain",
		"--disable-extensions",
		"--modules=all",
	}

	assert.Equal(t, expected, args)
}

func TestAuditArgs_RepeatsSliceFlagsAndSkipsEmptyStrings(t *testing.T) {
	args := portfolio.AuditArgs(portfolio.AuditConfig{
		Disable:           []string{"context_loss", "generic_return"},
		Exclude:           []string{"vendor"},
		Severity:          "critical",
		Type:              "ignored",
		SeverityThreshold: "",
	})

	expected := []string{
		"./...", "--format", "json",
		"--disable", "context_loss",
		"--disable", "generic_return",
		"--exclude", "vendor",
		"--severity", "critical",
		"--type", "ignored",
	}

	assert.Equal(t, expected, args)
}

func TestSanitizeGOFLAGS(t *testing.T) {
	tests := []struct {
		name  string
		value string
		want  string
	}{
		{"empty", "", ""},
		{"only mod", "-mod=mod", ""},
		{"bare mod", "-mod", ""},
		{"mod among others", "-mod=mod -tags=integration", "-tags=integration"},
		{"no mod", "-race", "-race"},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			assert.Equal(t, test.want, portfolio.SanitizeGOFLAGS(test.value))
		})
	}
}

func TestAuditArgs_NeverForwardsPresentationFlags(t *testing.T) {
	args := portfolio.AuditArgs(portfolio.AuditConfig{TypeAware: true})

	for _, forbidden := range []string{"--progress", "--verbose", "--quiet", "--output", "--pipeline"} {
		assert.NotContains(t, args, forbidden)
	}
}
