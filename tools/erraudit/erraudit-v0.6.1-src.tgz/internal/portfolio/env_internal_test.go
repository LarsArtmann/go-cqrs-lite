package portfolio

import (
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"
)

func envMap(t *testing.T) map[string]string {
	t.Helper()

	env := childEnv()
	parsed := make(map[string]string, len(env))

	for _, entry := range env {
		key, value, found := strings.Cut(entry, "=")
		assert.True(t, found, "malformed env entry %q", entry)
		parsed[key] = value
	}

	return parsed
}

func TestChildEnv_SanitizesWorkspaceModuleModeAndExperiment(t *testing.T) {
	t.Setenv("GOWORK", "/home/lars/projects/go.work")
	t.Setenv("GOFLAGS", "-mod=mod -tags=integration")
	t.Setenv("GOEXPERIMENT", "none")

	env := envMap(t)

	assert.Equal(t, "off", env["GOWORK"])
	assert.Equal(t, "jsonv2", env["GOEXPERIMENT"])
	assert.Equal(t, "-tags=integration", env["GOFLAGS"])
}

func TestChildEnv_ForcesExperimentWhenUnset(t *testing.T) {
	t.Setenv("GOEXPERIMENT", "")

	env := envMap(t)

	assert.Equal(t, "jsonv2", env["GOEXPERIMENT"])
	assert.Equal(t, "off", env["GOWORK"])
}

func TestChildEnv_DropsGOFLAGSWhenOnlyModRemains(t *testing.T) {
	t.Setenv("GOFLAGS", "-mod=mod")

	env := envMap(t)

	_, present := env["GOFLAGS"]
	assert.False(t, present, "GOFLAGS must be dropped when -mod was its only content")
}

func TestParseChildReport_RejectsEmptyOutput(t *testing.T) {
	report, err := parseChildReport([]byte("  \n"))

	assert.Error(t, err)
	assert.Nil(t, report)
}

func TestParseChildReport_RejectsGarbage(t *testing.T) {
	report, err := parseChildReport([]byte("not json at all"))

	assert.Error(t, err)
	assert.Nil(t, report)
}

func TestStderrTail_TrimsAndCollapses(t *testing.T) {
	long := strings.Repeat("x", stderrTailLimit+50)

	tail := stderrTail("line one\nline two\n" + long)

	assert.LessOrEqual(t, len(tail), stderrTailLimit)
	assert.NotContains(t, tail, "\n")
	assert.True(t, strings.HasSuffix(tail, strings.Repeat("x", 10)))
}
