package portfolio

import (
	"context"

	sdk "github.com/LarsArtmann/project-discovery-sdk"
	"github.com/LarsArtmann/project-discovery-sdk/domain"
	apierrors "github.com/larsartmann/erraudit/pkg/errors"
)

// SDKDiscoverer discovers projects through project-discovery-sdk: marker-based
// project detection plus content analysis, filtered to Go, with the SDK's
// disk cache enabled so repeat fleet runs are cheap. No enrichers are
// requested — the fleet needs paths only, which keeps the dependency closure
// and discovery latency minimal.
type SDKDiscoverer struct{}

// DiscoverProjects resolves Go projects under the configured search paths.
func (SDKDiscoverer) DiscoverProjects(ctx context.Context, cfg SearchConfig) ([]ProjectRef, error) {
	result, err := sdk.Discover(
		ctx,
		&sdk.DiscoverOptions{ //nolint:exhaustruct_v5 // external SDK options: zero values ARE the intended minimal config
			SearchPaths: cfg.Paths,
			Languages:   []domain.Language{domain.LanguageGo},
			UseCache:    true,
		},
	)
	if err != nil {
		return nil, apierrors.Wrap(err, "discover Go projects under %v", cfg.Paths)
	}

	refs := make([]ProjectRef, 0, len(result.Projects))
	for i := range result.Projects {
		project := &result.Projects[i]

		refs = append(refs, ProjectRef{
			Name: project.DirName,
			Path: project.Path,
		})
	}

	return refs, nil
}
