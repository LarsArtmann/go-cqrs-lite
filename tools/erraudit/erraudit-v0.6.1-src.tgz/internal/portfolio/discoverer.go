package portfolio

import (
	"context"
	"errors"
	"io/fs"
	"os"
	"path/filepath"
	"strings"

	apierrors "github.com/larsartmann/erraudit/pkg/errors"
)

// SearchConfig configures project discovery.
type SearchConfig struct {
	// Paths are the directories whose immediate children are project
	// candidates (e.g. ~/projects).
	Paths []string
}

// ProjectDiscoverer enumerates the Go projects a fleet run should analyze.
// The interface exists so tests can inject deterministic project sets and so
// the discovery mechanism (project-discovery-sdk, marker walk, explicit CLI
// paths) stays swappable without touching orchestration.
type ProjectDiscoverer interface {
	// DiscoverProjects returns one ProjectRef per discoverable Go project.
	DiscoverProjects(ctx context.Context, cfg SearchConfig) ([]ProjectRef, error)
}

// MarkerDiscoverer is the dependency-free fallback discoverer: a directory is
// a project when it is an immediate subdirectory of a search path and
// directly contains a go.mod. It mirrors the SDK scanner's default MaxDepth=1
// marker semantics closely enough for tests and offline use.
type MarkerDiscoverer struct{}

// DiscoverProjects walks every search path's immediate children and returns
// those containing a go.mod. Missing search paths are skipped (a fleet
// without ~/GolandProjects is normal); any other read or stat failure
// propagates so a broken sweep is never mistaken for an empty one.
func (MarkerDiscoverer) DiscoverProjects(_ context.Context, cfg SearchConfig) ([]ProjectRef, error) {
	var refs []ProjectRef

	for _, base := range cfg.Paths {
		expanded, err := ExpandPath(base)
		if err != nil {
			return nil, apierrors.Wrap(err, "resolve search path %q", base)
		}

		entries, err := os.ReadDir(expanded)
		if err != nil {
			if !errors.Is(err, fs.ErrNotExist) {
				return nil, apierrors.Wrap(err, "read search path %s", expanded)
			}

			continue
		}

		for _, entry := range entries {
			if !entry.IsDir() || strings.HasPrefix(entry.Name(), ".") {
				continue
			}

			dir := filepath.Join(expanded, entry.Name())

			if _, err := os.Stat(filepath.Join(dir, "go.mod")); err != nil {
				if !errors.Is(err, fs.ErrNotExist) {
					return nil, apierrors.Wrap(err, "stat %s/go.mod", dir)
				}

				continue
			}

			refs = append(refs, ProjectRef{Name: entry.Name(), Path: dir})
		}
	}

	return refs, nil
}

// ExpandPath resolves a leading ~ to the user's home directory. Absolute and
// relative paths pass through unchanged.
func ExpandPath(target string) (string, error) {
	if target != "~" && !strings.HasPrefix(target, "~/") {
		return target, nil
	}

	home, err := os.UserHomeDir()
	if err != nil {
		return "", apierrors.Wrap(err, "resolve home directory for %q", target)
	}

	if target == "~" {
		return home, nil
	}

	return filepath.Join(home, strings.TrimPrefix(target, "~/")), nil
}
