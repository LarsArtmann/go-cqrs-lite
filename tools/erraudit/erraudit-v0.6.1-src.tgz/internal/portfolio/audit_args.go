package portfolio

import "strings"

// AuditConfig carries the audit-semantics flags forwarded verbatim to every
// child analysis. It is a deliberate subset of AppConfig: only flags that
// change WHAT is reported may cross the process boundary. Presentation flags
// (--format beyond the forced json, --output, --progress, --verbose, --quiet)
// and orchestration flags (--pipeline, --violations-only) never do, so child
// behavior cannot drift from the documented fleet contract.
type AuditConfig struct {
	TypeAware            bool
	EnforceErrorFamily   bool
	EnforceSamberOops    bool
	EnforceGenericReturn bool
	EnforceDeferredClose bool
	EnforceCodedErrors   bool
	NoSuppress           bool
	Explain              bool
	DisableExtensions    bool
	Disable              []string
	Exclude              []string
	ModulesAll           bool
	Severity             string
	Type                 string
	SeverityThreshold    string
}

// childExitViolationsFound mirrors the CLI's exit code 2 contract: a child
// exiting 2 analyzed successfully and found violations (the JSON on stdout is
// valid); any other non-zero exit is a failure.
const childExitViolationsFound = 2

// AuditArgs builds the child erraudit argv for one project. The target is
// always "./..." resolved in the child's working directory, and the output is
// always machine-readable JSON — the fleet's private contract with itself.
func AuditArgs(cfg AuditConfig) []string {
	args := []string{"./...", "--format", "json"}

	appendBool := func(flag string, set bool) {
		if set {
			args = append(args, flag)
		}
	}

	appendRepeated := func(flag string, values []string) {
		for _, value := range values {
			args = append(args, flag, value)
		}
	}

	appendString := func(flag, value string) {
		if value != "" {
			args = append(args, flag, value)
		}
	}

	appendBool("--type-aware", cfg.TypeAware)
	appendBool("--enforce-go-error-family", cfg.EnforceErrorFamily)
	appendBool("--enforce-samber-oops", cfg.EnforceSamberOops)
	appendBool("--enforce-generic-return", cfg.EnforceGenericReturn)
	appendBool("--enforce-deferred-close", cfg.EnforceDeferredClose)
	appendBool("--enforce-coded-errors", cfg.EnforceCodedErrors)
	appendBool("--no-suppress", cfg.NoSuppress)
	appendBool("--explain", cfg.Explain)
	appendBool("--disable-extensions", cfg.DisableExtensions)
	appendBool("--modules=all", cfg.ModulesAll)

	appendRepeated("--disable", cfg.Disable)
	appendRepeated("--exclude", cfg.Exclude)

	appendString("--severity", cfg.Severity)
	appendString("--type", cfg.Type)
	appendString("--severity-threshold", cfg.SeverityThreshold)

	return args
}

// SanitizeGOFLAGS strips -mod flags from a GOFLAGS value: inherited
// -mod=mod from a direnv shell breaks workspace-mode projects, and vendor
// projects demand their own mode. Other flags pass through.
func SanitizeGOFLAGS(value string) string {
	fields := strings.Fields(value)
	kept := make([]string, 0, len(fields))

	//art-dupl:accept idiomatic split-filter-rejoin loop, 4 lines, unrelated packages, different filters and domains
	for _, field := range fields {
		if strings.HasPrefix(field, "-mod=") || field == "-mod" {
			continue
		}

		kept = append(kept, field)
	}

	return strings.Join(kept, " ")
}
