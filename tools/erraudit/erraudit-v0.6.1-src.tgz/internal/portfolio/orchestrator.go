package portfolio

import (
	"context"
	"sync"
	"sync/atomic"
	"time"

	apierrors "github.com/larsartmann/erraudit/pkg/errors"
	findingsdk "github.com/larsartmann/go-finding"
	"golang.org/x/sync/errgroup"
)

// DefaultConcurrency is the fleet default worker count. Type-aware analyses
// are go/packages-heavy; eight concurrent children saturate a typical dev
// machine without thrashing it.
const DefaultConcurrency = 8

// ProjectRunner analyzes a single project and returns the child's parsed
// go-finding report. SelfExecRunner is the production implementation; tests
// inject fakes.
type ProjectRunner interface {
	Analyze(ctx context.Context, ref ProjectRef, cfg AuditConfig) (*findingsdk.Report, error)
}

// Orchestrator fans one audit config out over a set of projects and folds
// the outcomes into a Report. Per-project failures are collected, never
// propagated: one broken repository must not abort the sweep.
type Orchestrator struct {
	Runner ProjectRunner

	// Concurrency caps parallel child analyses; values below 1 run
	// sequentially.
	Concurrency int

	// OnProgress, when set, is invoked after every completed project with
	// the done and total counts. Called from worker goroutines.
	OnProgress func(done, total int)
}

// Run analyzes every ref and assembles the report. Cancellation via ctx
// stops launching new children; already-collected results are kept.
func (o *Orchestrator) Run(ctx context.Context, refs []ProjectRef, cfg AuditConfig) *Report {
	//nolint:makezero // sized-to-refs and index-assigned, never appended
	results := make([]ProjectResult, len(refs))
	failures := make([]ProjectFailure, 0)

	var (
		failuresMu sync.Mutex
		done       atomic.Int64
	)

	workers := max(o.Concurrency, 1)

	//art-dupl:accept canonical errgroup bounded-concurrency setup, 2 lines, unrelated packages, different worker domains
	group, groupCtx := errgroup.WithContext(ctx)
	group.SetLimit(workers)

	for i := range refs {
		index, ref := i, refs[i]

		group.Go(func() error {
			started := time.Now()

			graph, err := o.Runner.Analyze(groupCtx, ref, cfg)
			if err != nil {
				failuresMu.Lock()

				failures = append(failures, ProjectFailure{
					Name:  ref.Name,
					Path:  ref.Path,
					Error: err.Error(),
				})
				failuresMu.Unlock()
			} else {
				results[index] = ResultFromReport(ref, graph, time.Since(started))
			}

			if o.OnProgress != nil {
				o.OnProgress(int(done.Add(1)), len(refs))
			}

			// A failed project is data, not an error: returning nil keeps
			// the pool running the remaining projects.
			return nil
		})
	}

	// The only error errgroup can observe is a context cancellation; both
	// outcomes produce the same report of whatever completed.
	if err := group.Wait(); err != nil {
		failuresMu.Lock()

		failures = append(failures, ProjectFailure{
			Name:  "",
			Path:  "",
			Error: apierrors.Wrap(err, "portfolio sweep").Error(),
		})
		failuresMu.Unlock()
	}

	analyzed := make([]ProjectResult, 0, len(results))
	for _, result := range results {
		if result.Name != "" {
			analyzed = append(analyzed, result)
		}
	}

	return &Report{
		Summary:  Summarize(analyzed, failures, 0),
		Projects: analyzed,
		Failures: failures,
	}
}
