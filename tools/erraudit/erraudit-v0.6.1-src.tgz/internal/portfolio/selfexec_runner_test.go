package portfolio_test

import (
	"context"
	"os"
	"os/exec"
	"path/filepath"
	"testing"
	"time"

	"github.com/larsartmann/erraudit/internal/portfolio"
	findingsdk "github.com/larsartmann/go-finding"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// stubBinary is built once in TestMain from internal/portfolio/fakeerraudit
// so the self-exec runner is exercised against a real child process.
var stubBinary string

func TestMain(m *testing.M) {
	dir, err := os.MkdirTemp("", "erraudit-fakeerraudit-")
	if err != nil {
		panic(err)
	}

	binary := filepath.Join(dir, "fakeerraudit")

	build := exec.Command("go", "build", "-o", binary,
		"github.com/larsartmann/erraudit/internal/portfolio/fakeerraudit")
	build.Stdout = os.Stderr
	build.Stderr = os.Stderr

	if err := build.Run(); err != nil {
		panic(err)
	}

	stubBinary = binary

	code := m.Run()

	_ = os.RemoveAll(dir)

	os.Exit(code)
}

func newStubRunner() *portfolio.SelfExecRunner {
	return &portfolio.SelfExecRunner{
		Executable: func() (string, error) { return stubBinary, nil },
	}
}

// stubProject creates a directory whose base name selects the stub's canned
// response (the stub switches on filepath.Base(os.Getwd())).
func stubProject(t *testing.T, name string) portfolio.ProjectRef {
	t.Helper()

	dir := filepath.Join(t.TempDir(), name)
	require.NoError(t, os.MkdirAll(dir, 0o755))

	return portfolio.ProjectRef{Name: name, Path: dir}
}

func TestSelfExecRunner_ParsesViolationsProjectExitTwo(t *testing.T) {
	ref := stubProject(t, "violations-project")

	report, err := newStubRunner().Analyze(context.Background(), ref, portfolio.AuditConfig{})

	require.NoError(t, err)
	require.NotNil(t, report)
	assert.Equal(t, 4, report.Len())
	assert.Equal(t, 4, report.Summary.Total)
	assert.Equal(t, 5, report.Summary.FilesScanned)
	assert.Equal(t, 1, report.CountBySeverity(findingsdk.SeverityCritical))
	assert.Equal(t, 2, report.CountBySeverity(findingsdk.SeverityError))
	assert.Equal(t, 1, report.CountBySeverity(findingsdk.SeverityWarning))
}

func TestSelfExecRunner_ParsesCleanProject(t *testing.T) {
	ref := stubProject(t, "clean-project")

	report, err := newStubRunner().Analyze(context.Background(), ref, portfolio.AuditConfig{})

	require.NoError(t, err)
	assert.Empty(t, report.FindingsSnapshot())
	assert.Equal(t, 3, report.Summary.FilesScanned)
}

func TestSelfExecRunner_FailureExitOneCarriesStderr(t *testing.T) {
	ref := stubProject(t, "broken-project")

	report, err := newStubRunner().Analyze(context.Background(), ref, portfolio.AuditConfig{})

	assert.Error(t, err)
	assert.Nil(t, report)
	assert.Contains(t, err.Error(), "exited 1")
	assert.Contains(t, err.Error(), "simulated analysis failure")
}

func TestSelfExecRunner_UnknownProjectYieldsEmptyScan(t *testing.T) {
	ref := stubProject(t, "unknown-project")

	report, err := newStubRunner().Analyze(context.Background(), ref, portfolio.AuditConfig{})

	require.NoError(t, err)
	require.NotNil(t, report)
	assert.Equal(t, 0, report.Summary.FilesScanned)
	assert.Empty(t, report.FindingsSnapshot())
}

func TestSelfExecRunner_ExecutableResolutionFailureWraps(t *testing.T) {
	runner := &portfolio.SelfExecRunner{
		Executable: func() (string, error) {
			return "", assert.AnError
		},
	}

	graph, err := runner.Analyze(context.Background(), portfolio.ProjectRef{Name: "x"}, portfolio.AuditConfig{})

	assert.Error(t, err)
	assert.Nil(t, graph)
	assert.Contains(t, err.Error(), "resolve erraudit binary")
}

func TestResultFromReport_CountsSeverityBucketsAndTopTypes(t *testing.T) {
	report := findingsdk.NewReport(findingsdk.ToolInfo{Name: "test"})
	report.AddFindings([]findingsdk.Finding{
		{Rule: "ignored", Severity: findingsdk.SeverityCritical},
		{Rule: "ignored", Severity: findingsdk.SeverityCritical},
		{Rule: "silent_swallow", Severity: findingsdk.SeverityError},
		{Rule: "context_loss", Severity: findingsdk.SeverityWarning},
	})
	report.ComputeSummary()
	report.Summary.FilesScanned = 12

	result := portfolio.ResultFromReport(portfolio.ProjectRef{Name: "n", Path: "p"}, report, 1500*time.Millisecond)

	assert.Equal(t, 4, result.Violations)
	assert.Equal(t, 2, result.Critical)
	assert.Equal(t, 1, result.Errors)
	assert.Equal(t, 1, result.Warnings)
	assert.Equal(t, 12, result.FilesScanned)
	assert.Equal(t, int64(1500), result.DurationMs)

	require.Len(t, result.TopTypes, 3)
	assert.Equal(t, "ignored", result.TopTypes[0].Type)
	assert.Equal(t, 2, result.TopTypes[0].Count)
}

func TestResultFromReport_NoViolationsYieldsNilTopTypes(t *testing.T) {
	result := portfolio.ResultFromReport(
		portfolio.ProjectRef{Name: "n"},
		&findingsdk.Report{},
		0,
	)

	assert.Nil(t, result.TopTypes)
	assert.Equal(t, 0, result.FilesScanned)
}

func TestSummarize_FoldsTotals(t *testing.T) {
	summary := portfolio.Summarize(
		[]portfolio.ProjectResult{
			{FilesScanned: 10, Violations: 3, Critical: 1, Errors: 1, Warnings: 1},
			{FilesScanned: 5, Violations: 1, Critical: 0, Errors: 1, Warnings: 0},
		},
		[]portfolio.ProjectFailure{{Name: "gone"}},
		4,
	)

	assert.Equal(t, 2, summary.ProjectsAnalyzed)
	assert.Equal(t, 1, summary.ProjectsFailed)
	assert.Equal(t, 4, summary.ProjectsHidden)
	assert.Equal(t, 15, summary.FilesScanned)
	assert.Equal(t, 4, summary.Violations)
	assert.Equal(t, 1, summary.Critical)
	assert.Equal(t, 2, summary.Errors)
	assert.Equal(t, 1, summary.Warnings)
}
