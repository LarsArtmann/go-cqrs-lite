package lsp

import (
	"context"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/sourcegraph/go-lsp"
	"github.com/sourcegraph/jsonrpc2"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func makeParams(v any) *json.RawMessage {
	data, _ := json.Marshal(v)
	raw := json.RawMessage(data)
	return &raw
}

func TestNewServer(t *testing.T) {
	server := NewServer()
	require.NotNil(t, server)
	assert.NotNil(t, server.documents)
}

func TestIsGoFile(t *testing.T) {
	tests := []struct {
		name     string
		uri      string
		expected bool
	}{
		{
			name:     "go file",
			uri:      "file:///path/to/file.go",
			expected: true,
		},
		{
			name:     "go file with query",
			uri:      "file:///path/to/file.go?line=10",
			expected: false,
		},
		{
			name:     "non-go file",
			uri:      "file:///path/to/file.js",
			expected: false,
		},
		{
			name:     "no extension",
			uri:      "file:///path/to/file",
			expected: false,
		},
		{
			name:     "empty string",
			uri:      "",
			expected: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			assert.Equal(t, tt.expected, isGoFile(tt.uri))
		})
	}
}

func TestURIToPath(t *testing.T) {
	tests := []struct {
		name     string
		uri      string
		expected string
	}{
		{
			name:     "file uri",
			uri:      "file:///path/to/file.go",
			expected: "/path/to/file.go",
		},
		{
			name:     "file uri with windows path",
			uri:      "file:///C:/Users/test/file.go",
			expected: "/C:/Users/test/file.go",
		},
		{
			name:     "no file prefix",
			uri:      "/path/to/file.go",
			expected: "/path/to/file.go",
		},
		{
			name:     "empty string",
			uri:      "",
			expected: "",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			assert.Equal(t, tt.expected, uriToPath(tt.uri))
		})
	}
}

func TestViolationToDiagnostic(t *testing.T) {
	tests := []struct {
		name             string
		violation        types.ErrorViolation
		expectedSeverity int
	}{
		{
			name: "high severity maps to error",
			violation: types.MakeTestViolation(
				"test.go",
				1,
				types.ErrorTypePanic,
				types.SeverityHigh,
				"test message",
			),
			expectedSeverity: 1, // lsp.Error
		},
		{
			name: "medium severity maps to warning",
			violation: types.MakeTestViolation(
				"test.go",
				2,
				types.ErrorTypeIgnored,
				types.SeverityMedium,
				"test message",
			),
			expectedSeverity: 1, // lsp.Error
		},
		{
			name: "low severity maps to warning",
			violation: types.MakeTestViolation(
				"test.go",
				3,
				types.ErrorTypeUnwrapped,
				types.SeverityLow,
				"test message",
			),
			expectedSeverity: 2, // lsp.Warning
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			diag := violationToDiagnostic(tt.violation)
			assert.Equal(t, tt.expectedSeverity, int(diag.Severity))
			assert.Equal(t, tt.violation.Message, diag.Message)
			assert.Equal(t, "erraudit", diag.Source)
		})
	}
}

func TestViolationToDiagnostic_Position(t *testing.T) {
	t.Run("invalid position returns zero", func(t *testing.T) {
		v := types.MakeTestViolation("test.go", 1, types.ErrorTypeIgnored, types.SeverityMedium, "test")
		diag := violationToDiagnostic(v)
		assert.Equal(t, 0, diag.Range.Start.Line)
		assert.Equal(t, 0, diag.Range.Start.Character)
	})
}

// --- handleRequest tests ---

func TestHandleRequest_Initialize(t *testing.T) {
	server := NewServer()
	params := lsp.InitializeParams{
		RootURI: lsp.DocumentURI("file:///test"),
	}
	req := &jsonrpc2.Request{
		ID:     jsonrpc2.ID{Num: 1},
		Method: "initialize",
		Params: makeParams(params),
	}
	result, err := server.handleRequest(context.Background(), req)
	require.NoError(t, err)

	initResult, ok := result.(*lsp.InitializeResult)
	require.True(t, ok)
	assert.NotNil(t, initResult.Capabilities.TextDocumentSync)
	assert.Equal(t, lsp.DocumentURI("file:///test"), server.rootURI)
}

func TestHandleRequest_Initialize_WithRootPath(t *testing.T) {
	server := NewServer()
	params := lsp.InitializeParams{
		RootPath: "/some/path",
	}
	req := &jsonrpc2.Request{
		ID:     jsonrpc2.ID{Num: 1},
		Method: "initialize",
		Params: makeParams(params),
	}
	result, err := server.handleRequest(context.Background(), req)
	require.NoError(t, err)
	assert.NotNil(t, result)
	assert.Equal(t, lsp.DocumentURI("file:///some/path"), server.rootURI)
}

func TestHandleRequest_Initialize_MalformedParams(t *testing.T) {
	server := NewServer()
	badParams := json.RawMessage(`{invalid json}`)
	req := &jsonrpc2.Request{
		ID:     jsonrpc2.ID{Num: 1},
		Method: "initialize",
		Params: &badParams,
	}
	_, err := server.handleRequest(context.Background(), req)
	require.Error(t, err)
}

func TestHandleRequest_Shutdown(t *testing.T) {
	server := NewServer()
	server.initialized = true

	req := &jsonrpc2.Request{
		ID:     jsonrpc2.ID{Num: 1},
		Method: "shutdown",
	}
	result, err := server.handleRequest(context.Background(), req)
	require.NoError(t, err)
	assert.Nil(t, result)
	assert.False(t, server.initialized)
}

func TestHandleRequest_UnknownMethod(t *testing.T) {
	server := NewServer()
	req := &jsonrpc2.Request{
		ID:     jsonrpc2.ID{Num: 1},
		Method: "custom/method",
	}
	result, err := server.handleRequest(context.Background(), req)
	require.Error(t, err)
	assert.Nil(t, result)

	jsonErr, ok := err.(*jsonrpc2.Error)
	require.True(t, ok)
	assert.EqualValues(t, jsonrpc2.CodeMethodNotFound, jsonErr.Code)
}

// --- handleNotification tests ---

func TestHandleNotification_Initialized(t *testing.T) {
	server := NewServer()
	req := &jsonrpc2.Request{Method: "initialized"}
	err := server.handleNotification(context.Background(), nil, req)
	require.NoError(t, err)
	assert.True(t, server.initialized)
}

func TestHandleNotification_DidSave(t *testing.T) {
	server := NewServer()
	req := &jsonrpc2.Request{Method: "textDocument/didSave"}
	err := server.handleNotification(context.Background(), nil, req)
	require.NoError(t, err)
}

func TestHandleNotification_Unknown(t *testing.T) {
	server := NewServer()
	req := &jsonrpc2.Request{Method: "custom/notification"}
	err := server.handleNotification(context.Background(), nil, req)
	require.NoError(t, err)
}

func TestHandleNotification_DidOpen_GoFile_NilConn(t *testing.T) {
	server := NewServer()
	code := "package main\n\nfunc main() {\n\tpanic(\"x\")\n}\n"
	params := lsp.DidOpenTextDocumentParams{
		TextDocument: lsp.TextDocumentItem{
			URI:  "file:///test.go",
			Text: code,
		},
	}
	req := &jsonrpc2.Request{
		Method: "textDocument/didOpen",
		Params: makeParams(params),
	}
	err := server.handleNotification(context.Background(), nil, req)
	require.NoError(t, err)

	server.mu.RLock()
	doc, exists := server.documents["file:///test.go"]
	server.mu.RUnlock()
	require.True(t, exists)
	assert.Equal(t, code, doc.text)
}

func TestHandleNotification_DidOpen_NonGoFile(t *testing.T) {
	server := NewServer()
	params := lsp.DidOpenTextDocumentParams{
		TextDocument: lsp.TextDocumentItem{
			URI:  "file:///test.js",
			Text: "console.log('hello')",
		},
	}
	req := &jsonrpc2.Request{
		Method: "textDocument/didOpen",
		Params: makeParams(params),
	}
	err := server.handleNotification(context.Background(), nil, req)
	require.NoError(t, err)

	server.mu.RLock()
	_, exists := server.documents["file:///test.js"]
	server.mu.RUnlock()
	assert.False(t, exists)
}

func TestHandleNotification_DidOpen_MalformedParams(t *testing.T) {
	server := NewServer()
	badParams := json.RawMessage(`{invalid}`)
	req := &jsonrpc2.Request{
		Method: "textDocument/didOpen",
		Params: &badParams,
	}
	err := server.handleNotification(context.Background(), nil, req)
	require.Error(t, err)
}

func TestHandleNotification_DidChange(t *testing.T) {
	server := NewServer()
	server.documents["file:///test.go"] = &document{
		text:    "package main",
		version: 1,
	}

	params := lsp.DidChangeTextDocumentParams{
		TextDocument: lsp.VersionedTextDocumentIdentifier{
			TextDocumentIdentifier: lsp.TextDocumentIdentifier{
				URI: "file:///test.go",
			},
			Version: 2,
		},
		ContentChanges: []lsp.TextDocumentContentChangeEvent{
			{Text: "package main\n\nfunc main() {}"},
		},
	}
	req := &jsonrpc2.Request{
		Method: "textDocument/didChange",
		Params: makeParams(params),
	}
	err := server.handleNotification(context.Background(), nil, req)
	require.NoError(t, err)

	server.mu.RLock()
	doc := server.documents["file:///test.go"]
	server.mu.RUnlock()
	assert.Equal(t, 2, doc.version)
	assert.Equal(t, "package main\n\nfunc main() {}", doc.text)
}

func TestHandleNotification_DidChange_NoChanges(t *testing.T) {
	server := NewServer()
	req := &jsonrpc2.Request{
		Method: "textDocument/didChange",
		Params: makeParams(lsp.DidChangeTextDocumentParams{
			TextDocument: lsp.VersionedTextDocumentIdentifier{
				TextDocumentIdentifier: lsp.TextDocumentIdentifier{
					URI: "file:///test.go",
				},
			},
		}),
	}
	err := server.handleNotification(context.Background(), nil, req)
	require.NoError(t, err)
}

func TestHandleNotification_DidChange_NonGoFile(t *testing.T) {
	server := NewServer()
	params := lsp.DidChangeTextDocumentParams{
		TextDocument: lsp.VersionedTextDocumentIdentifier{
			TextDocumentIdentifier: lsp.TextDocumentIdentifier{
				URI: "file:///test.js",
			},
		},
		ContentChanges: []lsp.TextDocumentContentChangeEvent{
			{Text: "console.log('updated')"},
		},
	}
	req := &jsonrpc2.Request{
		Method: "textDocument/didChange",
		Params: makeParams(params),
	}
	err := server.handleNotification(context.Background(), nil, req)
	require.NoError(t, err)
}

func TestHandleNotification_DidChange_MalformedParams(t *testing.T) {
	server := NewServer()
	badParams := json.RawMessage(`{invalid}`)
	req := &jsonrpc2.Request{
		Method: "textDocument/didChange",
		Params: &badParams,
	}
	err := server.handleNotification(context.Background(), nil, req)
	require.Error(t, err)
}

func TestHandleNotification_DidClose(t *testing.T) {
	server := NewServer()
	server.documents["file:///test.go"] = &document{text: "package main", version: 1}

	params := lsp.DidCloseTextDocumentParams{
		TextDocument: lsp.TextDocumentIdentifier{
			URI: "file:///test.go",
		},
	}
	req := &jsonrpc2.Request{
		Method: "textDocument/didClose",
		Params: makeParams(params),
	}
	err := server.handleNotification(context.Background(), nil, req)
	require.NoError(t, err)

	server.mu.RLock()
	_, exists := server.documents["file:///test.go"]
	server.mu.RUnlock()
	assert.False(t, exists)
}

func TestHandleNotification_DidClose_MalformedParams(t *testing.T) {
	server := NewServer()
	badParams := json.RawMessage(`{invalid}`)
	req := &jsonrpc2.Request{
		Method: "textDocument/didClose",
		Params: &badParams,
	}
	err := server.handleNotification(context.Background(), nil, req)
	require.Error(t, err)
}

// --- publishDiagnostics tests ---

func TestPublishDiagnostics_NilConn(t *testing.T) {
	server := NewServer()
	err := server.publishDiagnostics(context.Background(), "file:///test.go", "package main")
	require.NoError(t, err)
}

func TestPublishDiagnostics_NilConn_EmptyText(t *testing.T) {
	server := NewServer()
	err := server.publishDiagnostics(context.Background(), "file:///test.go", "")
	require.NoError(t, err)
}

// --- analyzeContent tests ---

func TestAnalyzeContent_ValidGo(t *testing.T) {
	server := NewServer()
	code := `package main

import "os"

func helper() {
	file, _ := os.Open("test.txt")
	defer file.Close()
}
`
	graph, err := server.analyzeContent(context.Background(), "test.go", code)
	require.NoError(t, err)
	require.NotNil(t, graph)
	assert.NotEmpty(t, graph.Violations)
}

func TestAnalyzeContent_ValidGo_NoViolations(t *testing.T) {
	server := NewServer()
	code := `package main

func add(a, b int) int {
	return a + b
}
`
	graph, err := server.analyzeContent(context.Background(), "test.go", code)
	require.NoError(t, err)
	require.NotNil(t, graph)
	assert.Empty(t, graph.Violations)
}

func TestAnalyzeContent_InvalidGo(t *testing.T) {
	server := NewServer()
	_, err := server.analyzeContent(context.Background(), "test.go", "this is not valid go code")
	require.Error(t, err)
}

func TestAnalyzeContent_EmptyString(t *testing.T) {
	server := NewServer()
	graph, err := server.analyzeContent(context.Background(), "test.go", "")
	require.Error(t, err)
	assert.Nil(t, graph)
}

func TestAnalyzeContent_CancelledContext(t *testing.T) {
	server := NewServer()
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	graph, err := server.analyzeContent(ctx, "test.go", "package main")
	require.Error(t, err)
	assert.Nil(t, graph)
	assert.ErrorIs(t, err, context.Canceled)
}

func TestPublishDiagnostics_CancelledContext_NilConn(t *testing.T) {
	server := NewServer()
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	err := server.publishDiagnostics(ctx, "file:///test.go", "package main")
	require.NoError(t, err) // nil conn returns nil early
}

// --- suppression policy tests (S12: LSP hides //nolint, matching the CLI) ---

func writeTempGoFile(t *testing.T, content string) string {
	t.Helper()

	path := filepath.Join(t.TempDir(), "fixture.go")
	require.NoError(t, os.WriteFile(path, []byte(content), 0o600))

	return path
}

const suppressedFixture = `package main

import "os"

func helper() {
	file, _ := os.Open("test.txt") //nolint:erraudit // test fixture: suppressed on purpose
	defer file.Close()
}
`

const unsuppressedFixture = `package main

import "os"

func helper() {
	file, _ := os.Open("test.txt")
	defer file.Close()
}
`

func TestDiagnosticsFor_SuppressedHidden(t *testing.T) {
	server := NewServer()
	path := writeTempGoFile(t, suppressedFixture)

	diagnostics := server.diagnosticsFor(context.Background(), path, suppressedFixture)
	assert.Empty(t, diagnostics,
		"//nolint:erraudit must hide the violation in the editor exactly like the CLI")
}

func TestDiagnosticsFor_UnsuppressedPublished(t *testing.T) {
	server := NewServer()
	path := writeTempGoFile(t, unsuppressedFixture)

	diagnostics := server.diagnosticsFor(context.Background(), path, unsuppressedFixture)
	require.NotEmpty(t, diagnostics)
	assert.NotEmpty(t, diagnostics[0].Message)
}

func TestDiagnosticsFor_SuppressionReadsDisk(t *testing.T) {
	server := NewServer()
	path := writeTempGoFile(t, suppressedFixture)

	edited := strings.Replace(
		suppressedFixture,
		" //nolint:erraudit // test fixture: suppressed on purpose",
		"",
		1,
	)

	diagnostics := server.diagnosticsFor(context.Background(), path, edited)
	assert.Empty(
		t,
		diagnostics,
		"suppression reads the saved file like the CLI: deleting the nolint comment hides the diagnostic only after save",
	)
}

// --- unmarshalParams tests (indirect via request/notification handlers) ---

func TestHandleRequest_Initialize_MissingParams(t *testing.T) {
	server := NewServer()
	req := &jsonrpc2.Request{
		ID:     jsonrpc2.ID{Num: 1},
		Method: "initialize",
		Params: nil,
	}
	_, err := server.handleRequest(context.Background(), req)
	require.Error(t, err)
}
