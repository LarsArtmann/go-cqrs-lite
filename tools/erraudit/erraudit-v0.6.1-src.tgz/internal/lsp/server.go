// Package lsp implements a Language Server Protocol server for the
// erraudit analyzer, providing real-time diagnostics in editors.
package lsp

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"go/parser"
	"go/token"
	"os"
	"strings"
	"sync"

	"github.com/larsartmann/erraudit/cmd/erraudit/cmd/pipeline"
	"github.com/larsartmann/erraudit/internal/ast"
	apierrors "github.com/larsartmann/erraudit/pkg/errors"
	"github.com/larsartmann/erraudit/pkg/finding"
	"github.com/larsartmann/erraudit/pkg/types"
	findingsdk "github.com/larsartmann/go-finding"
	"github.com/sourcegraph/go-lsp"
	"github.com/sourcegraph/jsonrpc2"
)

// LSP method names as defined by the protocol specification.
const (
	methodInitialize  = "initialize"
	methodInitialized = "initialized"
	methodShutdown    = "shutdown"
	methodExit        = "exit"
	methodDidOpen     = "textDocument/didOpen"
	methodDidChange   = "textDocument/didChange"
	methodDidClose    = "textDocument/didClose"
)

// Server implements an LSP server for error handling analysis.
// It implements the jsonrpc2.Handler interface.
type Server struct {
	mu          sync.RWMutex
	conn        *jsonrpc2.Conn
	rootURI     lsp.DocumentURI
	documents   map[lsp.DocumentURI]*document
	initialized bool
}

type document struct {
	text    string
	version int
}

// NewServer creates a new LSP server instance.
func NewServer() *Server {
	return &Server{
		documents: make(map[lsp.DocumentURI]*document),
	}
}

// Handle implements jsonrpc2.Handler to process incoming requests.
func (s *Server) Handle(ctx context.Context, conn *jsonrpc2.Conn, req *jsonrpc2.Request) {
	// Check if this is a request (has ID) or notification (no ID)
	if req.ID != (jsonrpc2.ID{}) {
		// It's a request - needs response
		result, err := s.handleRequest(ctx, req)
		if err != nil {
			jsonErr, ok := errors.AsType[*jsonrpc2.Error](err)
			if !ok {
				jsonErr = &jsonrpc2.Error{
					Code:    jsonrpc2.CodeInternalError,
					Message: err.Error(),
				}
			}

			_ = conn.ReplyWithError( //nolint:erraudit // LSP fire-and-forget: connection broken if reply fails
				ctx,
				req.ID,
				jsonErr,
			)

			return
		}

		_ = conn.Reply(ctx, req.ID, result) //nolint:erraudit // LSP fire-and-forget: connection broken if reply fails

		return
	}

	// It's a notification - no response expected
	_ = s.handleNotification(ctx, conn, req) //nolint:erraudit // LSP fire-and-forget: notification has no reply
}

// Serve starts the LSP server on the given stream.
func (s *Server) Serve(ctx context.Context, stream jsonrpc2.ObjectStream) error {
	handler := jsonrpc2.AsyncHandler(s)
	s.conn = jsonrpc2.NewConn(ctx, stream, handler)

	// Wait for disconnect
	<-s.conn.DisconnectNotify()

	return nil
}

// handleRequest handles LSP requests that expect a response.
func (s *Server) handleRequest(_ context.Context, req *jsonrpc2.Request) (any, error) {
	switch req.Method {
	case methodInitialize:
		return s.handleInitialize(req)
	case methodShutdown:
		return s.handleShutdown()
	default:
		return nil, &jsonrpc2.Error{
			Code:    jsonrpc2.CodeMethodNotFound,
			Message: fmt.Sprintf("method %q not found", req.Method),
		}
	}
}

// handleNotification handles LSP notifications (no response).
func (s *Server) handleNotification(
	ctx context.Context,
	_ *jsonrpc2.Conn,
	req *jsonrpc2.Request,
) error {
	switch req.Method {
	case methodInitialized:
		s.mu.Lock()
		s.initialized = true
		s.mu.Unlock()

		return nil
	case methodExit:
		return s.handleExit()
	case methodDidOpen:
		return s.handleDidOpen(ctx, req)
	case methodDidChange:
		return s.handleDidChange(ctx, req)
	case methodDidClose:
		return s.handleDidClose(ctx, req)
	case "textDocument/didSave":
		return nil // No action needed
	default:
		// Unknown notifications are ignored per LSP spec
		return nil
	}
}

// handleInitialize handles the LSP initialize request.
func (s *Server) handleInitialize(req *jsonrpc2.Request) (*lsp.InitializeResult, error) {
	var params lsp.InitializeParams

	if err := unmarshalParamsWithOperation(req, &params, "initialize"); err != nil {
		return nil, err
	}

	s.mu.Lock()

	s.rootURI = params.RootURI
	if s.rootURI == "" && params.RootPath != "" {
		s.rootURI = lsp.DocumentURI("file://" + params.RootPath)
	}

	s.mu.Unlock()

	return &lsp.InitializeResult{
		Capabilities: lsp.ServerCapabilities{
			TextDocumentSync: &lsp.TextDocumentSyncOptionsOrKind{
				Options: &lsp.TextDocumentSyncOptions{
					OpenClose: true,
					Change:    lsp.TDSKFull,
					Save:      &lsp.SaveOptions{IncludeText: false},
				},
			},
		},
	}, nil
}

// handleShutdown handles the LSP shutdown request.
func (s *Server) handleShutdown() (any, error) {
	s.mu.Lock()
	s.initialized = false
	s.mu.Unlock()

	//nolint:nilnil // LSP shutdown response result is "null" per spec
	return nil, nil
}

// unmarshalParamsWithOperation unmarshals JSON-RPC request params and wraps errors with operation name.
func unmarshalParamsWithOperation(req *jsonrpc2.Request, v any, operation string) error {
	err := unmarshalParams(req, v)
	if err != nil {
		return apierrors.Wrap(err, "failed to unmarshal %s params for request %s", operation, req.ID)
	}

	return nil
}

// handleExit handles the LSP exit notification.
func (s *Server) handleExit() error {
	os.Exit(0)

	return nil
}

// handleDidOpen handles the textDocument/didOpen notification.
func (s *Server) handleDidOpen(ctx context.Context, req *jsonrpc2.Request) error {
	var params lsp.DidOpenTextDocumentParams
	if err := unmarshalParamsWithOperation(req, &params, "didOpen"); err != nil {
		return err
	}

	// Only handle Go files
	if !strings.HasSuffix(string(params.TextDocument.URI), ".go") {
		return nil
	}

	s.mu.Lock()
	s.documents[params.TextDocument.URI] = &document{
		text:    params.TextDocument.Text,
		version: params.TextDocument.Version,
	}
	s.mu.Unlock()

	// Analyze and publish diagnostics
	return s.publishDiagnostics(ctx, params.TextDocument.URI, params.TextDocument.Text)
}

// handleDidChange handles the textDocument/didChange notification.
func (s *Server) handleDidChange(ctx context.Context, req *jsonrpc2.Request) error {
	var params lsp.DidChangeTextDocumentParams
	if err := unmarshalParamsWithOperation(req, &params, "didChange"); err != nil {
		return err
	}

	// Only handle Go files
	if !strings.HasSuffix(string(params.TextDocument.URI), ".go") {
		return nil
	}

	if len(params.ContentChanges) == 0 {
		return nil
	}

	// For full sync, the last change contains the full document text
	text := params.ContentChanges[len(params.ContentChanges)-1].Text

	s.mu.Lock()

	if doc, ok := s.documents[params.TextDocument.URI]; ok {
		doc.text = text
		doc.version = params.TextDocument.Version
	}

	s.mu.Unlock()

	// Analyze and publish diagnostics
	return s.publishDiagnostics(ctx, params.TextDocument.URI, text)
}

// handleDidClose handles the textDocument/didClose notification.
func (s *Server) handleDidClose(ctx context.Context, req *jsonrpc2.Request) error {
	var params lsp.DidCloseTextDocumentParams
	if err := unmarshalParamsWithOperation(req, &params, "didClose"); err != nil {
		return err
	}

	s.mu.Lock()
	delete(s.documents, params.TextDocument.URI)
	s.mu.Unlock()

	// Clear diagnostics for the closed file
	return s.publishDiagnostics(ctx, params.TextDocument.URI, "")
}

// publishDiagnostics analyzes the document and publishes diagnostics to the client.
func (s *Server) publishDiagnostics(ctx context.Context, uri lsp.DocumentURI, text string) error {
	if s.conn == nil {
		return nil
	}

	if ctx.Err() != nil {
		return nil //nolint:nilerr // intentional: cancelled context = skip silently
	}

	diagnostics := s.diagnosticsFor(ctx, uriToPath(string(uri)), text)

	// Send diagnostics notification
	params := lsp.PublishDiagnosticsParams{
		URI:         uri,
		Diagnostics: diagnostics,
	}

	if err := s.conn.Notify(ctx, "textDocument/publishDiagnostics", params); err != nil {
		return apierrors.Wrap(
			err,
			"failed to publish diagnostics for uri=%v (filePath=%s, text len=%d)",
			uri,
			uriToPath(string(uri)),
			len(text),
		)
	}

	return nil
}

// diagnosticsFor analyzes the in-memory document and converts the surviving
// violations to LSP diagnostics. Suppression runs through the shared pipeline
// finishing step (the same choke point as analyze, watch, lint, and
// --pipeline), so the editor cannot disagree with the CLI on what //nolint
// hides. Per the owner decision, suppressed violations are HIDDEN, matching
// all CLI paths. The suppression engine reads the file from DISK — exactly
// like the CLI — so a nolint comment typed into an unsaved buffer takes
// effect on save, and a deleted one stops suppressing on save.
func (s *Server) diagnosticsFor(ctx context.Context, filePath, text string) []lsp.Diagnostic {
	if text == "" {
		return nil
	}

	graph, err := s.analyzeContent(ctx, filePath, text)
	if err != nil || graph == nil {
		// Analysis failure = no diagnostics this round; the error is already
		// surfaced upstream.
		return nil
	}

	// noSuppress stays false (audit mode is a CLI concept; the editor always
	// honors //nolint) and explain stays false (diagnostic messages must stay
	// single-line; explanations are a CLI/tree rendering concern).
	graph.Violations = pipeline.FinalizeViolations(
		graph.Violations,
		[]string{filePath},
		false,
		false,
	)

	diagnostics := make([]lsp.Diagnostic, 0, len(graph.Violations))
	for _, v := range graph.Violations {
		diagnostics = append(diagnostics, violationToDiagnostic(v))
	}

	return diagnostics
}

// analyzeContent analyzes the given content and returns the error graph.
// Returns context.Canceled if the context is already cancelled before
// analysis begins.
func (s *Server) analyzeContent(ctx context.Context, filePath, content string) (*types.ErrorGraph, error) {
	if err := ctx.Err(); err != nil {
		return nil, apierrors.Wrap(err, "context cancelled before analysis")
	}

	fset := token.NewFileSet()

	// Parse the file content
	f, err := parser.ParseFile(fset, filePath, content, parser.AllErrors|parser.ParseComments)
	if err != nil {
		return nil, apierrors.Wrap(
			err,
			"failed to parse file %s (content len=%d)",
			filePath,
			len(content),
		)
	}

	// Extract package name
	pkgName := f.Name.Name

	// Create analyzer and run analysis, threading the request context
	// so cancellation and trace data propagate to hooks.
	analyzer := ast.NewAnalyzer(fset, pkgName, filePath, ast.WithCtx(ctx))

	return analyzer.Analyze(f), nil
}

// violationToDiagnostic converts an ErrorViolation to an LSP Diagnostic
// using the go-finding bridge for standardized conversion.
func violationToDiagnostic(v types.ErrorViolation) lsp.Diagnostic {
	f, err := finding.ViolationToFinding(v)
	if err != nil {
		return lsp.Diagnostic{
			Range: lsp.Range{
				Start: lsp.Position{Line: v.Position.Line - 1, Character: 0},
				End:   lsp.Position{Line: v.Position.Line - 1, Character: 0},
			},
			Severity: lsp.Warning,
			Source:   "erraudit",
			Message:  v.Message,
		}
	}

	goFindingDiag := f.ToLSP()

	var severity lsp.DiagnosticSeverity = lsp.Warning

	switch goFindingDiag.Severity {
	case findingsdk.LSPSeverityError:
		severity = lsp.Error
	case findingsdk.LSPSeverityWarning:
		severity = lsp.Warning
	case findingsdk.LSPSeverityInfo:
		severity = lsp.Information
	case findingsdk.LSPSeverityHint:
		severity = lsp.Hint
	}

	return lsp.Diagnostic{
		Range: lsp.Range{
			Start: lsp.Position{
				Line:      goFindingDiag.Range.Start.Line,
				Character: goFindingDiag.Range.Start.Character,
			},
			End: lsp.Position{
				Line:      goFindingDiag.Range.End.Line,
				Character: goFindingDiag.Range.End.Character,
			},
		},
		Severity: severity,
		Code:     goFindingDiag.Code,
		Source:   goFindingDiag.Source,
		Message:  goFindingDiag.Message,
	}
}

// unmarshalParams unmarshals JSON-RPC request params.
func unmarshalParams(req *jsonrpc2.Request, v any) error {
	if req.Params == nil {
		return &jsonrpc2.Error{
			Code:    jsonrpc2.CodeInvalidParams,
			Message: "missing params",
		}
	}

	if err := json.Unmarshal(*req.Params, v); err != nil {
		return apierrors.Wrap(err, "failed to unmarshal params")
	}

	return nil
}

// isGoFile checks if the URI points to a Go file.
func isGoFile(uri string) bool {
	return strings.HasSuffix(uri, ".go")
}

// uriToPath converts a file:// URI to a filesystem path.
func uriToPath(uri string) string {
	uri = strings.TrimPrefix(uri, "file://")

	return uri
}

// Ensure Server implements jsonrpc2.Handler.
var _ jsonrpc2.Handler = (*Server)(nil)
