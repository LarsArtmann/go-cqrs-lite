// Package testutil provides shared test helpers for parse + type-check
// boilerplate used across internal/ and pkg/ test suites.
package testutil

import (
	"go/ast"
	"go/importer"
	"go/parser"
	"go/token"
	"go/types"
	"testing"
)

// ParseResult holds the output of parsing and type-checking a Go source file.
type ParseResult struct {
	Fset *token.FileSet
	File *ast.File
	Pkg  *types.Package
	Info *types.Info
	Src  string
}

// ParseAndTypeCheck parses src and type-checks it as package "testpkg".
// info is fully populated (Types, Defs, Uses, Implicits, Selections).
// The importer uses source mode so test files with no build context work.
// Calls t.Fatal on parse or type-check errors.
func ParseAndTypeCheck(t *testing.T, filename, src string) ParseResult {
	t.Helper()

	fset := token.NewFileSet()

	file, err := parser.ParseFile(fset, filename, src, parser.ParseComments)
	if err != nil {
		t.Fatalf("parse error: %v", err)
	}

	info := &types.Info{ //nolint:exhaustruct_v5 // only fields needed for analysis are populated
		Types:      make(map[ast.Expr]types.TypeAndValue),
		Defs:       make(map[*ast.Ident]types.Object),
		Uses:       make(map[*ast.Ident]types.Object),
		Implicits:  make(map[ast.Node]types.Object),
		Selections: make(map[*ast.SelectorExpr]*types.Selection),
	}

	conf := types.Config{ //nolint:exhaustruct_v5 // only Importer is needed
		Importer: importer.ForCompiler(fset, "source", nil),
	}

	pkg, err := conf.Check("testpkg", fset, []*ast.File{file}, info)
	if err != nil {
		t.Fatalf("type check error: %v", err)
	}

	return ParseResult{Fset: fset, File: file, Pkg: pkg, Info: info, Src: src}
}
