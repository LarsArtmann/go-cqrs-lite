package analyzer

import (
	"path/filepath"
	"sort"
	"strings"

	astanalyzer "github.com/larsartmann/erraudit/internal/ast"
	"github.com/larsartmann/erraudit/pkg/types"
)

// mergeGraphLocked is a thread-safe version of mergeGraph.
func (a *MainAnalyzer) mergeGraphLocked(target, source *types.ErrorGraph) {
	a.mu.Lock()
	defer a.mu.Unlock()

	mergeGraph(target, source)
}

// mergeGraph combines data from source into target.
func mergeGraph(target, source *types.ErrorGraph) {
	target.Errors = append(target.Errors, source.Errors...)
	target.Violations = append(target.Violations, source.Violations...)

	target.Metrics = target.Metrics.Merge(source.Metrics)
	target.FilesScanned += source.FilesScanned
	target.PackagesScanned += source.PackagesScanned

	// Merge hierarchies
	if source.Hierarchy != nil {
		mergeHierarchy(target, source)
	}
}

// MergeGraphs combines independently produced graphs (one per module in
// --modules=all fan-out) into target and finalizes the combined hierarchy
// (cross-module relationship dedup, cycle removal, depth recomputation).
// This is the only sanctioned entry point for merging graphs that were each
// produced by a full AnalyzePackage run — never inline merging at call sites.
func MergeGraphs(target, source *types.ErrorGraph) {
	mergeGraph(target, source)

	if target != nil && target.Hierarchy != nil {
		astanalyzer.FinalizeHierarchy(target.Hierarchy)
	}
}

// finalizeGraph runs post-merge cleanup on the combined graph's hierarchy.
// Removes cross-file duplicate relationships, cross-file cycles, and
// recomputes graph-correct node depths. Called once after all per-file
// graphs are merged.
func (a *MainAnalyzer) finalizeGraph(graph *types.ErrorGraph) {
	if graph != nil && graph.Hierarchy != nil {
		astanalyzer.FinalizeHierarchy(graph.Hierarchy)
	}
}

// mergeHierarchy merges the source hierarchy into the target graph.
func mergeHierarchy(target, source *types.ErrorGraph) {
	// Initialize target hierarchy if needed
	if target.Hierarchy == nil {
		target.Hierarchy = &types.ErrorHierarchy{
			RootErrors:    make([]*types.ErrorNode, 0),
			AllNodes:      make(map[string]*types.ErrorNode),
			Relationships: make([]types.ErrorRelationship, 0),
			NamedErrors:   make([]types.NamedError, 0),
			Metrics: types.HierarchyMetrics{
				WrapCount: make(map[string]uint),
			},
		}
	}

	sh := source.Hierarchy
	th := target.Hierarchy

	// Merge named errors
	th.NamedErrors = append(th.NamedErrors, sh.NamedErrors...)

	// Merge relationships
	th.Relationships = append(th.Relationships, sh.Relationships...)

	// Merge all nodes (deduplicate by name)
	for name, node := range sh.AllNodes {
		if _, exists := th.AllNodes[name]; !exists {
			th.AllNodes[name] = node
		}
	}

	// Track which nodes have parents to identify root errors
	hasParent := make(map[string]bool)
	for _, rel := range th.Relationships {
		hasParent[rel.Child] = true
	}

	// Rebuild root errors (nodes without parents), sorted by name for deterministic output
	th.RootErrors = make([]*types.ErrorNode, 0)

	var rootNames []string

	for name := range th.AllNodes {
		if !hasParent[name] {
			rootNames = append(rootNames, name)
		}
	}

	sort.Strings(rootNames)

	for _, name := range rootNames {
		th.RootErrors = append(th.RootErrors, th.AllNodes[name])
	}

	// Merge metrics
	th.Metrics = th.Metrics.Merge(sh.Metrics)
}

// isExcluded checks if a path should be excluded from analysis.
// Uses path-component-aware matching to prevent false matches
// (e.g., "test" should not exclude "testdata").
func (a *MainAnalyzer) isExcluded(path string) bool {
	normalizedPath := filepath.ToSlash(path)

	for _, excluded := range a.excludedPaths {
		normalizedExcluded := filepath.ToSlash(excluded)

		if normalizedPath == normalizedExcluded {
			return true
		}

		if strings.Contains(normalizedPath, "/"+normalizedExcluded+"/") {
			return true
		}

		if strings.HasPrefix(normalizedPath, normalizedExcluded+"/") {
			return true
		}

		if strings.HasSuffix(normalizedPath, "/"+normalizedExcluded) {
			return true
		}
	}

	return false
}
