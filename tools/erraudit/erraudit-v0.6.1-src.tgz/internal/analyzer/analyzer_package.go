package analyzer

import (
	"context"
	"os"
	"path/filepath"
	"strings"
	"sync/atomic"
	"time"

	astanalyzer "github.com/larsartmann/erraudit/internal/ast"
	apierrors "github.com/larsartmann/erraudit/pkg/errors"
	"github.com/larsartmann/erraudit/pkg/extension/hooks"
	"github.com/larsartmann/erraudit/pkg/types"
	"golang.org/x/sync/errgroup"
	"golang.org/x/tools/go/packages"
)

// AnalyzePackage analyzes a Go package.
func (a *MainAnalyzer) AnalyzePackage(
	ctx context.Context,
	pkgPath string,
) (*types.ErrorGraph, error) {
	// Execute pre-analysis hook
	_, cancelled, err := hooks.Fire(ctx, hooks.HookPreAnalysis, &hooks.PreAnalysisData{Path: pkgPath})
	if err != nil {
		return nil, apierrors.Wrap(err, "pre-analysis hook failed")
	}

	if cancelled {
		return nil, apierrors.ErrAnalysisCancelledByHook
	}

	startTime := time.Now()
	// Load package using our fileset to ensure consistency
	// NOTE: Only loading what's needed for AST analysis.
	// NeedDeps/NeedImports/NeedTypes/NeedTypesInfo load ALL transitive dependencies,
	// which causes 10-100x memory explosion (17GB on large projects).
	// SSA analysis (when enabled) loads its own packages with needed flags.
	cfg := &packages.Config{
		Mode:  packages.NeedName | packages.NeedFiles | packages.NeedSyntax,
		Fset:  a.fset,
		Tests: false,
	}

	// Absolute patterns target a directory that may be unrelated to the
	// process cwd. Root `go list` at the target (Dir) and drop any explicit
	// GOWORK from the environment: an ambient workspace — whether discovered
	// above the process cwd or exported by the caller's environment — would
	// otherwise reject the pattern with "directory prefix ... does not
	// contain modules listed in go.work". With GOWORK removed, the go
	// command discovers the workspace (if any) from the target directory,
	// which is the semantics an embedded consumer wants. Relative patterns
	// keep the caller's environment untouched (CLI cwd semantics).
	if dir := absolutePatternRoot(pkgPath); dir != "" {
		cfg.Dir = dir
		cfg.Env = sanitizedTargetEnv()
	}

	if a.typeInfoEnabled {
		cfg.Mode |= packages.NeedTypes | packages.NeedTypesInfo
	}

	// If pkgPath doesn't already end with ...
	pattern := pkgPath
	if !strings.HasSuffix(pkgPath, "...") {
		pattern = pkgPath + "..."
	}

	// Try to get from cache first
	pkgs, err := a.loadPackagesWithCache(pattern, cfg)
	if err != nil {
		return nil, apierrors.Wrap(err, "load packages %s", pattern)
	}

	// Check for context cancellation
	select {
	case <-ctx.Done():
		return nil, apierrors.Wrap(
			ctx.Err(),
			"context cancelled while analyzing package %s (packages=%d)",
			pkgPath,
			len(pkgs),
		)
	default:
		// Continue
	}

	if packages.PrintErrors(pkgs) > 0 {
		return nil, apierrors.Wrap(
			apierrors.New("package errors"),
			"packages contain errors for %s (packages=%d)",
			pkgPath,
			len(pkgs),
		)
	}

	// Combine results from all packages using concurrent analysis
	combinedGraph := newErrorGraph(pkgPath)

	g, gctx := errgroup.WithContext(ctx)

	var done atomic.Int64

	for _, pkg := range pkgs {
		g.Go(func() error {
			if err := checkContextCancellation(gctx); err != nil {
				return err
			}

			graph := a.analyzeSinglePackage(ctx, pkg)

			a.mergeGraphLocked(combinedGraph, graph)

			if a.progress != nil {
				a.progress(int(done.Add(1)), len(pkgs), pkg.PkgPath)
			}

			return nil
		})
	}

	err = g.Wait()
	if err != nil {
		return nil, apierrors.Wrap(
			err,
			"failed during package analysis for %s (packages=%d)",
			pkgPath,
			len(pkgs),
		)
	}

	// Execute post-analysis hook
	duration := time.Since(startTime).Milliseconds()
	hooks.Notify(ctx, hooks.HookPostAnalysis, &hooks.PostAnalysisData{
		Path:     pkgPath,
		Duration: duration,
		Graph:    combinedGraph,
	})

	a.finalizeGraph(combinedGraph)

	return combinedGraph, nil
}

// loadPackagesWithCache loads Go packages, using the cache when available.
func (a *MainAnalyzer) loadPackagesWithCache(pattern string, cfg *packages.Config) ([]*packages.Package, error) {
	if a.pkgCache == nil {
		pkgs, err := packages.Load(cfg, pattern)
		if err != nil {
			return nil, apierrors.Wrap(err, "failed to load packages for pattern %s (cached=%v)", pattern, false)
		}

		return pkgs, nil
	}

	pkgs, cached := a.pkgCache.Get(pattern, cfg)
	if cached {
		return pkgs, nil
	}

	pkgs, err := packages.Load(cfg, pattern)
	if err != nil {
		return nil, apierrors.Wrap(err, "failed to load packages for pattern %s (cached=%v)", pattern, cached)
	}

	a.pkgCache.Set(pattern, pkgs, cfg)

	return pkgs, nil
}

// absolutePatternRoot returns the filesystem directory an absolute package
// pattern is rooted at, or "" for relative patterns (which the go command
// already resolves against the process working directory). Setting
// packages.Config.Dir makes the spawned `go list` run in the TARGET
// directory, so go.work discovery starts there instead of at the process
// cwd. Without this, an ambient workspace (a go.work above the cwd, or
// GOWORK set in the environment) rejects absolute out-of-workspace
// patterns with "directory prefix ... does not contain modules listed in
// go.work" — the analysis then reports package errors for code that
// compiles fine in its own module.
func absolutePatternRoot(pkgPath string) string {
	if !filepath.IsAbs(pkgPath) {
		return ""
	}

	if idx := strings.Index(pkgPath, "/..."); idx > 0 {
		return pkgPath[:idx]
	}

	return pkgPath
}

// sanitizedTargetEnv returns the current environment adjusted for running
// `go list` inside a target directory (packages.Config.Dir set from an
// absolute pattern). Two ambient settings from the caller's shell interfere
// with target-local module discovery:
//
//   - GOWORK pins workspace discovery to the caller's workspace, so it is
//     dropped; the go command then discovers go.work from the target
//     directory instead.
//   - GOFLAGS entries like -mod=mod conflict with workspace mode ("-mod may
//     only be set to readonly or vendor when in workspace mode") and are
//     removed. Analysis is read-only, so the default (-mod=readonly) is
//     correct for the target.
func sanitizedTargetEnv() []string {
	env := os.Environ()

	out := make([]string, 0, len(env))
	for _, entry := range env {
		switch {
		case strings.HasPrefix(entry, "GOWORK="):
			continue
		case strings.HasPrefix(entry, "GOFLAGS="):
			out = append(out, "GOFLAGS="+dropModFlags(strings.TrimPrefix(entry, "GOFLAGS=")))
		default:
			out = append(out, entry)
		}
	}

	return out
}

// dropModFlags removes -mod[=value] entries from a GOFLAGS value.
func dropModFlags(goflags string) string {
	var kept []string

	for flag := range strings.FieldsSeq(goflags) {
		if flag == "-mod" || strings.HasPrefix(flag, "-mod=") {
			continue
		}

		kept = append(kept, flag)
	}

	return strings.Join(kept, " ")
}

// analyzeSinglePackage analyzes a single loaded package
// Note: File-level analysis is sequential because token.FileSet is not thread-safe.
// Parallelism is achieved at the package level via AnalyzePackage's errgroup.
func (a *MainAnalyzer) analyzeSinglePackage(ctx context.Context, pkg *packages.Package) *types.ErrorGraph {
	graph := newErrorGraph(pkg.Name)
	graph.PackagesScanned = 1

	sharedFileCache := astanalyzer.NewFileCache()

	// Pre-collect function signatures from ALL files in the package so that
	// cross-file calls (helper in file A called from file B) are correctly
	// resolved by the blank-identifier check in default mode.
	pkgSigs := astanalyzer.CollectFuncSigs(pkg.Syntax)

	// Pre-collect package-level error variable names from ALL files so that
	// inline wrap/check sites in file A referencing a sentinel declared in
	// file B are attributed to the named error.
	pkgErrorDecls := astanalyzer.CollectErrorDecls(pkg.Syntax)

	// Build type resolver if type info is available from the loaded package.
	var typeResolver *astanalyzer.TypeResolver
	if a.typeInfoEnabled && pkg.TypesInfo != nil && pkg.Types != nil {
		typeResolver = astanalyzer.NewTypeResolver(pkg.TypesInfo, pkg.Types)
	}

	for _, file := range pkg.Syntax {
		filePath := a.fset.File(file.Pos()).Name()

		if a.isGeneratedFile(filePath) {
			continue
		}

		// Package mode must honor --exclude the same way the directory-walk
		// mode does; without this check, exclusions were silently ignored
		// whenever type-aware analysis promoted the target to package mode.
		if a.isExcluded(filePath) {
			continue
		}

		hooks.Notify(ctx, hooks.HookPreFile, &hooks.PreFileData{FilePath: filePath})

		opts := []astanalyzer.AnalyzerOption{
			astanalyzer.WithFileCache(sharedFileCache),
			astanalyzer.WithPackageSigs(pkgSigs),
			astanalyzer.WithPackageErrorDecls(pkgErrorDecls),
		}
		if typeResolver != nil {
			opts = append(opts, astanalyzer.WithTypeResolver(typeResolver))
		}

		if a.enforceErrorFamily {
			opts = append(opts, astanalyzer.WithEnforceErrorFamily(true))
		}

		if a.enforceSamberOops {
			opts = append(opts, astanalyzer.WithEnforceSamberOops(true))
		}

		if a.enforceGenericReturn {
			opts = append(opts, astanalyzer.WithEnforceGenericReturn(true))
		}

		if a.enforceDeferredClose {
			opts = append(opts, astanalyzer.WithEnforceDeferredClose(true))
		}

		if a.enforceCodedErrors {
			opts = append(opts, astanalyzer.WithEnforceCodedErrors(true))
		}

		if a.noSuppress {
			opts = append(opts, astanalyzer.WithNoSuppress(true))
		}

		opts = append(opts, astanalyzer.WithCtx(ctx))

		analyzer := astanalyzer.NewAnalyzer(a.fset, pkg.Name, filepath.Base(filePath), opts...)
		fileGraph := analyzer.Analyze(file)
		fileGraph.FilesScanned = 1

		hooks.Notify(ctx, hooks.HookPostFile, &hooks.PostFileData{
			FilePath: filePath,
			Error:    nil,
		})

		mergeGraph(graph, fileGraph)
	}

	// Run the legacyerrors analyzer for type-aware detection of errors.As/Is.
	// Requires type information; skipped when type info is unavailable.
	if a.typeInfoEnabled && pkg.TypesInfo != nil && pkg.Types != nil {
		legacyViolations := runLegacyAnalyzer(pkg, a.fset)
		graph.Violations = append(graph.Violations, legacyViolations...)
	}

	return graph
}
