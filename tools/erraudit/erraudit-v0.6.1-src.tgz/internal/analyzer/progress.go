package analyzer

import (
	"fmt"
	"io"
	"os"
	"sync"
	"time"
)

// ProgressFunc receives analysis progress notifications. done counts units
// (files in directory mode, packages in package mode) completed out of
// total; unit names the just-finished file or package path. Invoked
// concurrently from analysis goroutines; implementations must be
// goroutine-safe.
type ProgressFunc func(done, total int, unit string)

// ProgressPrinter renders analysis progress as in-place updates on a
// terminal. On terminals it rewrites one line via carriage returns,
// throttled to avoid flicker; on non-terminals (pipes, CI logs) it stays
// silent except for the final summary, keeping captured output clean.
type ProgressPrinter struct {
	w          io.Writer
	tty        bool
	mu         sync.Mutex
	done       int
	total      int
	started    bool
	start      time.Time
	lastRender time.Time
}

// NewProgressPrinter creates a printer for w. Pass os.Stderr from the CLI.
func NewProgressPrinter(w io.Writer) *ProgressPrinter {
	return &ProgressPrinter{ //nolint:exhaustruct_v5 // zero-value fields are the intended initial state
		w:   w,
		tty: isTerminalWriter(w),
	}
}

// newProgressPrinterWithTTY creates a printer with an explicit terminal
// flag. Tests use it to exercise the in-place update path without a real TTY.
func newProgressPrinterWithTTY(w io.Writer, tty bool) *ProgressPrinter {
	return &ProgressPrinter{ //nolint:exhaustruct_v5 // zero-value fields are the intended initial state
		w:   w,
		tty: tty,
	}
}

// Record consumes one progress notification.
func (p *ProgressPrinter) Record(done, total int, unit string) {
	p.mu.Lock()
	defer p.mu.Unlock()

	if !p.started {
		p.started = true
		p.start = time.Now()
	}

	p.done = done
	p.total = total

	if !p.tty {
		return
	}

	// Throttle redraws; always draw the first and the final unit.
	if done != total && time.Since(p.lastRender) < 100*time.Millisecond {
		return
	}

	p.lastRender = time.Now()

	elapsed := time.Since(p.start).Round(time.Second)
	if elapsed > 0 {
		fmt.Fprintf(p.w, "\rerraudit: analyzing %d/%d (elapsed %s)", done, total, elapsed)
	} else {
		fmt.Fprintf(p.w, "\rerraudit: analyzing %d/%d", done, total)
	}
}

// Finish writes the final progress line. On non-terminals it emits a single
// summary line; on terminals it completes the in-place updates with a
// newline so subsequent output starts on a fresh line.
func (p *ProgressPrinter) Finish() {
	p.mu.Lock()
	defer p.mu.Unlock()

	if !p.started {
		return
	}

	elapsed := time.Since(p.start).Round(time.Millisecond)

	if p.tty {
		fmt.Fprintf(p.w, "\rerraudit: analyzed %d/%d in %s\n", p.done, p.total, elapsed)

		return
	}

	fmt.Fprintf(p.w, "erraudit: analyzed %d %s in %s\n",
		p.done, progressUnitNoun(p.total), elapsed)
}

// progressUnitNoun returns "file(s)" or "package(s)" depending on the total
// being 1.
func progressUnitNoun(total int) string {
	if total == 1 {
		return "unit"
	}

	return "units"
}

// isTerminalWriter reports whether w is an interactive terminal.
func isTerminalWriter(w io.Writer) bool {
	f, ok := w.(*os.File)
	if !ok {
		return false
	}

	info, err := f.Stat()
	if err != nil {
		return false
	}

	return info.Mode()&os.ModeCharDevice != 0
}
