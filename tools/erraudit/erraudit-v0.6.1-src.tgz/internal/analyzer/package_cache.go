package analyzer

import (
	"os"
	"time"

	"github.com/larsartmann/erraudit/internal/cache"
	apierrors "github.com/larsartmann/erraudit/pkg/errors"
	"golang.org/x/tools/go/packages"
)

const (
	// DefaultMaxCachedPackages is the default maximum number of packages to cache.
	DefaultMaxCachedPackages = 100

	// DefaultMaxPackageCacheSizeBytes is the default maximum cache size (500MB).
	DefaultMaxPackageCacheSizeBytes = 500 * 1024 * 1024

	pkgSyntaxWeight = 10000 // weight per parsed syntax tree for cache accounting
	pkgFileWeight   = 5000  // weight per Go file for cache accounting
)

// PackageCacheEntry holds a cached package and its metadata.
type PackageCacheEntry struct {
	Pkgs        []*packages.Package
	LoadTime    time.Time
	FileModTime time.Time
	Size        int64
}

// PackageCache caches loaded packages to avoid repeated packages.Load calls.
// The cache is bounded by both package count and total estimated size.
type PackageCache struct {
	cache.Base[PackageCacheEntry]

	ttl         time.Duration
	maxPackages int
	maxSize     int64
}

// PackageCacheOption is a functional option for configuring the PackageCache.
type PackageCacheOption func(*PackageCache)

// WithMaxPackages sets the maximum number of packages to cache.
func WithMaxPackages(maxCount int) PackageCacheOption {
	return func(c *PackageCache) {
		c.maxPackages = maxCount
	}
}

// WithMaxCacheSize sets the maximum total cache size in bytes.
func WithMaxCacheSize(maxCacheSize int64) PackageCacheOption {
	return func(c *PackageCache) {
		c.maxSize = maxCacheSize
	}
}

// NewPackageCache creates a new package cache with the specified TTL.
func NewPackageCache(ttl time.Duration, opts ...PackageCacheOption) *PackageCache {
	c := &PackageCache{
		ttl:         ttl,
		maxPackages: DefaultMaxCachedPackages,
		maxSize:     DefaultMaxPackageCacheSizeBytes,
	}

	for _, opt := range opts {
		opt(c)
	}

	c.InitWithSizeTracking(c.maxPackages, func(e PackageCacheEntry) int64 { return e.Size })

	return c
}

// Get retrieves cached packages if they exist and are still valid.
func (c *PackageCache) Get(pkgPath string, cfg *packages.Config) ([]*packages.Package, bool) {
	entry, ok := c.Store().GetIfPresent(pkgPath)
	if !ok {
		return nil, false
	}

	// Check TTL
	if time.Since(entry.LoadTime) > c.ttl {
		return nil, false
	}

	// Check if source files have been modified
	if cfg.Dir != "" {
		if modTime, err := getDirModTime(cfg.Dir); err == nil && modTime.After(entry.FileModTime) {
			return nil, false
		}
	}

	return entry.Pkgs, true
}

// Set stores packages in the cache.
func (c *PackageCache) Set(pkgPath string, pkgs []*packages.Package, cfg *packages.Config) {
	size := estimatePackageSize(pkgs)

	if size > c.maxSize {
		return
	}

	if c.TotalSize()+size > c.maxSize {
		return
	}

	modTime := getModTimeFromConfig(cfg)

	c.Store().Set(pkgPath, PackageCacheEntry{
		Pkgs:        pkgs,
		LoadTime:    time.Now(),
		FileModTime: modTime,
		Size:        size,
	})
	c.AddSize(size)
	c.Store().CleanUp()
}

// Clear removes all entries from the cache.
func (c *PackageCache) Clear() {
	c.Base.Clear()
}

// Stats returns cache statistics.
func (c *PackageCache) Stats() PackageCacheStats {
	base := c.Base.Stats()

	return PackageCacheStats{
		BaseStats:       base,
		MaxPackages:     c.maxPackages,
		MaxSize:         c.maxSize,
		UtilizationSize: float64(base.TotalSize) / float64(c.maxSize),
		UtilizationPkgs: float64(base.KeyCount) / float64(c.maxPackages),
	}
}

// PackageCacheStats contains cache statistics.
type PackageCacheStats struct {
	cache.BaseStats

	MaxPackages     int
	MaxSize         int64
	UtilizationSize float64
	UtilizationPkgs float64
}

// estimatePackageSize estimates the memory size of packages.
func estimatePackageSize(pkgs []*packages.Package) int64 {
	var total int64

	for _, pkg := range pkgs {
		if pkg == nil {
			continue
		}

		total += int64(len(pkg.Syntax)) * pkgSyntaxWeight
		total += int64(len(pkg.GoFiles)) * pkgFileWeight

		for _, file := range pkg.Syntax {
			total += int64(file.End() - file.Pos())
		}
	}

	return total
}

// getModTimeFromConfig returns the modification time from the config's directory.
// Returns time.Time{} if the directory is not set or if there's an error.
func getModTimeFromConfig(cfg *packages.Config) time.Time {
	if cfg.Dir == "" {
		return time.Time{}
	}

	modTime, err := getDirModTime(cfg.Dir)
	if err != nil {
		return time.Time{}
	}

	return modTime
}

// getDirModTime returns the most recent modification time of Go files in a directory.
func getDirModTime(dir string) (time.Time, error) {
	entries, err := os.ReadDir(dir)
	if err != nil {
		return time.Time{}, apierrors.Wrap(err, "failed to read directory %s", dir)
	}

	var latest time.Time

	for _, entry := range entries {
		if !entry.IsDir() {
			info, err := entry.Info()
			if err != nil { //nolint:erraudit // best-effort mtime scan; entry already validated by ReadDir
				continue
			}

			if info.ModTime().After(latest) {
				latest = info.ModTime()
			}
		}
	}

	return latest, nil
}
