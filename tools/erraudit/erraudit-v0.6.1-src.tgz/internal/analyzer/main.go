package analyzer

import (
	"go/token"
	"sync"
	"time"

	"github.com/LarsArtmann/gogenfilter/v3"
	apierrors "github.com/larsartmann/erraudit/pkg/errors"
	"github.com/larsartmann/erraudit/pkg/types"
)

// MainAnalyzer performs comprehensive error analysis.
type MainAnalyzer struct {
	fset                 *token.FileSet
	excludedPaths        []string
	pkgCache             *PackageCache
	maxConcurrentFiles   int        // maximum number of files to analyze concurrently (0 = GOMAXPROCS)
	mu                   sync.Mutex // protects graph merging during concurrent analysis
	genFilter            *gogenfilter.Filter
	typeInfoEnabled      bool         // enable go/types integration for type-aware detection
	enforceErrorFamily   bool         // opt-in: flag stdlib error constructors as violations
	enforceSamberOops    bool         // opt-in: flag stdlib constructors + oops anti-patterns
	enforceGenericReturn bool         // opt-in: flag functions returning bare error interface
	enforceDeferredClose bool         // opt-in: flag defer x.Close() patterns
	enforceCodedErrors   bool         // opt-in: flag empty-code errorfamily constructors
	noSuppress           bool         // bypass AST-level false-positive heuristics (--no-suppress)
	progress             ProgressFunc // optional progress notifications (--progress)

	// dirErrorDecls holds package-level error declarations per directory,
	// collected by AnalyzeDirectory before the concurrent per-file walk so
	// AnalyzeFile can attribute inline references to errors declared in
	// SIBLING files of the same directory (package mode gets the same union
	// from go/packages syntax). Written once before the walk, read-only
	// afterwards — no mutex needed. Nil for standalone AnalyzeFile calls.
	dirErrorDecls map[string]map[string]bool
}

// MainAnalyzerOption is a functional option for configuring MainAnalyzer.
type MainAnalyzerOption func(*MainAnalyzer)

// WithPackageCache enables package caching with the specified TTL.
func WithPackageCache(ttl time.Duration) MainAnalyzerOption {
	return func(a *MainAnalyzer) {
		a.pkgCache = NewPackageCache(ttl)
	}
}

// WithExclusions sets the excluded paths for the analyzer.
func WithExclusions(excludedPaths []string) MainAnalyzerOption {
	return func(a *MainAnalyzer) {
		a.excludedPaths = excludedPaths
	}
}

// WithMaxConcurrentFiles sets the maximum number of files to analyze concurrently.
func WithMaxConcurrentFiles(maxCount int) MainAnalyzerOption {
	return func(a *MainAnalyzer) {
		a.maxConcurrentFiles = maxCount
	}
}

// WithTypeInfo enables go/types integration for type-aware violation detection.
// When enabled, the analyzer resolves return types to distinguish actual error
// returns from non-error returns, eliminating false positives on blank-identifier
// assignments (e.g., "_, _ = fmt.Fprint(f, msg)" will not be flagged).
func WithTypeInfo(enabled bool) MainAnalyzerOption {
	return func(a *MainAnalyzer) {
		a.typeInfoEnabled = enabled
	}
}

// WithEnforceErrorFamily enables the opt-in policy that flags stdlib error
// constructors (errors.New, fmt.Errorf, errors.Join) as violations. Use when
// the project enforces go-error-family as its error construction standard.
func WithEnforceErrorFamily(enabled bool) MainAnalyzerOption {
	return func(a *MainAnalyzer) {
		a.enforceErrorFamily = enabled
	}
}

// WithEnforceSamberOops enables the opt-in policy that flags stdlib error
// constructors as violations when the project enforces samber/oops. Also
// enables oops-specific anti-pattern detection (redundant nil guards before
// oops.Wrap/Wrapf).
func WithEnforceSamberOops(enabled bool) MainAnalyzerOption {
	return func(a *MainAnalyzer) {
		a.enforceSamberOops = enabled
	}
}

// WithEnforceGenericReturn enables the opt-in policy that flags functions
// returning bare error interface instead of a specific error type. Default:
// false — returning error is standard Go practice.
func WithEnforceGenericReturn(enabled bool) MainAnalyzerOption {
	return func(a *MainAnalyzer) {
		a.enforceGenericReturn = enabled
	}
}

// WithEnforceDeferredClose enables the opt-in policy that flags
// defer x.Close() patterns where the Close return value is ignored.
// Default: false — defer file.Close() is standard Go practice.
func WithEnforceDeferredClose(enabled bool) MainAnalyzerOption {
	return func(a *MainAnalyzer) {
		a.enforceDeferredClose = enabled
	}
}

// WithEnforceCodedErrors enables the opt-in policy that flags go-error-family
// constructor calls with an empty ("") error code. Empty-code errors lose
// their What/Why/Fix template at the CLI boundary. Default: false.
func WithEnforceCodedErrors(enabled bool) MainAnalyzerOption {
	return func(a *MainAnalyzer) {
		a.enforceCodedErrors = enabled
	}
}

// WithNoSuppress bypasses AST-level false-positive heuristics in the underlying
// AST analyzers so that all potential violations are reported. Corresponds to
// the --no-suppress CLI flag.
func WithNoSuppress(enabled bool) MainAnalyzerOption {
	return func(a *MainAnalyzer) {
		a.noSuppress = enabled
	}
}

// WithProgress installs a progress callback invoked after each analyzed unit
// (file in directory mode, package in package mode). Corresponds to the
// --progress CLI flag; nil (the default) disables notifications.
func WithProgress(fn ProgressFunc) MainAnalyzerOption {
	return func(a *MainAnalyzer) {
		a.progress = fn
	}
}

// NewMainAnalyzer creates a new main analyzer.
func NewMainAnalyzer() *MainAnalyzer {
	fset := token.NewFileSet()

	genFilter, _ := newGeneratedFileFilter() //nolint:erraudit // fallback to nil filter on error

	return &MainAnalyzer{
		fset:               fset,
		excludedPaths:      []string{},
		pkgCache:           nil, // caching disabled by default
		maxConcurrentFiles: 0,   // 0 means use GOMAXPROCS
		genFilter:          genFilter,
	}
}

// NewMainAnalyzerWithOptions creates a new main analyzer with functional options.
func NewMainAnalyzerWithOptions(opts ...MainAnalyzerOption) *MainAnalyzer {
	a := NewMainAnalyzer()
	//art-dupl:accept standard Go functional-options idiom — 3-line loop, unrelated packages, different option types
	for _, opt := range opts {
		opt(a)
	}

	return a
}

// NewMainAnalyzerWithExclusions creates a new main analyzer with excluded paths.
func NewMainAnalyzerWithExclusions(excludedPaths []string) *MainAnalyzer {
	analyzer := NewMainAnalyzer()
	analyzer.excludedPaths = excludedPaths

	return analyzer
}

// newErrorGraph creates a new empty ErrorGraph with the given package path.
func newErrorGraph(packagePath string) *types.ErrorGraph {
	return &types.ErrorGraph{
		Package:    packagePath,
		Errors:     make([]types.ErrorInfo, 0),
		Violations: make([]types.ErrorViolation, 0),
		Metrics: types.ErrorMetrics{
			MostCommonErrors: make(map[string]uint),
		},
	}
}

// newGeneratedFileFilter creates a gogenfilter Filter for detecting generated files.
func newGeneratedFileFilter() (*gogenfilter.Filter, error) {
	opts, err := gogenfilter.WithFilterOptions(gogenfilter.FilterAll)
	if err != nil {
		return nil, apierrors.Wrap(err, "creating filter options")
	}

	filter, err := gogenfilter.NewFilter(opts)
	if err != nil {
		return nil, apierrors.Wrap(err, "creating file filter")
	}

	return filter, nil
}

// isGeneratedFile checks if a file is auto-generated using gogenfilter.
func (a *MainAnalyzer) isGeneratedFile(path string) bool {
	if a.genFilter == nil {
		return false
	}

	filtered, err := a.genFilter.Filter(path)
	if err != nil {
		return false
	}

	return filtered
}
