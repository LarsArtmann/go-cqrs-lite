package analyzer

import (
	"go/ast"
	"go/token"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"golang.org/x/tools/go/analysis"
	"golang.org/x/tools/go/packages"
)

func TestConvertLegacyDiagnostic(t *testing.T) {
	fset := token.NewFileSet()
	f := fset.AddFile("test.go", -1, 100)
	f.SetLines([]int{0, 20, 40})

	t.Run("converts diagnostic with suggestion", func(t *testing.T) {
		diag := analysis.Diagnostic{
			Pos:     f.Pos(10),
			End:     f.Pos(18),
			Message: "use errors.AsType instead of errors.As",
			SuggestedFixes: []analysis.SuggestedFix{{
				Message:   "Replace with errors.AsType[*MyError](err)",
				TextEdits: []analysis.TextEdit{{Pos: f.Pos(10), End: f.Pos(18), NewText: []byte("new")}},
			}},
			Category: "legacyerrors",
		}

		v := convertLegacyDiagnostic(diag, fset)

		if v.Type != types.ErrorTypeLegacyAs {
			t.Errorf("expected type %q, got %q", types.ErrorTypeLegacyAs, v.Type)
		}
		if v.Severity != types.SeverityMedium {
			t.Errorf("expected severity %q, got %q", types.SeverityMedium, v.Severity)
		}
		if v.Message != diag.Message {
			t.Errorf("expected message %q, got %q", diag.Message, v.Message)
		}
		if v.Suggestion != "Replace with errors.AsType[*MyError](err)" {
			t.Errorf("expected suggestion %q, got %q", "Replace with errors.AsType[*MyError](err)", v.Suggestion)
		}
		if v.Position.Filename != "test.go" {
			t.Errorf("expected filename %q, got %q", "test.go", v.Position.Filename)
		}
		if v.Confidence.Float() != 0.70 {
			t.Errorf("expected confidence 0.70, got %v", v.Confidence.Float())
		}
		if v.ErrorName != "" {
			t.Errorf("expected empty ErrorName, got %q", v.ErrorName)
		}
	})

	t.Run("converts diagnostic without suggestion", func(t *testing.T) {
		diag := analysis.Diagnostic{
			Pos:     f.Pos(10),
			End:     f.Pos(18),
			Message: "consider using errors.AsType instead of errors.Is",
			SuggestedFixes: []analysis.SuggestedFix{{
				Message:   "",
				TextEdits: nil,
			}},
		}

		v := convertLegacyDiagnostic(diag, fset)

		if v.Suggestion != "" {
			t.Errorf("expected empty suggestion, got %q", v.Suggestion)
		}
	})

	t.Run("converts diagnostic with empty SuggestedFixes", func(t *testing.T) {
		diag := analysis.Diagnostic{
			Pos:     f.Pos(10),
			End:     f.Pos(18),
			Message: "legacy error usage",
		}

		v := convertLegacyDiagnostic(diag, fset)

		if v.Suggestion != "" {
			t.Errorf("expected empty suggestion, got %q", v.Suggestion)
		}
	})

	t.Run("produces valid violation", func(t *testing.T) {
		diag := analysis.Diagnostic{
			Pos:     f.Pos(10),
			End:     f.Pos(18),
			Message: "use errors.AsType instead of errors.As",
			SuggestedFixes: []analysis.SuggestedFix{{
				Message: "Replace with errors.AsType",
			}},
		}

		v := convertLegacyDiagnostic(diag, fset)

		if !v.IsValid() {
			t.Error("expected violation to be valid")
		}
	})
}

func TestRunLegacyAnalyzer_NilInputs(t *testing.T) {
	fset := token.NewFileSet()

	t.Run("nil package returns nil", func(t *testing.T) {
		result := runLegacyAnalyzer(nil, fset)
		if result != nil {
			t.Errorf("expected nil, got %d violations", len(result))
		}
	})

	t.Run("empty syntax returns nil", func(t *testing.T) {
		pkg := &packages.Package{}
		result := runLegacyAnalyzer(pkg, fset)
		if result != nil {
			t.Errorf("expected nil, got %d violations", len(result))
		}
	})

	t.Run("nil types returns nil", func(t *testing.T) {
		pkg := &packages.Package{
			Syntax: []*ast.File{},
		}
		result := runLegacyAnalyzer(pkg, fset)
		if result != nil {
			t.Errorf("expected nil, got %d violations", len(result))
		}
	})
}

func TestRunLegacyAnalyzer_Integration(t *testing.T) {
	if testing.Short() {
		t.Skip("skipping integration test in short mode")
	}

	t.Run("detects errors.As in real package", func(t *testing.T) {
		tmpDir := t.TempDir()

		goMod := `module legacytest

go 1.26
`
		if err := os.WriteFile(filepath.Join(tmpDir, "go.mod"), []byte(goMod), 0o644); err != nil {
			t.Fatalf("failed to write go.mod: %v", err)
		}

		code := `package main

import "errors"

type CustomError struct{ msg string }

func (e *CustomError) Error() string { return e.msg }

func process(err error) bool {
	var customErr *CustomError
	if errors.As(err, &customErr) {
		return true
	}
	return false
}
`
		if err := os.WriteFile(filepath.Join(tmpDir, "main.go"), []byte(code), 0o644); err != nil {
			t.Fatalf("failed to write main.go: %v", err)
		}

		cfg := &packages.Config{
			Mode: packages.NeedName | packages.NeedFiles | packages.NeedSyntax | packages.NeedTypes | packages.NeedTypesInfo,
			Dir:  tmpDir,
		}

		pkgs, err := packages.Load(cfg, "./...")
		if err != nil {
			t.Fatalf("failed to load package: %v", err)
		}

		if len(pkgs) == 0 {
			t.Fatal("no packages loaded")
		}

		pkg := pkgs[0]
		if len(pkg.Errors) > 0 {
			t.Fatalf("package has errors: %v", pkg.Errors)
		}

		fset := token.NewFileSet()
		violations := runLegacyAnalyzer(pkg, fset)

		if len(violations) == 0 {
			t.Fatal("expected violations, got none")
		}

		foundLegacyAs := false
		for _, v := range violations {
			if v.Type == types.ErrorTypeLegacyAs {
				foundLegacyAs = true
				if v.Severity != types.SeverityMedium {
					t.Errorf("expected severity medium, got %q", v.Severity)
				}
				if !strings.Contains(v.Suggestion, "errors.AsType") {
					t.Errorf("expected suggestion to contain 'errors.AsType', got %q", v.Suggestion)
				}
			}
		}
		if !foundLegacyAs {
			t.Fatalf("expected at least one legacy_as violation, got %v", violations)
		}
	})
}
