package analyzer

import (
	"context"
	"go/parser"
	"go/token"
	"path/filepath"

	astanalyzer "github.com/larsartmann/erraudit/internal/ast"
	apierrors "github.com/larsartmann/erraudit/pkg/errors"
	"github.com/larsartmann/erraudit/pkg/types"
)

// AnalyzeFile analyzes a single Go file
// Note: Creates its own FileSet for thread safety during concurrent analysis.
func (a *MainAnalyzer) AnalyzeFile(
	ctx context.Context,
	filePath string,
) (*types.ErrorGraph, error) {
	// Check for context cancellation
	select {
	case <-ctx.Done():
		return nil, apierrors.Wrap(ctx.Err(), "context cancelled while analyzing file %s", filePath)
	default:
		// Continue
	}

	// Create a new FileSet for this file to ensure thread safety
	// during concurrent analysis (parser.ParseFile modifies the FileSet)
	fset := token.NewFileSet()

	// Parse file
	node, err := parser.ParseFile(fset, filePath, nil, parser.AllErrors|parser.ParseComments)
	if err != nil {
		return nil, apierrors.Wrap(err, "failed to parse file %s", filePath)
	}

	// Extract package name
	pkgName := node.Name.Name

	// Create AST analyzer for this file (local variable, not stored on struct)
	var opts []astanalyzer.AnalyzerOption
	if a.enforceErrorFamily {
		opts = append(opts, astanalyzer.WithEnforceErrorFamily(true))
	}

	if a.enforceSamberOops {
		opts = append(opts, astanalyzer.WithEnforceSamberOops(true))
	}

	if a.enforceGenericReturn {
		opts = append(opts, astanalyzer.WithEnforceGenericReturn(true))
	}

	if a.enforceDeferredClose {
		opts = append(opts, astanalyzer.WithEnforceDeferredClose(true))
	}

	if a.enforceCodedErrors {
		opts = append(opts, astanalyzer.WithEnforceCodedErrors(true))
	}

	if a.noSuppress {
		opts = append(opts, astanalyzer.WithNoSuppress(true))
	}

	opts = append(opts, astanalyzer.WithCtx(ctx))

	if decls := a.dirErrorDecls[filepath.Dir(filePath)]; len(decls) > 0 {
		opts = append(opts, astanalyzer.WithPackageErrorDecls(decls))
	}

	astAnalyzer := astanalyzer.NewAnalyzer(fset, pkgName, filepath.Base(filePath), opts...)

	// Run AST analysis
	graph := astAnalyzer.Analyze(node)
	graph.Package = pkgName
	graph.FilesScanned = 1

	return graph, nil
}
