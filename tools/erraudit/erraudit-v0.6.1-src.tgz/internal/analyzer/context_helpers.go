package analyzer

import (
	"context"

	apierrors "github.com/larsartmann/erraudit/pkg/errors"
)

// checkContextCancellation checks if the context is cancelled and returns the error if so.
// This is a common pattern used in errgroup goroutines to check for early cancellation.
func checkContextCancellation(ctx context.Context) error {
	select {
	case <-ctx.Done():
		if err := ctx.Err(); err != nil {
			return apierrors.Wrap(err, "context cancelled")
		}

		return nil
	default:
		return nil
	}
}
