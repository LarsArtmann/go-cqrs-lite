package analyzer

import (
	"go/ast"
	"go/parser"
	"go/token"
	"path/filepath"

	astanalyzer "github.com/larsartmann/erraudit/internal/ast"
)

// collectDirectoryErrorDecls unions the package-level error declarations of
// every multi-file directory in the walk result, keyed by directory. The
// per-file analyzers in directory mode otherwise see only their own file's
// declarations, so an inline `fmt.Errorf("...: %w", ErrSibling)` referencing
// an error declared in a sibling file goes unattributed — and since the
// unreferenced annotation treats zero references as a dead-sentinel signal,
// that gap would produce false "unreferenced" claims.
//
// The pre-pass parses with SkipObjectResolution and without comments: the
// decl scan only needs top-level var/const constructor shapes, making it
// considerably cheaper than the full AnalyzeFile parse. Files that fail to
// parse here are skipped silently — the main analysis reports them.
func collectDirectoryErrorDecls(goFiles []string) map[string]map[string]bool {
	filesByDir := make(map[string][]string)

	for _, file := range goFiles {
		dir := filepath.Dir(file)
		filesByDir[dir] = append(filesByDir[dir], file)
	}

	declsByDir := make(map[string]map[string]bool, len(filesByDir))

	for dir, files := range filesByDir {
		if len(files) < 2 {
			continue
		}

		union := make(map[string]bool)

		for _, file := range files {
			fileDecls := collectFileErrorDecls(file)
			for name := range fileDecls {
				union[name] = true
			}
		}

		if len(union) > 0 {
			declsByDir[dir] = union
		}
	}

	return declsByDir
}

// collectFileErrorDecls parses one file minimally and returns its
// package-level error variable names. Empty on parse failure (the main
// analysis surfaces parse errors with full context).
func collectFileErrorDecls(path string) map[string]bool {
	fset := token.NewFileSet()

	node, err := parser.ParseFile(fset, path, nil, parser.SkipObjectResolution)
	if err != nil {
		return nil
	}

	files := []*ast.File{node}

	return astanalyzer.CollectErrorDecls(files)
}
