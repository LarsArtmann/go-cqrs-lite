package analyzer

import (
	"context"
	"fmt"
	"path/filepath"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// The linter-comparison fixture (docs/linter-comparison/fixture) is the
// evidence base for docs/linter-comparison.md's pattern matrix. This golden
// test pins erraudit's own columns row-by-row: if a detector change would
// silently invalidate a matrix cell, this test fails and the doc must be
// re-verified (or the fixture consciously updated in the same change).
//
// Line numbers refer to fixture/main.go; each entry names the matrix row it
// locks (p01…p15). Transcripts for every tool configuration live in
// docs/linter-comparison/transcripts/.
func TestLinterComparisonFixtureMatrix(t *testing.T) {
	t.Parallel()

	fixtureDir, err := filepath.Abs(filepath.Join("..", "..", "docs", "linter-comparison", "fixture"))
	require.NoError(t, err)

	type expect struct {
		line int
		rule string
	}

	set := func(entries []expect) map[string]bool {
		out := make(map[string]bool, len(entries))
		for _, e := range entries {
			out[fmt.Sprintf("%d:%s", e.line, e.rule)] = true
		}

		return out
	}

	findings := func(t *testing.T, opts ...MainAnalyzerOption) map[string]bool {
		t.Helper()

		graph, err := NewMainAnalyzerWithOptions(opts...).AnalyzePackage(
			context.Background(),
			fixtureDir+"/...",
		)
		require.NoError(t, err)
		require.NotNil(t, graph)

		out := make(map[string]bool, len(graph.Violations))
		for _, v := range graph.Violations {
			out[fmt.Sprintf("%d:%s", v.Position.Line, v.Type)] = true
		}

		return out
	}

	t.Run("default mode locks matrix rows p02 p06 p08 p11", func(t *testing.T) {
		t.Parallel()

		want := set([]expect{
			{46, "ignored"}, // p02: _ = fail()
			{68, "ignored"}, // p06: _, _ = fmt.Fprintf(...)
			{79, "ignored"}, // p08: x, _ := strconv.Atoi("1")
			{96, "ignored"}, // p11: _, _ = openStream()
		})

		assert.Equal(t, want, findings(t))
	})

	t.Run("no-suppress adds audit-only rows p05 p07", func(t *testing.T) {
		t.Parallel()

		want := set([]expect{
			{46, "ignored"}, // p02
			{63, "ignored"}, // p05: defer func(){ _ = s.Close() }() (audit-only)
			{68, "ignored"}, // p06
			{73, "ignored"}, // p07: _, n := getCount() (audit-only)
			{79, "ignored"}, // p08
			{96, "ignored"}, // p11
		})

		assert.Equal(t, want, findings(t, WithNoSuppress(true)))
	})

	t.Run("enforce-deferred-close adds row p04", func(t *testing.T) {
		t.Parallel()

		want := set([]expect{
			{46, "ignored"},                // p02
			{57, "deferred_close_ignored"}, // p04: defer s.Close() (opt-in)
			{68, "ignored"},                // p06
			{79, "ignored"},                // p08
			{96, "ignored"},                // p11
		})

		assert.Equal(t, want, findings(t, WithEnforceDeferredClose(true)))
	})
}
