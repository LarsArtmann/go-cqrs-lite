package analyzer

import (
	"context"
	"log/slog"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"sync/atomic"

	apierrors "github.com/larsartmann/erraudit/pkg/errors"
	"github.com/larsartmann/erraudit/pkg/types"
	"golang.org/x/sync/errgroup"
)

// File extension constants.
const (
	goExtension    = ".go"
	testFileSuffix = "_test.go"

	// DefaultMaxConcurrentFiles is the default maximum number of files to analyze concurrently.
	DefaultMaxConcurrentFiles = 0 // 0 means use GOMAXPROCS

	largeDirThreshold = 100 // number of Go files that triggers a progress log
)

// AnalyzeDirectory analyzes all Go files in a directory
// Uses bounded concurrency to prevent memory exhaustion on large codebases.
func (a *MainAnalyzer) AnalyzeDirectory(
	ctx context.Context,
	dirPath string,
) (*types.ErrorGraph, error) {
	// Find all Go files
	var goFiles []string

	err := filepath.Walk(dirPath, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return apierrors.Wrap(err, "failed to walk directory %s (ctx=%v)", dirPath, ctx.Err())
		}

		// Skip excluded paths
		if a.isExcluded(path) {
			if info.IsDir() {
				return filepath.SkipDir
			}

			return nil
		}

		if !info.IsDir() && strings.HasSuffix(path, goExtension) {
			if strings.HasSuffix(path, testFileSuffix) {
				return nil
			}

			if a.isGeneratedFile(path) {
				return nil
			}

			goFiles = append(goFiles, path)
		}

		return nil
	})
	if err != nil {
		return nil, apierrors.Wrap(
			err,
			"failed to walk directory %s (ctx=%v, files_found=%d)",
			dirPath,
			ctx.Err(),
			len(goFiles),
		)
	}

	// Combine results from all files using concurrent analysis
	combinedGraph := newErrorGraph(dirPath)

	// Per-directory error-decl pre-pass: lets each file's analyzer recognize
	// inline references to errors declared in sibling files (package mode
	// equivalence for the walk-based path).
	a.dirErrorDecls = collectDirectoryErrorDecls(goFiles)

	// Create errgroup with bounded concurrency
	maxWorkers := a.maxConcurrentFiles
	if maxWorkers <= 0 {
		maxWorkers = runtime.GOMAXPROCS(0)
	}

	//art-dupl:accept canonical errgroup bounded-concurrency setup, 2 lines, unrelated packages, different worker domains
	g, gctx := errgroup.WithContext(ctx)
	g.SetLimit(maxWorkers)

	var done atomic.Int64

	// Log progress for large directories
	if len(goFiles) > largeDirThreshold {
		slog.Info("analyzing large directory",
			"path", dirPath,
			"file_count", len(goFiles),
			"max_workers", maxWorkers)
	}

	for _, file := range goFiles {
		g.Go(func() error {
			if err := checkContextCancellation(gctx); err != nil {
				return err
			}

			graph, err := a.AnalyzeFile(gctx, file)
			if err != nil {
				slog.Error("failed to analyze file", "file", file, "error", err)

				return nil // Continue with other files
			}

			a.mergeGraphLocked(combinedGraph, graph)

			if a.progress != nil {
				a.progress(int(done.Add(1)), len(goFiles), file)
			}

			return nil
		})
	}

	if err := g.Wait(); err != nil {
		return nil, apierrors.Wrap(
			err,
			"failed to analyze directory %s (ctx=%v, total_files=%d)",
			dirPath,
			ctx.Err(),
			len(goFiles),
		)
	}

	a.finalizeGraph(combinedGraph)

	return combinedGraph, nil
}
