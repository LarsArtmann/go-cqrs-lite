package analyzer

import (
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestDropModFlags(t *testing.T) {
	t.Parallel()

	tests := map[string]string{
		"-mod=mod":            "",
		"-mod=mod -x":         "-x",
		"-x -mod=readonly -y": "-x -y",
		"-trimpath":           "-trimpath",
		"":                    "",
	}

	for in, want := range tests {
		assert.Equal(t, want, dropModFlags(in), "GOFLAGS %q", in)
	}
}

func TestSanitizedTargetEnv(t *testing.T) {
	t.Setenv("GOWORK", "/caller/go.work")
	t.Setenv("GOFLAGS", "-mod=mod -trimpath")

	env := sanitizedTargetEnv()

	assert.NotContains(t, env, "GOWORK=/caller/go.work", "GOWORK must be dropped for target-local discovery")

	raw, found := findEnvValue(env, "GOFLAGS")
	require.True(t, found, "GOFLAGS entry must survive sanitization")
	assert.Equal(t, "-trimpath", raw, "only -mod flags must be dropped from GOFLAGS")
}

func findEnvValue(env []string, key string) (string, bool) {
	prefix := key + "="

	for _, kv := range env {
		if after, ok := strings.CutPrefix(kv, prefix); ok {
			return after, true
		}
	}

	return "", false
}
