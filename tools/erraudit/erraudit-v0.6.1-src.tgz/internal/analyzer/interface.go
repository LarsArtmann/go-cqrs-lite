package analyzer

import (
	"context"

	"github.com/larsartmann/erraudit/pkg/types"
)

// Analyzer defines the interface for error analysis operations.
// This interface enables testability through mocking and allows
// for alternative implementations (e.g., cached, parallel, remote).
type Analyzer interface {
	// AnalyzeFile analyzes a single Go file and returns the error graph.
	AnalyzeFile(ctx context.Context, path string) (*types.ErrorGraph, error)

	// AnalyzeDirectory analyzes all Go files in a directory recursively.
	AnalyzeDirectory(ctx context.Context, dirPath string) (*types.ErrorGraph, error)

	// AnalyzePackage analyzes a Go package specified by its import path.
	// The path can include "..." to analyze all packages matching the pattern.
	AnalyzePackage(ctx context.Context, pkgPath string) (*types.ErrorGraph, error)
}

// Ensure MainAnalyzer implements the Analyzer interface.
var _ Analyzer = (*MainAnalyzer)(nil)
