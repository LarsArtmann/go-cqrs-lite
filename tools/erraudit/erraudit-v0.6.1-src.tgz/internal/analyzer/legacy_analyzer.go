package analyzer

import (
	"go/token"
	gotypes "go/types"

	"github.com/larsartmann/erraudit/pkg/lint/legacyerrors"
	"github.com/larsartmann/erraudit/pkg/types"
	"golang.org/x/tools/go/analysis"
	"golang.org/x/tools/go/analysis/passes/inspect"
	"golang.org/x/tools/go/ast/inspector"
	"golang.org/x/tools/go/packages"
)

const legacyConfidence = 0.70

// runLegacyAnalyzer runs the legacyerrors analyzer on a single package and
// converts its diagnostics to ErrorViolations.
// It requires pkg.Types and pkg.TypesInfo to be populated.
func runLegacyAnalyzer(pkg *packages.Package, fset *token.FileSet) []types.ErrorViolation {
	if pkg == nil || pkg.Types == nil || pkg.TypesInfo == nil || len(pkg.Syntax) == 0 {
		return nil
	}

	// Run inspect.Analyzer first to provide the inspector result.
	inspectPass := &analysis.Pass{
		Analyzer: inspect.Analyzer,
		Fset:     fset,
		Files:    pkg.Syntax,
		Report:   func(analysis.Diagnostic) {},
	}

	inspectorResult, err := inspect.Analyzer.Run(inspectPass)
	if err != nil {
		return nil
	}

	insp, ok := inspectorResult.(*inspector.Inspector)
	if !ok {
		return nil
	}

	// Collect diagnostics from the legacy analyzer.
	var diagnostics []analysis.Diagnostic

	legacyPass := &analysis.Pass{
		Analyzer:   legacyerrors.Analyzer,
		Fset:       fset,
		Files:      pkg.Syntax,
		Pkg:        pkg.Types,
		TypesInfo:  pkg.TypesInfo,
		TypesSizes: gotypes.SizesFor("gc", "amd64"),
		Report: func(d analysis.Diagnostic) {
			diagnostics = append(diagnostics, d)
		},
		ResultOf: map[*analysis.Analyzer]any{
			inspect.Analyzer: insp,
		},
	}

	_, _ = legacyerrors.Analyzer.Run( //nolint:erraudit // diagnostics collected via capture, return value unused
		legacyPass,
	)

	violations := make([]types.ErrorViolation, 0, len(diagnostics))

	for _, diag := range diagnostics {
		violations = append(violations, convertLegacyDiagnostic(diag, fset))
	}

	return violations
}

// convertLegacyDiagnostic converts a legacyerrors analysis.Diagnostic into a
// types.ErrorViolation. The diagnostic's Category (set by legacyerrors to
// CategoryLegacyAs or CategoryLegacyIs) drives both ErrorType and Severity
// selection so callers can distinguish real errors.As modernizations
// (SeverityMedium) from advisory errors.Is findings (SeverityLow, filterable
// via --severity-threshold error). A diagnostic missing a recognized category
// falls back to the legacy_as classification for backwards compatibility.
func convertLegacyDiagnostic(diag analysis.Diagnostic, fset *token.FileSet) types.ErrorViolation {
	suggestion := ""

	if len(diag.SuggestedFixes) > 0 {
		suggestion = diag.SuggestedFixes[0].Message
	}

	violationType, severity := classifyLegacyCategory(diag.Category)

	return types.NewErrorViolation(
		fset,
		diag.Pos,
		diag.End,
		violationType,
		severity,
		diag.Message,
		suggestion,
		"",
		types.NewConfidence(legacyConfidence),
	)
}

// classifyLegacyCategory maps a legacyerrors diagnostic Category to the
// matching (ErrorType, Severity) pair. Unknown categories default to
// (ErrorTypeLegacyAs, SeverityMedium) — the highest-precision interpretation
// — so a missing category never silently downgrades a real modernization.
func classifyLegacyCategory(category string) (types.ErrorType, types.Severity) {
	switch category {
	case legacyerrors.CategoryLegacyIs:
		return types.ErrorTypeLegacyIs, types.SeverityLow
	case legacyerrors.CategorySentinelConcreteType:
		return types.ErrorTypeSentinelConcreteType, types.SeverityMedium
	case legacyerrors.CategoryLegacyAs, "":
		return types.ErrorTypeLegacyAs, types.SeverityMedium
	default:
		return types.ErrorTypeLegacyAs, types.SeverityMedium
	}
}
