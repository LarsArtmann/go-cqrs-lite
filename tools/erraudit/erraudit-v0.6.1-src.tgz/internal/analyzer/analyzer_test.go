package analyzer

import (
	"context"
	"os"
	"path/filepath"
	"testing"
	"time"

	"github.com/larsartmann/erraudit/pkg/types"
	"golang.org/x/tools/go/packages"
)

// assertEmptyExcludedPaths is a test helper that verifies excludedPaths is empty.
func assertEmptyExcludedPaths(t *testing.T, excludedPaths []string) {
	t.Helper()

	if len(excludedPaths) != 0 {
		t.Error("expected empty excludedPaths")
	}
}

// assertTotalErrors is a test helper that verifies TotalErrors matches expected value.
func assertTotalErrors(t *testing.T, target *types.ErrorGraph, expected uint) {
	t.Helper()

	if target.Metrics.TotalErrors != expected {
		t.Errorf("expected TotalErrors=%d, got %d", expected, target.Metrics.TotalErrors)
	}
}

// assertWrapDepth is a test helper that verifies Metrics.WrapDepth matches expected value.
func assertWrapDepth(t *testing.T, target *types.ErrorGraph, expected uint) {
	t.Helper()

	if target.Metrics.WrapDepth != expected {
		t.Errorf("expected WrapDepth=%d, got %d", expected, target.Metrics.WrapDepth)
	}
}

// assertMostCommonError is a test helper that verifies an error count matches expected value.
func assertMostCommonError(t *testing.T, target *types.ErrorGraph, errorKey string, expected uint) {
	t.Helper()

	if target.Metrics.MostCommonErrors[errorKey] != expected {
		t.Errorf(
			"expected %s=%d, got %d",
			errorKey,
			expected,
			target.Metrics.MostCommonErrors[errorKey],
		)
	}
}

func TestNewMainAnalyzer(t *testing.T) {
	t.Run("creates analyzer with defaults", func(t *testing.T) {
		a := NewMainAnalyzer()
		if a == nil {
			t.Fatal("expected non-nil analyzer")
		}

		if a.fset == nil {
			t.Error("expected non-nil fset")
		}

		if a.pkgCache != nil {
			t.Error("expected nil pkgCache by default")
		}

		assertEmptyExcludedPaths(t, a.excludedPaths)
	})
}

func TestNewMainAnalyzerWithOptions(t *testing.T) {
	t.Run("applies no options", func(t *testing.T) {
		a := NewMainAnalyzerWithOptions()
		if a == nil {
			t.Fatal("expected non-nil analyzer")
		}

		if a.pkgCache != nil {
			t.Error("expected nil pkgCache without options")
		}
	})

	t.Run("applies package cache option", func(t *testing.T) {
		a := NewMainAnalyzerWithOptions(WithPackageCache(5 * time.Minute))
		if a == nil {
			t.Fatal("expected non-nil analyzer")
		}

		if a.pkgCache == nil {
			t.Error("expected non-nil pkgCache with option")
		}
	})

	t.Run("applies multiple options", func(t *testing.T) {
		a := NewMainAnalyzerWithOptions(
			WithPackageCache(5 * time.Minute),
		)
		if a.pkgCache == nil {
			t.Error("expected pkgCache to be set")
		}
	})
}

func TestNewMainAnalyzerWithExclusions(t *testing.T) {
	t.Run("creates analyzer with exclusions", func(t *testing.T) {
		exclusions := []string{"vendor", "node_modules"}

		a := NewMainAnalyzerWithExclusions(exclusions)
		if a == nil {
			t.Fatal("expected non-nil analyzer")
		}

		if len(a.excludedPaths) != 2 {
			t.Errorf("expected 2 excluded paths, got %d", len(a.excludedPaths))
		}
	})

	t.Run("creates analyzer with empty exclusions", func(t *testing.T) {
		a := NewMainAnalyzerWithExclusions([]string{})
		if a == nil {
			t.Fatal("expected non-nil analyzer")
		}

		assertEmptyExcludedPaths(t, a.excludedPaths)
	})
}

func TestIsExcluded(t *testing.T) {
	tests := []struct {
		name          string
		exclusions    []string
		path          string
		shouldExclude bool
	}{
		{
			name:          "no exclusions",
			exclusions:    []string{},
			path:          "/some/path/file.go",
			shouldExclude: false,
		},
		{
			name:          "path contains excluded string",
			exclusions:    []string{"vendor"},
			path:          "/project/vendor/package/file.go",
			shouldExclude: true,
		},
		{
			name:          "path does not contain excluded string",
			exclusions:    []string{"vendor"},
			path:          "/project/src/file.go",
			shouldExclude: false,
		},
		{
			name:          "multiple exclusions match one",
			exclusions:    []string{"vendor", "node_modules", "testdata"},
			path:          "/project/node_modules/lib/file.go",
			shouldExclude: true,
		},
		{
			name:          "partial match at start",
			exclusions:    []string{"test"},
			path:          "/test/file.go",
			shouldExclude: true,
		},
		{
			name:          "substring false positive — testdata should not match test",
			exclusions:    []string{"test"},
			path:          "/project/testdata/file.go",
			shouldExclude: false,
		},
		{
			name:          "substring false positive — testing should not match test",
			exclusions:    []string{"test"},
			path:          "/project/testing/file.go",
			shouldExclude: false,
		},
		{
			name:          "path-component match in middle",
			exclusions:    []string{"vendor"},
			path:          "/project/vendor/pkg/file.go",
			shouldExclude: true,
		},
		{
			name:          "exact match",
			exclusions:    []string{"vendor"},
			path:          "vendor",
			shouldExclude: true,
		},
		{
			name:          "suffix match",
			exclusions:    []string{"vendor"},
			path:          "/project/vendor",
			shouldExclude: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			a := NewMainAnalyzerWithExclusions(tt.exclusions)

			result := a.isExcluded(tt.path)
			if result != tt.shouldExclude {
				t.Errorf("isExcluded(%q) = %v, want %v", tt.path, result, tt.shouldExclude)
			}
		})
	}
}

func TestNewErrorGraph(t *testing.T) {
	t.Run("creates graph with package path", func(t *testing.T) {
		graph := newErrorGraph("github.com/example/pkg")
		if graph == nil {
			t.Fatal("expected non-nil graph")
		}

		if graph.Package != "github.com/example/pkg" {
			t.Errorf("expected package 'github.com/example/pkg', got %q", graph.Package)
		}
	})

	t.Run("initializes empty slices", func(t *testing.T) {
		graph := newErrorGraph("test")
		if graph.Errors == nil {
			t.Error("expected Errors to be initialized")
		}

		if graph.Violations == nil {
			t.Error("expected Violations to be initialized")
		}

		if graph.Metrics.MostCommonErrors == nil {
			t.Error("expected MostCommonErrors to be initialized")
		}

		if len(graph.Errors) != 0 {
			t.Error("expected empty Errors slice")
		}
	})

	t.Run("creates independent graphs", func(t *testing.T) {
		graph1 := newErrorGraph("pkg1")
		graph2 := newErrorGraph("pkg2")

		graph1.Errors = append(graph1.Errors, types.ErrorInfo{})
		if len(graph2.Errors) != 0 {
			t.Error("expected graph2.Errors to be independent from graph1")
		}
	})
}

func TestMergeGraph(t *testing.T) {
	t.Run("merges empty graphs", func(t *testing.T) {
		target := newErrorGraph("target")
		source := newErrorGraph("source")

		mergeGraph(target, source)

		if len(target.Errors) != 0 {
			t.Error("expected no errors after merging empty graphs")
		}
	})

	t.Run("merges errors", func(t *testing.T) {
		target := newErrorGraph("target")
		source := newErrorGraph("source")
		source.Errors = append(
			source.Errors,
			types.ErrorInfo{Message: "error1"},
			types.ErrorInfo{Message: "error2"},
		)

		mergeGraph(target, source)

		if len(target.Errors) != 2 {
			t.Errorf("expected 2 errors, got %d", len(target.Errors))
		}
	})

	t.Run("merges violations", func(t *testing.T) {
		target := newErrorGraph("target")
		source := newErrorGraph("source")
		source.Violations = append(
			source.Violations,
			types.ErrorViolation{Message: "violation1"},
		)

		mergeGraph(target, source)

		if len(target.Violations) != 1 {
			t.Errorf("expected 1 violation, got %d", len(target.Violations))
		}
	})

	t.Run("merges metrics", func(t *testing.T) {
		target := newErrorGraph("target")
		target.Metrics.TotalErrors = 5
		target.Metrics.WrapDepth = 3

		source := newErrorGraph("source")
		source.Metrics.TotalErrors = 10
		source.Metrics.WrapDepth = 7

		mergeGraph(target, source)

		assertTotalErrors(t, target, 15)
		assertWrapDepth(t, target, 7)
	})

	t.Run("merges MostCommonErrors", func(t *testing.T) {
		target := newErrorGraph("target")
		target.Metrics.MostCommonErrors["err1"] = 2
		target.Metrics.MostCommonErrors["err2"] = 1

		source := newErrorGraph("source")
		source.Metrics.MostCommonErrors["err1"] = 3
		source.Metrics.MostCommonErrors["err3"] = 5

		mergeGraph(target, source)

		assertMostCommonError(t, target, "err1", 5)
		assertMostCommonError(t, target, "err2", 1)
		assertMostCommonError(t, target, "err3", 5)
	})

	t.Run("uses max for WrapDepth", func(t *testing.T) {
		target := newErrorGraph("target")
		target.Metrics.WrapDepth = 10

		source := newErrorGraph("source")
		source.Metrics.WrapDepth = 5

		mergeGraph(target, source)

		assertWrapDepth(t, target, 10)
	})
}

func TestMergeGraphLocked(t *testing.T) {
	t.Run("is thread-safe", func(t *testing.T) {
		a := NewMainAnalyzer()
		target := newErrorGraph("target")

		done := make(chan bool)

		for range 10 {
			go func() {
				source := newErrorGraph("source")
				source.Metrics.TotalErrors = 1
				source.Errors = append(source.Errors, types.ErrorInfo{})
				a.mergeGraphLocked(target, source)

				done <- true
			}()
		}

		for range 10 {
			<-done
		}

		assertTotalErrors(t, target, 10)

		if len(target.Errors) != 10 {
			t.Errorf("expected 10 errors, got %d", len(target.Errors))
		}
	})
}

func TestMainAnalyzer_AnalyzeFile(t *testing.T) {
	t.Run("analyzes valid file", func(t *testing.T) {
		a := NewMainAnalyzer()

		testCode := `package main

import "errors"

func process() error {
	return errors.New("test error")
}
`

		tmpFile := filepath.Join(t.TempDir(), "test.go")
		if err := os.WriteFile(tmpFile, []byte(testCode), 0o644); err != nil {
			t.Fatalf("failed to create test file: %v", err)
		}

		graph, err := a.AnalyzeFile(context.Background(), tmpFile)
		if err != nil {
			t.Fatalf("AnalyzeFile failed: %v", err)
		}

		if graph == nil {
			t.Fatal("expected non-nil graph")
		}
	})

	t.Run("returns error for non-existent file", func(t *testing.T) {
		a := NewMainAnalyzer()

		_, err := a.AnalyzeFile(context.Background(), "/nonexistent/file.go")
		if err == nil {
			t.Error("expected error for non-existent file")
		}
	})

	t.Run("respects context cancellation", func(t *testing.T) {
		a := NewMainAnalyzer()

		ctx, cancel := context.WithCancel(context.Background())
		cancel()

		_, err := a.AnalyzeFile(ctx, "/some/file.go")
		if err == nil {
			t.Error("expected error due to cancelled context")
		}
	})
}

func TestMainAnalyzer_AnalyzeDirectory(t *testing.T) {
	t.Run("analyzes valid directory", func(t *testing.T) {
		a := NewMainAnalyzer()

		assertValidAnalysis(t, func(ctx context.Context, path string) (*types.ErrorGraph, error) {
			return a.AnalyzeDirectory(ctx, path)
		}, "AnalyzeDirectory")
	})

	t.Run("returns error for non-existent directory", func(t *testing.T) {
		a := NewMainAnalyzer()

		_, err := a.AnalyzeDirectory(context.Background(), "/nonexistent/dir")
		if err == nil {
			t.Error("expected error for non-existent directory")
		}
	})
}

func TestMainAnalyzer_AnalyzePackage(t *testing.T) {
	t.Run("analyzes valid package", func(t *testing.T) {
		a := NewMainAnalyzer()

		assertValidAnalysis(t, func(ctx context.Context, path string) (*types.ErrorGraph, error) {
			return a.AnalyzePackage(ctx, path)
		}, "AnalyzePackage")
	})
}

// TestAnalyzePackage_AbsoluteOutOfWorkspacePattern regression-tests
// packages.Config.Dir derivation for absolute patterns. An ambient GOWORK
// (set in the environment, or a go.work above the process cwd) must not
// reject an absolute pattern whose target lives outside that workspace:
// before the fix, `go list` ran in the process cwd, discovered the ambient
// go.work, and failed with "directory prefix ... does not contain modules
// listed in go.work"; AnalyzePackage then returned "packages contain
// errors" for code that compiles fine in its own module.
func TestAnalyzePackage_AbsoluteOutOfWorkspacePattern(t *testing.T) {
	wsDir := t.TempDir()
	writeTestFile(t, filepath.Join(wsDir, "go.work"), "go 1.26\n\nuse ./only\n")
	writeTestFile(t, filepath.Join(wsDir, "only", "go.mod"), "module example.com/only\n\ngo 1.26\n")
	writeTestFile(t, filepath.Join(wsDir, "only", "only.go"), "package only\n")

	modDir := t.TempDir()
	writeTestFile(t, filepath.Join(modDir, "go.mod"), "module example.com/conv\n\ngo 1.26\n")
	writeTestFile(t, filepath.Join(modDir, "main.go"), `package main

import "errors"

type myError struct{}

func (e *myError) Error() string { return "boom" }

func main() {
	err := error(&myError{})
	var target *myError
	if errors.As(err, &target) {
		_ = target
	}
}
`)

	t.Setenv("GOWORK", filepath.Join(wsDir, "go.work"))

	a := NewMainAnalyzerWithOptions(WithTypeInfo(true))

	graph, err := a.AnalyzePackage(context.Background(), modDir+"/...")
	if err != nil {
		t.Fatalf("AnalyzePackage on out-of-workspace absolute pattern failed: %v", err)
	}

	if graph == nil {
		t.Fatal("expected non-nil graph")
	}
}

func TestAbsolutePatternRoot(t *testing.T) {
	tests := []struct {
		pattern string
		want    string
	}{
		{"/tmp/foo/...", "/tmp/foo"},
		{"/tmp/foo", "/tmp/foo"},
		{"/tmp/foo/.../bar", "/tmp/foo"},
		{"./...", ""},
		{"github.com/foo/...", ""},
		{"../../examples", ""},
		{".", ""},
	}

	for _, tt := range tests {
		if got := absolutePatternRoot(tt.pattern); got != tt.want {
			t.Errorf("absolutePatternRoot(%q) = %q, want %q", tt.pattern, got, tt.want)
		}
	}
}

// writeTestFile writes content to path, creating parent directories.
func writeTestFile(t *testing.T, path, content string) {
	t.Helper()

	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		t.Fatal(err)
	}

	if err := os.WriteFile(path, []byte(content), 0o644); err != nil {
		t.Fatal(err)
	}
}

// assertValidAnalysis is a test helper that validates a successful analysis operation.
func assertValidAnalysis(
	t *testing.T,
	analyzeFn func(context.Context, string) (*types.ErrorGraph, error),
	methodName string,
) {
	t.Helper()

	graph, err := analyzeFn(context.Background(), "../../examples")
	if err != nil {
		t.Fatalf("%s failed: %v", methodName, err)
	}

	if graph == nil {
		t.Fatal("expected non-nil graph")
	}
}

func TestMainAnalyzer_ImplementsInterface(t *testing.T) {
	var _ Analyzer = (*MainAnalyzer)(nil)
}

func TestPackageCache(t *testing.T) {
	t.Run("NewPackageCache creates cache", func(t *testing.T) {
		cache := NewPackageCache(5 * time.Minute)
		if cache == nil {
			t.Fatal("expected non-nil cache")
		}

		if cache.ttl != 5*time.Minute {
			t.Errorf("expected ttl=5m, got %v", cache.ttl)
		}
	})

	t.Run("Get returns false for missing entry", func(t *testing.T) {
		cache := NewPackageCache(5 * time.Minute)
		cfg := &packages.Config{}

		_, found := cache.Get("nonexistent", cfg)
		if found {
			t.Error("expected false for missing entry")
		}
	})

	t.Run("Set and Get roundtrip", func(t *testing.T) {
		cache := NewPackageCache(5 * time.Minute)
		cfg := &packages.Config{Dir: t.TempDir()}
		pkgs := []*packages.Package{{Name: "test"}}

		cache.Set("testpkg", pkgs, cfg)
		got, found := cache.Get("testpkg", cfg)

		if !found {
			t.Fatal("expected to find cached entry")
		}

		if len(got) != 1 || got[0].Name != "test" {
			t.Errorf("expected package 'test', got %v", got)
		}
	})

	t.Run("Clear removes all entries", func(t *testing.T) {
		cache := NewPackageCache(5 * time.Minute)
		cfg := &packages.Config{Dir: t.TempDir()}
		pkgs := []*packages.Package{{Name: "test"}}

		cache.Set("pkg1", pkgs, cfg)
		cache.Set("pkg2", pkgs, cfg)
		cache.Clear()

		pkgNames := []string{"pkg1", "pkg2"}
		for _, name := range pkgNames {
			if _, found := cache.Get(name, cfg); found {
				t.Errorf("expected %s to be cleared", name)
			}
		}
	})

	t.Run("Get returns false after TTL expires", func(t *testing.T) {
		cache := NewPackageCache(1 * time.Nanosecond)
		cfg := &packages.Config{Dir: t.TempDir()}
		pkgs := []*packages.Package{{Name: "test"}}

		cache.Set("testpkg", pkgs, cfg)
		time.Sleep(10 * time.Millisecond)

		_, found := cache.Get("testpkg", cfg)
		if found {
			t.Error("expected false after TTL expiry")
		}
	})

	t.Run("Get with empty Dir", func(t *testing.T) {
		cache := NewPackageCache(5 * time.Minute)
		cfg := &packages.Config{Dir: ""}
		pkgs := []*packages.Package{{Name: "test"}}

		cache.Set("testpkg", pkgs, cfg)
		got, found := cache.Get("testpkg", cfg)

		if !found {
			t.Fatal("expected to find cached entry")
		}

		if len(got) != 1 {
			t.Errorf("expected 1 package, got %d", len(got))
		}
	})
}

func TestGetDirModTime(t *testing.T) {
	t.Run("returns time for valid directory", func(t *testing.T) {
		tmpDir := t.TempDir()
		// Create a file so there's something to check
		if err := os.WriteFile(
			filepath.Join(tmpDir, "test.go"),
			[]byte("package test"),
			0o644,
		); err != nil {
			t.Fatal(err)
		}

		modTime, err := getDirModTime(tmpDir)
		if err != nil {
			t.Fatalf("unexpected error: %v", err)
		}

		if modTime.IsZero() {
			t.Error("expected non-zero mod time for directory with files")
		}
	})

	t.Run("returns error for nonexistent directory", func(t *testing.T) {
		_, err := getDirModTime("/nonexistent/directory")
		if err == nil {
			t.Error("expected error for nonexistent directory")
		}
	})

	t.Run("returns latest mod time", func(t *testing.T) {
		tmpDir := t.TempDir()

		file1 := filepath.Join(tmpDir, "file1.go")
		file2 := filepath.Join(tmpDir, "file2.go")

		if err := os.WriteFile(file1, []byte("package test"), 0o644); err != nil {
			t.Fatal(err)
		}

		time.Sleep(10 * time.Millisecond)

		if err := os.WriteFile(file2, []byte("package test"), 0o644); err != nil {
			t.Fatal(err)
		}

		modTime, err := getDirModTime(tmpDir)
		if err != nil {
			t.Fatal(err)
		}

		info2, _ := os.Stat(file2)
		if !modTime.Equal(info2.ModTime()) {
			t.Errorf("expected modTime to equal file2's mod time")
		}
	})
}

func TestAnalyzePackageWithCache(t *testing.T) {
	t.Run("uses cache when available", func(t *testing.T) {
		a := NewMainAnalyzerWithOptions(WithPackageCache(5 * time.Minute))

		// First call populates cache
		graph1, err := a.AnalyzePackage(context.Background(), "../../examples")
		if err != nil {
			t.Fatalf("first call failed: %v", err)
		}

		// Second call uses cache
		graph2, err := a.AnalyzePackage(context.Background(), "../../examples")
		if err != nil {
			t.Fatalf("second call failed: %v", err)
		}

		if graph1 == nil || graph2 == nil {
			t.Fatal("expected non-nil graphs")
		}
	})
}
