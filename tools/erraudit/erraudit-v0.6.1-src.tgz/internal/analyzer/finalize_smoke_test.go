package analyzer

import (
	"context"
	"testing"
)

func TestFinalizeGraph_SmokeTestExamples(t *testing.T) {
	a := NewMainAnalyzer()
	graph, err := a.AnalyzeDirectory(context.Background(), "../../examples")
	if err != nil {
		t.Skipf("examples dir not available: %v", err)
	}
	if graph.Hierarchy == nil {
		t.Skip("no hierarchy in examples")
	}

	// Verify no duplicate relationships after cross-file finalization
	seen := map[string]int{}
	for _, rel := range graph.Hierarchy.Relationships {
		key := rel.Parent + "->" + rel.Child
		seen[key]++
		if seen[key] > 1 {
			t.Errorf("duplicate relationship %s after finalization", key)
		}
	}

	// Verify MaxDepth is reasonable
	if graph.Hierarchy.Metrics.MaxDepth > 100 {
		t.Errorf("MaxDepth %d suspiciously high (possible depth bug)",
			graph.Hierarchy.Metrics.MaxDepth)
	}

	t.Logf(
		"NamedErrors=%d Relationships=%d MaxDepth=%d DeepestError=%s RootErrors=%d",
		graph.Hierarchy.Metrics.TotalNamedErrors,
		graph.Hierarchy.Metrics.TotalRelationships,
		graph.Hierarchy.Metrics.MaxDepth,
		graph.Hierarchy.Metrics.DeepestError,
		len(graph.Hierarchy.RootErrors),
	)
}
