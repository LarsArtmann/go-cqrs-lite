package analyzer

import (
	"context"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func BenchmarkMainAnalyzer_AnalyzeFile(b *testing.B) {
	analyzer := NewMainAnalyzer()

	// Create a temporary test file
	testCode := `package main

import (
	"errors"
	"fmt"
)

func process(data string) error {
	if data == "" {
		return errors.New("empty data")
	}
	
	result, err := validate(data)
	if err != nil {
		return fmt.Errorf("validation failed: %w", err)
	}
	
	if err := save(result); err != nil {
		return fmt.Errorf("save failed: %v", err)
	}
	
	return nil
}

func validate(input string) (string, error) {
	if len(input) < 5 {
		return "", fmt.Errorf("input too short: %d", len(input))
	}
	return input, nil
}

func save(data string) error {
	if data == "invalid" {
		return errors.New("cannot save invalid data")
	}
	return nil
}
`
	// Use t.TempDir() for proper test isolation
	tmpFile := filepath.Join(b.TempDir(), "benchmark_test.go")

	err := os.WriteFile(tmpFile, []byte(testCode), 0o644)
	if err != nil {
		b.Fatalf("Failed to create test file: %v", err)
	}
	// Note: t.TempDir() handles cleanup automatically

	b.ResetTimer()
	b.ReportAllocs()

	for b.Loop() {
		_, err := analyzer.AnalyzeFile(context.Background(), tmpFile)
		if err != nil {
			b.Fatalf("Analysis failed: %v", err)
		}
	}
}

func BenchmarkMainAnalyzer_AnalyzeDirectory(b *testing.B) {
	analyzer := NewMainAnalyzer()

	// Use examples directory if it exists
	dirPath := "../../examples"

	b.ResetTimer()
	b.ReportAllocs()

	for b.Loop() {
		_, err := analyzer.AnalyzeDirectory(context.Background(), dirPath)
		if err != nil {
			b.Fatalf("Directory analysis failed: %v", err)
		}
	}
}

func BenchmarkMainAnalyzer_AnalyzePackage(b *testing.B) {
	benchmarkAnalyzePackage(b, NewMainAnalyzer())
}

// BenchmarkMainAnalyzer_AnalyzePackage_Cached tests performance with package caching enabled
// This simulates the common use case of analyzing the same package multiple times (e.g., in watch mode).
func BenchmarkMainAnalyzer_AnalyzePackage_Cached(b *testing.B) {
	benchmarkAnalyzePackage(b, NewMainAnalyzerWithOptions(WithPackageCache(5*time.Minute)))
}

// benchmarkAnalyzePackage is the shared benchmark loop for package analysis.
func benchmarkAnalyzePackage(b *testing.B, analyzer *MainAnalyzer) {
	b.ResetTimer()
	b.ReportAllocs()

	for b.Loop() {
		_, err := analyzer.AnalyzePackage(context.Background(), "../../examples")
		if err != nil {
			b.Fatalf("Package analysis failed: %v", err)
		}
	}
}
