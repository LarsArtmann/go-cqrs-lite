package analyzer

import (
	"go/token"
	"strconv"

	apierrors "github.com/larsartmann/erraudit/pkg/errors"
	"github.com/larsartmann/erraudit/pkg/lint/legacyerrors"
	"github.com/larsartmann/erraudit/pkg/types"
	"golang.org/x/tools/go/packages"
)

// LegacyerrorsResult bundles the output of RunLegacyerrorsForPatterns so
// callers (cmd/erraudit/cmd lint subcommand) get the violations,
// the shared file set (for position info), and the list of source files
// (for //nolint suppression matching) in one return value.
type LegacyerrorsResult struct {
	Violations  []types.ErrorViolation
	Fset        *token.FileSet
	SourceFiles []string
}

// RunLegacyerrorsForPatterns loads the given package patterns with full type
// information, runs the legacyerrors analyzer on each, and returns the
// aggregated violations plus the source files the violations came from.
//
// Package resolution is relative to the process working directory. For
// directory-scoped analysis (e.g. tests that must not mutate global CWD),
// use RunLegacyerrorsForDir instead.
//
// Analyzer-level //nolint suppression is disabled for the duration of this
// call: every diagnostic is reported regardless of //nolint comments. The
// caller applies suppression at the pipeline level so --no-suppress works
// as documented (show all violations, including suppressed ones).
//
// This is the entry point used by the `lint` subcommand: it produces the
// raw violation stream that the caller then filters (--severity,
// --severity-threshold, --type), suppresses (--no-suppress), and writes
// (--format, --output) using the shared pipeline helpers.
//
// Package errors are reported via packages.PrintErrors but do not abort
// the run — type-checking failures in one package shouldn't prevent
// reporting in another.
func RunLegacyerrorsForPatterns(patterns []string) (LegacyerrorsResult, error) {
	return RunLegacyerrorsForDir("", patterns)
}

// RunLegacyerrorsForDir is like RunLegacyerrorsForPatterns but resolves
// package patterns relative to dir (empty means the process working directory).
// This avoids the need for os.Chdir in callers that need directory-scoped
// analysis, making it safe for parallel test execution.
func RunLegacyerrorsForDir(dir string, patterns []string) (LegacyerrorsResult, error) {
	if len(patterns) == 0 {
		patterns = []string{"./..."}
	}

	cfg := &packages.Config{
		Dir:   dir,
		Mode:  packages.LoadSyntax,
		Tests: true,
	}

	initial, err := packages.Load(cfg, patterns...)
	if err != nil {
		return LegacyerrorsResult{}, apierrors.Wrap(err, "failed to load packages (dir=%q, patterns=%v)", dir, patterns)
	}

	// Report package-level errors but continue analysis so a broken package
	// doesn't hide findings in a healthy one. PrintErrors returns the count
	// of packages with errors (int, not error) — discarding it is fine.
	packages.PrintErrors(initial)

	// Disable analyzer-level //nolint suppression for the duration of this
	// call. The lint subcommand applies suppression at the pipeline level so
	// --no-suppress can audit the full list. The defer restores the previous
	// value so concurrent consumers (e.g. the fix command) are unaffected.
	prev := legacyerrors.DisableNolintSuppression.Load()

	legacyerrors.DisableNolintSuppression.Store(true)
	defer legacyerrors.DisableNolintSuppression.Store(prev)

	var (
		violations  []types.ErrorViolation
		sourceFiles []string
		seenFile    = map[string]struct{}{}
	)

	for _, pkg := range initial {
		if pkg == nil || len(pkg.Syntax) == 0 {
			continue
		}

		violations = append(violations, runLegacyAnalyzer(pkg, pkg.Fset)...)

		for _, goFile := range pkg.GoFiles {
			if _, seen := seenFile[goFile]; seen {
				continue
			}

			seenFile[goFile] = struct{}{}
			sourceFiles = append(sourceFiles, goFile)
		}
	}

	fset := token.NewFileSet()
	if len(initial) > 0 && initial[0] != nil {
		fset = initial[0].Fset
	}

	return LegacyerrorsResult{
		Violations:  dedupViolations(violations),
		Fset:        fset,
		SourceFiles: sourceFiles,
	}, nil
}

// dedupViolations removes duplicate violations that arise when Tests=true
// causes go/packages to return both a package and its test variant — both
// contain the same non-test source files, so the analyzer reports each
// finding in a non-test file twice. The dedup key is (filename, line, column,
// error type): two findings at the exact same position with the same rule
// are always the same finding.
func dedupViolations(violations []types.ErrorViolation) []types.ErrorViolation {
	seen := make(map[string]struct{}, len(violations))
	deduped := violations[:0]

	for _, v := range violations {
		key := v.Position.Filename + ":" +
			strconv.Itoa(v.Position.Line) + ":" +
			strconv.Itoa(v.Position.Column) + ":" +
			string(v.Type)

		if _, ok := seen[key]; ok {
			continue
		}

		seen[key] = struct{}{}

		deduped = append(deduped, v)
	}

	return deduped
}
