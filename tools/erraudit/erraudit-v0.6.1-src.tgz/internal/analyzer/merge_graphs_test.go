package analyzer

import (
	"go/token"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// TestMergeGraphs_FinalizesHierarchy pins the exported module-level merge
// entry point: it appends both graphs' data AND runs FinalizeHierarchy on the
// combined hierarchy, so cross-module relationship dedup and depth
// recomputation happen exactly as they do for per-file merges inside one
// analysis run.
func TestMergeGraphs_FinalizesHierarchy(t *testing.T) {
	t.Parallel()

	target := newErrorGraph("example.com/root")
	source := newErrorGraph("example.com/root/sub")

	rootErr := &types.ErrorNode{
		Name:     "ErrRoot",
		Kind:     types.ErrorKindSentinel,
		Depth:    0,
		Children: []*types.ErrorNode{},
	}
	leafErr := &types.ErrorNode{
		Name:     "ErrLeaf",
		Kind:     types.ErrorKindErrorf,
		Depth:    0,
		Position: token.Position{Filename: "sub/leaf.go", Line: 3},
		Children: []*types.ErrorNode{},
	}
	rootErr.Children = []*types.ErrorNode{leafErr}

	source.Hierarchy = &types.ErrorHierarchy{
		RootErrors: []*types.ErrorNode{rootErr},
		AllNodes: map[string]*types.ErrorNode{
			"ErrRoot": rootErr,
			"ErrLeaf": leafErr,
		},
		Relationships: []types.ErrorRelationship{
			{Parent: "ErrRoot", Child: "ErrLeaf", RelationshipType: types.RelationshipTypeWraps},
			{Parent: "ErrRoot", Child: "ErrLeaf", RelationshipType: types.RelationshipTypeWraps},
		},
		NamedErrors: []types.NamedError{{Name: "ErrRoot"}},
	}

	target.Violations = []types.ErrorViolation{{Type: types.ErrorTypeIgnored}}
	source.Violations = []types.ErrorViolation{{Type: types.ErrorTypeSilentSwallow}}
	target.FilesScanned = 1
	source.FilesScanned = 2

	MergeGraphs(target, source)

	require.NotNil(t, target.Hierarchy)
	assert.Len(t, target.Violations, 2)
	assert.Equal(t, 3, target.FilesScanned)
	assert.Len(
		t,
		target.Hierarchy.Relationships,
		1,
		"cross-module duplicate relationships must be deduplicated by FinalizeHierarchy",
	)
	assert.Equal(
		t,
		uint(1),
		target.Hierarchy.AllNodes["ErrLeaf"].Depth,
		"leaf depth must be recomputed from the relationship graph",
	)
}

// TestMergeGraphs_NilHierarchy proves merging graphs without hierarchies (no
// named errors discovered) stays safe — the common case for violation-only
// modules.
func TestMergeGraphs_NilHierarchy(t *testing.T) {
	t.Parallel()

	target := newErrorGraph("a")
	source := newErrorGraph("b")
	source.Violations = []types.ErrorViolation{{Type: types.ErrorTypeIgnored}}

	MergeGraphs(target, source)

	assert.Nil(t, target.Hierarchy)
	assert.Len(t, target.Violations, 1)
}
