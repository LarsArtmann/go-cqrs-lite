package analyzer

import (
	"context"
	"os"
	"path/filepath"
	"sync"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestProgressPrinter_NonTerminalEmitsSingleSummary(t *testing.T) {
	t.Parallel()

	var buf syncBuffer

	printer := newProgressPrinterWithTTY(&buf, false)
	printer.Record(1, 3, "a.go")
	printer.Record(2, 3, "b.go")
	printer.Record(3, 3, "c.go")
	printer.Finish()

	output := buf.String()

	assert.Contains(t, output, "analyzed 3 units")
	assert.NotContains(t, output, "\r", "non-terminal output must not contain in-place updates")
	assert.Equal(t, 1, len(splitLines(output)), "non-terminal output must be a single summary line")
}

func TestProgressPrinter_FinishWithoutRecordsIsNoop(t *testing.T) {
	t.Parallel()

	var buf syncBuffer

	newProgressPrinterWithTTY(&buf, true).Finish()

	assert.Empty(t, buf.String())
}

func TestProgressPrinter_TerminalReceivesUpdates(t *testing.T) {
	t.Parallel()

	var buf syncBuffer

	printer := newProgressPrinterWithTTY(&buf, true)
	printer.Record(1, 2, "a.go")
	printer.Record(2, 2, "b.go")
	printer.Finish()

	output := buf.String()

	assert.Contains(t, output, "analyzing 1/2")
	assert.Contains(t, output, "analyzed 2/2")
}

func TestWithProgress_CallbackSeesMonotonicCounts(t *testing.T) {
	t.Parallel()

	dir := t.TempDir()

	const fileCount = 4

	names := []string{"a", "b", "c", "d"}

	for _, name := range names {
		content := "package prog" + name + "\n\nvar ErrTest = errTest()\n"
		require.NoError(t, os.WriteFile(
			filepath.Join(dir, "mod"+name+".go"),
			[]byte(content), 0o644))
	}

	var (
		mu    sync.Mutex
		calls []int
	)

	analyzer := NewMainAnalyzerWithOptions(WithProgress(func(done, total int, _ string) {
		mu.Lock()
		defer mu.Unlock()

		assert.Equal(t, fileCount, total)
		calls = append(calls, done)
	}))

	graph, err := analyzer.AnalyzeDirectory(context.Background(), dir)
	require.NoError(t, err)
	require.NotNil(t, graph)

	mu.Lock()
	defer mu.Unlock()

	require.Len(t, calls, fileCount, "one callback per analyzed file")

	for i := 1; i < len(calls); i++ {
		assert.Greater(t, calls[i], calls[i-1], "counts must be strictly monotonic")
	}

	assert.Equal(t, fileCount, calls[len(calls)-1], "final callback reports the total")
}

// splitLines counts non-empty lines of s.
func splitLines(s string) []string {
	var lines []string

	start := 0

	for i := 0; i <= len(s); i++ {
		if i == len(s) || s[i] == '\n' {
			if line := s[start:i]; line != "" {
				lines = append(lines, line)
			}

			start = i + 1
		}
	}

	return lines
}

// syncBuffer is a goroutine-safe bytes buffer (progress callbacks arrive
// concurrently from analysis goroutines).
type syncBuffer struct {
	mu  sync.Mutex
	buf []byte
}

func (b *syncBuffer) Write(p []byte) (int, error) {
	b.mu.Lock()
	defer b.mu.Unlock()

	b.buf = append(b.buf, p...)

	return len(p), nil
}

func (b *syncBuffer) String() string {
	b.mu.Lock()
	defer b.mu.Unlock()

	return string(b.buf)
}
