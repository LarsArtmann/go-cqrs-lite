package fix

import (
	"go/token"
	"os"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"golang.org/x/tools/go/analysis"
)

// writeFile writes content to path with 0644 permissions.
func writeFile(path string, content []byte) error {
	return os.WriteFile(path, content, 0o644)
}

// makeFix creates a single Fix with text edits produced by buildEdits. The
// builder receives the *token.File so it can create Pos values in the same
// FileSet used by the returned Fix.
func makeFix(
	path, msg string,
	original []byte,
	buildEdits func(*token.File) []analysis.TextEdit,
) []Fix {
	fset := token.NewFileSet()
	file := fset.AddFile(path, -1, len(original))
	file.SetLinesForContent(original)

	return []Fix{{
		FilePath:  path,
		Message:   msg,
		TextEdits: buildEdits(file),
		Fset:      fset,
	}}
}

// makeFileChange constructs a single FileChange for applier tests. Reduces
// the noise of repeating the struct literal across the Write-related tests.
func makeFileChange(path string, original, modified []byte, editCount int) []FileChange {
	return []FileChange{{
		Path:      path,
		Original:  original,
		Modified:  modified,
		EditCount: editCount,
	}}
}

// editAt is a small helper to make a TextEdit at (start, end) with newText.
func editAt(file *token.File, start, end int, newText string) analysis.TextEdit {
	return analysis.TextEdit{Pos: file.Pos(start), End: file.Pos(end), NewText: []byte(newText)}
}

// makeFixFromTuples creates a Fix whose edits come from (start, end, newText)
// tuples. It removes the per-test boilerplate of declaring a callback that
// returns a slice of analysis.TextEdit.
func makeFixFromTuples(path, msg string, original []byte, edits [][3]any) []Fix {
	return makeFix(path, msg, original, func(f *token.File) []analysis.TextEdit {
		out := make([]analysis.TextEdit, len(edits))
		for i, e := range edits {
			out[i] = editAt(f, e[0].(int), e[1].(int), e[2].(string))
		}
		return out
	})
}

func TestApplier_Apply_SingleEdit(t *testing.T) {
	t.Parallel()

	// Since we need real file paths for os.ReadFile, create a temp file.
	tmpDir := t.TempDir()
	path := tmpDir + "/test.go"

	original := []byte("package main\n\nfunc main() {\n\terrors.As(err, &target)\n}\n")
	require.NoError(t, writeFile(path, original))

	fset := token.NewFileSet()
	file := fset.AddFile(path, -1, len(original))
	file.SetLinesForContent(original)

	fixes := []Fix{{
		FilePath: path,
		Message:  "fix errors.As",
		TextEdits: []analysis.TextEdit{{
			Pos:     file.Pos(28), // "errors.As(err, &target)"
			End:     file.Pos(53),
			NewText: []byte("target, _ = errors.AsType[*MyError](err)"),
		}},
		Fset: fset,
	}}

	applier := NewApplier()
	changes, err := applier.Apply(fixes)
	require.NoError(t, err)

	require.Len(t, changes, 1)
	assert.True(t, changes[0].Changed())
	assert.Equal(t, 1, changes[0].EditCount)
	assert.Contains(t, string(changes[0].Modified), "errors.AsType[*MyError](err)")
}

func TestApplier_Apply_MultipleEdits(t *testing.T) {
	t.Parallel()

	tmpDir := t.TempDir()
	path := tmpDir + "/multi.go"

	original := []byte("a b c d e f g")
	require.NoError(t, writeFile(path, original))

	fixes := makeFixFromTuples(path, "multi", original, [][3]any{
		{2, 3, "X"}, // b -> X
		{6, 7, "Y"}, // d -> Y
	})

	applier := NewApplier()
	changes, err := applier.Apply(fixes)
	require.NoError(t, err)

	require.Len(t, changes, 1)
	assert.Equal(t, "a X c Y e f g", string(changes[0].Modified))
	assert.Equal(t, 2, changes[0].EditCount)
}

func TestApplier_Apply_NoChanges(t *testing.T) {
	t.Parallel()

	tmpDir := t.TempDir()
	path := tmpDir + "/unchanged.go"

	original := []byte("package main\n")
	require.NoError(t, writeFile(path, original))

	applier := NewApplier()
	changes, err := applier.Apply(nil)
	require.NoError(t, err)

	assert.Empty(t, changes)
}

func TestApplier_Write(t *testing.T) {
	t.Parallel()

	tmpDir := t.TempDir()
	path := tmpDir + "/write.go"

	original := []byte("old content\n")
	require.NoError(t, writeFile(path, original))

	changes := makeFileChange(path, original, []byte("new content\n"), 1)

	applier := NewApplier()
	err := applier.Write(changes)
	require.NoError(t, err)

	content, err := os.ReadFile(path)
	require.NoError(t, err)
	assert.Equal(t, "new content\n", string(content))
}

func TestApplier_Write_SkipsUnchanged(t *testing.T) {
	t.Parallel()

	tmpDir := t.TempDir()
	path := tmpDir + "/unchanged.go"

	original := []byte("same\n")
	require.NoError(t, writeFile(path, original))

	changes := makeFileChange(path, original, original, 0)

	applier := NewApplier()
	err := applier.Write(changes)
	require.NoError(t, err)

	// File should not be touched.
	info, err := os.Stat(path)
	require.NoError(t, err)
	assert.Equal(t, int64(5), info.Size())
}

func TestFormatDiff(t *testing.T) {
	t.Parallel()

	changes := []FileChange{{
		Path:      "foo.go",
		Original:  []byte("a\nb\nc\n"),
		Modified:  []byte("a\nX\nc\n"),
		EditCount: 1,
	}}

	diff := FormatDiff(changes)
	assert.Contains(t, diff, "--- a/foo.go")
	assert.Contains(t, diff, "+++ b/foo.go")
	assert.Contains(t, diff, "-b")
	assert.Contains(t, diff, "+X")
}

func TestFormatDiff_Empty(t *testing.T) {
	t.Parallel()

	diff := FormatDiff(nil)
	assert.Empty(t, diff)
}

func TestApplier_Apply_OverlappingEditsRejected(t *testing.T) {
	t.Parallel()

	tmpDir := t.TempDir()
	path := tmpDir + "/overlap.go"

	original := []byte("abcdefghij")
	require.NoError(t, writeFile(path, original))

	fixes := makeFixFromTuples(path, "overlap", original, [][3]any{
		{1, 4, "XXX"}, // bcd -> XXX
		{3, 6, "YYY"}, // def -> YYY (overlaps)
	})

	applier := NewApplier()
	_, err := applier.Apply(fixes)
	require.Error(t, err)
	assert.Contains(t, err.Error(), "overlapping text edits")
}

func TestApplier_Apply_DeterministicOrder(t *testing.T) {
	t.Parallel()

	tmpDir := t.TempDir()

	pathA := tmpDir + "/a.go"
	pathB := tmpDir + "/b.go"
	pathC := tmpDir + "/c.go"

	require.NoError(t, writeFile(pathA, []byte("a")))
	require.NoError(t, writeFile(pathB, []byte("b")))
	require.NoError(t, writeFile(pathC, []byte("c")))

	fset := token.NewFileSet()
	fileA := fset.AddFile(pathA, -1, 1)
	fileA.SetLinesForContent([]byte("a"))
	fileB := fset.AddFile(pathB, -1, 1)
	fileB.SetLinesForContent([]byte("b"))
	fileC := fset.AddFile(pathC, -1, 1)
	fileC.SetLinesForContent([]byte("c"))

	fixes := []Fix{
		{
			FilePath:  pathC,
			TextEdits: []analysis.TextEdit{{Pos: fileC.Pos(0), End: fileC.Pos(1), NewText: []byte("C")}},
			Fset:      fset,
		},
		{
			FilePath:  pathA,
			TextEdits: []analysis.TextEdit{{Pos: fileA.Pos(0), End: fileA.Pos(1), NewText: []byte("A")}},
			Fset:      fset,
		},
		{
			FilePath:  pathB,
			TextEdits: []analysis.TextEdit{{Pos: fileB.Pos(0), End: fileB.Pos(1), NewText: []byte("B")}},
			Fset:      fset,
		},
	}

	applier := NewApplier()
	changes, err := applier.Apply(fixes)
	require.NoError(t, err)
	require.Len(t, changes, 3)

	paths := []string{changes[0].Path, changes[1].Path, changes[2].Path}
	assert.Equal(t, []string{pathA, pathB, pathC}, paths)
}

func TestApplier_Write_CreatesBackup(t *testing.T) {
	t.Parallel()

	tmpDir := t.TempDir()
	path := tmpDir + "/backup.go"

	original := []byte("original content\n")
	require.NoError(t, writeFile(path, original))

	changes := makeFileChange(path, original, []byte("modified content\n"), 1)

	applier := NewApplier()
	err := applier.Write(changes)
	require.NoError(t, err)

	// Modified file
	content, err := os.ReadFile(path)
	require.NoError(t, err)
	assert.Equal(t, "modified content\n", string(content))

	// Backup file
	backup, err := os.ReadFile(path + ".orig")
	require.NoError(t, err)
	assert.Equal(t, "original content\n", string(backup))
}

func TestApplier_Write_NoBackup(t *testing.T) {
	t.Parallel()

	tmpDir := t.TempDir()
	path := tmpDir + "/nobackup.go"

	original := []byte("original content\n")
	require.NoError(t, writeFile(path, original))

	changes := makeFileChange(path, original, []byte("modified content\n"), 1)

	applier := NewApplier().WithNoBackup()
	err := applier.Write(changes)
	require.NoError(t, err)

	// Modified file
	content, err := os.ReadFile(path)
	require.NoError(t, err)
	assert.Equal(t, "modified content\n", string(content))

	// No backup file
	_, err = os.Stat(path + ".orig")
	assert.True(t, os.IsNotExist(err))
}
