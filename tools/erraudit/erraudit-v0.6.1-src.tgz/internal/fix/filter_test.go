package fix

import (
	"os"
	"path/filepath"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestFilterExcluded(t *testing.T) {
	t.Parallel()

	fixes := []Fix{
		{FilePath: "foo/bar.go"},
		{FilePath: "vendor/x.go"},
		{FilePath: "baz/qux.go"},
	}

	filtered := FilterExcluded(fixes, []string{"vendor"})
	require.Len(t, filtered, 2)
	assert.Equal(t, "foo/bar.go", filtered[0].FilePath)
	assert.Equal(t, "baz/qux.go", filtered[1].FilePath)
}

func TestFilterExcluded_Empty(t *testing.T) {
	t.Parallel()

	fixes := []Fix{{FilePath: "a.go"}}
	assert.Equal(t, fixes, FilterExcluded(fixes, nil))
}

func TestIsPathExcluded(t *testing.T) {
	t.Parallel()

	assert.True(t, isPathExcluded("vendor/x.go", []string{"vendor"}))
	assert.True(t, isPathExcluded("deep/vendor/y.go", []string{"vendor"}))
	assert.True(t, isPathExcluded("foo_test.go", []string{"*_test.go"}))
	assert.False(t, isPathExcluded("main.go", []string{"vendor"}))
	assert.False(t, isPathExcluded("main.go", nil))
}

func TestContainsPathSegment(t *testing.T) {
	t.Parallel()

	assert.True(t, containsPathSegment("vendor", "vendor"))
	assert.True(t, containsPathSegment("vendor/x.go", "vendor"))
	assert.True(t, containsPathSegment("foo/vendor/bar.go", "vendor"))
	assert.True(t, containsPathSegment("foo/vendor", "vendor"))
	assert.False(t, containsPathSegment("foo/vendored/bar.go", "vendor"))
	assert.False(t, containsPathSegment("main.go", "vendor"))
}

func TestFilterSuppressed_Empty(t *testing.T) {
	t.Parallel()

	assert.Empty(t, FilterSuppressed(nil))
}

func TestFilterSuppressed_NoNolint(t *testing.T) {
	t.Parallel()

	tmpDir := t.TempDir()
	src := filepath.Join(tmpDir, "a.go")
	require.NoError(t, os.WriteFile(src, []byte("package main\n\nfunc main() {}\n"), 0o600))

	fixes := []Fix{
		{FilePath: src, Category: "oops_redundant_guard", Line: 3},
		{FilePath: src, Category: "legacy_as", Line: 3},
	}

	result := FilterSuppressed(fixes)
	require.Len(t, result, 2, "no //nolint directive → both fixes survive")
}

func TestFilterSuppressed_BlanketNolint(t *testing.T) {
	t.Parallel()

	tmpDir := t.TempDir()
	src := filepath.Join(tmpDir, "a.go")
	// //nolint:erraudit on line 3 (blanket form — suppresses every category).
	content := "package main\n\nfunc main() { _ = 1 } //nolint:erraudit\n"
	require.NoError(t, os.WriteFile(src, []byte(content), 0o600))

	fixes := []Fix{
		{FilePath: src, Category: "oops_redundant_guard", Line: 3},
		{FilePath: src, Category: "legacy_as", Line: 3},
	}

	result := FilterSuppressed(fixes)
	assert.Empty(t, result, "blanket //nolint:erraudit suppresses every category")
}

func TestFilterSuppressed_SpecificRule(t *testing.T) {
	t.Parallel()

	tmpDir := t.TempDir()
	src := filepath.Join(tmpDir, "a.go")
	// //nolint:erraudit:oops_redundant_guard on line 3 (specific rule).
	content := "package main\n\nfunc main() { _ = 1 } //nolint:erraudit:oops_redundant_guard\n"
	require.NoError(t, os.WriteFile(src, []byte(content), 0o600))

	fixes := []Fix{
		{FilePath: src, Category: "oops_redundant_guard", Line: 3},
		{FilePath: src, Category: "legacy_as", Line: 3},
	}

	result := FilterSuppressed(fixes)
	require.Len(t, result, 1, "only the matching category is suppressed")
	assert.Equal(t, "legacy_as", result[0].Category)
}
