//go:build ignore

package main

import "errors"

type MyError struct{}

func (e *MyError) Error() string { return "my error" }

func handle(err error) bool {
	if _, ok := errors.AsType[*MyError](err); ok {
		return true
	}
	return false
}
