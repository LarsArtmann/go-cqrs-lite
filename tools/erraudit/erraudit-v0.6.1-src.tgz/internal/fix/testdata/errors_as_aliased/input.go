//go:build ignore

package main

import (
	"errors"
	myos "os"
)

func handle(err error) {
	var target *myos.PathError
	errors.As(err, &target)
	_ = target
}
