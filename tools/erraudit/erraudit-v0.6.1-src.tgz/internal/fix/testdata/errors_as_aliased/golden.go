//go:build ignore

package main

import (
	"errors"
	myos "os"
)

func handle(err error) {
	var target *myos.PathError
	target, _ = errors.AsType[*myos.PathError](err)
	_ = target
}
