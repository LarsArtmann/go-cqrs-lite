//go:build ignore

package main

import "github.com/samber/oops"

func process(err error) error {
	if err != nil {
		return oops.Wrap(err)
	}
	return nil
}
