//go:build ignore

package main

import "github.com/samber/oops"

func process(err error) error {
	return oops.Wrap(err)
}
