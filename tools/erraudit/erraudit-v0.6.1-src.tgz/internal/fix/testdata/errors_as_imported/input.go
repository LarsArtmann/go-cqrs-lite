//go:build ignore

package main

import (
	"errors"
	"os"
)

func handle(err error) {
	var target *os.PathError
	errors.As(err, &target)
	_ = target
}
