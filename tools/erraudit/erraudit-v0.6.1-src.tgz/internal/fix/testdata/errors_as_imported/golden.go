//go:build ignore

package main

import (
	"errors"
	"os"
)

func handle(err error) {
	var target *os.PathError
	target, _ = errors.AsType[*os.PathError](err)
	_ = target
}
