//go:build ignore

package main

import "errors"

type MyError struct{}

func (e *MyError) Error() string { return "my error" }

func handle(err error) bool {
	_, ok := errors.AsType[*MyError](err)
	return ok
}
