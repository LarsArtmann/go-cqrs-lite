//go:build ignore

package main

import "errors"

type MyError struct{}

func (e *MyError) Error() string { return "my error" }

func handle(err error) bool {
	var target *MyError
	ok := errors.As(err, &target)
	return ok
}
