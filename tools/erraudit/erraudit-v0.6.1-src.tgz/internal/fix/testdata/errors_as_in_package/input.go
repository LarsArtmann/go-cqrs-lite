//go:build ignore

package main

import "errors"

type MyError struct{}

func (e *MyError) Error() string { return "my error" }

func handle(err error) {
	var target *MyError
	errors.As(err, &target)
	_ = target
}
