//go:build ignore

package main

import "errors"

type MyError struct{}

func (e *MyError) Error() string { return "my error" }

func handle(err error) int {
	target, ok := errors.AsType[*MyError](err)
	if !ok {
		return 0
	}
	_ = target
	return 1
}
