//go:build ignore

package main

import "errors"

type MyError struct{}

func (e *MyError) Error() string { return "my error" }

func handle(err error) int {
	var target *MyError
	if !errors.As(err, &target) {
		return 0
	}
	_ = target
	return 1
}
