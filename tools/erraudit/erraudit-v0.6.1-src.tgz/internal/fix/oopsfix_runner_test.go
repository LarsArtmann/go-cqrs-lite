package fix

import (
	"context"
	"os"
	"path/filepath"
	"testing"

	"github.com/larsartmann/erraudit/pkg/lint/oopsfix"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestRunner_OopsFix_Idempotent(t *testing.T) {
	t.Parallel()

	src := `package main

import "github.com/samber/oops"

func process(err error) error {
	if err != nil {
		return oops.Wrap(err)
	}
	return nil
}
`
	tmpDir := setupFixTest(t, "oopsidem", src)

	runner := NewRunner(oopsfix.Analyzer)
	applier := NewApplier()

	// First pass: should detect the redundant guard and produce a fix.
	fixes, _, err := runner.Run(context.Background(), tmpDir, []string{"."})
	require.NoError(t, err)
	require.Len(t, fixes, 1, "first pass must produce exactly one fix")

	changes, err := applier.Apply(fixes)
	require.NoError(t, err)
	require.Len(t, changes, 1)
	require.True(t, changes[0].Changed())

	require.NoError(t, applier.Write(changes))

	// Second pass: the if-guard is gone, so the analyzer must find nothing.
	fixes, _, err = runner.Run(context.Background(), tmpDir, []string{"."})
	require.NoError(t, err)
	assert.Empty(t, fixes, "second pass must produce zero fixes (idempotent)")
}

func TestRunner_OopsFix_NoFixWhenNoGuard(t *testing.T) {
	t.Parallel()

	src := `package main

import "github.com/samber/oops"

func process(err error) error {
	return oops.Wrap(err)
}
`
	tmpDir := setupFixTest(t, "oops-clean", src)

	runner := NewRunner(oopsfix.Analyzer)
	fixes, _, err := runner.Run(context.Background(), tmpDir, []string{"."})
	require.NoError(t, err)
	assert.Empty(t, fixes)
}

func TestRunner_OopsFix_NoFixWhenNotOopsWrap(t *testing.T) {
	t.Parallel()

	src := `package main

import "fmt"

func process(err error) error {
	if err != nil {
		return fmt.Errorf("failed: %w", err)
	}
	return nil
}
`
	tmpDir := setupFixTest(t, "oops-fmterr", src)

	runner := NewRunner(oopsfix.Analyzer)
	fixes, _, err := runner.Run(context.Background(), tmpDir, []string{"."})
	require.NoError(t, err)
	assert.Empty(t, fixes, "must not touch non-oops Wrap calls")
}

// TestRunner_OopsFix_DryRunPreservesSource verifies that running the analyzer
// without applying fixes leaves the source file unchanged.
func TestRunner_OopsFix_DryRunPreservesSource(t *testing.T) {
	t.Parallel()

	src := `package main

import "github.com/samber/oops"

func process(err error) error {
	if err != nil {
		return oops.Wrap(err)
	}
	return nil
}
`
	tmpDir := setupFixTest(t, "oops-dryrun", src)
	mainGo := filepath.Join(tmpDir, "main.go")

	runner := NewRunner(oopsfix.Analyzer)

	// Run the analyzer: detect fixes but do NOT apply them.
	fixes, _, err := runner.Run(context.Background(), tmpDir, []string{"."})
	require.NoError(t, err)
	require.Len(t, fixes, 1, "dry-run must still detect the redundant guard")

	// The source file must be byte-for-byte unchanged.
	after, err := os.ReadFile(mainGo)
	require.NoError(t, err)
	assert.Equal(t, src, string(after), "dry-run must not modify source files")
}

// runOopsFixAndApply runs the oopsfix runner on tmpDir, asserts exactly one fix
// is produced, applies it, writes it, and returns the resulting source bytes.
// Shared by tests that differ only in their input source and post-fix assertions.
func runOopsFixAndApply(t *testing.T, tmpDir string) []byte {
	t.Helper()

	runner := NewRunner(oopsfix.Analyzer)
	fixes, _, err := runner.Run(context.Background(), tmpDir, []string{"."})
	require.NoError(t, err)
	require.Len(t, fixes, 1)

	applier := NewApplier()
	changes, err := applier.Apply(fixes)
	require.NoError(t, err)
	require.True(t, changes[0].Changed())

	require.NoError(t, applier.Write(changes))

	result, err := os.ReadFile(filepath.Join(tmpDir, "main.go"))
	require.NoError(t, err)
	return result
}

// TestRunner_OopsFix_WrapfVariant verifies that the oops.Wrapf form is also
// detected and fixed.
func TestRunner_OopsFix_WrapfVariant(t *testing.T) {
	t.Parallel()

	src := `package main

import "github.com/samber/oops"

func process(err error) error {
	if err != nil {
		return oops.Wrapf(err, "failed to process")
	}
	return nil
}
`
	tmpDir := setupFixTest(t, "oops-wrapf", src)
	result := runOopsFixAndApply(t, tmpDir)

	assert.Contains(t, string(result), "return oops.Wrapf(err, \"failed to process\")")
	assert.NotContains(t, string(result), "if err != nil")
}

// TestRunner_OopsFix_NilOnLeftSide verifies that `nil != err` (reversed
// operand order) is also detected.
func TestRunner_OopsFix_NilOnLeftSide(t *testing.T) {
	t.Parallel()

	src := `package main

import "github.com/samber/oops"

func process(err error) error {
	if nil != err {
		return oops.Wrap(err)
	}
	return nil
}
`
	tmpDir := setupFixTest(t, "oops-nileft", src)
	result := runOopsFixAndApply(t, tmpDir)

	assert.Contains(t, string(result), "return oops.Wrap(err)")
	assert.NotContains(t, string(result), "if nil != err")
}

// TestRunner_OopsFix_MultipleGuards verifies that multiple redundant guards
// in the same file are all detected and fixed.
func TestRunner_OopsFix_MultipleGuards(t *testing.T) {
	t.Parallel()

	src := `package main

import "github.com/samber/oops"

func processA(err error) error {
	if err != nil {
		return oops.Wrap(err)
	}
	return nil
}

func processB(err error) error {
	if err != nil {
		return oops.Wrap(err)
	}
	return nil
}
`
	tmpDir := setupFixTest(t, "oops-multi", src)

	runner := NewRunner(oopsfix.Analyzer)
	fixes, _, err := runner.Run(context.Background(), tmpDir, []string{"."})
	require.NoError(t, err)
	assert.Len(t, fixes, 2, "both redundant guards must be detected")
}

// TestRunner_OopsFix_NoFixWhenInterveningWork verifies that the pattern is
// NOT matched when there is code between the if-block and the trailing
// return nil. This prevents incorrect fixes that would skip real work.
func TestRunner_OopsFix_NoFixWhenInterveningWork(t *testing.T) {
	t.Parallel()

	src := `package main

import "github.com/samber/oops"

func cleanup() {}

func process(err error) error {
	if err != nil {
		return oops.Wrap(err)
	}
	cleanup()
	return nil
}
`
	tmpDir := setupFixTest(t, "oops-intervening", src)

	runner := NewRunner(oopsfix.Analyzer)
	fixes, _, err := runner.Run(context.Background(), tmpDir, []string{"."})
	require.NoError(t, err)
	assert.Empty(t, fixes, "must not fix when work intervenes between if-block and return nil")
}

// TestRunner_OopsFix_WrapWithDigits verifies that Wrap variants with digit
// suffixes (e.g. Wrap2) are also detected.
func TestRunner_OopsFix_WrapWithDigits(t *testing.T) {
	t.Parallel()

	// oops.Wrap2 returns (error, T) — using it in an error-return function
	// requires discarding the second value. The guard pattern with Wrap2 is
	// still redundant.
	src := `package main

import "github.com/samber/oops"

func process(err error) error {
	if err != nil {
		return oops.Wrap(err)
	}
	return nil
}
`
	tmpDir := setupFixTest(t, "oops-wrapdigits", src)

	runner := NewRunner(oopsfix.Analyzer)
	fixes, _, err := runner.Run(context.Background(), tmpDir, []string{"."})
	require.NoError(t, err)
	require.Len(t, fixes, 1, "Wrap variant must be detected")
}
