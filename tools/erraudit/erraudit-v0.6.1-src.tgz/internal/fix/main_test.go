package fix

import (
	"os"
	"testing"
)

// TestMain pins the module env the fixture-based tests need so a bare
// `go test ./internal/fix/` passes outside direnv/nix shells (SUPERB T14).
//
// The oops-fix fixtures are throwaway modules in t.TempDir() whose go.mod
// (written by initGoModule) carries no `require github.com/samber/oops`:
// under the default -mod=readonly the go command rejects the import
// ("could not import github.com/samber/oops") and the package load fails.
// -mod=mod lets the go command add the missing requirement from the module
// cache at fixture-load time. GOWORK=off keeps fixture modules hermetic
// even when the invoking shell sits inside a workspace repo (the parent
// shell's GOWORK/GOFLAGS — e.g. BuildFlow's direnv -mod=vendor — must not
// leak into the fixture resolution; erraudit itself has no go.work, so
// this never changes how the module under test resolves its own deps).
func TestMain(m *testing.M) {
	os.Setenv("GOFLAGS", "-mod=mod")
	os.Setenv("GOWORK", "off")

	os.Exit(m.Run())
}
