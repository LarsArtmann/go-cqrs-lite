package fix

import (
	"context"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/larsartmann/erraudit/pkg/lint/legacyerrors"
	"github.com/larsartmann/erraudit/pkg/lint/oopsfix"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestGoldenFiles(t *testing.T) {
	t.Parallel()

	scenarios := []struct {
		name         string
		expectFixes  bool
		expectError  bool
		errorContain string
	}{
		{"errors_as_in_package", true, false, ""},
		{"errors_as_in_if", true, false, ""},
		{"errors_as_in_if_else", true, false, ""},
		{"errors_as_negated_if", true, false, ""},
		{"errors_as_assignment", true, false, ""},
		{"errors_as_imported", true, false, ""},
		{"errors_as_aliased", true, false, ""},
		{"no_fix_if_not_expr_stmt", false, false, ""},
		{"idempotency", false, false, ""},
		{"oops_redundant_guard", true, false, ""},
	}

	for _, tt := range scenarios {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			tmpDir := t.TempDir()
			require.NoError(t, initGoModule(tmpDir, tt.name))

			scenarioDir := filepath.Join("testdata", tt.name)
			input, err := os.ReadFile(filepath.Join(scenarioDir, "input.go"))
			require.NoError(t, err)

			goldenRaw, err := os.ReadFile(filepath.Join(scenarioDir, "golden.go"))
			require.NoError(t, err)
			golden := stripBuildTag(goldenRaw)

			srcPath := filepath.Join(tmpDir, "main.go")
			require.NoError(t, os.WriteFile(srcPath, stripBuildTag(input), 0o644))

			runner := NewRunner(legacyerrors.Analyzer, oopsfix.Analyzer)
			fixes, _, err := runner.Run(context.Background(), tmpDir, []string{"."})

			if tt.expectError {
				require.Error(t, err)
				if tt.errorContain != "" {
					assert.Contains(t, err.Error(), tt.errorContain)
				}
			} else {
				require.NoError(t, err)
			}

			if tt.expectFixes {
				require.NotEmpty(t, fixes, "expected fixes but got none")

				applier := NewApplier()
				changes, err := applier.Apply(fixes)
				require.NoError(t, err)
				require.Len(t, changes, 1)
				require.True(t, changes[0].Changed())

				err = applier.Write(changes)
				require.NoError(t, err)

				actual, err := os.ReadFile(srcPath)
				require.NoError(t, err)

				assert.Equal(t, normalizeGolden(string(golden)), normalizeGolden(string(actual)))
			} else {
				assert.Empty(t, fixes, "expected no fixes")

				// Verify file was NOT modified
				actual, err := os.ReadFile(srcPath)
				require.NoError(t, err)
				assert.Equal(t, string(stripBuildTag(input)), string(actual))
			}
		})
	}
}

// stripBuildTag removes //go:build ignore from the first line.
func stripBuildTag(data []byte) []byte {
	s := string(data)
	lines := strings.Split(s, "\n")
	if len(lines) > 0 && strings.HasPrefix(lines[0], "//go:build ") {
		lines = lines[1:]
		if len(lines) > 0 && lines[0] == "" {
			lines = lines[1:]
		}
	}
	return []byte(strings.Join(lines, "\n"))
}

// normalizeGolden strips build tags and trailing whitespace for comparison.
func normalizeGolden(s string) string {
	lines := strings.Split(s, "\n")
	var result []string
	//art-dupl:accept idiomatic split-filter-rejoin loop, 4 lines, unrelated packages, different filters and domains
	for _, line := range lines {
		if strings.HasPrefix(line, "//go:build ") {
			continue
		}
		result = append(result, line)
	}
	return strings.TrimSpace(strings.Join(result, "\n"))
}
