// Package fix provides infrastructure for running go/analysis analyzers
// and applying their suggested fixes to source files.
package fix

import (
	"context"
	"fmt"
	"go/token"
	"strings"

	apierrors "github.com/larsartmann/erraudit/pkg/errors"
	"golang.org/x/tools/go/analysis"
	"golang.org/x/tools/go/analysis/checker"
	"golang.org/x/tools/go/packages"
)

// Summary describes what the runner found, regardless of whether fixes
// were generated. It powers the user-facing "no fixes" message so that
// users understand why nothing was fixable.
type Summary struct {
	// TotalDiagnostics is the total number of diagnostics emitted by the
	// analyzers, including advisory ones without any TextEdit.
	TotalDiagnostics int

	// FixableCount is the number of diagnostics that produced at least one
	// fixable SuggestedFix (i.e. had non-empty TextEdits).
	FixableCount int

	// AdvisoryCount is the number of diagnostics that carried a SuggestedFix
	// with zero TextEdits — they are advisory-only and cannot be auto-applied.
	AdvisoryCount int
}

// Fix represents a single suggested fix for a file.
type Fix struct {
	FilePath  string
	Category  string // violation type (diagnostic Category), used for //nolint suppression
	Line      int    // source line of the flagged construct, used for //nolint suppression
	Message   string
	TextEdits []analysis.TextEdit
	Fset      *token.FileSet
}

// Runner executes analyzers on Go packages and collects suggested fixes.
type Runner struct {
	analyzers []*analysis.Analyzer
}

// NewRunner creates a runner for the given analyzers.
func NewRunner(analyzers ...*analysis.Analyzer) *Runner {
	return &Runner{analyzers: analyzers}
}

// Run loads packages matching patterns, runs analyzers, and returns collected fixes.
// dir is the working directory for package resolution (empty means current directory).
// The returned Summary describes diagnostic counts for user-facing messaging.
func (r *Runner) Run(ctx context.Context, dir string, patterns []string) ([]Fix, Summary, error) {
	var summary Summary

	cfg := &packages.Config{
		Context: ctx,
		Mode:    packages.LoadAllSyntax,
		Fset:    token.NewFileSet(),
		Dir:     dir,
		Tests:   true,
	}

	pkgs, err := packages.Load(cfg, patterns...)
	if err != nil {
		return nil, summary, apierrors.Wrap(err, "load packages (dir=%q, patterns=%v)", dir, patterns)
	}

	// Collect package-level errors for structured reporting.
	var pkgErrs []string

	for _, pkg := range pkgs {
		for _, e := range pkg.Errors {
			pkgErrs = append(pkgErrs, e.Error())
		}
	}

	// Note: we pass ALL packages (including test variants) to checker.Analyze
	// because it needs the complete package graph for type resolution.
	// Deduplication of fixes happens after extraction to avoid overlapping
	// text edits from test variants analyzing the same non-test files.
	graph, err := checker.Analyze(r.analyzers, pkgs, nil)
	if err != nil {
		return nil, summary, apierrors.Wrap(err, "analyze (dir=%q)", dir)
	}

	var fixes []Fix

	seenFix := make(map[string]struct{})

	for act := range graph.All() {
		if !act.IsRoot {
			continue
		}

		fileFixes, fileSummary := extractFixes(act.Package, act.Diagnostics)

		for _, f := range fileFixes {
			// Deduplicate fixes by file + first edit position. With Tests=true,
			// test variants produce the same diagnostics for non-test files.
			key := f.FilePath + ":"
			if len(f.TextEdits) > 0 {
				key += fmt.Sprintf("%d:%d", f.TextEdits[0].Pos, f.TextEdits[0].End)
			}

			if _, ok := seenFix[key]; ok {
				continue
			}

			seenFix[key] = struct{}{}

			fixes = append(fixes, f)
		}

		summary.TotalDiagnostics += fileSummary.TotalDiagnostics
		summary.FixableCount += fileSummary.FixableCount
		summary.AdvisoryCount += fileSummary.AdvisoryCount
	}

	if len(fixes) == 0 && len(pkgErrs) > 0 {
		return nil, summary, apierrors.New(
			"package errors (dir=%q):\n%s",
			dir,
			strings.Join(pkgErrs, "\n"),
		)
	}

	return fixes, summary, nil
}

// extractFixes converts diagnostics to Fix structs and counts diagnostic
// categories for the Summary.
func extractFixes(pkg *packages.Package, diagnostics []analysis.Diagnostic) ([]Fix, Summary) {
	var fixes []Fix

	var summary Summary

	for _, d := range diagnostics {
		summary.TotalDiagnostics++

		hasEdits := false

		for _, sf := range d.SuggestedFixes {
			if len(sf.TextEdits) == 0 {
				continue
			}

			hasEdits = true

			pos := pkg.Fset.Position(d.Pos)
			fixes = append(fixes, Fix{
				FilePath:  pos.Filename,
				Category:  d.Category,
				Line:      pos.Line,
				Message:   sf.Message,
				TextEdits: sf.TextEdits,
				Fset:      pkg.Fset,
			})
		}

		if hasEdits {
			summary.FixableCount++
		} else {
			summary.AdvisoryCount++
		}
	}

	return fixes, summary
}
