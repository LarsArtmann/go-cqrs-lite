package fix

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/larsartmann/erraudit/pkg/lint/legacyerrors"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestRunner_LegacyErrorsFix(t *testing.T) {
	t.Parallel()

	// Create a temporary module with a file that uses errors.As.
	tmpDir := setupFixTest(t, "testmod", `package main

import "errors"

type MyError struct{}

func (e *MyError) Error() string { return "my error" }

func handle(err error) {
	var target *MyError
	errors.As(err, &target)
	_ = target
}
`)

	runner := NewRunner(legacyerrors.Analyzer)
	fixes, _, err := runner.Run(context.Background(), tmpDir, []string{"."})
	require.NoError(t, err)

	require.Len(t, fixes, 1)
	assert.Contains(t, fixes[0].Message, "AsType")
	assert.Len(t, fixes[0].TextEdits, 1, "assignment form: one edit replacing the expr stmt")
	// In-package types should be rendered without package qualifier.
	assert.Contains(t, string(fixes[0].TextEdits[0].NewText), "target, _ = errors.AsType[*MyError](err)")
}

func setupFixTest(t *testing.T, modName, src string) string {
	t.Helper()

	tmpDir := t.TempDir()
	require.NoError(t, initGoModule(tmpDir, modName))
	require.NoError(t, os.WriteFile(filepath.Join(tmpDir, "main.go"), []byte(src), 0o644))

	return tmpDir
}

func runFixerAndAssertEmpty(t *testing.T, tmpDir string) {
	t.Helper()

	runner := NewRunner(legacyerrors.Analyzer)
	fixes, _, err := runner.Run(context.Background(), tmpDir, []string{"."})
	require.NoError(t, err)
	assert.Empty(t, fixes)
}

func TestRunner_NoFixesWhenNoViolations(t *testing.T) {
	t.Parallel()

	tmpDir := setupFixTest(t, "cleanmod", `package main

func main() {}
`)

	runFixerAndAssertEmpty(t, tmpDir)
}

func TestRunner_NoFixWhenNotExprStmt(t *testing.T) {
	t.Parallel()

	// errors.As in a return statement should NOT get an auto-fix TextEdit.
	tmpDir := setupFixTest(t, "condmod", `package main

import "errors"

type MyError struct{}

func (e *MyError) Error() string { return "my error" }

func handle(err error) bool {
	var target *MyError
	return errors.As(err, &target)
}
`)

	runFixerAndAssertEmpty(t, tmpDir)
}

func TestRunner_NoFixWhenTypeUnresolved(t *testing.T) {
	t.Parallel()

	// errors.As with non-variable second arg should NOT get an auto-fix.
	tmpDir := setupFixTest(t, "unresolvedmod", `package main

import "errors"

func handle(err error) {
	errors.As(err, nil)
}
`)

	runFixerAndAssertEmpty(t, tmpDir)
}

func TestRunner_Idempotent(t *testing.T) {
	t.Parallel()

	// Idempotency contract: applying the fix once produces a fix; applying
	// it a second time on the modified source produces zero fixes. Each case
	// exercises a distinct errors.As pattern (standalone expression, if
	// condition, negated if, assignment) so a regression in any pattern is
	// caught by exactly one named case.
	cases := []struct {
		name    string
		modName string
		src     string
	}{
		{
			name:    "StandaloneExpr",
			modName: "idempotentmod",
			src: `package main

import "errors"

type MyError struct{}

func (e *MyError) Error() string { return "my error" }

func handle(err error) {
	var target *MyError
	errors.As(err, &target)
	_ = target
}
`,
		},
		{
			name:    "IfStmt",
			modName: "idemifstmt",
			src: `package main

import "errors"

type MyError struct{}

func (e *MyError) Error() string { return "my error" }

func handle(err error) bool {
	var target *MyError
	if errors.As(err, &target) {
		return true
	}
	return false
}
`,
		},
		{
			name:    "NegatedIfStmt",
			modName: "idemnegif",
			src: `package main

import "errors"

type MyError struct{ code int }

func (e *MyError) Error() string { return "my error" }
func (e *MyError) Code() int     { return e.code }

func handle(err error) int {
	var target *MyError
	if !errors.As(err, &target) {
		return 0
	}
	return target.Code()
}
`,
		},
		{
			name:    "AssignmentStmt",
			modName: "idemassign",
			src: `package main

import "errors"

type MyError struct{}

func (e *MyError) Error() string { return "my error" }

func handle(err error) bool {
	var target *MyError
	ok := errors.As(err, &target)
	return ok
}
`,
		},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			tmpDir := setupFixTest(t, tc.modName, tc.src)

			runner := NewRunner(legacyerrors.Analyzer)
			applier := NewApplier()

			// First pass: should produce a fix.
			fixes, _, err := runner.Run(context.Background(), tmpDir, []string{"."})
			require.NoError(t, err)
			require.Len(t, fixes, 1)

			changes, err := applier.Apply(fixes)
			require.NoError(t, err)
			require.Len(t, changes, 1)
			require.True(t, changes[0].Changed())

			require.NoError(t, applier.Write(changes))

			// Second pass: should produce no fixes and no errors.
			fixes, _, err = runner.Run(context.Background(), tmpDir, []string{"."})
			require.NoError(t, err)
			assert.Empty(t, fixes)
		})
	}
}

func TestRunner_BrokenPackage_ReturnsError(t *testing.T) {
	t.Parallel()

	// Syntax error: missing closing brace.
	tmpDir := setupFixTest(t, "brokenmod", `package main

func main() {
	var x int
`)

	runner := NewRunner(legacyerrors.Analyzer)
	fixes, _, err := runner.Run(context.Background(), tmpDir, []string{"."})

	assert.Error(t, err)
	assert.Contains(t, err.Error(), "package errors")
	assert.Empty(t, fixes)
}

func TestRunner_NoFixForErrorsIs(t *testing.T) {
	t.Parallel()

	// errors.Is produces an advisory diagnostic but no TextEdit fix.
	tmpDir := setupFixTest(t, "errorsismod", `package main

import "errors"

var ErrNotFound = errors.New("not found")

func check(err error) bool {
	return errors.Is(err, ErrNotFound)
}
`)

	runFixerAndAssertEmpty(t, tmpDir)
}

func TestRunner_FixIfStmt(t *testing.T) {
	t.Parallel()

	tmpDir := setupFixTest(t, "ifstmtmod", `package main

import "errors"

type MyError struct{}

func (e *MyError) Error() string { return "my error" }

func handle(err error) int {
	var target *MyError
	if errors.As(err, &target) {
		return 1
	}
	return 0
}
`)

	runner := NewRunner(legacyerrors.Analyzer)
	fixes, _, err := runner.Run(context.Background(), tmpDir, []string{"."})
	require.NoError(t, err)
	require.Len(t, fixes, 1, "expected exactly one fix for if errors.As")
	assert.Len(t, fixes[0].TextEdits, 2, "expected two edits: var removal + if condition")

	combined := string(fixes[0].TextEdits[0].NewText) + string(fixes[0].TextEdits[1].NewText)
	assert.Contains(t, combined, "_, ok := errors.AsType[*MyError](err); ok")
}

func TestRunner_FixIfStmt_TargetUsedAfter_NoFix(t *testing.T) {
	t.Parallel()

	// target is used AFTER the if block — scope analysis must prevent the fix.
	tmpDir := setupFixTest(t, "scopeguardmod", `package main

import "errors"

type MyError struct{}

func (e *MyError) Error() string { return "my error" }

func handle(err error) int {
	var target *MyError
	if errors.As(err, &target) {
		return 1
	}
	_ = target // used after if — fix would be unsafe
	return 0
}
`)

	runFixerAndAssertEmpty(t, tmpDir)
}

func TestRunner_FixIfStmt_TargetUsedBeforeIf_NoFix(t *testing.T) {
	t.Parallel()

	// target is used BETWEEN the var declaration and the if — fix would
	// shadow the outer variable and break the usage.
	tmpDir := setupFixTest(t, "scopebeforemod", `package main

import (
	"errors"
	"fmt"
)

type MyError struct{}

func (e *MyError) Error() string { return "my error" }

func handle(err error) int {
	var target *MyError
	fmt.Println(target) // used before if
	if errors.As(err, &target) {
		return 1
	}
	return 0
}
`)

	runFixerAndAssertEmpty(t, tmpDir)
}

func TestRunner_FixNegatedIfStmt_TargetUsedBeforeIf_KeepsVarDecl(t *testing.T) {
	t.Parallel()

	// target is used before the if — negated fix should still work but NOT
	// remove the var declaration (target, ok := would reuse existing target).
	tmpDir := setupFixTest(t, "negscopebeforemod", `package main

import (
	"errors"
	"fmt"
)

type MyError struct{ code int }

func (e *MyError) Error() string { return "my error" }
func (e *MyError) Code() int     { return e.code }

func handle(err error) int {
	var target *MyError
	fmt.Println(target)
	if !errors.As(err, &target) {
		return 0
	}
	return target.Code()
}
`)

	runner := NewRunner(legacyerrors.Analyzer)
	fixes, _, err := runner.Run(context.Background(), tmpDir, []string{"."})
	require.NoError(t, err)
	require.Len(t, fixes, 1)

	// Should have exactly 1 edit (the if rewrite), NOT 2 (no var removal).
	assert.Len(t, fixes[0].TextEdits, 1, "should NOT remove var decl when target used before if")
}

func TestRunner_FixIfStmt_VarWithInitializer_NoFix(t *testing.T) {
	t.Parallel()

	// var target = someFunc() — has a side-effect initializer.
	// Should not produce any fix because removing the var would lose the
	// side effect, and the type is inferred.
	tmpDir := setupFixTest(t, "varinitmod", `package main

import "errors"

type MyError struct{}

func (e *MyError) Error() string { return "my error" }

func newError() *MyError { return &MyError{} }

func handle(err error) bool {
	var target = newError()
	if errors.As(err, &target) {
		return true
	}
	return false
}
`)

	runFixerAndAssertEmpty(t, tmpDir)
}

func TestRunner_FixAssignmentStmt(t *testing.T) {
	t.Parallel()

	tmpDir := setupFixTest(t, "assignmod", `package main

import "errors"

type MyError struct{}

func (e *MyError) Error() string { return "my error" }

func handle(err error) bool {
	var target *MyError
	ok := errors.As(err, &target)
	return ok
}
`)

	runner := NewRunner(legacyerrors.Analyzer)
	fixes, _, err := runner.Run(context.Background(), tmpDir, []string{"."})
	require.NoError(t, err)
	require.Len(t, fixes, 1, "expected exactly one fix for assignment pattern")

	// Verify the edit contains the correct transformation
	var combined strings.Builder
	for _, te := range fixes[0].TextEdits {
		combined.WriteString(string(te.NewText))
	}
	assert.Contains(t, combined.String(), "_, ok := errors.AsType[*MyError](err)")
}

func TestRunner_FixAssignmentStmt_AppliesCorrectly(t *testing.T) {
	t.Parallel()

	tmpDir := setupFixTest(t, "assignapplymod", `package main

import "errors"

type MyError struct{}

func (e *MyError) Error() string { return "my error" }

func handle(err error) bool {
	var target *MyError
	ok := errors.As(err, &target)
	return ok
}
`)

	runner := NewRunner(legacyerrors.Analyzer)
	applier := NewApplier()

	fixes, _, err := runner.Run(context.Background(), tmpDir, []string{"."})
	require.NoError(t, err)
	require.Len(t, fixes, 1)

	changes, err := applier.Apply(fixes)
	require.NoError(t, err)
	require.Len(t, changes, 1)
	require.True(t, changes[0].Changed())

	result := string(changes[0].Modified)
	assert.Contains(t, result, "_, ok := errors.AsType[*MyError](err)")
	assert.NotContains(t, result, "var target *MyError")
}

func TestRunner_FixNegatedIfStmt(t *testing.T) {
	t.Parallel()

	tmpDir := setupFixTest(t, "negifstmtmod", `package main

import "errors"

type MyError struct{}

func (e *MyError) Error() string { return "my error" }

func handle(err error) int {
	var target *MyError
	if !errors.As(err, &target) {
		return 0
	}
	_ = target
	return 1
}
`)

	runner := NewRunner(legacyerrors.Analyzer)
	fixes, _, err := runner.Run(context.Background(), tmpDir, []string{"."})
	require.NoError(t, err)
	require.Len(t, fixes, 1, "expected exactly one fix for negated if errors.As")

	// Find the edit that contains the hoisted statement
	for _, te := range fixes[0].TextEdits {
		text := string(te.NewText)
		if strings.Contains(text, "AsType") {
			assert.Contains(t, text, "target, ok := errors.AsType[*MyError](err)")
			assert.Contains(t, text, "if !ok")
		}
	}
}

func TestRunner_FixNegatedIfStmt_AppliesCorrectly(t *testing.T) {
	t.Parallel()

	tmpDir := setupFixTest(t, "negifstmtapplymod", `package main

import "errors"

type MyError struct{ code int }

func (e *MyError) Error() string  { return "my error" }
func (e *MyError) Code() int      { return e.code }

func handle(err error) int {
	var target *MyError
	if !errors.As(err, &target) {
		return 0
	}
	return target.Code()
}
`)

	runner := NewRunner(legacyerrors.Analyzer)
	applier := NewApplier()

	fixes, _, err := runner.Run(context.Background(), tmpDir, []string{"."})
	require.NoError(t, err)
	require.Len(t, fixes, 1)

	changes, err := applier.Apply(fixes)
	require.NoError(t, err)
	require.Len(t, changes, 1)
	require.True(t, changes[0].Changed())

	result := string(changes[0].Modified)
	assert.Contains(t, result, "target, ok := errors.AsType[*MyError](err)")
	assert.Contains(t, result, "if !ok {")
	assert.NotContains(t, result, "var target *MyError")
}

func TestRunner_FixIfStmt_AppliesCorrectly(t *testing.T) {
	t.Parallel()

	tmpDir := setupFixTest(t, "ifstmtapplymod", `package main

import "errors"

type MyError struct{}

func (e *MyError) Error() string { return "my error" }

func handle(err error) bool {
	var target *MyError
	if errors.As(err, &target) {
		return true
	}
	return false
}
`)

	runner := NewRunner(legacyerrors.Analyzer)
	applier := NewApplier()

	fixes, _, err := runner.Run(context.Background(), tmpDir, []string{"."})
	require.NoError(t, err)
	require.Len(t, fixes, 1)

	changes, err := applier.Apply(fixes)
	require.NoError(t, err)
	require.Len(t, changes, 1)
	require.True(t, changes[0].Changed())

	result := string(changes[0].Modified)
	assert.Contains(t, result, "if _, ok := errors.AsType[*MyError](err); ok {")
	assert.NotContains(t, result, "var target *MyError")
}

func initGoModule(dir, name string) error {
	goMod := fmt.Sprintf("module %s\n\ngo 1.26\n", name)
	return os.WriteFile(filepath.Join(dir, "go.mod"), []byte(goMod), 0o644)
}

func TestRunner_NoDuplicateFixesWithTestFiles(t *testing.T) {
	t.Parallel()

	// Regression: With Tests=true in packages.Config, go/packages returns both
	// the base and test variant packages, each containing the same non-test
	// source files. The runner must deduplicate fixes so each file gets only
	// one fix, not two.
	tmpDir := t.TempDir()
	require.NoError(t, initGoModule(tmpDir, "dupemod"))

	mainSrc := `package main

import "errors"

type MyError struct{}

func (e *MyError) Error() string { return "my error" }

func handle(err error) {
	var target *MyError
	errors.As(err, &target)
	_ = target
}
`
	require.NoError(t, os.WriteFile(filepath.Join(tmpDir, "main.go"), []byte(mainSrc), 0o644))

	// A test file that imports the same package — triggers the dual-variant
	// package loading.
	testSrc := `package main

import "testing"

func TestHandle(t *testing.T) {
	_ = handle(nil)
}
`
	require.NoError(t, os.WriteFile(filepath.Join(tmpDir, "main_test.go"), []byte(testSrc), 0o644))

	runner := NewRunner(legacyerrors.Analyzer)
	fixes, _, err := runner.Run(context.Background(), tmpDir, []string{"."})
	require.NoError(t, err)

	// Should produce exactly 1 fix for main.go, not 2.
	require.Len(t, fixes, 1, "must not produce duplicate fixes when test files are present")
}
