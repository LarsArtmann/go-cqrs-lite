package fix

import (
	"path/filepath"

	"github.com/larsartmann/erraudit/pkg/suppression"
	"github.com/larsartmann/erraudit/pkg/types"
)

// FilterExcluded removes fixes whose FilePath matches any excluded pattern.
// When excluded is empty, fixes is returned unchanged.
func FilterExcluded(fixes []Fix, excluded []string) []Fix {
	if len(excluded) == 0 {
		return fixes
	}

	result := make([]Fix, 0, len(fixes))
	for _, f := range fixes {
		if isPathExcluded(f.FilePath, excluded) {
			continue
		}

		result = append(result, f)
	}

	return result
}

// FilterSuppressed drops fixes whose source location carries a //nolint:erraudit
// (or //nolint:legacyerrors / bare //nolint) directive. This makes the fix
// command respect suppression uniformly across all analyzers (legacyerrors and
// oopsfix), consistent with the domain-level suppression applied by the analyze,
// watch, pipeline, and lint paths. Recognizes both the blanket
// //nolint:erraudit form (suppresses every category) and the specific
// //nolint:erraudit:<category> form (matched against Fix.Category).
func FilterSuppressed(fixes []Fix) []Fix {
	if len(fixes) == 0 {
		return fixes
	}

	files := make([]string, 0, len(fixes))
	seen := make(map[string]struct{}, len(fixes))

	for _, f := range fixes {
		if f.FilePath == "" {
			continue
		}

		if _, ok := seen[f.FilePath]; ok {
			continue
		}

		seen[f.FilePath] = struct{}{}
		files = append(files, f.FilePath)
	}

	engine := suppression.BuildEngineFromFiles(files)
	if engine.RuleCount() == 0 {
		return fixes
	}

	result := make([]Fix, 0, len(fixes))

	for _, f := range fixes {
		if engine.ShouldSuppress(types.ErrorType(f.Category), f.FilePath, f.Line, "") {
			continue
		}

		result = append(result, f)
	}

	return result
}

// isPathExcluded reports whether path matches any of the excluded path patterns.
func isPathExcluded(path string, excluded []string) bool {
	for _, pattern := range excluded {
		matched, err := filepath.Match(pattern, path)
		if err == nil && matched {
			return true
		}

		// Also check suffix and directory containment.
		if filepath.IsAbs(pattern) {
			if pattern == path || isSubPath(path, pattern) {
				return true
			}
		} else {
			if matched, _ := filepath.Match( //nolint:erraudit // ErrBadPattern means the pattern is malformed, not the path
				pattern,
				filepath.Base(path),
			); matched {
				return true
			}

			if containsPathSegment(path, pattern) {
				return true
			}
		}
	}

	return false
}

// isSubPath reports whether child is within parent.
func isSubPath(child, parent string) bool {
	rel, err := filepath.Rel(parent, child)
	if err != nil {
		return false
	}

	return rel != ".." && !filepath.IsAbs(rel) && rel != "."
}

// containsPathSegment reports whether path contains the given segment
// (e.g., "vendor" matches "foo/vendor/bar.go").
func containsPathSegment(path, segment string) bool {
	for {
		if filepath.Base(path) == segment {
			return true
		}

		parent := filepath.Dir(path)
		if parent == path {
			return false
		}

		path = parent
	}
}
