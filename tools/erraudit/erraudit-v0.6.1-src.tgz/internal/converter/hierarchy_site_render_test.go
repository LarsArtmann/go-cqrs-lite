package converter

import (
	"bytes"
	"go/token"
	"strings"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// Tests for the inline-wrap evidence rendering: site children under error
// nodes, centrality root ordering, package grouping, the unreferenced
// annotation, and the ASCII site cap.

func siteTestHierarchy() *types.ErrorHierarchy {
	h := &types.ErrorHierarchy{
		RootErrors: []*types.ErrorNode{
			{Name: "ErrDead", Position: token.Position{Filename: "other/dead.go", Line: 9}},
			{Name: "ErrHub", Position: token.Position{Filename: "pixy/pixy.go", Line: 8}},
		},
		Metrics: types.HierarchyMetrics{
			InlineWrapSites: 2,
			WrapSitesByError: map[string]uint{
				"ErrHub": 2,
			},
			CheckSitesByError: map[string]uint{
				"ErrHub": 1,
			},
			WrapSiteRefs: map[string][]types.ErrorSiteRef{
				"ErrHub": {
					{Position: token.Position{Filename: "pixy/pixy.go", Line: 20}, Function: "send"},
					{Position: token.Position{Filename: "pixy/pixy.go", Line: 13}, Function: "connect"},
				},
			},
			CheckSiteRefs: map[string][]types.ErrorSiteRef{
				"ErrHub": {
					{Position: token.Position{Filename: "pixy/handlers.go", Line: 3}, Function: "check"},
				},
			},
		},
	}

	// Production copies per-error counts onto nodes (applyNodeReferenceCounts
	// in the ast package) before rendering; mirror that here.
	for _, node := range h.RootErrors {
		node.InlineWraps = h.Metrics.WrapSitesByError[node.Name]
		node.Checks = h.Metrics.CheckSitesByError[node.Name]
	}

	return h
}

func renderTree(t *testing.T, h *types.ErrorHierarchy, opts TreeOptions) string {
	t.Helper()

	var buf bytes.Buffer

	require.NoError(t, WriteHierarchyTree(&buf, "", h, opts, false))

	return buf.String()
}

func TestWriteHierarchyTree_SiteChildren(t *testing.T) {
	out := renderTree(t, siteTestHierarchy(), TreeOptions{ShowWrapSites: true})

	assert.Contains(t, out, "wrapped @pixy/pixy.go:13 connect")
	assert.Contains(t, out, "wrapped @pixy/pixy.go:20 send")
	assert.Contains(t, out, "checked @pixy/handlers.go:3 check")

	// Deterministic position order: line 13 renders before line 20.
	assert.Less(t, strings.Index(out, ":13 connect"), strings.Index(out, ":20 send"))

	// Wrap sites render before check sites.
	assert.Less(t, strings.Index(out, "wrapped @"), strings.Index(out, "checked @"))
}

func TestWriteHierarchyTree_SiteChildrenOffByDefault(t *testing.T) {
	out := renderTree(t, siteTestHierarchy(), TreeOptions{})

	assert.NotContains(t, out, "wrapped @")
	assert.Contains(t, out, "2 inline wraps", "counts still annotate labels")
}

func TestWriteHierarchyTree_SiteChildrenCapped(t *testing.T) {
	out := renderTree(t, siteTestHierarchy(), TreeOptions{ShowWrapSites: true, MaxSites: 2})

	assert.Contains(t, out, "wrapped @pixy/pixy.go:13 connect")
	assert.Contains(t, out, "+1 more site(s)")
	assert.NotContains(t, out, "checked @", "cap applies across wrap and check sites combined")
}

func TestWriteHierarchyMarkdown_SiteChildrenUncapped(t *testing.T) {
	var buf bytes.Buffer

	require.NoError(
		t,
		WriteHierarchyMarkdown(&buf, "", siteTestHierarchy(), TreeOptions{ShowWrapSites: true, MaxSites: 1}),
	)

	out := buf.String()

	assert.Contains(t, out, "- wrapped @pixy/pixy.go:13 connect")
	assert.Contains(t, out, "- wrapped @pixy/pixy.go:20 send", "Markdown is never capped")
	assert.Contains(t, out, "- checked @pixy/handlers.go:3 check")
	assert.NotContains(t, out, "more site(s)")
}

func TestWriteHierarchyTree_CentralitySortWhenFlat(t *testing.T) {
	out := renderTree(t, siteTestHierarchy(), TreeOptions{})

	// ErrHub (2 wraps, 1 check) surfaces before ErrDead (0 references)
	// even though ErrDead comes later alphabetically too — assert hub first.
	hubIdx := strings.Index(out, "ErrHub")
	deadIdx := strings.Index(out, "ErrDead")

	require.GreaterOrEqual(t, hubIdx, 0)
	require.GreaterOrEqual(t, deadIdx, 0)
	assert.Less(t, hubIdx, deadIdx, "most-referenced error must surface first when flat")
}

func TestWriteHierarchyTree_NameSortOverridesCentrality(t *testing.T) {
	out := renderTree(t, siteTestHierarchy(), TreeOptions{Sort: TreeSortName})

	hubIdx := strings.Index(out, "ErrHub")
	deadIdx := strings.Index(out, "ErrDead")

	assert.Less(t, deadIdx, hubIdx, "--sort name keeps the incoming order (ErrDead was declared first)")
}

func TestSortRootsForRender_NeverMutatesInput(t *testing.T) {
	h := siteTestHierarchy()

	roots := h.RootErrors
	_ = sortRootsForRender(roots, h, TreeOptions{Sort: TreeSortWraps})

	assert.Same(t, roots[0], h.RootErrors[0], "h.RootErrors is shared cache state and must not be reordered")
}

func TestWriteHierarchyTree_GroupingByDirectory(t *testing.T) {
	out := renderTree(t, siteTestHierarchy(), TreeOptions{GroupByPackage: true})

	assert.Contains(t, out, "other (1)")
	assert.Contains(t, out, "pixy (1)")
	assert.NotContains(t, out, "(root)", "no root-directory nodes in this fixture")
}

func TestWriteHierarchyTree_GroupingSkippedForSingleDirectory(t *testing.T) {
	h := siteTestHierarchy()
	h.RootErrors[0].Position = token.Position{Filename: "pixy/dead.go", Line: 1}

	out := renderTree(t, h, TreeOptions{GroupByPackage: true})

	assert.NotContains(t, out, "pixy (2)", "a single group renders without a header container")
}

func TestReferenceAnnotation_UnreferencedRequiresNoDeclaredConnection(t *testing.T) {
	h := siteTestHierarchy()
	h.Relationships = []types.ErrorRelationship{
		{Parent: "ErrWrapper", Child: "ErrDead"},
	}

	dead := h.RootErrors[0]

	assert.Equal(t, " · unreferenced", referenceAnnotation(dead, false))
	assert.Empty(t, referenceAnnotation(dead, true), "a declared relationship (as child) means the sentinel is in use")
}

func TestWriteHierarchyTree_UnreferencedAnnotation(t *testing.T) {
	out := renderTree(t, siteTestHierarchy(), TreeOptions{})

	assert.Contains(t, out, "ErrDead @other/dead.go:9 · unreferenced")
	assert.Contains(t, out, "ErrHub @pixy/pixy.go:8 · 2 inline wraps · 1 check")
	assert.NotContains(t, out, "ErrHub @pixy/pixy.go:8 · unreferenced")
}

func TestIsValidTreeSortMode(t *testing.T) {
	assert.True(t, IsValidTreeSortMode("auto"))
	assert.True(t, IsValidTreeSortMode("wraps"))
	assert.True(t, IsValidTreeSortMode("name"))
	assert.False(t, IsValidTreeSortMode(""))
	assert.False(t, IsValidTreeSortMode("bogus"))
}
