package converter

import (
	"fmt"
	"io"
	"strconv"
	"strings"

	"github.com/larsartmann/erraudit/pkg/types"
)

// ANSI escape sequences for terminal styling. Used only when useColor is true.
const (
	ansiReset     = "\033[0m"
	ansiBold      = "\033[1m"
	ansiDim       = "\033[2m"
	ansiRed       = "\033[31m"
	ansiGreen     = "\033[32m"
	ansiYellow    = "\033[33m"
	ansiBlue      = "\033[34m"
	ansiMagenta   = "\033[35m"
	ansiCyan      = "\033[36m"
	ansiWhite     = "\033[37m"
	ansiBoldRed   = "\033[1;31m"
	ansiBoldCyan  = "\033[1;36m"
	ansiBoldWhite = "\033[1;37m"
)

// colorizer conditionally wraps text with ANSI escape codes.
// When color is false, all methods return the plain text unchanged.
type colorizer struct {
	color bool
}

func (c colorizer) wrap(code, text string) string {
	if !c.color {
		return text
	}

	return code + text + ansiReset
}

// kindColor returns the ANSI color code for an error kind badge.
func kindColor(kind types.ErrorKind) string {
	switch kind {
	case types.ErrorKindSentinel, types.ErrorKindNew:
		return ansiBlue
	case types.ErrorKindErrorf, types.ErrorKindWrap:
		return ansiYellow
	case types.ErrorKindCustom:
		return ansiMagenta
	case types.ErrorKindFamilyNew, types.ErrorKindFamilyWrap:
		return ansiGreen
	case types.ErrorKindOopsErrorf, types.ErrorKindOopsWrap:
		return ansiCyan
	case types.ErrorKindJoin:
		return ansiMagenta
	default:
		return ansiBlue
	}
}

// WriteHierarchyTree renders the error hierarchy as a styled ASCII tree.
// Each segment of the label (name, kind, position, violations) gets its own
// color, making the tree far more scannable than a uniform-colored render.
// When useColor is false, output is plain text with no ANSI codes.
func WriteHierarchyTree(
	w io.Writer,
	pkg string,
	h *types.ErrorHierarchy,
	opts TreeOptions,
	useColor bool,
) error {
	if h == nil || len(h.RootErrors) == 0 {
		return nil
	}

	c := colorizer{color: useColor}

	// Root node
	rootLabel := c.wrap(ansiBoldCyan, "Error Hierarchy")
	if pkg != "" {
		rootLabel += " " + c.wrap(ansiDim, "("+pkg+")")
	}

	fmt.Fprintf(w, "%s %s\n", c.wrap(ansiDim, "└──"), rootLabel)

	groups := buildRenderGroups(h, opts)

	for gi, group := range groups {
		isLastGroup := gi == len(groups)-1

		if group.Label != "" {
			connector := "├── "
			if isLastGroup {
				connector = "└── "
			}

			fmt.Fprintf(w, "%s%s\n", c.wrap(ansiDim, "    "+connector), c.wrap(ansiBold, group.Label))
		}

		indent := "    "
		if group.Label != "" {
			indent = "        "
			if !isLastGroup {
				indent = "    │       "
			}
		}

		writeStyledNodes(w, h, group.Nodes, indent, opts, 1, c)
	}

	// Stats footer: makes even a flat hierarchy self-describing — a bare
	// list of sentinels with zero relationships otherwise reads as a
	// meaningless dump rather than "no wrapping exists here".
	fmt.Fprintln(w, c.wrap(ansiDim, hierarchyStatsFooter(h)))

	return nil
}

// WriteHierarchyMarkdown renders the error hierarchy as a Markdown bullet list.
// No ANSI codes are emitted regardless of opts — Markdown is always plain text.
func WriteHierarchyMarkdown(
	w io.Writer,
	pkg string,
	h *types.ErrorHierarchy,
	opts TreeOptions,
) error {
	if h == nil || len(h.RootErrors) == 0 {
		return nil
	}

	rootLabel := "Error Hierarchy"
	if pkg != "" {
		rootLabel += " (" + pkg + ")"
	}

	fmt.Fprintf(w, "- %s\n", rootLabel)

	for _, group := range buildRenderGroups(h, opts) {
		depth := 1

		if group.Label != "" {
			fmt.Fprintf(w, "  - %s\n", group.Label)

			depth = 2
		}

		for _, node := range group.Nodes {
			writeMarkdownNode(w, h, node, opts, depth, declConnectedNames(h))
		}
	}

	return nil
}

// hierarchyStatsFooter composes the summary line under the tree: error and
// relationship counts, max depth, and — when present — the inline reference
// totals that live outside the declared hierarchy.
func hierarchyStatsFooter(h *types.ErrorHierarchy) string {
	footer := fmt.Sprintf("%d errors · %d relationships · max depth %d",
		h.Metrics.TotalNamedErrors,
		h.Metrics.TotalRelationships,
		h.Metrics.MaxDepth)

	if h.Metrics.InlineWrapSites > 0 {
		footer += " · " + pluralizeCount(uint64(h.Metrics.InlineWrapSites), "inline wrap site")
	}

	if checkTotal := h.Metrics.TotalCheckSites(); checkTotal > 0 {
		footer += " · " + pluralizeCount(uint64(checkTotal), "sentinel check")
	}

	if h.Metrics.TypeCheckSites > 0 {
		footer += " · " + pluralizeCount(uint64(h.Metrics.TypeCheckSites), "type check")
	}

	return footer
}

// writeStyledNodes renders error nodes as indented ASCII tree branches.
func writeStyledNodes(
	w io.Writer,
	h *types.ErrorHierarchy,
	nodes []*types.ErrorNode,
	indent string,
	opts TreeOptions,
	depth int,
	c colorizer,
) {
	for i, node := range nodes {
		isLast := i == len(nodes)-1

		connector := "├── "
		if isLast {
			connector = "└── "
		}

		label := buildStyledLabel(node, opts, c, declConnectedNames(h))

		fmt.Fprintf(w, "%s%s\n", c.wrap(ansiDim, indent+connector), label)

		childIndent := indent + "    "
		if !isLast {
			childIndent = indent + "│   "
		}

		for _, siteLabel := range siteChildLabels(h, node, opts, true) {
			fmt.Fprintf(w, "%s%s\n", c.wrap(ansiDim, childIndent+"  · "), c.wrap(ansiDim, siteLabel))
		}

		if opts.MaxDepth > 0 && depth >= opts.MaxDepth {
			continue
		}

		if len(node.Children) > 0 {
			writeStyledNodes(w, h, node.Children, childIndent, opts, depth+1, c)
		}
	}
}

// buildStyledLabel composes a label string from node data, with each segment
// independently colored: name (bold white), kind badge (by kind), position
// (dim), occurrences (dim), violations (bold red).
func buildStyledLabel(node *types.ErrorNode, opts TreeOptions, c colorizer, declConnected map[string]bool) string {
	name := displayName(node)

	var b strings.Builder

	b.WriteString(c.wrap(ansiBoldWhite, name))

	if !opts.NoKind && node.Kind != "" {
		b.WriteString(" ")
		b.WriteString(c.wrap(kindColor(node.Kind), "["+string(node.Kind)+"]"))
	}

	if !opts.NoPosition {
		if pos := shortPosition(node.Position); pos != "" {
			b.WriteString(" ")
			b.WriteString(c.wrap(ansiDim, "@"+pos))
		}
	}

	if node.Occurrences > 1 {
		count := "(" + strconv.FormatUint(uint64(node.Occurrences), 10) + ")"

		b.WriteString(" ")
		b.WriteString(c.wrap(ansiCyan, count))
	}

	if node.Violations > 0 {
		violations := "[" + strconv.FormatUint(uint64(node.Violations), 10) + " violations]"

		b.WriteString(" ")
		b.WriteString(c.wrap(ansiBoldRed, violations))
	}

	if annotation := referenceAnnotation(node, declConnected[displayName(node)]); annotation != "" {
		b.WriteString(c.wrap(ansiDim, annotation))
	}

	return b.String()
}

// writeMarkdownNode renders a single error node and its descendants as
// nested Markdown bullet items.
func writeMarkdownNode(
	w io.Writer,
	h *types.ErrorHierarchy,
	node *types.ErrorNode,
	opts TreeOptions,
	depth int,
	declConnected map[string]bool,
) {
	indent := strings.Repeat("  ", depth)

	label := buildPlainLabel(node, opts, declConnected)

	fmt.Fprintf(w, "%s- %s\n", indent, label)

	for _, site := range siteChildLabels(h, node, opts, false) {
		fmt.Fprintf(w, "%s  - %s\n", indent, site)
	}

	if opts.MaxDepth > 0 && depth >= opts.MaxDepth {
		return
	}

	for _, child := range node.Children {
		writeMarkdownNode(w, h, child, opts, depth+1, declConnected)
	}
}

// buildPlainLabel builds a label without any ANSI styling for Markdown output.
func buildPlainLabel(node *types.ErrorNode, opts TreeOptions, declConnected map[string]bool) string {
	name := displayName(node)

	var b strings.Builder

	b.WriteString(name)

	if !opts.NoKind && node.Kind != "" {
		b.WriteString(" [" + string(node.Kind) + "]")
	}

	if !opts.NoPosition {
		if pos := shortPosition(node.Position); pos != "" {
			b.WriteString(" @")
			b.WriteString(pos)
		}
	}

	if node.Occurrences > 1 {
		b.WriteString(" (x")
		b.WriteString(strconv.FormatUint(uint64(node.Occurrences), 10))
		b.WriteString(")")
	}

	if node.Violations > 0 {
		b.WriteString(" [")
		b.WriteString(strconv.FormatUint(uint64(node.Violations), 10))
		b.WriteString(" violations]")
	}

	b.WriteString(referenceAnnotation(node, declConnected[displayName(node)]))

	return b.String()
}
