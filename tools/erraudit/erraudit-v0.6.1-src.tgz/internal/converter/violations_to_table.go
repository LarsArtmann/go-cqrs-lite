// Package converter transforms erraudit domain types into go-output
// data models (Table, TreeNode, GraphBuilder) for rendering in any
// of the 16+ output formats supported by go-output.
package converter

import (
	"maps"
	"slices"
	"strconv"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/larsartmann/go-output"
)

// ViolationsToTable converts a slice of ErrorViolations into an output.Table
// with columns: Type, Severity, File, Line, Column, Message. When any
// violation has a populated Explanation field (i.e. --explain is active), an
// Explanation column is appended.
func ViolationsToTable(violations []types.ErrorViolation) *output.Table {
	hasExplanation := false

	for _, v := range violations {
		if v.Explanation != "" {
			hasExplanation = true

			break
		}
	}

	headers := []string{"Type", "Severity", "File", "Line", "Column", "Message"}
	if hasExplanation {
		headers = append(headers, "Explanation")
	}

	t := output.NewTable(headers)

	for _, v := range violations {
		row := []string{
			string(v.Type),
			string(v.Severity),
			v.Position.Filename,
			strconv.Itoa(v.Position.Line),
			strconv.Itoa(v.Position.Column),
			v.Message,
		}
		if hasExplanation {
			row = append(row, v.Explanation)
		}

		t.AddRow(row)
	}

	return t
}

// MetricsToTable converts ErrorMetrics into a two-column output.Table
// with columns: Metric, Value.
func MetricsToTable(metrics types.ErrorMetrics) *output.Table {
	t := output.NewTable([]string{"Metric", "Value"})

	t.AddRow([]string{"Total Errors", strconv.FormatUint(uint64(metrics.TotalErrors), 10)})
	t.AddRow([]string{"Max Wrap Depth", strconv.FormatUint(uint64(metrics.WrapDepth), 10)})
	t.AddRow([]string{"Error Returns", strconv.FormatUint(uint64(metrics.ErrorReturns), 10)})
	t.AddRow([]string{"Error Wraps", strconv.FormatUint(uint64(metrics.ErrorWraps), 10)})
	t.AddRow([]string{"Silent Swallows", strconv.FormatUint(uint64(metrics.SilentSwallows), 10)})
	t.AddRow([]string{"Panics On Errors", strconv.FormatUint(uint64(metrics.PanicsOnErrors), 10)})
	t.AddRow([]string{"Ignored Errors", strconv.FormatUint(uint64(metrics.IgnoredErrors), 10)})

	sortedCommon := slices.Sorted(maps.Keys(metrics.MostCommonErrors))
	for _, name := range sortedCommon {
		t.AddRow([]string{"Common: " + name, strconv.FormatUint(uint64(metrics.MostCommonErrors[name]), 10)})
	}

	return t
}
