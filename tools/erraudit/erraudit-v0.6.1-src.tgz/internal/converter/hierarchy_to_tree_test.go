package converter

import (
	"go/token"
	"os"
	"strconv"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
)

func TestHierarchyToTreeNode_RootLabelWithPackage(t *testing.T) {
	h := &types.ErrorHierarchy{
		RootErrors: []*types.ErrorNode{
			{Name: "ErrFoo", Kind: types.ErrorKindSentinel},
		},
	}

	root := HierarchyToTreeNode("github.com/example/pkg", h, TreeOptions{})

	assert.Equal(t, "Error Hierarchy (github.com/example/pkg)", root.Label.Get())
	assert.Len(t, root.Children, 1)
}

func TestHierarchyToTreeNode_RootLabelWithoutPackage(t *testing.T) {
	h := &types.ErrorHierarchy{
		RootErrors: []*types.ErrorNode{
			{Name: "ErrFoo"},
		},
	}

	root := HierarchyToTreeNode("", h, TreeOptions{})

	assert.Equal(t, "Error Hierarchy", root.Label.Get())
}

func TestHierarchyToTreeNode_NestedChildren(t *testing.T) {
	h := &types.ErrorHierarchy{
		RootErrors: []*types.ErrorNode{
			{
				Name: "ErrRoot",
				Children: []*types.ErrorNode{
					{Name: "ErrChild1"},
					{Name: "ErrChild2", Children: []*types.ErrorNode{
						{Name: "ErrGrandchild"},
					}},
				},
			},
		},
	}

	root := HierarchyToTreeNode("", h, TreeOptions{})

	require := assert.New(t)
	require.Len(root.Children, 1)

	top := root.Children[0]
	require.Equal("ErrRoot", top.Label.Get())
	require.Len(top.Children, 2)
	require.Equal("ErrChild1 · unreferenced", top.Children[0].Label.Get())

	nested := top.Children[1]
	require.Equal("ErrChild2", nested.Label.Get())
	require.Len(nested.Children, 1)
	require.Equal("ErrGrandchild · unreferenced", nested.Children[0].Label.Get())
}

func TestHierarchyToTreeNode_LabelIncludesKindAndPosition(t *testing.T) {
	h := &types.ErrorHierarchy{
		RootErrors: []*types.ErrorNode{
			{
				Name: "ErrNotFound",
				Kind: types.ErrorKindSentinel,
				Position: token.Position{
					Filename: "/project/pkg/errors.go",
					Line:     42,
				},
			},
		},
	}

	root := HierarchyToTreeNode("", h, TreeOptions{})

	assert.Equal(t, "ErrNotFound [sentinel] @errors.go:42 · unreferenced", root.Children[0].Label.Get())
}

func TestHierarchyToTreeNode_LabelOmitsEmptyKindAndPosition(t *testing.T) {
	h := &types.ErrorHierarchy{
		RootErrors: []*types.ErrorNode{
			{Name: "ErrPlain"},
		},
	}

	root := HierarchyToTreeNode("", h, TreeOptions{})

	assert.Equal(t, "ErrPlain · unreferenced", root.Children[0].Label.Get())
}

func TestHierarchyToTreeNode_AnonymousErrorGetsPlaceholder(t *testing.T) {
	h := &types.ErrorHierarchy{
		RootErrors: []*types.ErrorNode{
			{Name: "", Kind: types.ErrorKindCustom},
		},
	}

	root := HierarchyToTreeNode("", h, TreeOptions{})

	assert.Equal(t, "<anonymous> [custom_type] · unreferenced", root.Children[0].Label.Get())
}

func TestHierarchyToTreeNode_EmptyHierarchy(t *testing.T) {
	h := &types.ErrorHierarchy{}

	root := HierarchyToTreeNode("", h, TreeOptions{})

	assert.Equal(t, "Error Hierarchy", root.Label.Get())
	assert.Empty(t, root.Children)
}

func TestHierarchyToTreeNode_MultipleRootErrors(t *testing.T) {
	h := &types.ErrorHierarchy{
		RootErrors: []*types.ErrorNode{
			{Name: "ErrA"},
			{Name: "ErrB"},
			{Name: "ErrC"},
		},
	}

	root := HierarchyToTreeNode("", h, TreeOptions{})

	assert.Len(t, root.Children, 3)
	assert.Equal(t, "ErrA · unreferenced", root.Children[0].Label.Get())
	assert.Equal(t, "ErrB · unreferenced", root.Children[1].Label.Get())
	assert.Equal(t, "ErrC · unreferenced", root.Children[2].Label.Get())
}

func TestHierarchyToTreeNode_OccurrencesShownWhenGreaterThanOne(t *testing.T) {
	h := &types.ErrorHierarchy{
		RootErrors: []*types.ErrorNode{
			{Name: "ErrRepeated", Occurrences: 3},
		},
	}

	root := HierarchyToTreeNode("", h, TreeOptions{})

	assert.Equal(t, "ErrRepeated (x3) · unreferenced", root.Children[0].Label.Get())
}

func TestHierarchyToTreeNode_OccurrencesOmittedWhenOne(t *testing.T) {
	h := &types.ErrorHierarchy{
		RootErrors: []*types.ErrorNode{
			{Name: "ErrSingle", Occurrences: 1},
		},
	}

	root := HierarchyToTreeNode("", h, TreeOptions{})

	assert.Equal(t, "ErrSingle · unreferenced", root.Children[0].Label.Get())
}

func TestHierarchyToTreeNode_ViolationsShownWhenGreaterThanZero(t *testing.T) {
	h := &types.ErrorHierarchy{
		RootErrors: []*types.ErrorNode{
			{Name: "ErrBad", Violations: 5},
		},
	}

	root := HierarchyToTreeNode("", h, TreeOptions{})

	assert.Equal(t, "ErrBad [5 violations] · unreferenced", root.Children[0].Label.Get())
}

func TestHierarchyToTreeNode_ViolationsOmittedWhenZero(t *testing.T) {
	h := &types.ErrorHierarchy{
		RootErrors: []*types.ErrorNode{
			{Name: "ErrClean", Violations: 0},
		},
	}

	root := HierarchyToTreeNode("", h, TreeOptions{})

	assert.Equal(t, "ErrClean · unreferenced", root.Children[0].Label.Get())
}

func TestHierarchyToTreeNode_OccurrencesAndViolationsTogether(t *testing.T) {
	h := &types.ErrorHierarchy{
		RootErrors: []*types.ErrorNode{
			{Name: "ErrComplex", Kind: types.ErrorKindSentinel, Occurrences: 4, Violations: 2},
		},
	}

	root := HierarchyToTreeNode("", h, TreeOptions{})

	assert.Equal(t, "ErrComplex [sentinel] (x4) [2 violations] · unreferenced", root.Children[0].Label.Get())
}

func TestHierarchyToTreeNode_NoPositionSuppressesPosition(t *testing.T) {
	h := &types.ErrorHierarchy{
		RootErrors: []*types.ErrorNode{
			{
				Name: "ErrNoPos",
				Kind: types.ErrorKindSentinel,
				Position: token.Position{
					Filename: "/project/pkg/errors.go",
					Line:     10,
				},
			},
		},
	}

	root := HierarchyToTreeNode("", h, TreeOptions{NoPosition: true})

	assert.Equal(t, "ErrNoPos [sentinel] · unreferenced", root.Children[0].Label.Get())
}

func TestHierarchyToTreeNode_NoKindSuppressesKind(t *testing.T) {
	h := &types.ErrorHierarchy{
		RootErrors: []*types.ErrorNode{
			{Name: "ErrNoKind", Kind: types.ErrorKindSentinel},
		},
	}

	root := HierarchyToTreeNode("", h, TreeOptions{NoKind: true})

	assert.Equal(t, "ErrNoKind · unreferenced", root.Children[0].Label.Get())
}

func TestHierarchyToTreeNode_NoPositionAndNoKindTogether(t *testing.T) {
	h := &types.ErrorHierarchy{
		RootErrors: []*types.ErrorNode{
			{
				Name: "ErrBare",
				Kind: types.ErrorKindCustom,
				Position: token.Position{
					Filename: "/project/pkg/errors.go",
					Line:     1,
				},
				Occurrences: 2,
			},
		},
	}

	root := HierarchyToTreeNode("", h, TreeOptions{NoPosition: true, NoKind: true})

	assert.Equal(t, "ErrBare (x2) · unreferenced", root.Children[0].Label.Get())
}

func TestHierarchyToTreeNode_MaxDepthLimitsRecursion(t *testing.T) {
	h := &types.ErrorHierarchy{
		RootErrors: []*types.ErrorNode{
			{
				Name: "ErrRoot",
				Children: []*types.ErrorNode{
					{Name: "ErrChild", Children: []*types.ErrorNode{
						{Name: "ErrGrandchild", Children: []*types.ErrorNode{
							{Name: "ErrGreat"},
						}},
					}},
				},
			},
		},
	}

	root := HierarchyToTreeNode("", h, TreeOptions{MaxDepth: 2})

	require := assert.New(t)
	require.Len(root.Children, 1)
	require.Equal("ErrRoot", root.Children[0].Label.Get())

	top := root.Children[0]
	require.Len(top.Children, 1)
	require.Equal("ErrChild", top.Children[0].Label.Get())

	child := top.Children[0]
	require.Empty(child.Children, "depth 2 should prevent grandchildren")
}

func TestHierarchyToTreeNode_MaxDepthZeroIsUnlimited(t *testing.T) {
	h := &types.ErrorHierarchy{
		RootErrors: []*types.ErrorNode{
			{
				Name: "ErrRoot",
				Children: []*types.ErrorNode{
					{Name: "ErrChild", Children: []*types.ErrorNode{
						{Name: "ErrGrandchild"},
					}},
				},
			},
		},
	}

	root := HierarchyToTreeNode("", h, TreeOptions{MaxDepth: 0})

	require := assert.New(t)
	require.Len(root.Children, 1)

	top := root.Children[0]
	require.Equal("ErrRoot", top.Label.Get())
	require.Len(top.Children, 1)

	child := top.Children[0]
	require.Equal("ErrChild", child.Label.Get())
	require.Len(child.Children, 1)

	grandchild := child.Children[0]
	require.Equal("ErrGrandchild · unreferenced", grandchild.Label.Get())
	require.Empty(grandchild.Children)
}

func TestShortPosition(t *testing.T) {
	tests := []struct {
		name string
		pos  token.Position
		want string
	}{
		{
			name: "file and line",
			pos:  token.Position{Filename: "/project/pkg/errors.go", Line: 10},
			want: "errors.go:10",
		},
		{
			name: "filename only no line",
			pos:  token.Position{Filename: "/project/pkg/errors.go"},
			want: "errors.go",
		},
		{
			name: "empty position",
			pos:  token.Position{},
			want: "",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			assert.Equal(t, tt.want, shortPosition(tt.pos))
		})
	}
}

// buildChainHierarchy creates a hierarchy with the given depth and branching
// factor for benchmarking. Each non-leaf node gets `branching` children.
func buildChainHierarchy(depth, branching int) *types.ErrorHierarchy {
	if depth <= 0 {
		return &types.ErrorHierarchy{}
	}

	return &types.ErrorHierarchy{
		RootErrors: []*types.ErrorNode{buildChainNode(0, depth, branching)},
	}
}

func buildChainNode(currentDepth, maxDepth, branching int) *types.ErrorNode {
	node := &types.ErrorNode{
		Name:        "Err" + strconv.Itoa(currentDepth),
		Kind:        types.ErrorKindSentinel,
		Occurrences: uint(currentDepth + 1),
		Violations:  uint(currentDepth),
	}

	if currentDepth+1 < maxDepth {
		node.Children = make([]*types.ErrorNode, branching)
		for i := range node.Children {
			node.Children[i] = buildChainNode(currentDepth+1, maxDepth, branching)
		}
	}

	return node
}

func BenchmarkHierarchyToTreeNode(b *testing.B) {
	benchmarks := []struct {
		name      string
		depth     int
		branching int
	}{
		{"shallow_narrow", 3, 2},
		{"shallow_wide", 3, 5},
		{"deep_narrow", 10, 2},
		{"deep_wide", 5, 4},
	}

	for _, bm := range benchmarks {
		h := buildChainHierarchy(bm.depth, bm.branching)

		b.Run(bm.name, func(b *testing.B) {
			b.ReportAllocs()

			for b.Loop() {
				_ = HierarchyToTreeNode("bench", h, TreeOptions{})
			}
		})
	}
}

func TestHierarchyToTreeNode_ReferenceAnnotation(t *testing.T) {
	h := &types.ErrorHierarchy{
		RootErrors: []*types.ErrorNode{
			{Name: "ErrChecked", InlineWraps: 1, Checks: 3},
			{Name: "ErrUnreferenced"},
		},
	}

	root := HierarchyToTreeNode("", h, TreeOptions{})

	assert.Equal(
		t,
		"ErrChecked · 1 inline wrap · 3 checks",
		root.Children[0].Label.Get(),
		"reference counts render singular/plural correctly",
	)
	assert.Equal(
		t,
		"ErrUnreferenced · unreferenced",
		root.Children[1].Label.Get(),
		"zero-reference childless nodes are marked as unreferenced (dead-sentinel candidates)",
	)
}

func TestShortPosition_RelativeUnderWorkingDir(t *testing.T) {
	// An absolute path under the working directory renders as a navigable
	// relative path, not a bare base name (the base name is ambiguous in
	// multi-package trees).
	wd, err := os.Getwd()
	if err != nil {
		t.Skip("working directory unavailable")
	}

	pos := token.Position{Filename: wd + "/internal/pbx/client.go", Line: 43}

	assert.Equal(t, "internal/pbx/client.go:43", shortPosition(pos))
	assert.Equal(
		t,
		"errors.go:10",
		shortPosition(token.Position{Filename: "errors.go", Line: 10}),
		"relative paths pass through",
	)
}
