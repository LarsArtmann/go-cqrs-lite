package converter_test

import (
	"bytes"
	"go/token"
	"regexp"
	"strings"
	"testing"

	"github.com/larsartmann/erraudit/internal/converter"
	"github.com/larsartmann/erraudit/pkg/types"
)

func styledTestHierarchy() *types.ErrorHierarchy {
	root := &types.ErrorNode{
		Name:    "ErrBase",
		Message: "base",
		Kind:    types.ErrorKindNew,
		Position: token.Position{
			Filename: "errors.go",
			Line:     3,
			Column:   5,
		},
		Depth:       1,
		Occurrences: 1,
	}
	child := &types.ErrorNode{
		Name:    "ErrWrapped",
		Message: "wrapped: base",
		Kind:    types.ErrorKindErrorf,
		Position: token.Position{
			Filename: "errors.go",
			Line:     4,
			Column:   5,
		},
		Depth:       2,
		Occurrences: 1,
	}
	root.Children = []*types.ErrorNode{child}

	return &types.ErrorHierarchy{
		RootErrors: []*types.ErrorNode{root},
		Metrics: types.HierarchyMetrics{
			TotalNamedErrors:   2,
			TotalRelationships: 1,
			MaxDepth:           2,
		},
	}
}

func TestWriteHierarchyTree_ColorAndPlain(t *testing.T) {
	t.Parallel()

	h := styledTestHierarchy()

	var colorBuf bytes.Buffer
	if err := converter.WriteHierarchyTree(&colorBuf, "pkg", h, converter.TreeOptions{}, true); err != nil {
		t.Fatalf("WriteHierarchyTree(color) error: %v", err)
	}

	colorOut := colorBuf.String()
	if !strings.Contains(colorOut, "\033[") {
		t.Error("color output must contain ANSI escape codes")
	}

	for _, want := range []string{"ErrBase", "ErrWrapped", "Error Hierarchy", "(pkg)", "2 errors", "max depth 2"} {
		if !strings.Contains(colorOut, want) {
			t.Errorf("color output missing %q", want)
		}
	}

	var plainBuf bytes.Buffer
	if err := converter.WriteHierarchyTree(&plainBuf, "pkg", h, converter.TreeOptions{}, false); err != nil {
		t.Fatalf("WriteHierarchyTree(plain) error: %v", err)
	}

	plainOut := plainBuf.String()
	if strings.Contains(plainOut, "\033[") {
		t.Error("plain output must not contain ANSI escape codes")
	}

	for _, want := range []string{"ErrBase", "ErrWrapped", "errors.go:3"} {
		if !strings.Contains(plainOut, want) {
			t.Errorf("plain output missing %q", want)
		}
	}
}

func TestWriteHierarchyTree_NoPositionNoKind(t *testing.T) {
	t.Parallel()

	h := styledTestHierarchy()

	var buf bytes.Buffer
	opts := converter.TreeOptions{NoPosition: true, NoKind: true}
	if err := converter.WriteHierarchyTree(&buf, "", h, opts, false); err != nil {
		t.Fatalf("WriteHierarchyTree error: %v", err)
	}

	out := buf.String()
	if strings.Contains(out, "errors.go") {
		t.Error("NoPosition must omit source positions")
	}

	if strings.Contains(out, "sentinel") || strings.Contains(out, "errorf") {
		t.Error("NoKind must omit kind badges")
	}
}

func TestWriteHierarchyTree_NilAndEmpty(t *testing.T) {
	t.Parallel()

	var buf bytes.Buffer
	if err := converter.WriteHierarchyTree(&buf, "", nil, converter.TreeOptions{}, false); err != nil {
		t.Fatalf("nil hierarchy must not error, got %v", err)
	}

	if err := converter.WriteHierarchyTree(
		&buf,
		"",
		&types.ErrorHierarchy{},
		converter.TreeOptions{},
		false,
	); err != nil {
		t.Fatalf("empty hierarchy must not error, got %v", err)
	}

	if buf.Len() != 0 {
		t.Errorf("nil/empty hierarchy must write nothing, got %q", buf.String())
	}
}

func TestWriteHierarchyMarkdown(t *testing.T) {
	t.Parallel()

	h := styledTestHierarchy()

	var buf bytes.Buffer
	if err := converter.WriteHierarchyMarkdown(&buf, "pkg", h, converter.TreeOptions{}); err != nil {
		t.Fatalf("WriteHierarchyMarkdown error: %v", err)
	}

	out := buf.String()
	if strings.Contains(out, "\033[") {
		t.Error("markdown output must never contain ANSI codes")
	}

	for _, want := range []string{"- Error Hierarchy (pkg)", "  - ErrBase [errors.new] @errors.go:3", "    - ErrWrapped [fmt.errorf] @errors.go:4"} {
		if !strings.Contains(out, want) {
			t.Errorf("markdown output missing %q, got:\n%s", want, out)
		}
	}
}

func TestKindColor_CoversKnownKinds(t *testing.T) {
	t.Parallel()

	// The function is unexported; verify through the styled label path that
	// different kinds produce different ANSI codes (when color is on).
	kinds := []types.ErrorKind{
		types.ErrorKindSentinel,
		types.ErrorKindErrorf,
		types.ErrorKindCustom,
		types.ErrorKindFamilyNew,
		types.ErrorKindOopsErrorf,
		types.ErrorKindJoin,
	}

	seen := make(map[string]bool)
	for _, k := range kinds {
		node := &types.ErrorNode{Name: "E", Kind: k}
		h := &types.ErrorHierarchy{
			RootErrors: []*types.ErrorNode{node},
			Metrics:    types.HierarchyMetrics{TotalNamedErrors: 1},
		}

		var buf bytes.Buffer
		if err := converter.WriteHierarchyTree(
			&buf,
			"",
			h,
			converter.TreeOptions{NoPosition: true, NoKind: false},
			true,
		); err != nil {
			t.Fatalf("WriteHierarchyTree error: %v", err)
		}

		// Extract the badge segment (second ANSI-colored field in the label).
		seen[extractBadgeColor(buf.String())] = true
	}

	if len(seen) < 3 {
		t.Errorf("expected distinct badge colors across kinds, saw %d distinct: %v", len(seen), seen)
	}
}

// extractBadgeColor returns the ANSI code wrapping the kind badge — the
// escape sequence immediately preceding the badge's literal "[" — or "" when
// none is present. Used to assert kind-based color variety.
func extractBadgeColor(out string) string {
	re := regexp.MustCompile(`\x1b\[[0-9;]*m\[`)

	loc := re.FindStringIndex(out)
	if loc == nil {
		return ""
	}

	return out[loc[0] : loc[1]-1]
}

func TestWriteHierarchyTree_ReferenceAnnotationsAndFooter(t *testing.T) {
	h := &types.ErrorHierarchy{
		RootErrors: []*types.ErrorNode{
			{
				Name:        "ErrNotFound",
				Kind:        types.ErrorKindSentinel,
				Position:    token.Position{Filename: "messages.go", Line: 15},
				InlineWraps: 1,
				Checks:      3,
			},
		},
		AllNodes: map[string]*types.ErrorNode{},
		Metrics: types.HierarchyMetrics{
			TotalNamedErrors: 1,
			InlineWrapSites:  86,
		},
	}

	h.AllNodes["ErrNotFound"] = h.RootErrors[0]
	h.Metrics.CheckSitesByError = map[string]uint{"ErrNotFound": 3}

	var buf bytes.Buffer

	if err := converter.WriteHierarchyTree(
		&buf,
		"15 packages · 38 files",
		h,
		converter.TreeOptions{},
		false,
	); err != nil {
		t.Fatalf("WriteHierarchyTree: %v", err)
	}

	out := buf.String()

	for _, want := range []string{
		"Error Hierarchy (15 packages · 38 files)",
		"ErrNotFound [sentinel] @messages.go:15 · 1 inline wrap · 3 checks",
		"1 errors · 0 relationships · max depth 0 · 86 inline wrap sites · 3 sentinel checks",
	} {
		if !strings.Contains(out, want) {
			t.Errorf("tree output missing %q\nGot:\n%s", want, out)
		}
	}

	if strings.Contains(out, "└── 1 errors") {
		t.Error("stats footer must not render as a fake second tree root")
	}
}
