package converter

import (
	"go/token"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
)

func TestViolationsToTable(t *testing.T) {
	violations := []types.ErrorViolation{
		{
			Position: token.Position{Filename: "main.go", Line: 10, Column: 5},
			Type:     types.ErrorTypeSilentSwallow,
			Severity: types.SeverityHigh,
			Message:  "error silently swallowed",
		},
		{
			Position: token.Position{Filename: "util.go", Line: 20, Column: 1},
			Type:     types.ErrorTypeUnwrapped,
			Severity: types.SeverityMedium,
			Message:  "error not wrapped with %w",
		},
	}

	table := ViolationsToTable(violations)

	assert.Equal(t, []string{"Type", "Severity", "File", "Line", "Column", "Message"}, table.GetHeaders())
	assert.Equal(t, 2, table.RowCount())

	rows := table.GetRows()
	assert.Equal(t, "silent_swallow", rows[0][0])
	assert.Equal(t, "main.go", rows[0][2])
	assert.Equal(t, "10", rows[0][3])
}

func TestViolationsToTable_Empty(t *testing.T) {
	table := ViolationsToTable(nil)
	assert.Equal(t, 0, table.RowCount())
}

func TestViolationsToTable_WithExplanation(t *testing.T) {
	violations := []types.ErrorViolation{
		{
			Position:    token.Position{Filename: "main.go", Line: 10, Column: 5},
			Type:        types.ErrorTypeSilentSwallow,
			Severity:    types.SeverityHigh,
			Message:     "error silently swallowed",
			Explanation: "An if err != nil block is empty or does not handle the error.",
		},
		{
			Position:    token.Position{Filename: "util.go", Line: 20, Column: 1},
			Type:        types.ErrorTypeUnwrapped,
			Severity:    types.SeverityMedium,
			Message:     "error not wrapped with %w",
			Explanation: "fmt.Errorf creates a new error without wrapping the original.",
		},
	}

	table := ViolationsToTable(violations)

	assert.Equal(t,
		[]string{"Type", "Severity", "File", "Line", "Column", "Message", "Explanation"},
		table.GetHeaders(),
	)
	assert.Equal(t, 2, table.RowCount())

	rows := table.GetRows()
	assert.Equal(t, "An if err != nil block is empty or does not handle the error.", rows[0][6])
	assert.Equal(t, "fmt.Errorf creates a new error without wrapping the original.", rows[1][6])
}

func TestViolationsToTable_ExplanationOnlyForPopulated(t *testing.T) {
	violations := []types.ErrorViolation{
		{
			Position:    token.Position{Filename: "main.go", Line: 10, Column: 5},
			Type:        types.ErrorTypeSilentSwallow,
			Severity:    types.SeverityHigh,
			Message:     "error silently swallowed",
			Explanation: "has explanation",
		},
		{
			Position: token.Position{Filename: "util.go", Line: 20, Column: 1},
			Type:     types.ErrorTypeUnwrapped,
			Severity: types.SeverityMedium,
			Message:  "error not wrapped with %w",
		},
	}

	table := ViolationsToTable(violations)

	assert.Equal(t,
		[]string{"Type", "Severity", "File", "Line", "Column", "Message", "Explanation"},
		table.GetHeaders(),
	)

	rows := table.GetRows()
	assert.Equal(t, "has explanation", rows[0][6])
	assert.Equal(t, "", rows[1][6], "empty explanation for violations without one")
}

func TestMetricsToTable(t *testing.T) {
	metrics := types.ErrorMetrics{
		TotalErrors:    100,
		WrapDepth:      5,
		ErrorReturns:   50,
		ErrorWraps:     30,
		SilentSwallows: 10,
		PanicsOnErrors: 5,
		IgnoredErrors:  5,
		MostCommonErrors: map[string]uint{
			"fmt.Errorf": 20,
		},
	}

	table := MetricsToTable(metrics)

	assert.Equal(t, []string{"Metric", "Value"}, table.GetHeaders())
	assert.GreaterOrEqual(t, table.RowCount(), 7)
}
