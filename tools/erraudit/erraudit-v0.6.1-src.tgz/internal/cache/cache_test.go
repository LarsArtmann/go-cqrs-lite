package cache

import (
	"testing"
)

// entryWithSize is a test entry that carries a byte size for size-tracking tests.
type entryWithSize struct {
	value string
	size  int64
}

func sizeOfEntry(e entryWithSize) int64 { return e.size }

func TestBase_Init_StoreAndGet(t *testing.T) {
	t.Parallel()

	var b Base[string]
	b.Init(10, nil)

	b.Store().Set("a", "alpha")
	b.Store().Set("b", "beta")

	if v, ok := b.Store().GetIfPresent("a"); !ok || v != "alpha" {
		t.Errorf("GetIfPresent(%q) = %q, %v; want alpha, true", "a", v, ok)
	}

	if v, ok := b.Store().GetIfPresent("b"); !ok || v != "beta" {
		t.Errorf("GetIfPresent(%q) = %q, %v; want beta, true", "b", v, ok)
	}

	if _, ok := b.Store().GetIfPresent("missing"); ok {
		t.Error("GetIfPresent(missing) returned true; want false")
	}
}

func TestBase_Init_KeyCount(t *testing.T) {
	t.Parallel()

	var b Base[int]
	b.Init(100, nil)

	for i := range 5 {
		b.Store().Set(string(rune('a'+i)), i)
	}

	if got := b.KeyCount(); got != 5 {
		t.Errorf("KeyCount() = %d; want 5", got)
	}
}

func TestBase_Init_EvictionOnMaxEntries(t *testing.T) {
	t.Parallel()

	var b Base[int]
	b.Init(3, nil)

	for i := range 10 {
		b.Store().Set(string(rune('a'+i)), i)
	}
	b.Store().CleanUp()

	// All 10 were inserted but max is 3, so at most 3 remain.
	if got := b.KeyCount(); got > 3 {
		t.Errorf("KeyCount() = %d; want <= 3 after inserting 10 into max-3 cache", got)
	}

	if b.EvictionCount() == 0 {
		t.Error("EvictionCount() = 0; want > 0 after exceeding max entries")
	}
}

func TestBase_InitWithSizeTracking_TotalSize(t *testing.T) {
	t.Parallel()

	var b Base[entryWithSize]
	b.InitWithSizeTracking(100, sizeOfEntry)

	b.Store().Set("x", entryWithSize{value: "x", size: 100})
	b.AddSize(100)

	b.Store().Set("y", entryWithSize{value: "y", size: 200})
	b.AddSize(200)

	if got := b.TotalSize(); got != 300 {
		t.Errorf("TotalSize() = %d; want 300", got)
	}
}

func TestBase_InitWithSizeTracking_EvictionSubtractsSize(t *testing.T) {
	t.Parallel()

	var b Base[entryWithSize]
	b.InitWithSizeTracking(2, sizeOfEntry)

	b.Store().Set("big", entryWithSize{value: "big", size: 500})
	b.AddSize(500)

	b.Store().Set("med", entryWithSize{value: "med", size: 300})
	b.AddSize(300)

	// Insert a third entry to force eviction (max entries = 2)
	b.Store().Set("sml", entryWithSize{value: "sml", size: 100})
	b.AddSize(100)

	b.Store().CleanUp()

	// TotalSize should be <= 600 (500+300+100 minus at least one evicted entry's size)
	totalAfterEviction := b.TotalSize()
	if totalAfterEviction > 600 {
		t.Errorf("TotalSize() = %d after eviction; want <= 600", totalAfterEviction)
	}

	if b.EvictionCount() == 0 {
		t.Error("EvictionCount() = 0; want > 0 after inserting 3 into max-2 cache")
	}
}

func TestBase_Clear_RemovesEntriesAndResetsSize(t *testing.T) {
	t.Parallel()

	var b Base[entryWithSize]
	b.InitWithSizeTracking(100, sizeOfEntry)

	b.Store().Set("a", entryWithSize{value: "a", size: 42})
	b.AddSize(42)

	b.Store().Set("b", entryWithSize{value: "b", size: 58})
	b.AddSize(58)

	if got := b.KeyCount(); got != 2 {
		t.Fatalf("KeyCount() before Clear = %d; want 2", got)
	}
	if got := b.TotalSize(); got != 100 {
		t.Fatalf("TotalSize() before Clear = %d; want 100", got)
	}

	b.Clear()

	if got := b.KeyCount(); got != 0 {
		t.Errorf("KeyCount() after Clear = %d; want 0", got)
	}
	if got := b.TotalSize(); got != 0 {
		t.Errorf("TotalSize() after Clear = %d; want 0", got)
	}
}

func TestBase_Clear_DoesNotResetEvictionCount(t *testing.T) {
	t.Parallel()

	var b Base[int]
	b.Init(2, nil)

	for i := range 10 {
		b.Store().Set(string(rune('a'+i)), i)
	}
	b.Store().CleanUp()

	evictionsBefore := b.EvictionCount()
	if evictionsBefore == 0 {
		t.Fatal("EvictionCount() = 0; want > 0 before Clear")
	}

	b.Clear()

	// Clear calls InvalidateAll which triggers OnAtomicDeletion for each
	// remaining entry, so eviction count increases rather than resetting.
	if got := b.EvictionCount(); got < evictionsBefore {
		t.Errorf("EvictionCount() after Clear = %d; want >= %d (Clear evicts remaining entries)", got, evictionsBefore)
	}
}

func TestBase_Stats_AggregatesCorrectly(t *testing.T) {
	t.Parallel()

	var b Base[entryWithSize]
	b.InitWithSizeTracking(100, sizeOfEntry)

	b.Store().Set("x", entryWithSize{value: "x", size: 100})
	b.AddSize(100)

	b.Store().Set("y", entryWithSize{value: "y", size: 200})
	b.AddSize(200)

	stats := b.Stats()

	if stats.KeyCount != 2 {
		t.Errorf("Stats().KeyCount = %d; want 2", stats.KeyCount)
	}
	if stats.TotalSize != 300 {
		t.Errorf("Stats().TotalSize = %d; want 300", stats.TotalSize)
	}
	if stats.EvictionCount != 0 {
		t.Errorf("Stats().EvictionCount = %d; want 0", stats.EvictionCount)
	}
}

func TestBase_Stats_WithEvictions(t *testing.T) {
	t.Parallel()

	var b Base[int]
	b.Init(2, nil)

	for i := range 5 {
		b.Store().Set(string(rune('a'+i)), i)
	}
	b.Store().CleanUp()

	stats := b.Stats()

	if stats.KeyCount > 2 {
		t.Errorf("Stats().KeyCount = %d; want <= 2", stats.KeyCount)
	}
	if stats.EvictionCount == 0 {
		t.Error("Stats().EvictionCount = 0; want > 0")
	}
}

func TestBase_Store_ReturnsNonNil(t *testing.T) {
	t.Parallel()

	var b Base[string]
	b.Init(10, nil)

	if b.Store() == nil {
		t.Error("Store() returned nil after Init")
	}
}

func TestBase_EmptyCache_KeyCountAndSize(t *testing.T) {
	t.Parallel()

	var b Base[string]
	b.Init(10, nil)

	if got := b.KeyCount(); got != 0 {
		t.Errorf("KeyCount() on empty cache = %d; want 0", got)
	}
	if got := b.TotalSize(); got != 0 {
		t.Errorf("TotalSize() on empty cache = %d; want 0", got)
	}
	if got := b.EvictionCount(); got != 0 {
		t.Errorf("EvictionCount() on empty cache = %d; want 0", got)
	}
}

func TestBase_Init_DoesNotTrackSize(t *testing.T) {
	t.Parallel()

	var b Base[entryWithSize]
	b.Init(100, nil) // Init, not InitWithSizeTracking

	b.Store().Set("x", entryWithSize{value: "x", size: 999})
	b.AddSize(999)

	// Init uses OnAtomicDeletion without sizeOf, so TotalSize is
	// manually tracked via AddSize. Clear still resets to 0.
	if got := b.TotalSize(); got != 999 {
		t.Errorf("TotalSize() after AddSize(999) = %d; want 999", got)
	}

	b.Clear()
	if got := b.TotalSize(); got != 0 {
		t.Errorf("TotalSize() after Clear = %d; want 0", got)
	}
}
