// Package cache provides a shared size-bounded cache base built on otter.
// Package-specific caches embed Base[V] to reuse store construction, size
// accounting, Clear, and stats primitives without re-implementing them.
package cache

import (
	"slices"
	"sync/atomic"

	"github.com/maypok86/otter/v2"
)

// SizeOf extracts the byte size from a cache entry for accounting.
// Callers pass a closure that reads the size field from their entry type.
type SizeOf[V any] func(V) int64

// Base is the shared state and behavior for a size-bounded otter cache.
// Embed it in a package-specific cache type and call Init in the constructor.
type Base[V any] struct {
	store         *otter.Cache[string, V]
	currentSize   atomic.Int64
	evictionCount atomic.Int64
}

// Init constructs the underlying otter store with the given max entries and
// eviction accounting. sizeOf is called on each evicted entry to decrement
// the tracked total size. Must be called once before any other method.
func (b *Base[V]) Init(maxEntries int, sizeOf SizeOf[V]) {
	b.store = otter.Must(&otter.Options[string, V]{
		MaximumSize: maxEntries,
		OnAtomicDeletion: func(_ otter.DeletionEvent[string, V]) {
			b.evictionCount.Add(1)
		},
	})
}

// InitWithSizeTracking is like Init but also tracks total byte size across
// live entries by subtracting the evicted entry's size on deletion. Use this
// when the cache enforces a total-size bound in addition to entry count.
func (b *Base[V]) InitWithSizeTracking(maxEntries int, sizeOf SizeOf[V]) {
	b.store = otter.Must(&otter.Options[string, V]{
		MaximumSize: maxEntries,
		OnAtomicDeletion: func(e otter.DeletionEvent[string, V]) {
			b.evictionCount.Add(1)
			b.currentSize.Add(-sizeOf(e.Value))
		},
	})
}

// Clear removes all entries and resets size tracking.
func (b *Base[V]) Clear() {
	b.store.InvalidateAll()
	b.currentSize.Store(0)
}

// BaseStats holds the cache primitives common to every cache type.
// Package-specific stats structs embed this and add their own bounds fields.
type BaseStats struct {
	KeyCount      int
	TotalSize     int64
	EvictionCount int64
}

// Stats returns the primitive cache statistics.
func (b *Base[V]) Stats() BaseStats {
	return BaseStats{
		KeyCount:      b.KeyCount(),
		TotalSize:     b.TotalSize(),
		EvictionCount: b.EvictionCount(),
	}
}

// Store exposes the underlying otter cache for entry-level operations
// (GetIfPresent, Set, CleanUp, Keys). Used by package-specific Get/Set/Has.
func (b *Base[V]) Store() *otter.Cache[string, V] { return b.store }

// AddSize atomically adds delta bytes to the tracked total. Callers use this
// after inserting an entry to keep the size bound accurate.
func (b *Base[V]) AddSize(delta int64) { b.currentSize.Add(delta) }

// TotalSize returns the current total bytes held in the cache.
func (b *Base[V]) TotalSize() int64 { return b.currentSize.Load() }

// EvictionCount returns the number of entries evicted since construction.
func (b *Base[V]) EvictionCount() int64 { return b.evictionCount.Load() }

// KeyCount returns the current number of cached entries.
func (b *Base[V]) KeyCount() int { return len(slices.Collect(b.store.Keys())) }
