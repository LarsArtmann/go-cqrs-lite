package ast

// Benchmarks for the analyzer passes whose cost was asserted "cheap" before
// being measured (2026-09-04 feedback report, TODO_LIST P3):
//
//   - the declaration pre-passes (collectErrorDecls per file for inline
//     usage tracking, collectDeferredClosureSpans for the Close exemption)
//   - the stdlib no-error-return table lookup in the blank-identifier path
//
// Run:
//
//	go test ./internal/ast/ -bench 'BenchmarkUsagePrePass|BenchmarkDeferredClosurePrePass|BenchmarkStdlibNoErrorLookup' -benchmem
//
// Measured 2026-09-23 (AMD RYZEN AI MAX+ 395, Go 1.27.1, -benchtime=1s):
//
//	BenchmarkAnalyzer_Analyze (whole file, for scale)    25,077 ns/op  18,637 B/op  184 allocs/op
//	BenchmarkUsagePrePass_DeclCollection                     115 ns/op     256 B/op    2 allocs/op
//	BenchmarkUsagePrePass_PackageDeclCollection (8 files)  1,513 ns/op   2,304 B/op   18 allocs/op
//	BenchmarkDeferredClosurePrePass                        1,337 ns/op      56 B/op    3 allocs/op
//	BenchmarkStdlibNoErrorLookup                              43 ns/op       0 B/op    0 allocs/op
//
// The usage pre-pass costs ~0.5% of a full file analysis; the deferred-closure
// span pre-pass ~5%; the stdlib table lookup is a free map probe. "Cheap" is
// now a measurement. Refresh these numbers when touching the passes.

import (
	"go/ast"
	"go/parser"
	"go/token"
	"testing"
)

// usagePrePassFixture is a representative file: package-level sentinels,
// inline fmt.Errorf %w sites, errors.Join, and defer-with-closure teardown.
const usagePrePassFixture = `package main

import (
	"errors"
	"fmt"
	"io"
	"strings"
)

var (
	ErrBase    = errors.New("base")
	ErrDerived = fmt.Errorf("derived: %w", ErrBase)
	ErrJoined  = errors.Join(ErrBase, ErrDerived)
)

func load(r io.Reader) ([]byte, error) {
	data, err := io.ReadAll(r)
	if err != nil {
		return nil, fmt.Errorf("read failed: %w", err)
	}
	if len(data) == 0 {
		return nil, errors.New("empty payload")
	}
	return data, nil
}

func teardown(c io.Closer) {
	defer func() {
		_ = c.Close()
	}()
}

func splitLine(line string) (before, after string, ok bool) {
	before, after, ok = strings.Cut(line, "=")
	return before, after, ok
}

func main() {
	if _, err := load(nil); err != nil {
		fmt.Println(err)
	}
}
`

func parseFixture(b *testing.B) *ast.File {
	b.Helper()

	fset := token.NewFileSet()

	node, err := parser.ParseFile(fset, "fixture.go", usagePrePassFixture, parser.AllErrors)
	if err != nil {
		b.Fatalf("parse fixture: %v", err)
	}

	return node
}

func BenchmarkUsagePrePass_DeclCollection(b *testing.B) {
	node := parseFixture(b)

	b.ReportAllocs()

	for b.Loop() {
		_ = collectErrorDecls(node)
	}
}

func BenchmarkUsagePrePass_PackageDeclCollection(b *testing.B) {
	node := parseFixture(b)

	files := make([]*ast.File, 0, 8)
	for range 8 {
		files = append(files, node)
	}

	b.ReportAllocs()

	for b.Loop() {
		_ = CollectErrorDecls(files)
	}
}

func BenchmarkDeferredClosurePrePass(b *testing.B) {
	node := parseFixture(b)

	b.ReportAllocs()

	for b.Loop() {
		_ = collectDeferredClosureSpans(node)
	}
}

func BenchmarkStdlibNoErrorLookup(b *testing.B) {
	node := parseFixture(b)

	b.ReportAllocs()

	for b.Loop() {
		if !calleeIsStdlibNoError(loadCall, node) {
			b.Fatal("strings.Cut must be recognized as stdlib no-error")
		}
	}
}

// loadCall is a synthetic strings.Cut call for the lookup benchmark.
var loadCall = &ast.CallExpr{
	Fun: &ast.SelectorExpr{
		X:   &ast.Ident{Name: "strings"},
		Sel: &ast.Ident{Name: "Cut"},
	},
}
