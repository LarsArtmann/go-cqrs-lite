package ast

// This file is intentionally kept minimal as tests have been split into:
// - analyzer_basic_test.go for basic analysis tests
// - analyzer_violation_test.go for violation detection tests
// - analyzer_edge_cases_test.go for edge case tests
// - benchmark_test.go for benchmarks
