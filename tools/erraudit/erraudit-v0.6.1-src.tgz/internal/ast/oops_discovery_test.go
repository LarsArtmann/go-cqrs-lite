package ast

import (
	"go/parser"
	"go/token"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// parseForDiscovery returns both the analyzer and graph so tests can access
// internal state (namedErrors) via the existing findNamedError helper.
func parseForDiscovery(t *testing.T, code string) (*Analyzer, *types.ErrorGraph) {
	t.Helper()

	fset := token.NewFileSet()
	node, err := parser.ParseFile(fset, "test.go", code, parser.AllErrors)
	require.NoError(t, err)

	analyzer := NewAnalyzer(fset, "main", "test.go")

	return analyzer, analyzer.Analyze(node)
}

func TestOopsDiscovery_Errorf(t *testing.T) {
	t.Parallel()

	code := `package main

import "github.com/samber/oops"

var ErrNotFound = oops.Errorf("resource not found")`

	a, _ := parseForDiscovery(t, code)

	err := findNamedError(t, a, "ErrNotFound")
	assert.Equal(t, types.ErrorKindOopsErrorf, err.Kind)
	assert.Equal(t, "resource not found", err.Message)
}

func TestOopsDiscovery_New(t *testing.T) {
	t.Parallel()

	code := `package main

import "github.com/samber/oops"

var ErrBase = oops.New("base error")`

	a, _ := parseForDiscovery(t, code)

	err := findNamedError(t, a, "ErrBase")
	assert.Equal(t, types.ErrorKindOopsErrorf, err.Kind)
	assert.Equal(t, "base error", err.Message)
}

func TestOopsDiscovery_WrapfCreatesRelationship(t *testing.T) {
	t.Parallel()

	code := `package main

import "github.com/samber/oops"

var ErrBase = oops.Errorf("base")
var ErrWrapped = oops.Wrapf(ErrBase, "wrapped")`

	a, graph := parseForDiscovery(t, code)

	wrapped := findNamedError(t, a, "ErrWrapped")
	assert.Equal(t, types.ErrorKindOopsWrap, wrapped.Kind)
	assert.Equal(t, "ErrBase", wrapped.ParentName)

	found := false

	for _, rel := range graph.Hierarchy.Relationships {
		if rel.Parent == "ErrWrapped" && rel.Child == "ErrBase" {
			assert.Equal(t, types.RelationshipTypeWraps, rel.RelationshipType)
			found = true
		}
	}

	assert.True(t, found, "should have wraps relationship ErrWrapped → ErrBase")
}

func TestOopsDiscovery_WrapCreatesRelationship(t *testing.T) {
	t.Parallel()

	code := `package main

import "github.com/samber/oops"

var ErrBase = oops.Errorf("base")
var ErrWrapped = oops.Wrap(ErrBase)`

	a, _ := parseForDiscovery(t, code)

	wrapped := findNamedError(t, a, "ErrWrapped")
	assert.Equal(t, types.ErrorKindOopsWrap, wrapped.Kind)
}

func TestOopsDiscovery_AliasedImportNotMatched(t *testing.T) {
	t.Parallel()

	code := `package main

import o "github.com/samber/oops"

var ErrAlias = o.Errorf("aliased")`

	a, _ := parseForDiscovery(t, code)

	for _, ne := range a.namedErrors {
		if ne.Name == "ErrAlias" {
			assert.NotEqual(t, types.ErrorKindOopsErrorf, ne.Kind,
				"aliased import should not be classified as oops")
		}
	}
}
