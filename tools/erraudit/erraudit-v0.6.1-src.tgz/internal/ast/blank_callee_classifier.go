package ast

import (
	"go/ast"
)

// blankCalleeVerdict is the tri-state outcome of classifying one blank
// identifier position in default mode (no type info, no --no-suppress):
// a rung either PROVED the value cannot be an error (suppress) or proved
// nothing (flag). "Provably error" certainty only exists with type
// resolution, which is decided before the classifier runs.
type blankCalleeVerdict int

const (
	// blankCalleeFlag is the conservative default: no heuristic could rule
	// out an error return, so the site stays flagged.
	blankCalleeFlag blankCalleeVerdict = iota
	// blankCalleeSuppress means one rung proved the value at blankIndex
	// cannot be an error, so the false positive is suppressed.
	blankCalleeSuppress
)

// blankCalleeHeuristic is one rung of the default-mode precision ladder.
type blankCalleeHeuristic struct {
	name     string
	classify func(call *ast.CallExpr, blankIndex int) blankCalleeVerdict
}

// blankCalleeClassifier evaluates the default-mode blank-identifier precision
// ladder in ONE explicit, ordered place: comma-ok AST shape, then the stdlib
// no-error-return table, then declared same-file/cross-file signatures, with
// the conservative flag as the terminal fallback. Order matters — cheap
// shape checks run before table lookups — and the first suppress verdict
// wins, so the ladder cannot silently reorder without this file changing.
type blankCalleeClassifier struct {
	heuristics []blankCalleeHeuristic
}

// newBlankCalleeClassifier builds the production ladder. The rungs close over
// the analyzer, not a file: currentFile changes per analyzed file, so each
// file-dependent rung reads it at classification time.
func newBlankCalleeClassifier(analyzer *Analyzer) *blankCalleeClassifier {
	return &blankCalleeClassifier{
		heuristics: []blankCalleeHeuristic{
			{
				name: "comma-ok shape",
				classify: func(call *ast.CallExpr, blankIndex int) blankCalleeVerdict {
					if blankIsLikelyNonError(call, blankIndex) {
						return blankCalleeSuppress
					}

					return blankCalleeFlag
				},
			},
			{
				name: "stdlib no-error table",
				classify: func(call *ast.CallExpr, blankIndex int) blankCalleeVerdict {
					if file := analyzer.currentFile; file != nil && calleeIsStdlibNoError(call, file) {
						return blankCalleeSuppress
					}

					return blankCalleeFlag
				},
			},
			{
				name: "declared signature",
				classify: func(call *ast.CallExpr, blankIndex int) blankCalleeVerdict {
					if name := callFuncName(call); name != "" && analyzer.calleeReturnsNonError(name, blankIndex) {
						return blankCalleeSuppress
					}

					return blankCalleeFlag
				},
			},
		},
	}
}

// classify runs the ladder in order and returns the first suppress verdict
// together with the deciding rung's name (so tests can pin WHICH heuristic
// decided); when every rung reports flag, the conservative fallback applies.
func (c *blankCalleeClassifier) classify(call *ast.CallExpr, blankIndex int) (blankCalleeVerdict, string) {
	for _, h := range c.heuristics {
		if v := h.classify(call, blankIndex); v == blankCalleeSuppress {
			return v, h.name
		}
	}

	return blankCalleeFlag, ""
}
