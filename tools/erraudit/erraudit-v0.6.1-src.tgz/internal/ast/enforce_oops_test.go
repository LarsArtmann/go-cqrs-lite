package ast

import (
	"go/parser"
	"go/token"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
)

// helperParseWithOopsEnforcement parses code and analyzes it with oops
// enforcement enabled.
func helperParseWithOopsEnforcement(t *testing.T, code string, enforce bool) *types.ErrorGraph {
	t.Helper()

	fset := token.NewFileSet()

	node, err := parser.ParseFile(fset, "", code, parser.AllErrors)
	if err != nil {
		t.Fatalf("Failed to parse code: %v", err)
	}

	opts := []AnalyzerOption{}
	if enforce {
		opts = append(opts, WithEnforceSamberOops(true))
	}

	analyzer := NewAnalyzer(fset, "main", "test.go", opts...)

	return analyzer.Analyze(node)
}

// findOopsRedundantGuardViolations returns all oops_redundant_guard violations.
func findOopsRedundantGuardViolations(t *testing.T, graph *types.ErrorGraph) []types.ErrorViolation {
	t.Helper()

	var result []types.ErrorViolation

	for _, v := range graph.Violations {
		if v.Type == types.ErrorTypeOopsRedundantGuard {
			result = append(result, v)
		}
	}

	return result
}

// --- Enforcement tests ---

func TestEnforceOops_FlagOff(t *testing.T) {
	t.Parallel()

	code := `package main

import (
	"errors"
	"fmt"
)

var ErrA = errors.New("a")
var ErrB = fmt.Errorf("wrapped: %w", ErrA)
var ErrC = errors.Join(ErrA, ErrB)`
	graph := helperParseWithOopsEnforcement(t, code, false)

	violations := findStdlibViolations(t, graph)
	assert.Empty(t, violations, "flag OFF must produce zero stdlib-constructor findings")
}

func TestEnforceOops_FlagOn(t *testing.T) {
	t.Parallel()

	code := `package main

import (
	"errors"
	"fmt"
)

var ErrA = errors.New("a")
var ErrB = fmt.Errorf("wrapped: %w", ErrA)
var ErrC = errors.Join(ErrA, ErrB)`
	graph := helperParseWithOopsEnforcement(t, code, true)

	violations := findStdlibViolations(t, graph)
	assert.Len(t, violations, 3, "flag ON must flag all three stdlib constructors")

	constructors := make(map[string]bool)

	for _, v := range violations {
		constructors[v.ErrorName] = true
		assert.Equal(t, types.SeverityMedium, v.Severity)
		assert.Contains(t, v.Message, "enforces samber/oops")
	}

	assert.True(t, constructors["errors.New"], "errors.New must be flagged")
	assert.True(t, constructors["fmt.Errorf"], "fmt.Errorf must be flagged")
	assert.True(t, constructors["errors.Join"], "errors.Join must be flagged")
}

func TestEnforceOops_OopsConstructorsNotFlagged(t *testing.T) {
	t.Parallel()

	code := `package main

import (
	"errors"
	"github.com/samber/oops"
)

var ErrA = oops.Errorf("something failed")
var ErrB = oops.Wrapf(ErrA, "context")
var ErrC = errors.New("stdlib")`
	graph := helperParseWithOopsEnforcement(t, code, true)

	violations := findStdlibViolations(t, graph)
	assert.Len(t, violations, 1, "only the stdlib constructor should be flagged")
	assert.Equal(t, "errors.New", violations[0].ErrorName)
}

func TestEnforceOops_SmartSuggestionErrorfWithWrap(t *testing.T) {
	t.Parallel()

	code := `package main

import "fmt"

var Err = fmt.Errorf("failed: %w", someErr)`
	graph := helperParseWithOopsEnforcement(t, code, true)

	violations := findStdlibViolations(t, graph)
	if assert.Len(t, violations, 1) {
		assert.Contains(t, violations[0].Suggestion, "oops.Wrapf")
		assert.Contains(t, violations[0].Suggestion, "%w")
	}
}

func TestEnforceOops_SmartSuggestionErrorfWithoutWrap(t *testing.T) {
	t.Parallel()

	code := `package main

import "fmt"

var Err = fmt.Errorf("just a message")`
	graph := helperParseWithOopsEnforcement(t, code, true)

	violations := findStdlibViolations(t, graph)
	if assert.Len(t, violations, 1) {
		assert.Contains(t, violations[0].Suggestion, "oops.Errorf")
		assert.NotContains(t, violations[0].Suggestion, "Wrapf")
	}
}

func TestEnforceOops_SmartSuggestionErrorsNew(t *testing.T) {
	t.Parallel()

	code := `package main

import "errors"

var Err = errors.New("not found")`
	graph := helperParseWithOopsEnforcement(t, code, true)

	violations := findStdlibViolations(t, graph)
	if assert.Len(t, violations, 1) {
		assert.Contains(t, violations[0].Suggestion, "oops.Errorf")
	}
}

func TestEnforceOops_SmartSuggestionErrorsJoin(t *testing.T) {
	t.Parallel()

	code := `package main

import "errors"

var Err = errors.Join(err1, err2)`
	graph := helperParseWithOopsEnforcement(t, code, true)

	violations := findStdlibViolations(t, graph)
	if assert.Len(t, violations, 1) {
		assert.Contains(t, violations[0].Suggestion, "oops.Join")
	}
}

func TestEnforceOops_ZeroOverheadWhenOff(t *testing.T) {
	t.Parallel()

	code := `package main

import (
	"errors"
	"fmt"
)

func foo() error {
	err := bar()
	if err != nil {
		return fmt.Errorf("failed: %w", err)
	}
	return errors.New("done")
}

func bar() error { return nil }`
	graph := helperParseWithOopsEnforcement(t, code, false)

	violations := findStdlibViolations(t, graph)
	assert.Empty(t, violations, "disabled enforcement must have zero overhead")
}

func TestEnforceOops_InFunctionBody(t *testing.T) {
	t.Parallel()

	code := `package main

import (
	"errors"
	"fmt"
)

func process() error {
	err := step()
	if err != nil {
		return fmt.Errorf("failed: %w", err)
	}
	return errors.New("ok")
}

func step() error { return nil }`
	graph := helperParseWithOopsEnforcement(t, code, true)

	violations := findStdlibViolations(t, graph)
	assert.GreaterOrEqual(t, len(violations), 2,
		"stdlib constructors in function bodies must be flagged")
}

// TestEnforceOops_BothFlagsPriority verifies that when both --enforce-go-error-family
// and --enforce-samber-oops are active simultaneously, oops takes message priority
// (it is the more specific target library).
func TestEnforceOops_BothFlagsPriority(t *testing.T) {
	t.Parallel()

	code := `package main

import "errors"

var Err = errors.New("not found")`

	fset := token.NewFileSet()
	node, err := parser.ParseFile(fset, "", code, parser.AllErrors)
	if err != nil {
		t.Fatalf("Failed to parse: %v", err)
	}

	analyzer := NewAnalyzer(
		fset, "main", "test.go",
		WithEnforceSamberOops(true),
		WithEnforceErrorFamily(true),
	)

	graph := analyzer.Analyze(node)

	violations := findStdlibViolations(t, graph)
	if assert.Len(t, violations, 1, "both flags must still produce exactly one violation per constructor") {
		assert.Contains(t, violations[0].Message, "samber/oops",
			"oops policy should take message priority when both flags are on")
		assert.NotContains(t, violations[0].Message, "go-error-family",
			"go-error-family should NOT be the primary message when oops is also active")
	}
}
