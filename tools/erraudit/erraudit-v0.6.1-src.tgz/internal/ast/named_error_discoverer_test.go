package ast

import (
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
)

// wrapsRels returns the "wraps" relationships recorded by the analyzer.
func wrapsRels(t *testing.T, a *Analyzer) []types.ErrorRelationship {
	t.Helper()

	var rels []types.ErrorRelationship

	for _, r := range a.relationships {
		if r.RelationshipType == types.RelationshipTypeWraps {
			rels = append(rels, r)
		}
	}

	return rels
}

func assertWrapsChild(t *testing.T, rels []types.ErrorRelationship, parent, child string) {
	t.Helper()

	for _, r := range rels {
		if r.Parent == parent && r.Child == child {
			return
		}
	}

	t.Errorf("expected a wraps relationship %s -> %s among %v", parent, child, rels)
}

// TestNamedErrorDiscoverer_MultiWrapErrorf verifies that a fmt.Errorf call with
// two %w verbs produces one wrapping relationship per wrapped error.
func TestNamedErrorDiscoverer_MultiWrapErrorf(t *testing.T) {
	code := `package main

import (
	"errors"
	"fmt"
)

var (
	ErrA = errors.New("a")
	ErrB = errors.New("b")
	ErrMulti = fmt.Errorf("%w: %w", ErrA, ErrB)
)
`
	a, _ := helperParseAndAnalyze(t, code)

	rels := wrapsRels(t, a)
	assert.Len(t, rels, 2, "two %%w verbs must yield two wraps relationships")
	assertWrapsChild(t, rels, "ErrMulti", "ErrA")
	assertWrapsChild(t, rels, "ErrMulti", "ErrB")
}

// TestNamedErrorDiscoverer_SingleWrapUnchanged guards the existing single-wrap
// behavior against regression: one %w still records exactly one relationship.
func TestNamedErrorDiscoverer_SingleWrapUnchanged(t *testing.T) {
	code := `package main

import (
	"errors"
	"fmt"
)

var (
	ErrBase = errors.New("base")
	ErrWrap = fmt.Errorf("wrapped: %w", ErrBase)
)
`
	a, _ := helperParseAndAnalyze(t, code)

	rels := wrapsRels(t, a)
	assert.Len(t, rels, 1)
	assert.Equal(t, "ErrWrap", rels[0].Parent)
	assert.Equal(t, "ErrBase", rels[0].Child)
}

// TestNamedErrorDiscoverer_ErrorfWithoutWrap records no wrapping relationship
// when the format string uses %v (loses the chain) rather than %w.
func TestNamedErrorDiscoverer_ErrorfWithoutWrap(t *testing.T) {
	code := `package main

import (
	"errors"
	"fmt"
)

var (
	ErrBase = errors.New("base")
	ErrLost = fmt.Errorf("lost: %v", ErrBase)
)
`
	a, _ := helperParseAndAnalyze(t, code)

	assert.Empty(t, wrapsRels(t, a))
}

// TestNamedErrorDiscoverer_ErrorfMixedVerbs ensures %w is correlated to its
// positional argument even when other verbs (%s) precede it.
func TestNamedErrorDiscoverer_ErrorfMixedVerbs(t *testing.T) {
	code := `package main

import (
	"errors"
	"fmt"
)

var (
	ErrA = errors.New("a")
	ErrB = errors.New("b")
	ErrMixed = fmt.Errorf("ctx %s: %w", ErrA, ErrB)
)
`
	a, _ := helperParseAndAnalyze(t, code)

	rels := wrapsRels(t, a)
	assert.Len(t, rels, 1, "only the %%w argument (ErrB) should be wrapped")
	assert.Equal(t, "ErrB", rels[0].Child)
}

// TestNamedErrorDiscoverer_ErrorsJoin verifies that errors.Join produces a join
// named error and one wrapping relationship per joined argument.
func TestNamedErrorDiscoverer_ErrorsJoin(t *testing.T) {
	code := `package main

import (
	"errors"
)

var (
	ErrA = errors.New("a")
	ErrB = errors.New("b")
	ErrJoined = errors.Join(ErrA, ErrB)
)
`
	a, _ := helperParseAndAnalyze(t, code)

	var joinErr *types.NamedError

	for i := range a.namedErrors {
		if a.namedErrors[i].Name == "ErrJoined" {
			joinErr = &a.namedErrors[i]

			break
		}
	}

	if assert.NotNil(t, joinErr, "ErrJoined should be discovered") {
		assert.Equal(t, types.ErrorKindJoin, joinErr.Kind)
	}

	rels := wrapsRels(t, a)
	assert.Len(t, rels, 2, "errors.Join of two errors must yield two wraps relationships")
	assertWrapsChild(t, rels, "ErrJoined", "ErrA")
	assertWrapsChild(t, rels, "ErrJoined", "ErrB")
}

// TestNamedErrorDiscoverer_BranchingMetricsMultiWrap is the headline regression
// test: single-file analysis with a multi-%w wrap must report a branching
// factor above 1.0 (previously always 1.0).
func TestNamedErrorDiscoverer_BranchingMetricsMultiWrap(t *testing.T) {
	code := `package main

import (
	"errors"
	"fmt"
)

var (
	ErrA = errors.New("a")
	ErrB = errors.New("b")
	ErrMulti = fmt.Errorf("%w: %w", ErrA, ErrB)
)
`
	_, graph := helperParseAndAnalyze(t, code)

	m := graph.Hierarchy.Metrics
	assert.Greater(t, m.AvgBranchingFactor, 1.0, "multi-wrap must raise AvgBranchingFactor above 1.0")
	assert.Equal(t, "ErrMulti", m.MaxBranchingParent)
	assert.Equal(t, uint(2), m.MaxBranchingCount)
}

// TestNamedErrorDiscoverer_BranchingMetricsJoin is the headline regression test
// for errors.Join: single-file analysis must report a branching factor above
// 1.0 (previously join was invisible, so the metric was always 1.0).
func TestNamedErrorDiscoverer_BranchingMetricsJoin(t *testing.T) {
	code := `package main

import (
	"errors"
)

var (
	ErrA = errors.New("a")
	ErrB = errors.New("b")
	ErrC = errors.New("c")
	ErrJoined = errors.Join(ErrA, ErrB, ErrC)
)
`
	_, graph := helperParseAndAnalyze(t, code)

	m := graph.Hierarchy.Metrics
	assert.Greater(t, m.AvgBranchingFactor, 1.0, "errors.Join must raise AvgBranchingFactor above 1.0")
	assert.Equal(t, "ErrJoined", m.MaxBranchingParent)
	assert.Equal(t, uint(3), m.MaxBranchingCount)
}
