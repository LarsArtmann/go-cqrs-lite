package ast

// Helper functions for AST analysis
// This module contains small, focused utility functions

import (
	"bytes"
	"fmt"
	"go/ast"
	"go/printer"
	"go/token"
	"strings"

	"github.com/larsartmann/erraudit/pkg/types"
)

const unknownFuncName = "<unknown>"

// getCallName gets the name of a function call for display in suggestions.
//
// For selector expressions (x.Method or pkg.Func), the receiver expression is
// rendered to source text via go/printer so that nested selectors such as
// `h.storage.Get` render correctly — the previous fmt.Sprintf("%s", fun.X)
// called the AST node's default String(), which leaked the Go struct form
// (e.g. `&{h storage}.Get`) into user-facing messages.
func (a *Analyzer) getCallName(call *ast.CallExpr) string {
	switch fun := call.Fun.(type) {
	case *ast.Ident:
		return fun.Name
	case *ast.SelectorExpr:
		return exprToSource(a.fset, fun.X) + "." + fun.Sel.Name
	default:
		return unknownFuncName
	}
}

// exprToSource renders an AST expression back to its source-text form using
// go/printer. Returns unknownFuncName if rendering fails. Used to display
// receiver expressions (e.g. `h.storage`, `client.conn`) in suggestion text
// without leaking the AST node's struct representation.
func exprToSource(fset *token.FileSet, expr ast.Expr) string {
	if ident, ok := expr.(*ast.Ident); ok {
		// Fast path: a bare identifier needs no printer round-trip.
		return ident.Name
	}

	var buf bytes.Buffer
	if err := printer.Fprint(&buf, fset, expr); err != nil {
		return unknownFuncName
	}

	return buf.String()
}

// getContainingFunctionName gets the name of the function containing a node.
func (a *Analyzer) getContainingFunctionName(node ast.Node) string {
	// Return the current function name being tracked
	funcName := a.currentFuncName()
	if funcName != "" {
		return funcName
	}

	// Fallback to traversing AST up to find function
	for {
		switch n := node.(type) {
		case *ast.FuncDecl:
			if n.Name != nil {
				return n.Name.Name
			}

			return "<anonymous>"
		case *ast.SelectorExpr:
			node = n.X
		case *ast.CallExpr:
			node = n.Fun
		case nil:
			return unknownFuncName
		default:
			return unknownFuncName
		}
	}
}

// buildLineSnippet builds a formatted code snippet with line numbers
// and marks the current line with a prefix.
func buildLineSnippet(lines []string, lineNum, startLine, endLine int) string {
	var snippet strings.Builder

	for i := startLine; i <= endLine; i++ {
		prefix := "  "
		if i == lineNum {
			prefix = "> "
		}

		fmt.Fprintf(&snippet, "%s%d %s\n", prefix, i, lines[i-1])
	}

	return snippet.String()
}

// createErrorInfo creates an ErrorInfo with the given parameters.
// It delegates to createErrorInfoWithVars with a nil vars slice.
func createErrorInfo(
	fset *token.FileSet,
	pos token.Pos,
	errorType types.ErrorType,
	message, functionName, pkgName, fileName string,
) types.ErrorInfo {
	return createErrorInfoWithVars(fset, pos, errorType, message, functionName, pkgName, fileName, nil)
}

// createErrorInfoWithVars creates an ErrorInfo with variables.
func createErrorInfoWithVars(
	fset *token.FileSet,
	pos token.Pos,
	errorType types.ErrorType,
	message, functionName, pkgName, fileName string,
	vars []string,
) types.ErrorInfo {
	position := fset.Position(pos)

	return types.ErrorInfo{
		Position: position,
		Type:     errorType,
		Message:  message,
		Context: types.ErrorContext{
			FunctionName: functionName,
			PackageName:  pkgName,
			FileName:     fileName,
			LineNumber:   position.Line,
			Vars:         vars,
		},
	}
}

// extractCodeSnippet extracts a code snippet from the source file.
func (a *Analyzer) extractCodeSnippet(pos token.Pos, contextLines int) string {
	if pos == token.NoPos {
		return ""
	}

	position := a.fset.Position(pos)
	if position.Filename == "" {
		return ""
	}

	lines, err := a.cacheFile(position.Filename)
	if err != nil {
		return ""
	}

	lineNum := position.Line

	startLine := max(1, lineNum-contextLines)
	endLine := min(len(lines), lineNum+contextLines)

	return buildLineSnippet(lines, lineNum, startLine, endLine)
}

// stringLiteralValue returns the unquoted string content of an AST expression
// that is a STRING-kind *ast.BasicLit. Returns "" when the expression is not a
// string literal. The single canonical extraction point for "this AST node
// should be a string literal" — used by oops, fmt.Errorf, and any other
// format-string argument parsing.
func stringLiteralValue(expr ast.Expr) string {
	lit, ok := expr.(*ast.BasicLit)
	if !ok || lit.Kind != token.STRING {
		return ""
	}

	return strings.Trim(lit.Value, `"`)
}
