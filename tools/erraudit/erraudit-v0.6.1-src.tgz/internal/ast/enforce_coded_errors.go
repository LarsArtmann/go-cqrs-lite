package ast

// Opt-in coded-errors detector: flags go-error-family constructor calls whose
// error-code argument is the empty string literal (""). Empty-code errors
// cannot resolve a What/Why/Fix message template, so at the CLI boundary they
// render as bare text without a suggested fix — the exact gap coded sentinels
// exist to prevent. Enabled via --enforce-coded-errors.
//
// The check reuses the errorFamilyConstructors registry: in every constructor
// signature the code argument sits immediately before the message argument,
// so the code index is messageIndex-1 (New: family, CODE, msg; NewRejection:
// CODE, msg; Wrap: err, family, CODE, msg; WrapRejection: err, CODE, msg; and
// the Wrap*f variants likewise).
//
// Only the literal "" is flagged. Passing a variable, a constant, or
// errorfamily.Code(err) (code inheritance) is a deliberate non-literal choice
// and is never flagged, which keeps the check at zero false positives.

import (
	"go/ast"
	"go/token"

	"github.com/larsartmann/erraudit/pkg/types"
)

// detectUncodedConstructors walks the AST and emits a violation for every
// go-error-family constructor call whose code argument is the empty string
// literal. Runs only when --enforce-coded-errors is active.
func detectUncodedConstructors(a *Analyzer, node ast.Node) {
	ast.Inspect(node, func(n ast.Node) bool {
		call, ok := n.(*ast.CallExpr)
		if !ok {
			return true
		}

		pkgName, methodName, ok := callSelector(call)
		if !ok {
			return true
		}

		info, found := errorFamilyConstructorInfo(pkgName, methodName)
		if !found {
			return true
		}

		codeIndex := info.messageIndex - 1
		if codeIndex < 0 || codeIndex >= len(call.Args) {
			return true
		}

		lit, ok := call.Args[codeIndex].(*ast.BasicLit)
		if !ok || lit.Kind != token.STRING {
			return true
		}

		if unquoteBasicString(lit.Value) != "" {
			return true
		}

		constructor := pkgName + "." + methodName

		violation := types.NewErrorViolation(
			a.fset, call.Pos(), call.End(),
			types.ErrorTypeUncodedConstructor, types.SeverityMedium,
			constructor+" called with empty error code",
			"Pass a stable dotted code (e.g. \"config.invalid\") and register a What/Why/Fix template for it; "+
				"wrap a coded sentinel to inherit its code",
			constructor,
			types.NewConfidence(enforceConfidence),
		)

		a.appendViolation(violation)

		return true
	})
}

// unquoteBasicString strips surrounding double quotes or backticks from a
// basic literal's value. The empty code this detector matches may be spelled
// "" or “ — both must be recognized.
func unquoteBasicString(value string) string {
	if len(value) >= 2 {
		first, last := value[0], value[len(value)-1]
		if (first == '"' && last == '"') || (first == '`' && last == '`') {
			return value[1 : len(value)-1]
		}
	}

	return value
}
