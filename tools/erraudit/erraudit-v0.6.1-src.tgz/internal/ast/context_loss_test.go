package ast

import (
	"strings"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
)

// findContextLossViolations returns all context-loss violations from the graph.
func findContextLossViolations(t *testing.T, graph *types.ErrorGraph) []types.ErrorViolation {
	t.Helper()

	var result []types.ErrorViolation

	for _, v := range graph.Violations {
		if v.Type == types.ErrorTypeContextLoss {
			result = append(result, v)
		}
	}

	return result
}

// parseAndFindContextLoss parses inline Go source, analyzes it, and returns
// all context-loss violations. This is the shared ceremony for context-loss
// tests: parse → find violations.
func parseAndFindContextLoss(t *testing.T, code string) []types.ErrorViolation {
	t.Helper()
	_, graph := helperParseAndAnalyze(t, code)
	return findContextLossViolations(t, graph)
}

// assertContextLossForVar asserts that a context-loss violation exists for the
// given variable name.
func assertContextLossForVar(t *testing.T, violations []types.ErrorViolation, varName string) {
	t.Helper()

	for _, v := range violations {
		if v.ErrorName == varName {
			return
		}
	}

	t.Errorf("expected context-loss violation for variable %q among %d violations", varName, len(violations))
}

// assertNoContextLossForVar asserts that NO context-loss violation exists for
// the given variable name.
func assertNoContextLossForVar(t *testing.T, violations []types.ErrorViolation, varName string) {
	t.Helper()

	for _, v := range violations {
		if v.ErrorName == varName {
			t.Errorf("unexpected context-loss violation for variable %q: %s", varName, v.Message)
		}
	}
}

// TestContextLoss_ImmediateLossOnBareReturnErr verifies that bare `return err`
// in a non-thin function with business context variables triggers context-loss violations.
func TestContextLoss_ImmediateLossOnBareReturnErr(t *testing.T) {
	code := `package main

func fetchUser(userID string) error {
	err := doDB()
	if err != nil {
		return err
	}
	_ = userID
	_ = "step2"
	_ = "step3"
	return nil
}

func doDB() error { return nil }
`
	violations := parseAndFindContextLoss(t, code)
	assert.NotEmpty(t, violations, "bare return err must trigger context-loss")
	assertContextLossForVar(t, violations, "userID")

	for _, v := range violations {
		if v.ErrorName == "userID" {
			assert.Equal(t, types.ContextLossImmediate, v.ContextLoss.Subtype)
			assert.False(t, v.ContextLoss.Recoverable)
		}
	}
}

// TestContextLoss_WrappingLoss verifies that fmt.Errorf("%w", err) without
// including context variables triggers wrapping-loss violations.
func TestContextLoss_WrappingLoss(t *testing.T) {
	code := `package main

import "fmt"

func processOrder(orderID string) error {
	err := validate()
	if err != nil {
		return fmt.Errorf("processing failed: %w", err)
	}
	return nil
}

func validate() error { return nil }
`
	violations := parseAndFindContextLoss(t, code)
	assertContextLossForVar(t, violations, "orderID")

	for _, v := range violations {
		if v.ErrorName == "orderID" {
			assert.Equal(t, types.ContextLossWrapping, v.ContextLoss.Subtype)
			assert.True(t, v.ContextLoss.Recoverable)
		}
	}
}

// TestContextLoss_FPRejection_BoolType verifies that boolean variables are
// never flagged as context loss.
func TestContextLoss_FPRejection_BoolType(t *testing.T) {
	code := `package main

func check(valid bool) error {
	err := doCheck()
	if err != nil {
		return err
	}
	return nil
}

func doCheck() error { return nil }
`
	violations := parseAndFindContextLoss(t, code)
	assertNoContextLossForVar(t, violations, "valid")
}

// TestContextLoss_FPRejection_CredentialVariables verifies that credential
// variables (password, token, etc.) are never flagged.
func TestContextLoss_FPRejection_CredentialVariables(t *testing.T) {
	code := `package main

import "fmt"

func authenticate(password, userID string) error {
	err := checkAuth()
	if err != nil {
		return fmt.Errorf("auth failed: %w", err)
	}
	return nil
}

func checkAuth() error { return nil }
`
	violations := parseAndFindContextLoss(t, code)
	assertNoContextLossForVar(t, violations, "password")
	assertContextLossForVar(t, violations, "userID")
}

// TestContextLoss_FPRejection_InfrastructureVariables verifies that
// infrastructure variables (ctx, db, log, etc.) are never flagged.
func TestContextLoss_FPRejection_InfrastructureVariables(t *testing.T) {
	code := `package main

import (
	"context"
	"fmt"
)

func query(ctx context.Context, userID string) error {
	err := db(ctx)
	if err != nil {
		return fmt.Errorf("query failed: %w", err)
	}
	return nil
}

func db(ctx context.Context) error { return nil }
`
	violations := parseAndFindContextLoss(t, code)
	assertNoContextLossForVar(t, violations, "ctx")
	assertContextLossForVar(t, violations, "userID")
}

// TestContextLoss_FPRejection_CollectionType verifies that collection types
// (slices, maps) are never flagged.
func TestContextLoss_FPRejection_CollectionType(t *testing.T) {
	code := `package main

import "fmt"

func batch(items []string, userID string) error {
	err := process()
	if err != nil {
		return fmt.Errorf("batch failed: %w", err)
	}
	return nil
}

func process() error { return nil }
`
	violations := parseAndFindContextLoss(t, code)
	assertNoContextLossForVar(t, violations, "items")
	assertContextLossForVar(t, violations, "userID")
}

// TestContextLoss_FPRejection_PointerType verifies that pointer types are
// never flagged (they are infrastructure/complex types).
func TestContextLoss_FPRejection_PointerType(t *testing.T) {
	code := `package main

func update(conn *Conn, userID string) error {
	err := doUpdate()
	if err != nil {
		return err
	}
	return nil
}

type Conn struct{}
func doUpdate() error { return nil }
`
	violations := parseAndFindContextLoss(t, code)
	assertNoContextLossForVar(t, violations, "conn")
}

// TestContextLoss_FPRejection_VarIncluded verifies that variables already
// referenced in the error are NOT flagged.
func TestContextLoss_FPRejection_VarIncluded(t *testing.T) {
	code := `package main

import "fmt"

func fetch(userID string) error {
	err := db()
	if err != nil {
		return fmt.Errorf("failed for user %s: %w", userID, err)
	}
	return nil
}

func db() error { return nil }
`
	violations := parseAndFindContextLoss(t, code)
	assertNoContextLossForVar(t, violations, "userID")
}

// TestContextLoss_FPRejection_SentinelReturn verifies that returning a
// package-level sentinel error is not flagged.
func TestContextLoss_FPRejection_SentinelReturn(t *testing.T) {
	code := `package main

import "errors"

var ErrNotFound = errors.New("not found")

func lookup(userID string) error {
	err := find()
	if err != nil {
		return ErrNotFound
	}
	return nil
}

func find() error { return nil }
`
	violations := parseAndFindContextLoss(t, code)
	assert.Empty(t, violations, "sentinel error returns must not trigger context-loss")
}

// TestContextLoss_SeverityCritical verifies that critical context variables
// (userID, etc.) get SeverityHigh.
func TestContextLoss_SeverityCritical(t *testing.T) {
	code := `package main

import "fmt"

func fetch(userID string) error {
	err := db()
	if err != nil {
		return fmt.Errorf("failed: %w", err)
	}
	return nil
}

func db() error { return nil }
`
	violations := parseAndFindContextLoss(t, code)
	for _, v := range violations {
		if v.ErrorName == "userID" {
			assert.Equal(t, types.SeverityHigh, v.Severity,
				"userID must be SeverityHigh")
		}
	}
}

// TestContextLoss_SeverityMedium verifies that non-critical string variables
// get SeverityMedium.
func TestContextLoss_SeverityMedium(t *testing.T) {
	code := `package main

import "fmt"

func process(recordName string) error {
	err := doWork()
	if err != nil {
		return fmt.Errorf("failed: %w", err)
	}
	return nil
}

func doWork() error { return nil }
`
	violations := parseAndFindContextLoss(t, code)
	for _, v := range violations {
		if v.ErrorName == "recordName" {
			assert.Equal(t, types.SeverityMedium, v.Severity,
				"recordName matches business suffix *Name but not critical/diagnostic → Medium")
		}
	}
}

// TestContextLoss_VarIncludedInAnyPath verifies that a variable included in
// ANY error return path in the function is not flagged, even on paths where
// it's missing.
func TestContextLoss_VarIncludedInAnyPath(t *testing.T) {
	code := `package main

import (
	"errors"
	"fmt"
)

func dualPath(userID string) error {
	err := step1()
	if err != nil {
		return fmt.Errorf("user %s step1: %w", userID, err)
	}

	err = step2()
	if err != nil {
		return err // userID not included here, but is on the other path
	}
	_ = "extra1"
	_ = "extra2"
	return nil
}

func step1() error { return errors.New("fail") }
func step2() error { return errors.New("fail") }
`
	// userID is included in the step1 error path, so even though it's missing
	// in the step2 path, it should NOT be flagged (cross-path filter).
	violations := parseAndFindContextLoss(t, code)
	assertNoContextLossForVar(t, violations, "userID")
}

// TestContextLoss_NoErrorReturn verifies that functions without error returns
// are not analyzed.
func TestContextLoss_NoErrorReturn(t *testing.T) {
	code := `package main

func compute(userID string) int {
	return 42
}
`
	violations := parseAndFindContextLoss(t, code)
	assert.Empty(t, violations)
}

// TestContextLoss_LocalVariableLoss verifies that local variables (not just
// parameters) are detected when lost on error paths.
func TestContextLoss_LocalVariableLoss(t *testing.T) {
	code2 := `package main

import "fmt"

func process() error {
	resourceName := "widget-42"
	err := load()
	if err != nil {
		return fmt.Errorf("load failed: %w", err)
	}
	return nil
}

func load() error { return nil }
`
	violations := parseAndFindContextLoss(t, code2)
	assertContextLossForVar(t, violations, "resourceName")
}

// TestContextLoss_VarDeclaredAfterError verifies that variables declared after
// the error return are not considered in scope.
func TestContextLoss_VarDeclaredAfterError(t *testing.T) {
	code := `package main

func process() error {
	err := step1()
	if err != nil {
		return err
	}
	lateVar := "important"
	_ = lateVar
	return nil
}

func step1() error { return nil }
`
	violations := parseAndFindContextLoss(t, code)
	assertNoContextLossForVar(t, violations, "lateVar")
}

// TestContextLoss_ErrorFamilyWithContext verifies that go-error-family
// constructors with .WithContext() suppress the loss detection.
func TestContextLoss_ErrorFamilyWithContext(t *testing.T) {
	t.Skip("WithContext chaining requires call-chain analysis not yet implemented")
}

// TestContextLoss_ErrorFamilyFormatArgNotFlagged verifies that context
// variables passed as format arguments to go-error-family constructors
// (e.g. errorfamily.WrapRejectionf(err, "code", "failed: %q", configPath)) are
// NOT flagged as context loss. The rejectContextIncluded FP rejection pipeline
// walks the full CallExpr AST including all Args, so configPath is found as
// an *ast.Ident and suppressed.
//
// This closes the gap from the 2026-08-03 context-loss FP report which
// claimed configPath was flagged — it should not be.
func TestContextLoss_ErrorFamilyFormatArgNotFlagged(t *testing.T) {
	code := `package main

func loadConfig(configPath string) error {
	err := read()
	if err != nil {
		return errorfamily.WrapRejectionf(err, "config.load_failed", "failed to load %q", configPath)
	}
	return nil
}

func read() error { return nil }
`
	violations := parseAndFindContextLoss(t, code)
	assertNoContextLossForVar(t, violations, "configPath")
}

// TestContextLoss_ErrorFamilyMissingVarFlagged is the control case for the
// previous test: when configPath is NOT passed to the constructor, it SHOULD
// be flagged. This confirms the detector works and the previous test isn't
// just passing because the function is too thin or the expression is
// unrecognized.
func TestContextLoss_ErrorFamilyMissingVarFlagged(t *testing.T) {
	code := `package main

func loadConfig(configPath string) error {
	err := read()
	if err != nil {
		return errorfamily.WrapRejectionf(err, "config.load_failed", "failed to load")
	}
	return nil
}

func read() error { return nil }
`
	violations := parseAndFindContextLoss(t, code)
	assertContextLossForVar(t, violations, "configPath")
}

// TestContextLoss_MultipleVars verifies that multiple lost variables in the
// same function are consolidated into a single violation listing all variables.
func TestContextLoss_MultipleVars(t *testing.T) {
	code := `package main

import "fmt"

func transfer(fromAccountID, toAccountID string, transferAmount int) error {
	err := execute()
	if err != nil {
		return fmt.Errorf("transfer failed: %w", err)
	}
	return nil
}

func execute() error { return nil }
`
	violations := parseAndFindContextLoss(t, code)
	assert.GreaterOrEqual(t, len(violations), 1,
		"multiple context vars should produce at least one consolidated violation")

	// The consolidated violation should mention the primary variable
	if len(violations) > 0 {
		primary := violations[0].ErrorName
		assert.Contains(t, []string{"fromAccountID", "toAccountID", "transferAmount"}, primary,
			"primary variable should be one of the flagged vars")
	}
}

// TestContextLoss_ThinWrapperSkip verifies that bare-error returns in thin
// delegation functions (≤5 statements) are NOT flagged for context loss.
func TestContextLoss_ThinWrapperSkip(t *testing.T) {
	code := `package main

func delegate(userID string) error {
    err := doWork()
    if err != nil {
        return err
    }
    return nil
}

func doWork() error { return nil }
`
	violations := parseAndFindContextLoss(t, code)
	assert.Empty(t, violations, "thin wrapper functions with bare return err should not be flagged")
}

// TestContextLoss_ThinWrapperWrappingStillFlagged verifies that wrapping
// returns in thin functions ARE still flagged (only bare returns are skipped).
func TestContextLoss_ThinWrapperWrappingStillFlagged(t *testing.T) {
	code := `package main

import "fmt"

func delegate(userID string) error {
    err := doWork()
    if err != nil {
        return fmt.Errorf("failed: %w", err)
    }
    return nil
}

func doWork() error { return nil }
`
	violations := parseAndFindContextLoss(t, code)
	assertContextLossForVar(t, violations, "userID")
}

// TestContextLoss_ClosureVarsNotFlagged verifies that variables declared inside
// closures (callbacks, function literals) are NOT flagged as lost at the
// enclosing function's error returns — they are not in scope there.
func TestContextLoss_ClosureVarsNotFlagged(t *testing.T) {
	code := `package main

import "fmt"

func walkFiles(rootPath string) error {
    var lineCount int
    walkErr := walkCallback(rootPath, func(filePath string) error {
        lineCount++
        return nil
    })
    if walkErr != nil {
        return fmt.Errorf("walk failed: %w", walkErr)
    }
    return nil
}

func walkCallback(root string, fn func(p string) error) error { return nil }
`
	violations := parseAndFindContextLoss(t, code)
	// lineCount is declared in the enclosing function but inside a FuncLit
	// scope for the callback — it should NOT be flagged at the walkErr return.
	// filePath is a closure param — also not in scope at the outer return.
	assertNoContextLossForVar(t, violations, "filePath")
}

// TestContextLoss_LoopScopeVarsNotFlagged verifies that variables declared
// inside a for-loop body are NOT flagged at return statements outside that
// loop body — they are no longer in scope.
func TestContextLoss_LoopScopeVarsNotFlagged(t *testing.T) {
	code := `package main

import "fmt"

func processLines(filePath string, lines []string) error {
    for i, line := range lines {
        lineNum := i + 1
        if len(line) > 100 {
            _ = lineNum
        }
    }

    if err := saveFile(filePath); err != nil {
        return fmt.Errorf("save failed: %w", err)
    }
    return nil
}

func saveFile(path string) error { return nil }
`
	violations := parseAndFindContextLoss(t, code)
	// lineNum and line are declared inside the for-loop body.
	// The error return is AFTER the loop — these vars are not in scope.
	assertNoContextLossForVar(t, violations, "lineNum")
}

// TestContextLoss_NilOnErrorPathSkip verifies that variables co-assigned with
// the error variable (nil on error path) are NOT flagged.
func TestContextLoss_NilOnErrorPathSkip(t *testing.T) {
	code := `package main

import "fmt"

func render(templateName, userID string) error {
    tmpl, err := parseTemplate(templateName)
    if err != nil {
        return fmt.Errorf("failed: %w", err)
    }
    _ = tmpl
    return nil
}

func parseTemplate(name string) (*Template, error) { return nil, nil }
type Template struct{}
`
	violations := parseAndFindContextLoss(t, code)
	// tmpl is co-assigned with err → nil on error path → should NOT be flagged
	assertNoContextLossForVar(t, violations, "tmpl")
	// userID is a regular param → SHOULD be flagged
	assertContextLossForVar(t, violations, "userID")
}

// TestContextLoss_ConsolidationCap verifies that a single error return site
// emits at most one consolidated violation even when many variables are flagged.
func TestContextLoss_ConsolidationCap(t *testing.T) {
	code := `package main

import "fmt"

func complexOp(userID, orderID, productID, sessionID, requestID, traceID, itemID string) error {
    err := doWork()
    if err != nil {
        return fmt.Errorf("failed: %w", err)
    }
    return nil
}

func doWork() error { return nil }
`
	violations := parseAndFindContextLoss(t, code)
	// Should emit exactly ONE consolidated violation, not 7
	assert.Len(t, violations, 1, "multiple flagged variables should consolidate into one violation")
}

// TestContextLoss_AllowlistGate verifies that only variables matching
// business-context suffixes are flagged. Generic names that don't match any
// suffix (store, buf, data, handler, x) must NOT trigger violations, while
// business-context names (userID, configPath) MUST trigger violations.
func TestContextLoss_AllowlistGate(t *testing.T) {
	code := `package main

import "fmt"

func setup(store string, buf string, data string, handler string, userID string, configPath string) error {
	err := initSystem()
	if err != nil {
		return fmt.Errorf("setup failed: %w", err)
	}
	return nil
}

func initSystem() error { return nil }`
	violations := parseAndFindContextLoss(t, code)

	// Non-business-context names must NOT be flagged
	assertNoContextLossForVar(t, violations, "store")
	assertNoContextLossForVar(t, violations, "buf")
	assertNoContextLossForVar(t, violations, "data")
	assertNoContextLossForVar(t, violations, "handler")

	// Business-context names MUST be flagged (at least one appears as primary)
	assert.NotEmpty(t, violations, "business-context vars must trigger violations")
	if len(violations) > 0 {
		// The consolidated violation message should mention at least one business var
		assert.True(t,
			strings.Contains(violations[0].Message, "userID") ||
				strings.Contains(violations[0].Message, "configPath"),
			"violation should mention a business-context variable")
	}
}

// TestContextLoss_SuffixBasedSeverity verifies that suffix-based matching
// correctly escalates severity: *ID → High (critical), *Path → High (diagnostic),
// *Name → Medium (business but not critical/diagnostic).
func TestContextLoss_SuffixBasedSeverity(t *testing.T) {
	code := `package main

import "fmt"

func process(userID string, configPath string, recordName string) error {
	err := doWork()
	if err != nil {
		return fmt.Errorf("failed: %w", err)
	}
	return nil
}

func doWork() error { return nil }`
	violations := parseAndFindContextLoss(t, code)

	for _, v := range violations {
		switch v.ErrorName {
		case "userID":
			assert.Equal(t, types.SeverityHigh, v.Severity,
				"*ID suffix → critical → SeverityHigh")
		case "configPath":
			assert.Equal(t, types.SeverityHigh, v.Severity,
				"*Path suffix → diagnostic → SeverityHigh")
		case "recordName":
			assert.Equal(t, types.SeverityMedium, v.Severity,
				"*Name suffix → business but not critical/diagnostic → SeverityMedium")
		}
	}
}

// TestContextLoss_GenericNamesRejected verifies that common infrastructure
// and plumbing variable names from real-world Go codebases are NOT flagged,
// even without a denylist. The allowlist naturally excludes them because they
// don't match business-context suffixes.
func TestContextLoss_GenericNamesRejected(t *testing.T) {
	code := `package main

import "fmt"

func process(logger string, mu string, ch string, i string, x string, y string, result string, entry string) error {
	err := doWork()
	if err != nil {
		return fmt.Errorf("failed: %w", err)
	}
	return nil
}

func doWork() error { return nil }`
	violations := parseAndFindContextLoss(t, code)

	// None of these generic names match business-context suffixes
	for _, name := range []string{"logger", "mu", "ch", "i", "x", "y", "result", "entry"} {
		assertNoContextLossForVar(t, violations, name)
	}
}
