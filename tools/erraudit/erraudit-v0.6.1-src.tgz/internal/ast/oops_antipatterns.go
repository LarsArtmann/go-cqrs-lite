package ast

// Oops-specific anti-pattern detection.
//
// When --enforce-samber-oops is active, this detector flags patterns that are
// suboptimal or incorrect when using samber/oops:
//
//  1. Redundant nil guard before oops.Wrap/Wrapf:
//       if err != nil {
//           return oops.Wrap(err)
//       }
//       return nil
//     Since oops.Wrap/Wrapf return nil when the input error is nil, the guard
//     is unnecessary boilerplate. The entire if-block can be replaced with a
//     single `return oops.Wrap(err)`.

import (
	"fmt"
	"go/ast"
	"strings"

	"github.com/larsartmann/erraudit/pkg/oopspattern"
	"github.com/larsartmann/erraudit/pkg/types"
)

const (
	redundantGuardConfidence = 0.85
	minWrapfArgs             = 2 // Wrapf(err, format, ...) needs at least err + format
	misusedWConfidence       = 0.80
)

// wrapfFormatString extracts the string literal value from the format argument
// of an oops.Wrapf call. Returns "" when the argument is not a string literal.
func wrapfFormatString(formatArg ast.Expr) string {
	return stringLiteralValue(formatArg)
}

// detectOopsRedundantGuard walks the AST and flags `if err != nil { return
// oops.Wrap(err) }; return nil` patterns. These are redundant because
// oops.Wrap/Wrapf return nil for nil input — the nil guard adds boilerplate
// without value.
func detectOopsRedundantGuard(a *Analyzer, node ast.Node) {
	ast.Inspect(node, func(n ast.Node) bool {
		block, ok := n.(*ast.BlockStmt)
		if !ok {
			return true
		}

		matches := oopspattern.FindRedundantGuards(block)
		for _, m := range matches {
			method := wrapMethodName(m.WrapRet)

			message := fmt.Sprintf(
				"Redundant nil guard before oops.%s(%s) — Wrap/Wrapf return nil for nil input",
				method, m.ErrName,
			)

			suggestion := fmt.Sprintf(
				"Replace the if-block and `return nil` with a single `return oops.%s(%s)`",
				method, m.ErrName,
			)

			violation := types.NewErrorViolation(
				a.fset, m.IfStmt.Pos(), m.IfStmt.End(),
				types.ErrorTypeOopsRedundantGuard, types.SeverityLow,
				message, suggestion, m.ErrName,
				types.NewConfidence(redundantGuardConfidence),
			)

			a.appendViolation(violation)
		}

		return true
	})
}

// wrapMethodName extracts the method name (Wrap or Wrapf) from the call
// expression inside a return statement.
func wrapMethodName(ret *ast.ReturnStmt) string {
	if len(ret.Results) == 0 {
		return methodWrap
	}

	call, ok := ret.Results[0].(*ast.CallExpr)
	if !ok {
		return methodWrap
	}

	_, method, ok := callSelector(
		call,
	)
	if !ok {
		return methodWrap
	}

	return method
}

// detectOopsMisusedW flags oops.Wrapf calls where the format string contains
// %w. In oops.Wrapf, %w does NOT establish error chaining (unlike fmt.Errorf
// and oops.Errorf) — it renders the error as a string only. The wrapped error
// object is discarded. This is a common source of confusion.
//
// Example anti-pattern:
//
//	oops.Wrapf(err, "failed: %w", otherErr)  // otherErr is NOT chained
//
// Fix: use %s or %v for display, or restructure to oops.Errorf if chaining is needed.
func detectOopsMisusedW(a *Analyzer, node ast.Node) {
	ast.Inspect(node, func(n ast.Node) bool {
		call, ok := n.(*ast.CallExpr)
		if !ok {
			return true
		}

		pkg, method, ok := callSelector(call)
		if !ok || pkg != oopsPackageName || method != methodWrapf {
			return true
		}

		// Wrapf(err, format, args...) — format is the 2nd argument (index 1)
		if len(call.Args) < minWrapfArgs {
			return true
		}

		formatStr := wrapfFormatString(call.Args[1])
		if formatStr == "" || !strings.Contains(formatStr, "%w") {
			return true
		}

		message := "oops.Wrapf format string contains %w — %w does NOT chain in Wrapf (only string rendering); use %s/%v or restructure to oops.Errorf"

		suggestion := "Replace %w with %s (display) or use oops.Errorf(\"msg: %w\", err) if chaining is needed"

		violation := types.NewErrorViolation(
			a.fset, call.Pos(), call.End(),
			types.ErrorTypeOopsMisusedW, types.SeverityLow,
			message, suggestion, "oops.Wrapf",
			types.NewConfidence(misusedWConfidence),
		)

		a.appendViolation(violation)

		return true
	})
}
