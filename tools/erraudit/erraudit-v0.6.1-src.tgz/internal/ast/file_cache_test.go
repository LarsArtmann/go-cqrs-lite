package ast

import (
	"os"
	"path/filepath"
	"testing"
)

// generateIndexedFilename generates a filename like "file0.go", "file1.go", etc.
// For values >= 10, it uses decimal digits (e.g., "file10.go").
func generateIndexedFilename(tmpDir, prefix string, index int) string {
	if index < 10 {
		return filepath.Join(tmpDir, prefix+string(rune('0'+index))+".go")
	}

	return filepath.Join(tmpDir, prefix+string(rune('0'+index%10))+string(rune('0'+index/10))+".go")
}

// createTestFiles creates numbered test files in tmpDir with optional content.
func createTestFiles(tmpDir string, count int, content string) {
	for i := range count {
		filename := generateIndexedFilename(tmpDir, "file", i)
		_ = os.WriteFile(filename, []byte(content), 0o644)
	}
}

// loadAllIntoCache loads the first count files matching `prefix` into the cache,
// logging (rather than failing) on per-file errors — the cache test cares about
// aggregate behavior, not individual file errors.
func loadAllIntoCache(t *testing.T, cache *FileCache, tmpDir, prefix string, count int) {
	t.Helper()
	for i := range count {
		filename := generateIndexedFilename(tmpDir, prefix, i)

		_, err := cache.Load(filename)
		if err != nil {
			t.Logf("Load(%s) error: %v", filename, err)
		}
	}
}

// TestFileCache_MaxFilesLimit tests that the cache respects the max files limit.
func TestFileCache_MaxFilesLimit(t *testing.T) {
	// Create temp directory with test files
	tmpDir := t.TempDir()
	fileCount := 20

	for i := range fileCount {
		filename := generateIndexedFilename(tmpDir, "file", i)
		content := "package test\n// " + string(make([]byte, 1000)) // ~1KB per file
		_ = os.WriteFile(filename, []byte(content), 0o644)
	}

	// Create cache with low limit
	cache := NewFileCache(WithMaxFiles(5))

	// Load all files
	loadAllIntoCache(t, cache, tmpDir, "file", fileCount)

	stats := cache.Stats()
	if stats.KeyCount > 5 {
		t.Errorf("cache should have at most 5 files, got %d", stats.KeyCount)
	}

	if stats.EvictionCount == 0 {
		t.Error("expected some evictions")
	}
}

// TestFileCache_MaxSizeLimit tests that the cache respects the max size limit.
func TestFileCache_MaxSizeLimit(t *testing.T) {
	tmpDir := t.TempDir()

	// Create files that will exceed the size limit
	for i := range 10 {
		filename := generateIndexedFilename(tmpDir, "large", i)

		content := make([]byte, 20*1024) // 20KB per file
		for j := range content {
			content[j] = byte('x')
		}

		_ = os.WriteFile(filename, content, 0o644)
	}

	// Create cache with 50KB limit (should fit ~2 files)
	cache := NewFileCache(WithMaxSize(50 * 1024))

	// Load all files
	loadAllIntoCache(t, cache, tmpDir, "large", 10)

	stats := cache.Stats()
	if stats.TotalSize > 50*1024*1.1 { // Allow 10% overhead
		t.Errorf("cache size %d exceeds limit 51200", stats.TotalSize)
	}
}

// TestFileCache_LRUEviction tests that LRU eviction works correctly.
func TestFileCache_LRUEviction(t *testing.T) {
	tmpDir := t.TempDir()

	// Create 3 test files
	createTestFiles(tmpDir, 3, "package test\n")

	// Create cache with limit of 2 files
	cache := NewFileCache(WithMaxFiles(2))

	// Load files in order: 0, 1, 2
	file0 := filepath.Join(tmpDir, "file0.go")
	file1 := filepath.Join(tmpDir, "file1.go")
	file2 := filepath.Join(tmpDir, "file2.go")

	_, _ = cache.Load(file0)
	_, _ = cache.Load(file1)
	_, _ = cache.Load(file2) // Cache at capacity, should evict one

	// file2 (most recent) must be cached
	if !cache.Has(file2) {
		t.Error("file2 should still be cached")
	}

	// Cache should have at most 2 entries after eviction
	stats := cache.Stats()
	if stats.KeyCount > 2 {
		t.Errorf("cache should have at most 2 files, got %d", stats.KeyCount)
	}
}

// TestFileCache_TouchUpdatesLRU tests that accessing a file updates its LRU position.
func TestFileCache_TouchUpdatesLRU(t *testing.T) {
	tmpDir := t.TempDir()

	// Create 3 test files
	createTestFiles(tmpDir, 3, "package test\n")

	cache := NewFileCache(WithMaxFiles(2))

	file0 := filepath.Join(tmpDir, "file0.go")
	file1 := filepath.Join(tmpDir, "file1.go")
	file2 := filepath.Join(tmpDir, "file2.go")

	_, _ = cache.Load(file0)
	_, _ = cache.Load(file1)
	_, _ = cache.Load(file0) // Touch file0 to make it most recently used
	_, _ = cache.Load(file2) // Should evict file1, not file0

	// file0 should still be cached (was touched)
	if !cache.Has(file0) {
		t.Error("file0 should still be cached after being touched")
	}

	// file1 should be evicted
	if cache.Has(file1) {
		t.Error("file1 should have been evicted")
	}
}

// TestFileCache_ClearWithStats tests that Clear removes all entries and resets stats.
func TestFileCache_ClearWithStats(t *testing.T) {
	tmpDir := t.TempDir()

	filename := filepath.Join(tmpDir, "test.go")
	_ = os.WriteFile(filename, []byte("package test\n"), 0o644)

	cache := NewFileCache()
	_, _ = cache.Load(filename)

	if !cache.Has(filename) {
		t.Error("file should be cached")
	}

	cache.Clear()

	if cache.Has(filename) {
		t.Error("file should not be cached after Clear")
	}
}

// TestFileCache_SingleLargeFile tests that a single file exceeding max size is not cached.
func TestFileCache_SingleLargeFile(t *testing.T) {
	tmpDir := t.TempDir()

	// Create a file larger than the cache limit
	filename := filepath.Join(tmpDir, "large.go")
	content := make([]byte, 200*1024) // 200KB
	_ = os.WriteFile(filename, content, 0o644)

	// Create cache with 100KB limit
	cache := NewFileCache(WithMaxSize(100 * 1024))

	lines, err := cache.Load(filename)
	if err != nil {
		t.Fatalf("Load failed: %v", err)
	}

	// File should be returned but not cached
	if len(lines) == 0 {
		t.Error("file should have been read")
	}

	if cache.Has(filename) {
		t.Error("large file should not be cached")
	}
}

// TestFileCache_Stats tests that Stats returns correct information.
func TestFileCache_Stats(t *testing.T) {
	tmpDir := t.TempDir()

	// Create test file
	filename := filepath.Join(tmpDir, "test.go")
	_ = os.WriteFile(filename, []byte("package test\nconst x = 1\n"), 0o644)

	cache := NewFileCache(WithMaxFiles(10), WithMaxSize(1024*1024))
	_, _ = cache.Load(filename)

	stats := cache.Stats()

	if stats.KeyCount != 1 {
		t.Errorf("expected 1 file, got %d", stats.KeyCount)
	}

	if stats.TotalSize <= 0 {
		t.Errorf("expected positive size, got %d", stats.TotalSize)
	}

	if stats.MaxFiles != 10 {
		t.Errorf("expected MaxFiles=10, got %d", stats.MaxFiles)
	}

	if stats.UtilizationFiles <= 0 {
		t.Error("expected positive utilization")
	}
}

// BenchmarkFileCache_Load benchmarks loading files into the cache.
func BenchmarkFileCache_Load(b *testing.B) {
	tmpDir := b.TempDir()
	filename := filepath.Join(tmpDir, "test.go")
	_ = os.WriteFile(filename, []byte("package test\nconst x = 1\n"), 0o644)

	cache := NewFileCache()

	b.ResetTimer()

	for b.Loop() {
		_, _ = cache.Load(filename)
	}
}

// BenchmarkFileCache_LoadWithEviction benchmarks loading with eviction pressure.
func BenchmarkFileCache_LoadWithEviction(b *testing.B) {
	tmpDir := b.TempDir()

	// Create 100 files
	for i := range 100 {
		filename := generateIndexedFilename(tmpDir, "file", i)
		_ = os.WriteFile(filename, []byte("package test\n"), 0o644)
	}

	cache := NewFileCache(WithMaxFiles(10))

	b.ResetTimer()

	for i := 0; b.Loop(); i++ {
		filename := generateIndexedFilename(tmpDir, "file", i)
		_, _ = cache.Load(filename)
	}
}
