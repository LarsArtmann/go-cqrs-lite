package ast

import (
	"go/ast"
	"go/parser"
	"go/token"
	"go/types"
	"testing"

	"github.com/larsartmann/erraudit/internal/testutil"
)

// loadTestPackageTypes parses and type-checks a Go source file, returning
// the fset, AST file, types.Info, and types.Package for use in tests.
func loadTestPackageTypes(
	t *testing.T,
	code string,
) (*token.FileSet, *ast.File, *types.Info, *types.Package) {
	t.Helper()

	pr := testutil.ParseAndTypeCheck(t, "test.go", code)

	return pr.Fset, pr.File, pr.Info, pr.Pkg
}

func TestTypeResolver_Available(t *testing.T) {
	t.Run("NilResolver", func(t *testing.T) {
		var r *TypeResolver
		if r.Available() {
			t.Error("nil resolver should not be available")
		}
	})

	t.Run("NilInfo", func(t *testing.T) {
		r := NewTypeResolver(nil, nil)
		if r.Available() {
			t.Error("resolver with nil info should not be available")
		}
	})

	t.Run("ValidResolver", func(t *testing.T) {
		code := `package testpkg`
		_, _, info, pkg := loadTestPackageTypes(t, code)
		r := NewTypeResolver(info, pkg)
		if !r.Available() {
			t.Error("resolver with valid info should be available")
		}
	})
}

func TestTypeResolver_ReturnTypeIsError(t *testing.T) {
	code := `package testpkg

import "fmt"
import "errors"

func returnsError() error { return errors.New("boom") }
func returnsString() string { return "ok" }
func returnsMulti() (string, error) { return "", nil }
func returnsIntBool() (int, bool) { return 0, false }

func example() {
	_ = returnsError()
	_ = returnsString()
	_, _ = returnsMulti()
	_, _ = returnsIntBool()
	_, _ = fmt.Println("hello")
}`

	fset, file, info, pkg := loadTestPackageTypes(t, code)
	resolver := NewTypeResolver(info, pkg)

	if !resolver.Available() {
		t.Fatal("resolver should be available")
	}

	// Find all assignment statements and check type resolution.
	type expectation struct {
		funcName    string
		blankIndex  int
		wantIsError bool
	}

	expectations := map[string]expectation{
		"returnsError":   {blankIndex: 0, wantIsError: true},
		"returnsString":  {blankIndex: 0, wantIsError: false},
		"returnsMulti":   {blankIndex: 0, wantIsError: false},
		"returnsIntBool": {blankIndex: 0, wantIsError: false},
		"fmt.Println":    {blankIndex: 0, wantIsError: false},
	}

	found := 0

	ast.Inspect(file, func(n ast.Node) bool {
		assign, ok := n.(*ast.AssignStmt)
		if !ok {
			return true
		}

		if len(assign.Rhs) == 0 {
			return true
		}

		call, ok := assign.Rhs[0].(*ast.CallExpr)
		if !ok {
			return true
		}

		callName := getCallNameFromAST(call)

		exp, ok := expectations[callName]
		if !ok {
			return true
		}

		found++

		got := resolver.ReturnTypeIsError(call, exp.blankIndex)
		if got != exp.wantIsError {
			t.Errorf(
				"ReturnTypeIsError(%s, %d) = %v, want %v",
				callName,
				exp.blankIndex,
				got,
				exp.wantIsError,
			)
		}

		return true
	})

	if found != len(expectations) {
		t.Errorf("found %d calls, expected %d", found, len(expectations))
	}

	_ = fset
}

func getCallNameFromAST(call *ast.CallExpr) string {
	switch fn := call.Fun.(type) {
	case *ast.Ident:
		return fn.Name
	case *ast.SelectorExpr:
		if ident, ok := fn.X.(*ast.Ident); ok {
			return ident.Name + "." + fn.Sel.Name
		}

		return fn.Sel.Name
	default:
		return ""
	}
}

func TestImplementsError(t *testing.T) {
	code := `package testpkg

import "errors"

type MyError struct { msg string }
func (e *MyError) Error() string { return e.msg }

var errSentinel = errors.New("sentinel")
`
	_, _, info, pkg := loadTestPackageTypes(t, code)

	// Look up types from the package scope.
	for _, name := range []string{"errSentinel", "MyError"} {
		obj := pkg.Scope().Lookup(name)
		if obj == nil {
			t.Errorf("expected to find %s in package scope", name)

			continue
		}

		// Just verify the type checker resolved it.
		t.Logf("%s type: %s", name, obj.Type())
	}

	_ = info
}

func TestTypeResolver_ExprImplementsError(t *testing.T) {
	code := `package testpkg

type PointerError struct{ msg string }
func (e *PointerError) Error() string { return e.msg }

type ValueError struct{ msg string }
func (e ValueError) Error() string { return e.msg }

type FakeErr struct{ count int }

var ErrA = &PointerError{msg: "a"}
var ErrB = ValueError{msg: "b"}
var ErrCount = &FakeErr{count: 0}
`

	fset, file, info, pkg := loadTestPackageTypes(t, code)
	resolver := NewTypeResolver(info, pkg)

	if !resolver.Available() {
		t.Fatal("resolver should be available")
	}

	// Find the var declarations and check ExprImplementsError.
	checked := 0

	ast.Inspect(file, func(n ast.Node) bool {
		genDecl, ok := n.(*ast.GenDecl)
		if !ok {
			return true
		}

		for _, spec := range genDecl.Specs {
			vs, ok := spec.(*ast.ValueSpec)
			if !ok || len(vs.Values) == 0 {
				continue
			}

			name := vs.Names[0].Name
			expr := vs.Values[0]
			got := resolver.ExprImplementsError(expr)

			var want bool

			switch name {
			case "ErrA", "ErrB":
				want = true
			case "ErrCount":
				want = false
			default:
				continue
			}

			checked++

			if got != want {
				pos := fset.Position(expr.Pos())
				t.Errorf("ExprImplementsError(%s at %s) = %v, want %v", name, pos, got, want)
			}
		}

		return true
	})

	if checked != 3 {
		t.Errorf("expected to check 3 vars, checked %d", checked)
	}
}

func TestTypeResolver_ExprImplementsError_NilResolver(t *testing.T) {
	var r *TypeResolver
	if r.ExprImplementsError(nil) {
		t.Error("nil resolver should return false")
	}
}

func TestTypeResolver_ExprTypeErrorStatus(t *testing.T) {
	code := `package testpkg

type PointerError struct{ msg string }
func (e *PointerError) Error() string { return e.msg }

type FakeErr struct{ count int }

var ErrA = &PointerError{msg: "a"}
var ErrCount = &FakeErr{count: 0}`

	fset, file, info, pkg := loadTestPackageTypes(t, code)
	resolver := NewTypeResolver(info, pkg)

	checked := 0

	ast.Inspect(file, func(n ast.Node) bool {
		genDecl, ok := n.(*ast.GenDecl)
		if !ok {
			return true
		}

		for _, spec := range genDecl.Specs {
			vs, ok := spec.(*ast.ValueSpec)
			if !ok || len(vs.Values) == 0 {
				continue
			}

			name := vs.Names[0].Name
			expr := vs.Values[0]
			status := resolver.ExprTypeErrorStatus(expr)

			var want ErrorTypeStatus

			switch name {
			case "ErrA":
				want = ErrorTypeImplements
			case "ErrCount":
				want = ErrorTypeDoesNotImplement
			default:
				continue
			}

			checked++

			if status != want {
				pos := fset.Position(expr.Pos())
				t.Errorf("ExprTypeErrorStatus(%s at %s) = %v, want %v", name, pos, status, want)
			}
		}

		return true
	})

	if checked != 2 {
		t.Errorf("expected to check 2 vars, checked %d", checked)
	}
}

func TestTypeResolver_ExprTypeErrorStatus_NilResolver(t *testing.T) {
	var r *TypeResolver
	if got := r.ExprTypeErrorStatus(nil); got != ErrorTypeUnresolved {
		t.Errorf("nil resolver should return ErrorTypeUnresolved, got %v", got)
	}
}

func TestTypeResolver_ExprTypeErrorStatus_UnresolvedExpr(t *testing.T) {
	// A resolver with a non-nil but empty types.Info — all expressions are
	// unresolved because they're not in the Types map.
	resolver := NewTypeResolver(
		&types.Info{Types: make(map[ast.Expr]types.TypeAndValue)},
		types.NewPackage("testpkg", "testpkg"),
	)

	if got := resolver.ExprTypeErrorStatus(nil); got != ErrorTypeUnresolved {
		t.Errorf("nil expr should return ErrorTypeUnresolved, got %v", got)
	}
}

func TestExtractCustomErrorTypeName_TypeAwareRejectsNonError(t *testing.T) {
	// When type-aware mode is ON and the type is resolved as NOT implementing
	// error, extractCustomErrorTypeName should return "" (no false positive).
	code := `package testpkg

type CustomError struct{ msg string }
func (e *CustomError) Error() string { return e.msg }

type Counter struct{ count int }

var ErrCustom = &CustomError{msg: "x"}
var ErrCounter = &Counter{count: 0}`

	fset, file, info, pkg := loadTestPackageTypes(t, code)
	resolver := NewTypeResolver(info, pkg)

	analyzer := NewAnalyzer(fset, "test", "test.go")
	analyzer.typeResolver = resolver
	discoverer := NewNamedErrorDiscoverer(analyzer)

	ast.Inspect(file, func(n ast.Node) bool {
		genDecl, ok := n.(*ast.GenDecl)
		if !ok {
			return true
		}

		for _, spec := range genDecl.Specs {
			vs, ok := spec.(*ast.ValueSpec)
			if !ok || len(vs.Values) == 0 {
				continue
			}

			name := vs.Names[0].Name
			expr := vs.Values[0]
			got := discoverer.extractCustomErrorTypeName(expr)

			switch name {
			case "ErrCustom":
				if got != "CustomError" {
					t.Errorf("ErrCustom: expected 'CustomError', got %q", got)
				}
			case "ErrCounter":
				if got != "" {
					t.Errorf("ErrCounter: expected '' (Counter doesn't implement error), got %q", got)
				}
			}
		}

		return true
	})
}

func TestExtractCustomErrorTypeName_TypeAwareUnresolvedFallbackToHeuristic(t *testing.T) {
	// When type-aware mode is ON but the type checker couldn't resolve the
	// expression's type (simulated with an empty types.Info), the naming
	// heuristic should be used as a graceful fallback — NOT a false negative.
	fset := token.NewFileSet()

	resolver := NewTypeResolver(
		&types.Info{Types: make(map[ast.Expr]types.TypeAndValue)},
		types.NewPackage("testpkg", "testpkg"),
	)

	analyzer := NewAnalyzer(fset, "test", "test.go")
	analyzer.typeResolver = resolver
	discoverer := NewNamedErrorDiscoverer(analyzer)

	file, _ := parser.ParseFile(fset, "test.go", `package testpkg
type NotFoundError struct{ msg string }
func (e *NotFoundError) Error() string { return e.msg }

var ErrNotFound = &NotFoundError{msg: "x"}
`, parser.AllErrors)

	found := false

	ast.Inspect(file, func(n ast.Node) bool {
		genDecl, ok := n.(*ast.GenDecl)
		if !ok {
			return true
		}

		for _, spec := range genDecl.Specs {
			vs, ok := spec.(*ast.ValueSpec)
			if !ok || len(vs.Values) == 0 {
				continue
			}

			name := vs.Names[0].Name
			if name != "ErrNotFound" {
				continue
			}

			found = true
			got := discoverer.extractCustomErrorTypeName(vs.Values[0])
			if got != "NotFoundError" {
				t.Errorf("expected 'NotFoundError' via heuristic fallback, got %q", got)
			}
		}

		return true
	})

	if !found {
		t.Error("test setup error: ErrNotFound var not found")
	}
}

func TestTypeResolver_NamedErrorTypeName(t *testing.T) {
	code := `package testpkg

import "errors"

type PointerError struct{ msg string }
func (e *PointerError) Error() string { return e.msg }

type ValueError struct{ msg string }
func (e ValueError) Error() string { return e.msg }

type Counter struct{ count int }

func buildFailure() *PointerError { return &PointerError{msg: "x"} }

var ErrA = &PointerError{msg: "a"}
var ErrB = ValueError{msg: "b"}
var ErrCount = &Counter{count: 0}
var ErrSentinel = errors.New("boom")
var ErrFromFunc = buildFailure()
`

	_, file, info, pkg := loadTestPackageTypes(t, code)
	resolver := NewTypeResolver(info, pkg)

	if !resolver.Available() {
		t.Fatal("resolver should be available")
	}

	expectations := map[string]string{
		"ErrA":        "PointerError", // &PointerError{} → *PointerError → unwrap → "PointerError"
		"ErrB":        "ValueError",   // ValueError{} → value receiver → "ValueError"
		"ErrCount":    "",             // Counter doesn't implement error
		"ErrSentinel": "",             // errors.New → static type is 'error' interface, not a named type
		"ErrFromFunc": "PointerError", // buildFailure() → *PointerError → "PointerError"
	}

	checked := 0

	ast.Inspect(file, func(n ast.Node) bool {
		genDecl, ok := n.(*ast.GenDecl)
		if !ok {
			return true
		}

		for _, spec := range genDecl.Specs {
			vs, ok := spec.(*ast.ValueSpec)
			if !ok || len(vs.Values) == 0 {
				continue
			}

			name := vs.Names[0].Name
			want, ok := expectations[name]
			if !ok {
				continue
			}

			checked++

			got := resolver.NamedErrorTypeName(vs.Values[0])
			if got != want {
				t.Errorf("NamedErrorTypeName(%s) = %q, want %q", name, got, want)
			}
		}

		return true
	})

	if checked != len(expectations) {
		t.Errorf("checked %d vars, expected %d", checked, len(expectations))
	}
}

func TestTypeResolver_NamedErrorTypeName_NilResolver(t *testing.T) {
	var r *TypeResolver

	if name := r.NamedErrorTypeName(nil); name != "" {
		t.Errorf("nil resolver should return empty string, got %q", name)
	}
}

func TestExtractCustomErrorTypeName_TypeAwareDetectsBeyondNamingHeuristic(t *testing.T) {
	// A type whose name does NOT end in "Error"/"Err" but implements error.
	// Without type info this is invisible; with type info it should be detected.
	code := `package testpkg

type Failure struct{ msg string }
func (e *Failure) Error() string { return e.msg }

var ErrFoo = &Failure{msg: "boom"}
`

	fset, file, info, pkg := loadTestPackageTypes(t, code)
	analyzer := NewAnalyzer(fset, "test", "test.go")
	analyzer.typeResolver = NewTypeResolver(info, pkg)
	discoverer := NewNamedErrorDiscoverer(analyzer)

	found := false

	ast.Inspect(file, func(n ast.Node) bool {
		genDecl, ok := n.(*ast.GenDecl)
		if !ok {
			return true
		}

		for _, spec := range genDecl.Specs {
			vs, ok := spec.(*ast.ValueSpec)
			if !ok || len(vs.Values) == 0 {
				continue
			}

			if vs.Names[0].Name != "ErrFoo" {
				continue
			}

			found = true

			got := discoverer.extractCustomErrorTypeName(vs.Values[0])
			if got != "Failure" {
				t.Errorf("expected 'Failure' (type-aware overrides naming heuristic), got %q", got)
			}
		}

		return true
	})

	if !found {
		t.Error("test setup error: ErrFoo var not found")
	}
}

func TestExtractCustomErrorTypeName_TypeFirstPath(t *testing.T) {
	// A parenthesized struct literal doesn't match any AST pattern in
	// extractCustomErrorTypeName's switch. With type info available, the
	// type-first path should resolve the type name from go/types.
	code := `package testpkg

type Failure struct{ msg string }
func (e *Failure) Error() string { return e.msg }

var ErrFoo = (&Failure{msg: "boom"})
`

	fset, file, info, pkg := loadTestPackageTypes(t, code)
	analyzer := NewAnalyzer(fset, "test", "test.go")
	analyzer.typeResolver = NewTypeResolver(info, pkg)
	discoverer := NewNamedErrorDiscoverer(analyzer)

	found := false

	ast.Inspect(file, func(n ast.Node) bool {
		genDecl, ok := n.(*ast.GenDecl)
		if !ok {
			return true
		}

		for _, spec := range genDecl.Specs {
			vs, ok := spec.(*ast.ValueSpec)
			if !ok || len(vs.Values) == 0 {
				continue
			}

			if vs.Names[0].Name != "ErrFoo" {
				continue
			}

			found = true

			got := discoverer.extractCustomErrorTypeName(vs.Values[0])
			if got != "Failure" {
				t.Errorf("expected 'Failure' via type-first path, got %q", got)
			}
		}

		return true
	})

	if !found {
		t.Error("test setup error: ErrFoo var not found")
	}
}

func TestExtractCustomErrorTypeName_ErrorsNewNotMisclassifiedByTypeFirst(t *testing.T) {
	// errors.New returns *errors.errorString which implements error.
	// The type-first path must NOT classify it as a custom error type —
	// it's handled by tryErrorsNew later in the pipeline.
	code := `package testpkg

import "errors"

var ErrSentinel = errors.New("boom")
`

	fset, file, info, pkg := loadTestPackageTypes(t, code)
	analyzer := NewAnalyzer(fset, "test", "test.go")
	analyzer.typeResolver = NewTypeResolver(info, pkg)
	discoverer := NewNamedErrorDiscoverer(analyzer)

	found := false

	ast.Inspect(file, func(n ast.Node) bool {
		genDecl, ok := n.(*ast.GenDecl)
		if !ok {
			return true
		}

		for _, spec := range genDecl.Specs {
			vs, ok := spec.(*ast.ValueSpec)
			if !ok || len(vs.Values) == 0 {
				continue
			}

			if vs.Names[0].Name != "ErrSentinel" {
				continue
			}

			found = true

			got := discoverer.extractCustomErrorTypeName(vs.Values[0])
			if got != "" {
				t.Errorf("errors.New must not be classified as custom error type, got %q", got)
			}
		}

		return true
	})

	if !found {
		t.Error("test setup error: ErrSentinel var not found")
	}
}

func TestTypeNameFromExpr(t *testing.T) {
	tests := []struct {
		name string
		expr ast.Expr
		want string
	}{
		{"Ident", &ast.Ident{Name: "MyError"}, "MyError"},
		{"SelectorExpr", &ast.SelectorExpr{X: &ast.Ident{Name: "pkg"}, Sel: &ast.Ident{Name: "MyError"}}, "MyError"},
		{"OtherExpr", &ast.BasicLit{Kind: token.STRING, Value: `"x"`}, ""},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := typeNameFromExpr(tt.expr)
			if got != tt.want {
				t.Errorf("typeNameFromExpr(%s) = %q, want %q", tt.name, got, tt.want)
			}
		})
	}
}

func TestTypeResolver_ExprImplementsCloser(t *testing.T) {
	code := `package testpkg

type RealCloser struct{ id int }
func (r *RealCloser) Close() error { return nil }

type ValueCloser struct{ id int }
func (v ValueCloser) Close() error { return nil }

type VoidClose struct{ id int }
func (v *VoidClose) Close() {}

type NonCloser struct{ id int }

var rc = &RealCloser{id: 1}
var vc = ValueCloser{id: 2}
var vd = &VoidClose{id: 3}
var nc = &NonCloser{id: 4}
`

	_, file, info, pkg := loadTestPackageTypes(t, code)
	resolver := NewTypeResolver(info, pkg)

	if !resolver.Available() {
		t.Fatal("resolver should be available")
	}

	checked := 0

	ast.Inspect(file, func(n ast.Node) bool {
		genDecl, ok := n.(*ast.GenDecl)
		if !ok {
			return true
		}

		for _, spec := range genDecl.Specs {
			vs, ok := spec.(*ast.ValueSpec)
			if !ok || len(vs.Values) == 0 {
				continue
			}

			name := vs.Names[0].Name
			expr := vs.Values[0]
			got := resolver.ExprImplementsCloser(expr)

			var want ErrorTypeStatus

			switch name {
			case "rc", "vc":
				want = ErrorTypeImplements
			case "vd", "nc":
				want = ErrorTypeDoesNotImplement
			default:
				continue
			}

			checked++

			if got != want {
				t.Errorf("%s: ExprImplementsCloser = %v, want %v", name, got, want)
			}
		}

		return true
	})

	if checked == 0 {
		t.Fatal("test setup error: no variables checked")
	}
}

func TestTypeResolver_ExprImplementsCloser_NilResolver(t *testing.T) {
	var r *TypeResolver

	got := r.ExprImplementsCloser(&ast.Ident{Name: "x"})
	if got != ErrorTypeUnresolved {
		t.Errorf("nil resolver should return ErrorTypeUnresolved, got %v", got)
	}
}
