package ast

// Context-loss detection: identifies when a function's error-return paths drop
// meaningful context variables (IDs, paths, flags) that were in scope at the
// error site. Each loss is classified by subtype and severity, then emitted as
// an ErrorTypeContextLoss violation.
//
// This is a native reimplementation of branching-flow's tracker package,
// adapted to erraudit's type system and infrastructure. The detection logic
// (FP rejections, classifiers, severity) mirrors the tracker's pipeline, but
// uses AST inspection instead of string-based pattern matching where possible.

import (
	"fmt"
	"go/ast"
	"go/token"
	"sort"
	"strings"

	"github.com/larsartmann/erraudit/pkg/types"
)

// ContextLossDetector detects context-loss violations in Go functions.

const contextLossConfidence = 0.80

type ContextLossDetector struct {
	analyzer *Analyzer
}

// NewContextLossDetector creates a new context-loss detector.
func NewContextLossDetector(analyzer *Analyzer) *ContextLossDetector {
	return &ContextLossDetector{analyzer: analyzer}
}

// Detect walks the AST and emits context-loss violations for every function
// whose error-return paths drop meaningful context variables.
func (d *ContextLossDetector) Detect(node ast.Node) {
	ast.Inspect(node, func(n ast.Node) bool {
		fn, ok := n.(*ast.FuncDecl)
		if !ok || fn.Body == nil {
			return true
		}

		if !functionReturnsError(fn) {
			return true
		}

		d.detectInFunction(fn)

		return true
	})
}

// functionReturnsError reports whether fn has an error return value.
func functionReturnsError(fn *ast.FuncDecl) bool {
	if fn.Type.Results == nil {
		return false
	}

	for _, field := range fn.Type.Results.List {
		if ident, ok := field.Type.(*ast.Ident); ok && ident.Name == errorInterfaceName {
			return true
		}
	}

	return false
}

// isThinWrapper reports whether fn is a thin delegation function (≤5
// top-level statements). Bare-error returns in such functions are not flagged
// because the callee already contextualized the error.
func isThinWrapper(fn *ast.FuncDecl) bool {
	return fn.Body != nil && len(fn.Body.List) <= maxThinWrapperStatements
}

// isBareErrorExpr reports whether the error expression is a bare identifier
// (e.g. `return ..., err` — direct pass-through without wrapping).
func isBareErrorExpr(errExpr ast.Expr) bool {
	_, ok := errExpr.(*ast.Ident)

	return ok
}

// detectInFunction analyzes a single function for context-loss violations.
func (d *ContextLossDetector) detectInFunction(fn *ast.FuncDecl) {
	thinWrapper := isThinWrapper(fn)

	contextVars := d.collectContextVars(fn)
	if len(contextVars) == 0 {
		return
	}

	allErrorReturns := d.findErrorReturns(fn.Body)

	for _, ret := range allErrorReturns {
		errExpr := findErrorExpression(ret)
		if errExpr == nil {
			continue
		}

		// Skip bare-error returns (return ..., err) in thin delegation
		// functions. The callee already contextualized the error.
		if thinWrapper && isBareErrorExpr(errExpr) {
			continue
		}

		d.analyzeErrorReturn(ret, errExpr, contextVars, allErrorReturns)
	}
}

// contextVar represents a variable in scope at error-return sites.
type contextVar struct {
	name              string
	ident             *ast.Ident // declaration identifier (may be nil for range vars)
	typeExpr          ast.Expr   // AST type expression (may be nil for inferred locals)
	pos               token.Pos
	coAssignedWithErr bool      // true when assigned in the same := statement as an error variable
	blockStart        token.Pos // start of innermost enclosing block (scope boundary)
	blockEnd          token.Pos // end of innermost enclosing block (scope boundary)
}

// collectContextVars gathers all parameters and local variables declared in fn.
func (d *ContextLossDetector) collectContextVars(fn *ast.FuncDecl) []contextVar {
	vars := d.collectParams(fn)
	vars = append(vars, d.collectLocalVars(fn)...)

	return vars
}

// collectParams collects receiver and parameter variables from the function signature.
func (d *ContextLossDetector) collectParams(fn *ast.FuncDecl) []contextVar {
	var vars []contextVar

	if fn.Recv != nil {
		for _, field := range fn.Recv.List {
			for _, name := range field.Names {
				vars = append(vars, contextVar{
					name:              name.Name,
					ident:             name,
					typeExpr:          field.Type,
					pos:               field.Pos(),
					coAssignedWithErr: false,
					blockStart:        token.NoPos,
					blockEnd:          token.NoPos,
				})
			}
		}
	}

	for _, field := range fn.Type.Params.List {
		for _, name := range field.Names {
			vars = append(vars, contextVar{
				name:              name.Name,
				ident:             name,
				typeExpr:          field.Type,
				pos:               field.Pos(),
				coAssignedWithErr: false,
				blockStart:        token.NoPos,
				blockEnd:          token.NoPos,
			})
		}
	}

	return vars
}

// collectLocalVars collects local variables from the function body.
// Variables declared inside closures (*ast.FuncLit) are NOT collected —
// they are local to the closure, not in scope at the enclosing function's
// return statements. Variables inside nested blocks are collected with
// their innermost enclosing block's position range so that analyzeErrorReturn
// can verify scope containment.
func (d *ContextLossDetector) collectLocalVars(fn *ast.FuncDecl) []contextVar {
	var vars []contextVar

	var blocks []*ast.BlockStmt

	ast.Inspect(fn.Body, func(n ast.Node) bool {
		if n == nil {
			return true
		}

		// Don't descend into function literals (closures/callbacks).
		// Variables declared inside a closure are local to that closure,
		// not in scope at the enclosing function's return statements.
		if _, isFuncLit := n.(*ast.FuncLit); isFuncLit {
			return false
		}

		// Track block scopes for scope-containment checking.
		if block, ok := n.(*ast.BlockStmt); ok {
			blocks = append(blocks, block)
		}

		switch node := n.(type) {
		case *ast.AssignStmt:
			collectDefineStmt(node, &vars)
		case *ast.DeclStmt:
			collectVarDecl(node, &vars)
		case *ast.RangeStmt:
			collectRangeStmt(node, &vars)
		}

		return true
	})

	// Compute innermost enclosing block for each variable so that
	// analyzeErrorReturn can skip variables not in scope at a given return.
	for i := range vars {
		vars[i].blockStart, vars[i].blockEnd = innermostBlockRange(vars[i].pos, blocks)
	}

	return vars
}

// innermostBlockRange finds the position range of the smallest block that
// contains pos. Returns (NoPos, NoPos) when no enclosing block is found
// (e.g. for function-level parameters — these are in scope everywhere).
func innermostBlockRange(pos token.Pos, blocks []*ast.BlockStmt) (token.Pos, token.Pos) {
	var bestStart, bestEnd token.Pos

	for _, block := range blocks {
		start, end := block.Pos(), block.End()
		if pos < start || pos > end {
			continue
		}

		if bestStart == token.NoPos || (end-start) < (bestEnd-bestStart) {
			bestStart = start
			bestEnd = end
		}
	}

	return bestStart, bestEnd
}

func collectDefineStmt(node *ast.AssignStmt, vars *[]contextVar) {
	if node.Tok != token.DEFINE {
		return
	}

	// Detect whether any LHS is an error-like variable. If so, the other
	// LHS values are likely nil/zero on the error path (e.g. `tmpl, err :=
	// template.New(...).Parse(...)` — tmpl is nil when Parse fails).
	assignsWithErr := false

	for _, lhs := range node.Lhs {
		if ident, ok := lhs.(*ast.Ident); ok && looksLikeErrorName(ident.Name) {
			assignsWithErr = true

			break
		}
	}

	for i, lhs := range node.Lhs {
		ident, ok := lhs.(*ast.Ident)
		if !ok || ident.Name == "_" {
			continue
		}

		var typeExpr ast.Expr
		if i < len(node.Rhs) {
			typeExpr = inferTypeFromExpr(node.Rhs[i])
		}

		coAssignedWithErr := assignsWithErr && !looksLikeErrorName(ident.Name)

		*vars = append(*vars, contextVar{
			name:              ident.Name,
			ident:             ident,
			typeExpr:          typeExpr,
			pos:               node.Pos(),
			coAssignedWithErr: coAssignedWithErr,
			blockStart:        token.NoPos,
			blockEnd:          token.NoPos,
		})
	}
}

func collectVarDecl(node *ast.DeclStmt, vars *[]contextVar) {
	genDecl, ok := node.Decl.(*ast.GenDecl)
	if !ok || genDecl.Tok != token.VAR {
		return
	}

	for _, spec := range genDecl.Specs {
		vs, ok := spec.(*ast.ValueSpec)
		if !ok {
			continue
		}

		for i, name := range vs.Names {
			var typeExpr ast.Expr
			if vs.Type != nil {
				typeExpr = vs.Type
			} else if i < len(vs.Values) {
				typeExpr = inferTypeFromExpr(vs.Values[i])
			}

			*vars = append(*vars, contextVar{
				name:              name.Name,
				ident:             name,
				typeExpr:          typeExpr,
				pos:               vs.Pos(),
				coAssignedWithErr: false,
				blockStart:        token.NoPos,
				blockEnd:          token.NoPos,
			})
		}
	}
}

func collectRangeStmt(node *ast.RangeStmt, vars *[]contextVar) {
	if node.Tok != token.DEFINE {
		return
	}

	// Use the loop body position so that innermostBlockRange correctly
	// identifies the loop body as the enclosing scope, not the outer block.
	// Range variables are only in scope inside the loop body.
	varPos := node.Pos()
	if node.Body != nil {
		varPos = node.Body.Pos()
	}

	for _, lhs := range []ast.Expr{node.Key, node.Value} {
		if lhs == nil {
			continue
		}

		ident, ok := lhs.(*ast.Ident)
		if !ok || ident.Name == "_" {
			continue
		}

		*vars = append(*vars, contextVar{
			name:              ident.Name,
			ident:             ident,
			typeExpr:          nil,
			pos:               varPos,
			coAssignedWithErr: false,
			blockStart:        token.NoPos,
			blockEnd:          token.NoPos,
		})
	}
}

// inferTypeFromExpr attempts to infer a type expression from a value expression.
// Returns nil when the type cannot be determined from the AST alone.
func inferTypeFromExpr(expr ast.Expr) ast.Expr {
	switch e := expr.(type) {
	case *ast.BasicLit:
		switch e.Kind { //nolint:exhaustive // only literal kinds we can infer types from
		case token.STRING:
			return ast.NewIdent("string")
		case token.INT:
			return ast.NewIdent("int")
		case token.FLOAT:
			return ast.NewIdent("float64")
		case token.CHAR:
			return ast.NewIdent("rune")
		}
	case *ast.Ident:
		if e.Name == "true" || e.Name == "false" {
			return ast.NewIdent("bool")
		}
	case *ast.CompositeLit:
		return e.Type
	case *ast.UnaryExpr:
		if e.Op == token.AND {
			return &ast.StarExpr{X: e.X}
		}
	case *ast.FuncLit:
		return e.Type
	}

	return nil
}

// findErrorReturns collects all return statements in a function body that
// include an error value. Returns inside closures are excluded — they return
// from the closure, not from the enclosing function.
func (d *ContextLossDetector) findErrorReturns(body *ast.BlockStmt) []*ast.ReturnStmt {
	var returns []*ast.ReturnStmt

	ast.Inspect(body, func(n ast.Node) bool {
		if n == nil {
			return true
		}

		// Don't descend into closures — their returns are not returns
		// from the enclosing function.
		if _, isFuncLit := n.(*ast.FuncLit); isFuncLit {
			return false
		}

		ret, ok := n.(*ast.ReturnStmt)
		if !ok {
			return true
		}

		if findErrorExpression(ret) != nil {
			returns = append(returns, ret)
		}

		return true
	})

	return returns
}

// findErrorExpression locates the error value in a return statement.
// Returns nil when the return does not include an error.
func findErrorExpression(ret *ast.ReturnStmt) ast.Expr {
	for _, result := range ret.Results {
		if isLikelyErrorExpr(result) {
			return result
		}
	}

	return nil
}

// isLikelyErrorExpr reports whether expr looks like an error value.
func isLikelyErrorExpr(expr ast.Expr) bool {
	switch e := expr.(type) {
	case *ast.Ident:
		name := strings.ToLower(e.Name)

		return name == errorIdentifierName || name == errorInterfaceName ||
			strings.Contains(name, errorIdentifierSubstr)
	case *ast.CallExpr:
		pkg, method, _ := callSelector(
			e,
		)
		if pkg == errorsPkg || pkg == fmtPkg {
			return method == methodNew || method == methodErrorf || method == "Join" || method == methodUnwrap
		}

		if isErrorFamilyCall(e) {
			return true
		}

		// Heuristic: function name suggests error creation
		_, fnName, _ := callSelector(
			e,
		)
		if strings.HasPrefix(fnName, "New") || strings.HasPrefix(fnName, "Wrap") {
			return true
		}

		return false
	case *ast.SelectorExpr:
		sel := e.Sel.Name

		return strings.HasPrefix(sel, "Err")
	default:
		return false
	}
}

// maxVarsPerSite caps the number of variables listed in a single consolidated
// violation. When more variables are flagged, only the most relevant are shown.
const maxVarsPerSite = 3

// maxThinWrapperStatements defines the maximum number of top-level statements
// for a function to be considered a thin delegation/wrapper. Bare-error returns
// (return ..., err) in thin wrappers are not flagged — the callee already
// contextualized the error.
const maxThinWrapperStatements = 5

// flaggedContextVar pairs a context variable with its loss classification.
type flaggedContextVar struct {
	cv   contextVar
	loss *contextLossResult
}

// analyzeErrorReturn checks a single error return for context-loss violations.
// Instead of emitting one violation per variable, it collects all flagged
// variables and emits a single consolidated violation listing the most relevant.
func (d *ContextLossDetector) analyzeErrorReturn(
	ret *ast.ReturnStmt,
	errExpr ast.Expr,
	allVars []contextVar,
	allReturns []*ast.ReturnStmt,
) {
	allIncludedVars := d.varsIncludedInAnyReturn(allReturns)

	var flagged []flaggedContextVar

	for _, cv := range allVars {
		// Skip variables declared after this error return (source-order check)
		if cv.pos > ret.Pos() {
			continue
		}

		// Skip variables not in scope at this return (block-containment check).
		// Variables from nested blocks (loops, if-bodies) that don't contain
		// the return statement are not accessible at this error path.
		if cv.blockStart != token.NoPos {
			if ret.Pos() < cv.blockStart || ret.Pos() > cv.blockEnd {
				continue
			}
		}

		if allIncludedVars[cv.name] {
			continue // Included in some error path
		}

		loss := d.classifyContextLoss(cv, errExpr)
		if loss == nil {
			continue // FP rejection pipeline filtered it out
		}

		flagged = append(flagged, flaggedContextVar{cv: cv, loss: loss})
	}

	if len(flagged) == 0 {
		return
	}

	// Sort by relevance: higher severity first, then closer to the return site.
	sortFlaggedVars(flagged)

	if len(flagged) > maxVarsPerSite {
		flagged = flagged[:maxVarsPerSite]
	}

	d.emitConsolidatedViolation(flagged, ret)
}

// sortFlaggedVars sorts flagged variables by relevance: higher severity
// first, then by proximity to the return statement (closer is more relevant).
func sortFlaggedVars(flagged []flaggedContextVar) {
	sort.Slice(flagged, func(first, second int) bool {
		si, sj := flagged[first].loss.severity.Ordinal(), flagged[second].loss.severity.Ordinal()
		if si != sj {
			return si > sj // Higher severity first
		}

		// Closer assignment to the return → more relevant
		return flagged[first].cv.pos > flagged[second].cv.pos
	})
}

// emitConsolidatedViolation creates a single violation listing all flagged
// variables for one error-return site.
func (d *ContextLossDetector) emitConsolidatedViolation(
	flagged []flaggedContextVar,
	ret *ast.ReturnStmt,
) {
	primary := flagged[0]
	typeStr := typeExprString(primary.cv.typeExpr)

	names := make([]string, 0, len(flagged))
	for _, f := range flagged {
		names = append(names, f.cv.name)
	}

	var message string
	if len(flagged) == 1 {
		message = fmt.Sprintf("Context variable %q (%s) lost on error path: %s",
			primary.cv.name, typeStr, primary.loss.description)
	} else {
		message = fmt.Sprintf("Context variables lost on error path: %s — %s",
			strings.Join(names, ", "), primary.loss.description)
	}

	suggestion := d.buildSuggestion(primary.cv.name, primary.loss.subtype)

	violation := types.NewErrorViolation(
		d.analyzer.fset, ret.Pos(), ret.End(),
		types.ErrorTypeContextLoss, primary.loss.severity,
		message, suggestion, primary.cv.name,
		types.NewConfidence(contextLossConfidence),
	)
	violation.ContextLoss = &types.ContextLossDetail{
		Subtype:      primary.loss.subtype,
		VariableType: typeStr,
		Recoverable:  primary.loss.recoverable,
	}

	d.analyzer.appendViolation(violation)
}

// varsIncludedInAnyReturn returns a set of variable names that appear in any
// error expression across all error returns in the function.
func (d *ContextLossDetector) varsIncludedInAnyReturn(returns []*ast.ReturnStmt) map[string]bool {
	included := make(map[string]bool)

	for _, ret := range returns {
		errExpr := findErrorExpression(ret)
		if errExpr == nil {
			continue
		}

		ast.Inspect(errExpr, func(n ast.Node) bool {
			if ident, ok := n.(*ast.Ident); ok {
				included[ident.Name] = true
			}

			return true
		})
	}

	return included
}

// contextLossResult holds the classification of a detected context loss.
type contextLossResult struct {
	subtype     types.ContextLossSubtype
	description string
	severity    types.Severity
	recoverable bool
}

// classifyContextLoss applies the FP rejection pipeline and loss classifiers
// to determine whether a context variable constitutes a context loss and, if
// so, what subtype and severity it should have.
func (d *ContextLossDetector) classifyContextLoss(
	cv contextVar,
	errExpr ast.Expr,
) *contextLossResult {
	// --- FP rejection pipeline ---
	if rejectBlankIdentifier(cv.name) {
		return nil
	}

	if rejectCredential(cv.name) {
		return nil
	}

	// Allowlist gate: only flag variables matching business-context suffixes.
	// This replaces the former 100+ entry infrastructure denylist.
	if !isBusinessContextVar(cv.name) {
		return nil
	}

	// Type-based infrastructure rejection (when --type-aware is active):
	// reject variables of known infrastructure types even if their name
	// matches a business suffix (e.g. a context.Context named requestID).
	if d.rejectInfrastructureType(cv) {
		return nil
	}

	typeKind := classifyTypeKind(cv.typeExpr)

	if rejectByTypeKind(typeKind) {
		return nil
	}

	if rejectCoAssignedWithErr(cv) {
		return nil
	}

	if d.rejectContextIncluded(cv.name, errExpr) {
		return nil
	}

	if rejectSentinelReturn(errExpr) {
		return nil
	}

	// --- Loss classifiers (first match wins) ---

	severity := d.determineSeverity(cv.name, typeKind)

	if result := d.classifyVariadicSpread(errExpr, severity); result != nil {
		return result
	}

	if result := d.classifyErrorFamily(errExpr, severity); result != nil {
		return result
	}

	if result := d.classifyImmediateLoss(errExpr, severity); result != nil {
		return result
	}

	if result := d.classifyWrappingLoss(errExpr, severity); result != nil {
		return result
	}

	// Default: delayed recovery
	return &contextLossResult{
		subtype:     types.ContextLossDelayed,
		description: fmt.Sprintf("Context variable %q not included in error", cv.name),
		severity:    severity,
		recoverable: true,
	}
}

// buildSuggestion generates a fix suggestion based on the loss subtype.
func (d *ContextLossDetector) buildSuggestion(varName string, subtype types.ContextLossSubtype) string {
	switch subtype {
	case types.ContextLossImmediate:
		return fmt.Sprintf(
			"Include context: fmt.Errorf(\"failed for %s=%%v: %%w\", %s, err)",
			varName, varName,
		)
	case types.ContextLossWrapping:
		return fmt.Sprintf(
			"Add %s to the format string: fmt.Errorf(\"...: %s=%%v: %%w\", %s, err)",
			varName, varName, varName,
		)
	case types.ContextLossDelayed:
		return fmt.Sprintf(
			"Include %s in the error message so the caller can diagnose the failure",
			varName,
		)
	case types.ContextLossUnwrapped:
		return fmt.Sprintf(
			"Wrap the error: fmt.Errorf(\"...: %%w\", err) or include %s in the message",
			varName,
		)
	default:
		return fmt.Sprintf("Include %s in the error", varName)
	}
}

// determineSeverity maps variable importance to erraudit severity levels.
// branching-flow has 4 tiers (Critical/High/Medium/Low); erraudit has 3
// (High/Medium/Low). Critical and High both map to SeverityHigh.
func (d *ContextLossDetector) determineSeverity(varName string, kind typeKindInfo) types.Severity {
	if isCredentialVariable(varName) {
		return types.SeverityLow
	}

	if isCriticalContextVar(varName) {
		return types.SeverityHigh
	}

	if isDiagnosticContextVar(varName) {
		return types.SeverityHigh
	}

	// Type-based downgrade: function/interface/void types are rarely useful in errors
	if kind.isFunc || kind.isInterface || kind.isVoid {
		return types.SeverityLow
	}

	return types.SeverityMedium
}

// typeExprString returns a best-effort string representation of a type expression.
func typeExprString(typeExpr ast.Expr) string {
	if typeExpr == nil {
		return "unknown"
	}

	switch t := typeExpr.(type) {
	case *ast.Ident:
		return t.Name
	case *ast.SelectorExpr:
		if ident, ok := t.X.(*ast.Ident); ok {
			return ident.Name + "." + t.Sel.Name
		}

		return t.Sel.Name
	case *ast.StarExpr:
		return "*" + typeExprString(t.X)
	case *ast.ArrayType:
		return "[]" + typeExprString(t.Elt)
	case *ast.MapType:
		return "map[" + typeExprString(t.Key) + "]" + typeExprString(t.Value)
	case *ast.FuncType:
		return "func"
	case *ast.InterfaceType:
		if t.Methods == nil || len(t.Methods.List) == 0 {
			return "any"
		}

		return "interface"
	default:
		return "unknown"
	}
}
