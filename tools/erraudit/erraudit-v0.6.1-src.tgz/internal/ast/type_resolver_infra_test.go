package ast

// type_resolver_infra_test.go contains tests for IsInfrastructureType and
// IdentType — the type-based rejection safety net for context-loss detection.

import (
	"go/ast"
	"testing"
)

func TestIsInfrastructureType_Stdlib(t *testing.T) {
	code := `package testpkg

import (
	"context"
	"io"
	"sync"
	"database/sql"
	"net/http"
	"os"
	"log/slog"
)

var ctx context.Context
var r io.Reader
var w io.Writer
var c io.Closer
var mu sync.Mutex
var db *sql.DB
var req *http.Request
var rw http.ResponseWriter
var f *os.File
var logger *slog.Logger
`

	_, _, _, pkg := loadTestPackageTypes(t, code)

	tests := []struct {
		varName string
		want    bool
	}{
		{"ctx", true},
		{"r", true},
		{"w", true},
		{"c", true},
		{"mu", true},
		{"db", true},
		{"req", true},
		{"rw", true},
		{"f", true},
		{"logger", true},
	}

	for _, tt := range tests {
		t.Run(tt.varName, func(t *testing.T) {
			obj := pkg.Scope().Lookup(tt.varName)
			if obj == nil {
				t.Fatalf("variable %s not found in package scope", tt.varName)
			}

			got := IsInfrastructureType(obj.Type())
			if got != tt.want {
				t.Errorf("IsInfrastructureType(%s type=%s) = %v, want %v",
					tt.varName, obj.Type(), got, tt.want)
			}
		})
	}
}

func TestIsInfrastructureType_BusinessTypes(t *testing.T) {
	code := `package testpkg

var userID string
var count int
var ratio float64

type User struct { Name string }
var user User

type OrderID string
var orderID OrderID
`

	_, _, _, pkg := loadTestPackageTypes(t, code)

	tests := []struct {
		varName string
		want    bool
	}{
		{"userID", false},
		{"count", false},
		{"ratio", false},
		{"user", false},
		{"orderID", false},
	}

	for _, tt := range tests {
		t.Run(tt.varName, func(t *testing.T) {
			obj := pkg.Scope().Lookup(tt.varName)
			if obj == nil {
				t.Fatalf("variable %s not found in package scope", tt.varName)
			}

			got := IsInfrastructureType(obj.Type())
			if got != tt.want {
				t.Errorf("IsInfrastructureType(%s type=%s) = %v, want %v",
					tt.varName, obj.Type(), got, tt.want)
			}
		})
	}
}

func TestIsInfrastructureType_Nil(t *testing.T) {
	if IsInfrastructureType(nil) {
		t.Error("IsInfrastructureType(nil) should return false")
	}
}

func TestIsInfrastructureType_ThirdPartyPatterns(t *testing.T) {
	code := `package testpkg

type UserStore struct{}
type AccountRepository struct{}
type ApiClient struct{}
type TaskManager struct{}
type EventPublisher struct{}
type ConnectionPool struct{}
type WorkQueue struct{}

var store *UserStore
var repo *AccountRepository
var client *ApiClient
var manager *TaskManager
var pub *EventPublisher
var pool *ConnectionPool
var queue *WorkQueue
`

	_, _, _, pkg := loadTestPackageTypes(t, code)

	tests := []struct {
		varName string
		want    bool
	}{
		{"store", true},
		{"repo", true},
		{"client", true},
		{"manager", true},
		{"pub", true},
		{"pool", true},
		{"queue", true},
	}

	for _, tt := range tests {
		t.Run(tt.varName, func(t *testing.T) {
			obj := pkg.Scope().Lookup(tt.varName)
			if obj == nil {
				t.Fatalf("variable %s not found in package scope", tt.varName)
			}

			got := IsInfrastructureType(obj.Type())
			if got != tt.want {
				t.Errorf("IsInfrastructureType(%s type=%s) = %v, want %v",
					tt.varName, obj.Type(), got, tt.want)
			}
		})
	}
}

func TestIsInfrastructureType_BusinessTypeNotMatched(t *testing.T) {
	code := `package testpkg

type UserID string
type AccountName string
type FilePath string

var uid UserID
var name AccountName
var path FilePath
`

	_, _, _, pkg := loadTestPackageTypes(t, code)

	tests := []struct {
		varName string
		want    bool
	}{
		{"uid", false},
		{"name", false},
		{"path", false},
	}

	for _, tt := range tests {
		t.Run(tt.varName, func(t *testing.T) {
			obj := pkg.Scope().Lookup(tt.varName)
			if obj == nil {
				t.Fatalf("variable %s not found in package scope", tt.varName)
			}

			got := IsInfrastructureType(obj.Type())
			if got != tt.want {
				t.Errorf("IsInfrastructureType(%s type=%s) = %v, want %v",
					tt.varName, obj.Type(), got, tt.want)
			}
		})
	}
}

func TestIdentType_ResolvesCorrectType(t *testing.T) {
	code := `package testpkg

import "context"

func process(ctx context.Context, userID string) error {
	_ = ctx
	_ = userID
	return nil
}
`

	fset, file, info, pkg := loadTestPackageTypes(t, code)
	resolver := NewTypeResolver(info, pkg)

	if !resolver.Available() {
		t.Fatal("resolver should be available")
	}

	foundCtx := false
	foundUserID := false

	ast.Inspect(file, func(n ast.Node) bool {
		ident, ok := n.(*ast.Ident)
		if !ok {
			return true
		}

		resolved := resolver.IdentType(ident)
		if resolved == nil {
			return true
		}

		if ident.Name == "ctx" && IsInfrastructureType(resolved) {
			foundCtx = true
		}

		if ident.Name == "userID" && !IsInfrastructureType(resolved) {
			foundUserID = true
		}

		return true
	})

	_ = fset

	if !foundCtx {
		t.Error("expected to resolve ctx as an infrastructure type (context.Context)")
	}

	if !foundUserID {
		t.Error("expected to resolve userID as a non-infrastructure type (string)")
	}
}

func TestIdentType_NilResolver(t *testing.T) {
	var r *TypeResolver
	if r.IdentType(&ast.Ident{Name: "x"}) != nil {
		t.Error("nil resolver should return nil from IdentType")
	}
}

func TestRejectInfrastructureType_NilResolver(t *testing.T) {
	detector := &ContextLossDetector{
		analyzer: &Analyzer{
			typeResolver: nil,
		},
	}

	cv := contextVar{name: "requestID"}
	if detector.rejectInfrastructureType(cv) {
		t.Error("rejectInfrastructureType should return false when resolver is nil")
	}
}

func TestRejectInfrastructureType_UnavailableResolver(t *testing.T) {
	r := NewTypeResolver(nil, nil)
	detector := &ContextLossDetector{
		analyzer: &Analyzer{
			typeResolver: r,
		},
	}

	cv := contextVar{name: "requestID"}
	if detector.rejectInfrastructureType(cv) {
		t.Error("rejectInfrastructureType should return false when resolver is not available")
	}
}
