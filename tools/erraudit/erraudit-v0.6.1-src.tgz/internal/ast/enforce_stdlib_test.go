package ast

import (
	"go/parser"
	"go/token"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
)

// helperParseWithEnforcement parses code and analyzes it with enforcement enabled.
func helperParseWithEnforcement(t *testing.T, code string, enforce bool) *types.ErrorGraph {
	t.Helper()

	fset := token.NewFileSet()

	node, err := parser.ParseFile(fset, "", code, parser.AllErrors)
	if err != nil {
		t.Fatalf("Failed to parse code: %v", err)
	}

	opts := []AnalyzerOption{}
	if enforce {
		opts = append(opts, WithEnforceErrorFamily(true))
	}

	analyzer := NewAnalyzer(fset, "main", "test.go", opts...)

	return analyzer.Analyze(node)
}

// findStdlibViolations returns all stdlib_constructor violations.
func findStdlibViolations(t *testing.T, graph *types.ErrorGraph) []types.ErrorViolation {
	t.Helper()

	var result []types.ErrorViolation

	for _, v := range graph.Violations {
		if v.Type == types.ErrorTypeStdlibConstructor {
			result = append(result, v)
		}
	}

	return result
}

// TestEnforceErrorFamily_FlagOff verifies that with enforcement OFF, zero
// stdlib-constructor findings are produced — erraudit is neutral by default.
func TestEnforceErrorFamily_FlagOff(t *testing.T) {
	code := `package main

import (
	"errors"
	"fmt"
)

var ErrA = errors.New("a")
var ErrB = fmt.Errorf("wrapped: %w", ErrA)
var ErrC = errors.Join(ErrA, ErrB)
`
	graph := helperParseWithEnforcement(t, code, false)

	violations := findStdlibViolations(t, graph)
	assert.Empty(t, violations, "flag OFF must produce zero stdlib-constructor findings")
}

// TestEnforceErrorFamily_FlagOn verifies that with enforcement ON, all stdlib
// constructors are flagged.
func TestEnforceErrorFamily_FlagOn(t *testing.T) {
	code := `package main

import (
	"errors"
	"fmt"
)

var ErrA = errors.New("a")
var ErrB = fmt.Errorf("wrapped: %w", ErrA)
var ErrC = errors.Join(ErrA, ErrB)
`
	graph := helperParseWithEnforcement(t, code, true)

	violations := findStdlibViolations(t, graph)
	assert.Len(t, violations, 3, "flag ON must flag all three stdlib constructors")

	// Verify each constructor type is flagged
	constructors := make(map[string]bool)
	for _, v := range violations {
		constructors[v.ErrorName] = true
		assert.Equal(t, types.SeverityMedium, v.Severity)
		assert.Contains(t, v.Message, "enforces go-error-family")
	}

	assert.True(t, constructors["errors.New"], "errors.New must be flagged")
	assert.True(t, constructors["fmt.Errorf"], "fmt.Errorf must be flagged")
	assert.True(t, constructors["errors.Join"], "errors.Join must be flagged")
}

// TestEnforceErrorFamily_FamilyConstructorsNotFlagged verifies that go-error-family
// constructors are NOT flagged even when enforcement is ON.
func TestEnforceErrorFamily_FamilyConstructorsNotFlagged(t *testing.T) {
	code := `package main

import (
	"errors"
	"github.com/larsartmann/go-error-family"
)

var ErrA = errorfamily.NewRejection("REJ_001", "rejected")
var ErrB = errorfamily.WrapRejection(ErrA, "REJ_002", "wrapped")
var ErrC = errors.New("stdlib")
`
	graph := helperParseWithEnforcement(t, code, true)

	violations := findStdlibViolations(t, graph)
	assert.Len(t, violations, 1, "only the stdlib constructor should be flagged")
	assert.Equal(t, "errors.New", violations[0].ErrorName)
}

// TestEnforceErrorFamily_ZeroOverheadWhenOff verifies that the enforcement
// detector adds zero violations when disabled, even with stdlib constructors
// everywhere in the code.
func TestEnforceErrorFamily_ZeroOverheadWhenOff(t *testing.T) {
	code := `package main

import (
	"errors"
	"fmt"
)

func foo() error {
	err := bar()
	if err != nil {
		return fmt.Errorf("failed: %w", err)
	}
	return errors.New("done")
}

func bar() error {
	return errors.New("bar")
}
`
	graph := helperParseWithEnforcement(t, code, false)

	violations := findStdlibViolations(t, graph)
	assert.Empty(t, violations, "disabled enforcement must have zero overhead")
}

// TestEnforceErrorFamily_InFunctionBody verifies that stdlib constructors
// inside function bodies (not just package-level vars) are also flagged.
func TestEnforceErrorFamily_InFunctionBody(t *testing.T) {
	code := `package main

import (
	"errors"
	"fmt"
)

func process() error {
	err := step()
	if err != nil {
		return fmt.Errorf("failed: %w", err)
	}
	return errors.New("ok")
}

func step() error { return nil }
`
	graph := helperParseWithEnforcement(t, code, true)

	violations := findStdlibViolations(t, graph)
	assert.GreaterOrEqual(t, len(violations), 2,
		"stdlib constructors in function bodies must be flagged")
}

// TestEnforceErrorFamily_ProjectErrorsImportNotFlagged verifies that
// errors.New calls are NOT flagged when the file imports a project package
// under the name "errors" (e.g. github.com/.../pkg/errors) instead of stdlib
// "errors". This is the import-resolution fix.
func TestEnforceErrorFamily_ProjectErrorsImportNotFlagged(t *testing.T) {
	code := `package main

import (
	errors "github.com/larsartmann/erraudit/pkg/errors"
)

func process() error {
	return errors.New("project error")
}`
	graph := helperParseWithEnforcement(t, code, true)

	violations := findStdlibViolations(t, graph)
	assert.Empty(t, violations,
		"errors.New from project pkg/errors must NOT be flagged as stdlib")
}

// TestEnforceErrorFamily_AliasedStdlibImportFlagged verifies that when stdlib
// "errors" is imported under its real name, it IS flagged.
func TestEnforceErrorFamily_AliasedStdlibImportFlagged(t *testing.T) {
	code := `package main

import (
	"errors"
)

var ErrA = errors.New("stdlib error")
var ErrB = errors.Join(ErrA)
`
	graph := helperParseWithEnforcement(t, code, true)

	violations := findStdlibViolations(t, graph)
	assert.Len(t, violations, 2,
		"stdlib errors.New and errors.Join must be flagged")
}

// TestEnforceErrorFamily_FmtFromStdlibFlagged verifies that fmt.Errorf from
// real stdlib fmt IS flagged.
func TestEnforceErrorFamily_FmtFromStdlibFlagged(t *testing.T) {
	code := `package main

import (
	"fmt"
)

var ErrA = fmt.Errorf("failed: %d", 42)
`
	graph := helperParseWithEnforcement(t, code, true)

	violations := findStdlibViolations(t, graph)
	assert.Len(t, violations, 1, "stdlib fmt.Errorf must be flagged")
	assert.Equal(t, "fmt.Errorf", violations[0].ErrorName)
}
