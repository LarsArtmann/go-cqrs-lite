package ast

import (
	"go/ast"
	"go/token"
	"strings"
)

// formatStringLiteral returns the format string when call's first argument is
// a string basic literal, and false otherwise — variable formats and
// non-literal expressions have no statically known format to scan.
//
// Semantics (owner decision 2026-09-22): interpreted (\"...\") and raw
// (`...`) string literals are the SAME kind of format string. Both quote
// styles are trimmed so backtick fmt.Errorf formats are wrap sites exactly
// like quoted ones — this is the single canonical extraction; do not add
// per-site trimming.
func formatStringLiteral(call *ast.CallExpr) (string, bool) {
	if len(call.Args) == 0 {
		return "", false
	}

	lit, ok := call.Args[0].(*ast.BasicLit)
	if !ok || lit.Kind != token.STRING {
		return "", false
	}

	return strings.Trim(lit.Value, "\"`"), true
}

// wrapArgIndices scans a Go fmt format string and returns the 0-based
// positions (among the format arguments, i.e. the args that follow the format
// string) of every %w verb, in the order they appear.
//
// Each %w in a fmt.Errorf format string designates one wrapped error. Since
// Go 1.20 a format string may contain several %w verbs, each binding to the
// next positional argument. The returned indices let callers map those verbs
// back to the exact call arguments so multi-error wrapping relationships are
// recorded precisely rather than collapsing to a single parent.
//
// The boolean reports whether the format string could be parsed reliably.
// When false (e.g. explicit positional indexing like "%[1]w"), callers should
// fall back to a conservative heuristic instead of trusting an empty result.
//
// Scanning follows fmt's verb grammar: after a leading '%', optional flags
// (+ - 0 # or space), an optional width (digits or '*'), an optional
// '.precision' (digits or '*'), and finally the verb character. The '%%'
// escape consumes no argument; every other verb consumes exactly one.
func wrapArgIndices(format string) ([]int, bool) {
	var indices []int

	argIndex := 0

	for i := 0; i < len(format); {
		if format[i] != '%' {
			i++

			continue
		}

		i++ // consume '%'

		if i >= len(format) {
			break
		}

		// Explicit argument indexing (e.g. %[1]w) changes positional accounting
		// in a way this scanner does not model — signal unreliability so the
		// caller falls back rather than trusting a partial result.
		if format[i] == '[' {
			return nil, false
		}

		i = skipFlags(format, i)
		i = skipWidth(format, i)
		i = skipPrecision(format, i)

		if i >= len(format) {
			break
		}

		verb := format[i]
		i++

		if verb == '%' {
			continue
		}

		if verb == 'w' {
			indices = append(indices, argIndex)
		}

		argIndex++
	}

	return indices, true
}

// skipFlags advances past the optional flag runes that may follow '%'.
func skipFlags(format string, i int) int {
	for i < len(format) && strings.ContainsRune("+-0 #", rune(format[i])) {
		i++
	}

	return i
}

// skipWidth advances past an optional width specifier (digits or '*').
func skipWidth(format string, i int) int {
	return skipDigitsOrStar(format, i)
}

// skipPrecision advances past an optional '.precision' specifier.
func skipPrecision(format string, i int) int {
	if i >= len(format) || format[i] != '.' {
		return i
	}

	i++ // consume '.'

	return skipDigitsOrStar(format, i)
}

// skipDigitsOrStar advances past a run of format digits or '*' — the shared
// shape of width and precision value runs.
func skipDigitsOrStar(format string, i int) int {
	for i < len(format) && (isFormatDigit(format[i]) || format[i] == '*') {
		i++
	}

	return i
}

func isFormatDigit(c byte) bool {
	return c >= '0' && c <= '9'
}
