package ast

// analyzer_precision_test.go contains regression tests for the false-positive
// fixes documented in docs/feedback/new/
// 2026-07-26_analyze-detector-blank-identifier-and-silent-swallow-false-positives.md.
//
// Each test maps to a numbered acceptance criterion in that document:
//   - TestPrecision_BlankIdentifier_NonErrorCaptured         (Finding 1a, 1c)
//   - TestPrecision_BlankIdentifier_PresenceFlagSibling      (Finding 1b)
//   - TestPrecision_BlankIdentifier_MapIndex                 (comma-ok map)
//   - TestPrecision_SilentSwallow_ErrorAccumulation          (Finding 2)
//   - TestPrecision_SilentSwallow_NoErrorReturn_Downgraded   (Finding 3)
//   - TestPrecision_SilentSwallow_NoErrorReturn_StillCriticalWhenEmpty (Finding 3 edge)
//   - TestPrecision_SilentSwallow_LogThenReturnNil_StillFlagged (regression guard)
//   - TestPrecision_SuggestionNestedSelector                 (Observation C)
//
// All cases run WITHOUT type info (the default `erraudit ./...` mode), proving
// the AST-only heuristics eliminate the reported false positives.

import (
	"strings"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
)

// helperAssertNoViolationsOf fails the test if any violation of the given type
// is present in the graph. Used for negative cases ("must NOT be flagged").
func helperAssertNoViolationsOf(t *testing.T, graph *types.ErrorGraph, vtype types.ErrorType, context string) {
	t.Helper()

	for _, v := range graph.Violations {
		if v.Type == vtype {
			t.Errorf("False positive (%s): %s — got %s violation at %s: %q",
				context, vtype, v.Severity, v.Position, v.Message)
		}
	}
}

// helperFindViolation returns the first violation of the given type, or nil.
func helperFindViolation(graph *types.ErrorGraph, vtype types.ErrorType) *types.ErrorViolation {
	for i := range graph.Violations {
		if graph.Violations[i].Type == vtype {
			return &graph.Violations[i]
		}
	}

	return nil
}

// Acceptance criterion: "_, err := os.Stat(p) with the error checked is NOT flagged."
// The blank discards FileInfo; statErr is the error and is captured.
// The previous exact-match check on "err" missed statErr/registerErr/etc.
func TestPrecision_BlankIdentifier_NonErrorCaptured(t *testing.T) {
	t.Run("StatErr", func(t *testing.T) {
		// `_, statErr := os.Stat(p)` — statErr contains "Err", must be recognized.
		code := `
package main

import "os"

func check(p string) bool {
	_, statErr := os.Stat(p)
	if statErr == nil {
		return true
	}
	return false
}`
		helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
			helperAssertNoViolationsOf(t, graph, types.ErrorTypeIgnored,
				"_, statErr := os.Stat(p) — statErr captures the error")
		})
	})

	t.Run("RegisterErr", func(t *testing.T) {
		// `_, registerErr := h.RegisterBranch(...)` — registerErr captures the error.
		code := `
package main

func register(name string) error {
	_, registerErr := doRegister(name)
	if registerErr != nil {
		return registerErr
	}
	return nil
}

func doRegister(name string) (bool, error) { return true, nil }
`
		helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
			helperAssertNoViolationsOf(t, graph, types.ErrorTypeIgnored,
				"_, registerErr := doRegister(...) — registerErr captures the error")
		})
	})

	t.Run("ErrFooSuffix", func(t *testing.T) {
		// `_, errFoo := ...` — lowercase err prefix must also be recognized.
		code := `
package main

func example() error {
	_, errFoo := doWork()
	if errFoo != nil {
		return errFoo
	}
	return nil
}

func doWork() (int, error) { return 0, nil }
`
		helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
			helperAssertNoViolationsOf(t, graph, types.ErrorTypeIgnored,
				"_, errFoo := doWork() — errFoo captures the error")
		})
	})
}

// Acceptance criterion: "A blank identifier in a non-error position (incl. functions
// with no error return) is NOT flagged as ignored."
// Tests the comma-ok / (T, bool) accessor pattern where the sibling LHS is a
// presence-flag name (ok, found, exists, present, has).
func TestPrecision_BlankIdentifier_PresenceFlagSibling(t *testing.T) {
	presenceNames := []string{"ok", "found", "exists", "present", "has"}

	for _, name := range presenceNames {
		t.Run(name, func(t *testing.T) {
			code := `
package main

type Thing struct{}

type Store struct{}

func (s *Store) Get(n string) (*Thing, bool) { return nil, false }

func example(s *Store, n string) bool {
	_, ` + name + ` := s.Get(n)
	return ` + name + `
}
`
			helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
				helperAssertNoViolationsOf(t, graph, types.ErrorTypeIgnored,
					"_, "+name+" := s.Get(n) — "+name+" is a presence flag, not an error")
			})
		})
	}
}

// Map index comma-ok: `_, ok := m[key]` never returns an error.
func TestPrecision_BlankIdentifier_MapIndex(t *testing.T) {
	code := `
package main

func example() bool {
	m := map[string]int{"a": 1}
	_, ok := m["b"]
	return ok
}
`
	helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
		helperAssertNoViolationsOf(t, graph, types.ErrorTypeIgnored,
			"map index comma-ok never returns error")
	})
}

// Type assertion comma-ok: `_, ok := x.(T)` never returns an error.
func TestPrecision_BlankIdentifier_TypeAssertion(t *testing.T) {
	code := `
package main

func example(x any) bool {
	_, ok := x.(int)
	return ok
}
`
	helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
		helperAssertNoViolationsOf(t, graph, types.ErrorTypeIgnored,
			"type assertion comma-ok never returns error")
	})
}

// Real ignore is still caught when there is no error-capture sibling.
// Guards against over-suppression.
func TestPrecision_BlankIdentifier_RealIgnoreStillFlagged(t *testing.T) {
	code := `
package main

import "os"

func badFunc() {
	_, _ = os.Open("file.txt")
}`
	helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
		if helperFindViolation(graph, types.ErrorTypeIgnored) == nil {
			t.Error("Expected ErrorTypeIgnored for _, _ = os.Open(...) — both results blank")
		}
	})
}

// Signature-aware blank-identifier check: a same-file function whose return
// type at the blank position is provably not error is NOT flagged — even when
// the sibling LHS is NOT a conventional presence-flag name. This is the root
// fix for the band-aid presence-flag heuristic that could not cover all
// comma-ok / (T, bool) accessor patterns.
func TestPrecision_BlankIdentifier_SignatureAware_NonErrorReturn(t *testing.T) {
	t.Run("FunctionReturningTwoInts", func(t *testing.T) {
		// getCount returns (int, int) — position 0 is int, not error.
		// The sibling "n" is NOT a presence-flag name, so the old heuristic
		// would falsely flag this. The signature-aware check suppresses it.
		code := `
package main

func example() int {
	_, n := getCount()
	return n
}

func getCount() (int, int) { return 0, 0 }
`
		helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
			helperAssertNoViolationsOf(t, graph, types.ErrorTypeIgnored,
				"_, n := getCount() — getCount returns (int, int), not error")
		})
	})

	t.Run("FunctionReturningItemBool", func(t *testing.T) {
		// getItem returns (Item, bool) — position 0 is Item, not error.
		code := `
package main

type Item struct{ V int }

func example() Item {
	_, it := getItem()
	return it
}

func getItem() (Item, bool) { return Item{}, false }
`
		helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
			helperAssertNoViolationsOf(t, graph, types.ErrorTypeIgnored,
				"_, it := getItem() — getItem returns (Item, bool), not error")
		})
	})

	t.Run("MethodReturningItemBool", func(t *testing.T) {
		// Method Get returns (*Item, bool) — position 0 is *Item, not error.
		// The sibling "val" is NOT a presence-flag name.
		code := `
package main

type Item struct{ V int }
type Store struct{}

func (s *Store) Get(key string) (*Item, bool) { return nil, false }

func example(s *Store) *Item {
	_, val := s.Get("key")
	return val
}
`
		helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
			helperAssertNoViolationsOf(t, graph, types.ErrorTypeIgnored,
				"_, val := s.Get(key) — Get returns (*Item, bool), not error")
		})
	})
}

// Signature-aware check does NOT suppress when the return type IS error.
// Same-file function returning (int, error) with both blanks → still flagged.
func TestPrecision_BlankIdentifier_SignatureAware_ErrorReturnStillFlagged(t *testing.T) {
	code := `
package main

func badFunc() {
	_, _ = getErr()
}

func getErr() (int, error) { return 0, nil }
`
	helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
		if helperFindViolation(graph, types.ErrorTypeIgnored) == nil {
			t.Error("Expected ErrorTypeIgnored for _, _ = getErr() — getErr returns (int, error)")
		}
	})
}

// Signature-aware check does NOT suppress when the return type looks like a
// custom error type (name contains "error"). Conservative: potential error
// types are never silently suppressed.
func TestPrecision_BlankIdentifier_SignatureAware_CustomErrorTypeStillFlagged(t *testing.T) {
	code := `
package main

type MyError struct{ msg string }

func (e *MyError) Error() string { return e.msg }

func badFunc() {
	_, _ = getErr()
}

func getErr() (int, *MyError) { return 0, nil }
`
	helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
		if helperFindViolation(graph, types.ErrorTypeIgnored) == nil {
			t.Error("Expected ErrorTypeIgnored for _, _ = getErr() — *MyError looks like an error type")
		}
	})
}

// --no-suppress bypasses the signature-aware check: same-file function returning
// non-error is still flagged when the user explicitly requests all violations.
func TestPrecision_BlankIdentifier_NoSuppress_OverridesSignatureAware(t *testing.T) {
	code := `
package main

func example() int {
	_, n := getCount()
	return n
}

func getCount() (int, int) { return 0, 0 }
`
	_, graph := helperParseAndAnalyzeWithOptions(t, code, WithNoSuppress(true))
	if helperFindViolation(graph, types.ErrorTypeIgnored) == nil {
		t.Error("Expected ErrorTypeIgnored with --no-suppress despite non-error return signature")
	}
}

// --no-suppress bypasses the presence-flag heuristic: the presence-flag sibling
// check is skipped and the blank assignment is flagged.
func TestPrecision_BlankIdentifier_NoSuppress_OverridesPresenceFlag(t *testing.T) {
	code := `
package main

type Store struct{}

func (s *Store) Get(key string) (int, bool) { return 0, false }

func example(s *Store) bool {
	_, ok := s.Get("key")
	return ok
}
`
	_, graph := helperParseAndAnalyzeWithOptions(t, code, WithNoSuppress(true))
	if helperFindViolation(graph, types.ErrorTypeIgnored) == nil {
		t.Error("Expected ErrorTypeIgnored with --no-suppress despite presence-flag sibling")
	}
}

// Acceptance criterion: "An if err != nil block that appends/wraps/logs the error
// is NOT flagged as silent_swallow, and never at CRITICAL."
// The error is accumulated into a slice and surfaced on the failure path.
func TestPrecision_SilentSwallow_ErrorAccumulation(t *testing.T) {
	t.Run("AppendToSlice", func(t *testing.T) {
		code := `
package main

type Provider interface {
	Resolve(req string) (string, error)
}

func resolveAll(providers []Provider) string {
	var providerErrors []error
	for _, p := range providers {
		_, err := p.Resolve("req")
		if err != nil {
			providerErrors = append(providerErrors, err)
			continue
		}
	}
	if len(providerErrors) == 0 {
		return "ok"
	}
	return "failed"
}
`
		helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
			helperAssertNoViolationsOf(t, graph, types.ErrorTypeSilentSwallow,
				"error appended to providerErrors — not a swallow")
		})
	})

	t.Run("WrapError", func(t *testing.T) {
		// errors.Wrap(err, ...) preserves the error for later return.
		code := `
package main

import "fmt"

func wrapExample() error {
	err := doSomething()
	if err != nil {
		wrapped := fmt.Errorf("context: %w", err)
		return wrapped
	}
	return nil
}

func doSomething() error { return nil }
`
		helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
			helperAssertNoViolationsOf(t, graph, types.ErrorTypeSilentSwallow,
				"error wrapped with fmt.Errorf — preserved, not swallowed")
		})
	})
}

// P1.1: the error flows into a struct field, composite literal, or reassigned
// variable, and the carrier is then appended/wrapped. The direct-operand band-aid
// could not follow this intra-block data flow and misclassified these
// fan-out/aggregate patterns as CRITICAL swallows. The taint check now
// recognizes them.
func TestPrecision_SilentSwallow_ErrorFlowThroughFields(t *testing.T) {
	t.Run("FieldStoreThenAppend", func(t *testing.T) {
		// err taints `entry` via a field store; `entry` reaches append.
		code := `
package main

type Entry struct{ Err error }

func collect() []Entry {
	var entries []Entry
	for i := 0; i < 3; i++ {
		err := step()
		if err != nil {
			entry := Entry{}
			entry.Err = err
			entries = append(entries, entry)
			continue
		}
	}
	return entries
}

func step() error { return nil }
`
		helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
			helperAssertNoViolationsOf(t, graph, types.ErrorTypeSilentSwallow,
				"err stored in entry.Err then appended — preserved, not swallowed")
		})
	})

	t.Run("CompositeLiteralThenAppend", func(t *testing.T) {
		// err flows into a composite literal assigned to `r`; `r` reaches append.
		code := `
package main

type Result struct{ Err error }

func collect() []Result {
	var results []Result
	for i := 0; i < 3; i++ {
		err := step()
		if err != nil {
			r := Result{Err: err}
			results = append(results, r)
			continue
		}
	}
	return results
}

func step() error { return nil }
`
		helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
			helperAssertNoViolationsOf(t, graph, types.ErrorTypeSilentSwallow,
				"err stored in Result{Err: err} then appended — preserved, not swallowed")
		})
	})

	t.Run("ReassignThenAppend", func(t *testing.T) {
		// err reassigned to `e`; `e` reaches append.
		code := `
package main

func collect() []error {
	var errs []error
	for i := 0; i < 3; i++ {
		err := step()
		if err != nil {
			e := err
			errs = append(errs, e)
			continue
		}
	}
	return errs
}

func step() error { return nil }
`
		helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
			helperAssertNoViolationsOf(t, graph, types.ErrorTypeSilentSwallow,
				"err reassigned to e then appended — preserved, not swallowed")
		})
	})

	t.Run("TransitiveTwoHop", func(t *testing.T) {
		// err -> entry -> wrapped -> append (two taint hops).
		code := `
package main

type Entry struct{ Err error }

func collect() []Entry {
	var entries []Entry
	err := step()
	if err != nil {
		entry := Entry{Err: err}
		wrapped := entry
		entries = append(entries, wrapped)
		continue
	}
	return entries
}

func step() error { return nil }
`
		helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
			helperAssertNoViolationsOf(t, graph, types.ErrorTypeSilentSwallow,
				"err -> entry -> wrapped -> append (transitive taint) — preserved")
		})
	})
}

// P1.1 guard: storing the error in a field of a carrier that is NEVER surfaced
// (the per-iteration local is dropped) is still a swallow. Guards against
// over-suppression from the taint check.
func TestPrecision_SilentSwallow_FieldStoreDropped_StillFlagged(t *testing.T) {
	code := `
package main

type Entry struct{ Err error }

func work() {
	for i := 0; i < 3; i++ {
		err := step()
		if err != nil {
			entry := Entry{}
			entry.Err = err
			continue
		}
	}
}

func step() error { return nil }
`
	helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
		if helperFindViolation(graph, types.ErrorTypeSilentSwallow) == nil {
			t.Fatal("Expected silent_swallow — err stored in a dropped local then continue")
		}
	})
}

// Acceptance criterion: "A checked error in a function with no error return is
// downgraded from CRITICAL."
// The function returns int — there is nowhere for `return err` to go.
// A defensive break is not a CRITICAL swallow.
func TestPrecision_SilentSwallow_NoErrorReturn_Downgraded(t *testing.T) {
	code := `
package main

type Node struct{ hash string }

func count(start *Node, target string) int {
	count := 0
	current := start
	for current.hash != target {
		count++
		_, err := parent(current)
		if err != nil {
			break
		}
	}
	return count
}

func parent(n *Node) (*Node, error) { return nil, nil }
`
	helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
		v := helperFindViolation(graph, types.ErrorTypeSilentSwallow)
		if v == nil {
			t.Skip("no swallow violation emitted (acceptable — fully suppressed)")
		}

		if v.Severity == types.SeverityHigh {
			t.Errorf(
				"Function has no error return; swallow must not be CRITICAL (got %s): %q",
				v.Severity, v.Message,
			)
		}

		if !strings.Contains(strings.ToLower(v.Message), "no error return") {
			t.Errorf("Expected downgraded message to mention 'no error return', got: %q", v.Message)
		}
	})
}

// Edge case: an empty `if err != nil {}` block is STILL CRITICAL even when the
// function has no error return. An empty block means the error is completely
// ignored — that is always a swallow regardless of signature.
func TestPrecision_SilentSwallow_NoErrorReturn_StillCriticalWhenEmpty(t *testing.T) {
	code := `
package main

func check() int {
	err := doSomething()
	if err != nil {
	}
	return 0
}

func doSomething() error { return nil }
`
	helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
		v := helperFindViolation(graph, types.ErrorTypeSilentSwallow)
		if v == nil {
			t.Fatal("Expected silent_swallow for empty if-err-nil block")
		}

		if v.Severity != types.SeverityHigh {
			t.Errorf(
				"Empty if-err-nil block must remain CRITICAL even without error return; got %s",
				v.Severity,
			)
		}
	})
}

// Regression guard: the existing "log then return nil" swallow pattern must
// still be flagged. Logging does NOT preserve the error for the caller.
func TestPrecision_SilentSwallow_LogThenReturnNil_StillFlagged(t *testing.T) {
	code := `
package main

import (
	"errors"
	"log"
)

func example() error {
	err := errors.New("boom")
	if err != nil {
		log.Println(err)
		return nil
	}
	return nil
}
`
	helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
		v := helperFindViolation(graph, types.ErrorTypeSilentSwallow)
		if v == nil {
			t.Fatal("Expected silent_swallow for log.Println(err); return nil")
		}

		if v.Severity != types.SeverityHigh {
			t.Errorf("Log-then-return-nil swallow must be CRITICAL; got %s", v.Severity)
		}
	})
}

// P1.2: a function literal — a deferred closure, goroutine, or assigned callback
// — has its OWN return signature. The no-error-return downgrade must classify a
// swallow against the closure's signature, not the enclosing function's.
// Previously funcDeclStack only pushed *ast.FuncDecl, so a closure with no error
// return inside an error-returning function was wrongly reported CRITICAL (it
// inherited the outer function's signature).
//
// Fixture uses a bare continue (error NOT consumed by any call): since the
// 2026-09-04 feedback, log-then-return in a void closure is accepted handling
// (the logging call consumes the error) and no longer produces a violation.
func TestPrecision_SilentSwallow_DeferClosure_NoErrorReturn_Downgraded(t *testing.T) {
	code := `
package main

func outer() error {
	defer func() {
		for {
			_, err := step()
			if err != nil {
				continue
			}
			return
		}
	}()
	return nil
}

func step() error { return nil }
`
	helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
		v := helperFindViolation(graph, types.ErrorTypeSilentSwallow)
		if v == nil {
			t.Fatal("Expected silent_swallow for log.Println(err); return inside deferred closure")
		}

		if v.Severity == types.SeverityHigh {
			t.Errorf(
				"Deferred closure has no error return; swallow must not be CRITICAL (got %s): %q",
				v.Severity, v.Message,
			)
		}

		if !strings.Contains(strings.ToLower(v.Message), "no error return") {
			t.Errorf("Expected downgraded message to mention 'no error return', got: %q", v.Message)
		}
	})
}

// P1.2: same as above but for a goroutine closure (`go func(){...}()`).
// Bare continue (error NOT consumed) keeps the downgrade-path coverage; see
// the 2026-09-04 feedback for why log-and-return in void closures is accepted.
func TestPrecision_SilentSwallow_GoroutineClosure_NoErrorReturn_Downgraded(t *testing.T) {
	code := `
package main

func outer() error {
	go func() {
		for {
			_, err := step()
			if err != nil {
				continue
			}
			return
		}
	}()
	return nil
}

func step() error { return nil }
`
	helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
		v := helperFindViolation(graph, types.ErrorTypeSilentSwallow)
		if v == nil {
			t.Fatal("Expected silent_swallow for log.Println(err); return inside goroutine closure")
		}

		if v.Severity == types.SeverityHigh {
			t.Errorf(
				"Goroutine closure has no error return; swallow must not be CRITICAL (got %s): %q",
				v.Severity, v.Message,
			)
		}
	})
}

// P1.2 guard: a closure that DOES return error must still get CRITICAL for a
// log-then-return-nil swallow, even when the ENCLOSING function has no error
// return. Before the fix the closure inherited the enclosing signature and was
// wrongly downgraded.
func TestPrecision_SilentSwallow_ClosureWithErrorReturn_StillCritical(t *testing.T) {
	code := `
package main

import "log"

func outer() {
	cb := func() error {
		err := step()
		if err != nil {
			log.Println(err)
			return nil
		}
		return nil
	}
	_ = cb
}

func step() error { return nil }
`
	helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
		v := helperFindViolation(graph, types.ErrorTypeSilentSwallow)
		if v == nil {
			t.Fatal("Expected silent_swallow for log.Println(err); return nil inside error-returning closure")
		}

		if v.Severity != types.SeverityHigh {
			t.Errorf(
				"Closure returns error; log-then-return-nil swallow must be CRITICAL; got %s",
				v.Severity,
			)
		}
	})
}

// Acceptance criterion: "Suggestion text shows Storage.Get, not &{h storage}.Get."
// Nested selector receiver expressions must render as source text.
func TestPrecision_SuggestionNestedSelector(t *testing.T) {
	code := `
package main

type Container struct{ storage *NestedStorage }
type NestedStorage struct{}

func (s *NestedStorage) Get(name string) (string, error) { return "", nil }

func example(c *Container) {
	_, _ = c.storage.Get("name")
}
`
	helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
		v := helperFindViolation(graph, types.ErrorTypeIgnored)
		if v == nil {
			t.Fatal("Expected ignored violation for _, _ = c.storage.Get(...)")
		}

		if strings.Contains(v.Suggestion, "&{") {
			t.Errorf("Suggestion leaks AST struct form: %q", v.Suggestion)
		}

		if !strings.Contains(v.Suggestion, "c.storage.Get") {
			t.Errorf("Expected suggestion to contain 'c.storage.Get', got: %q", v.Suggestion)
		}
	})
}
