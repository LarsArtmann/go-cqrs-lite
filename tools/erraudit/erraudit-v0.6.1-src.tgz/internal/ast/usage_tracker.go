package ast

// Inline error-usage tracking. The declared hierarchy tracks package-level
// error variables only; these counters surface the runtime-side references —
// function-body wrap sites (fmt.Errorf %w, errors.Join) and errors.Is checks
// — so a flat hierarchy is reported with evidence instead of a bare zero.
//
// References are identified by identifier only (same package), matching the
// discovery model of NamedErrorDiscoverer; selector references such as
// store.ErrNotFound from another package are out of scope for AST mode.

import (
	"go/ast"
	"go/token"
	"maps"
	"strings"

	"github.com/larsartmann/erraudit/pkg/types"
)

// errorUsage accumulates inline reference-site counts for one file analysis.
// The maps are non-nil from NewAnalyzer onward; hierarchy metrics serialize
// them only when non-empty (omitempty). The selector maps hold qualified
// (pkg.Sel) references awaiting post-merge resolution.
type errorUsage struct {
	inlineWrapSites    uint
	typeCheckSites     uint
	wrapSitesByError   map[string]uint
	checkSitesByError  map[string]uint
	selectorWrapSites  map[string]uint
	selectorCheckSites map[string]uint

	// Detail sites behind the counts above: call position + enclosing function
	// per reference. Selector maps hold qualified ("pkg.Sel") keys resolved
	// post-merge by FinalizeHierarchy, mirroring the count maps.
	wrapSiteRefs          map[string][]types.ErrorSiteRef
	checkSiteRefs         map[string][]types.ErrorSiteRef
	selectorWrapSiteRefs  map[string][]types.ErrorSiteRef
	selectorCheckSiteRefs map[string][]types.ErrorSiteRef
}

// collectErrorDecls returns the names of package-level variables bound to
// error constructors in the given file. Used as a pre-pass so that inline
// references to errors declared LATER in the file (or in sibling files, via
// WithPackageErrorDecls) are recognized regardless of traversal order.
func collectErrorDecls(node ast.Node) map[string]bool {
	names := make(map[string]bool)

	file, ok := node.(*ast.File)
	if !ok {
		return names
	}

	for _, decl := range file.Decls {
		genDecl, ok := decl.(*ast.GenDecl)
		if !ok || (genDecl.Tok != token.VAR && genDecl.Tok != token.CONST) {
			continue
		}

		for _, spec := range genDecl.Specs {
			valueSpec, ok := spec.(*ast.ValueSpec)
			if !ok {
				continue
			}

			for i, name := range valueSpec.Names {
				if i < len(valueSpec.Values) && isErrorConstructorCall(valueSpec.Values[i]) {
					names[name.Name] = true
				}
			}
		}
	}

	return names
}

// CollectErrorDecls returns the names of package-level error variables across
// all files of a package (package-mode pre-pass, mirroring CollectFuncSigs).
func CollectErrorDecls(files []*ast.File) map[string]bool {
	names := make(map[string]bool)

	for _, file := range files {
		maps.Copy(names, collectErrorDecls(file))
	}

	return names
}

// isErrorConstructorCall reports whether expr is a call to a recognized error
// constructor (errors.New, fmt.Errorf, errors.Join, or any go-error-family /
// samber-oops constructor). The decl set is a candidate filter, not a
// discovery result, so broad family/oops matching is intentional.
func isErrorConstructorCall(expr ast.Expr) bool {
	call, ok := expr.(*ast.CallExpr)
	if !ok {
		return false
	}

	pkgName, methodName, ok := callSelector(call)
	if !ok {
		return false
	}

	switch pkgName {
	case "errors":
		return methodName == "New" || methodName == "Join"
	case "fmt":
		return methodName == "Errorf"
	case "errorfamily", "oops":
		return true
	default:
		return false
	}
}

// trackErrorUsage inspects a call expression during the main walk and records
// inline (function-body) wrap and check sites. Package-level calls are
// skipped — their wrapping is already represented as hierarchy relationships.
func (a *Analyzer) trackErrorUsage(call *ast.CallExpr) {
	if len(a.funcNameStack) == 0 {
		return
	}

	switch {
	case isCallTo(call, "fmt", "Errorf"):
		a.trackInlineWrap(call)
	case isCallTo(call, "errors", "Join"):
		a.trackInlineJoin(call)
	case isCallTo(call, "errors", "Is"):
		a.trackInlineCheck(call)
	case isCallTo(call, "errors", "As"):
		a.trackInlineAsCheck(call)
	case isWrapConstructorCall(call):
		a.trackInlineFamilyWrap(call)
	}
}

// isWrapConstructorCall reports whether call is an inline wrap-style
// constructor from go-error-family or samber-oops: errorfamily.Wrap* and
// oops.Wrap/Wrapf all take the wrapped cause as their first argument. This
// closes the constructor asymmetry with NamedErrorDiscoverer, which already
// recognizes the same constructors in package-level declarations.
func isWrapConstructorCall(call *ast.CallExpr) bool {
	pkgName, methodName, ok := callSelector(call)
	if !ok {
		return false
	}

	switch pkgName {
	case "errorfamily":
		return strings.HasPrefix(methodName, "Wrap")
	case "oops":
		return methodName == "Wrap" || methodName == "Wrapf"
	default:
		return false
	}
}

// trackInlineWrap counts a function-body fmt.Errorf %w site and records each
// named error it references — identifier operands directly, selector
// operands (otherPkg.ErrX) as qualified references resolved after merge.
func (a *Analyzer) trackInlineWrap(call *ast.CallExpr) {
	formatValue, ok := formatStringLiteral(call)
	if !ok || !strings.Contains(formatValue, "%w") {
		return
	}

	a.usage.inlineWrapSites++

	for _, name := range a.namedErrorDiscoverer.findWrappedErrorNames(call) {
		if a.isKnownErrorDecl(name) {
			a.recordWrapSite(name, call)
		}
	}

	for _, qualified := range selectorWrapTargets(call) {
		a.usage.selectorWrapSites[qualified]++
		a.usage.selectorWrapSiteRefs[qualified] = append(
			a.usage.selectorWrapSiteRefs[qualified], a.siteRef(call))
	}
}

// trackInlineJoin counts a function-body errors.Join site and records each
// named error among its arguments.
func (a *Analyzer) trackInlineJoin(call *ast.CallExpr) {
	a.usage.inlineWrapSites++

	for _, arg := range call.Args {
		if name, ok := a.declErrorIdent(arg); ok {
			a.recordWrapSite(name, call)
		}
	}
}

// trackInlineCheck counts an errors.Is reference to a named error: the
// sentinel operand is the second argument by API contract. Identifier
// operands resolve against declared errors; selector operands are recorded
// as qualified references for post-merge attribution.
func (a *Analyzer) trackInlineCheck(call *ast.CallExpr) {
	if len(call.Args) < minErrorfArgs {
		return
	}

	if name, ok := a.declErrorIdent(call.Args[1]); ok {
		a.usage.checkSitesByError[name]++
		a.usage.checkSiteRefs[name] = append(a.usage.checkSiteRefs[name], a.siteRef(call))

		return
	}

	if qualified, ok := qualifiedErrorIdent(call.Args[1]); ok {
		a.usage.selectorCheckSites[qualified]++
		a.usage.selectorCheckSiteRefs[qualified] = append(
			a.usage.selectorCheckSiteRefs[qualified], a.siteRef(call))
	}
}

// trackInlineAsCheck counts a function-body errors.As site. The target
// operand is a TYPE (e.g. &myErr), not a named sentinel, so per-error
// attribution needs type information — AST mode records the total only.
func (a *Analyzer) trackInlineAsCheck(_ *ast.CallExpr) {
	a.usage.typeCheckSites++
}

// trackInlineFamilyWrap counts a function-body errorfamily.Wrap* / oops.Wrap*
// site and attributes its first argument (the wrapped cause) when it names a
// declared error — identifier directly, selector as a qualified reference for
// post-merge attribution.
func (a *Analyzer) trackInlineFamilyWrap(call *ast.CallExpr) {
	if len(call.Args) == 0 {
		return
	}

	a.usage.inlineWrapSites++

	if name, ok := a.declErrorIdent(call.Args[0]); ok {
		a.recordWrapSite(name, call)

		return
	}

	if qualified, ok := qualifiedErrorIdent(call.Args[0]); ok {
		a.usage.selectorWrapSites[qualified]++
		a.usage.selectorWrapSiteRefs[qualified] = append(
			a.usage.selectorWrapSiteRefs[qualified], a.siteRef(call))
	}
}

// qualifiedErrorIdent extracts a "pkg.Sel" qualified name from a selector
// expression.
func qualifiedErrorIdent(expr ast.Expr) (string, bool) {
	sel, ok := expr.(*ast.SelectorExpr)
	if !ok {
		return "", false
	}

	pkgIdent, ok := sel.X.(*ast.Ident)
	if !ok {
		return "", false
	}

	return pkgIdent.Name + "." + sel.Sel.Name, true
}

// selectorWrapTargets returns the qualified ("pkg.Sel") operands wrapped by a
// fmt.Errorf %w call. Mirrors findWrappedErrorNames' two strategies: operand
// positions correlated from the literal format string when reliable,
// otherwise a scan of all arguments for Err-prefixed selectors (the
// conservative fallback keeps non-error arguments out).
func selectorWrapTargets(call *ast.CallExpr) []string {
	if len(call.Args) < minErrorfArgs {
		return nil
	}

	formatValue, ok := formatStringLiteral(call)
	if ok {
		if indices, reliable := wrapArgIndices(formatValue); reliable {
			return qualifiedAtIndices(call.Args[1:], indices)
		}
	}

	var names []string

	for _, arg := range call.Args[1:] {
		sel, ok := arg.(*ast.SelectorExpr)
		if !ok || !strings.HasPrefix(sel.Sel.Name, "Err") {
			continue
		}

		if qualified, ok := qualifiedErrorIdent(arg); ok {
			names = append(names, qualified)
		}
	}

	return names
}

// qualifiedAtIndices returns the qualified selector names at the given
// 0-based argument positions.
func qualifiedAtIndices(args []ast.Expr, indices []int) []string {
	var names []string

	for _, idx := range indices {
		if idx >= len(args) {
			continue
		}

		if qualified, ok := qualifiedErrorIdent(args[idx]); ok {
			names = append(names, qualified)
		}
	}

	return names
}

// recordWrapSite bumps the inline wrap count for one named error and records
// the site reference (position + enclosing function) behind it.
func (a *Analyzer) recordWrapSite(name string, call *ast.CallExpr) {
	a.usage.wrapSitesByError[name]++
	a.usage.wrapSiteRefs[name] = append(a.usage.wrapSiteRefs[name], a.siteRef(call))
}

// siteRef builds an ErrorSiteRef for a call site: fset-resolved position and
// the innermost enclosing named function (empty inside closures without a
// named frame).
func (a *Analyzer) siteRef(call *ast.CallExpr) types.ErrorSiteRef {
	ref := types.ErrorSiteRef{Function: a.currentFuncName()}
	if a.fset != nil {
		ref.Position = a.fset.Position(call.Pos())
	}

	return ref
}

// declErrorIdent reports whether expr is an identifier referring to a
// declared named error, returning its name.
func (a *Analyzer) declErrorIdent(expr ast.Expr) (string, bool) {
	ident, ok := expr.(*ast.Ident)
	if !ok {
		return "", false
	}

	return ident.Name, a.isKnownErrorDecl(ident.Name)
}

// isKnownErrorDecl reports whether name refers to a package-level error
// declaration known to this analyzer: either pre-collected from the package
// (WithPackageErrorDecls + same-file pre-pass) or already discovered during
// the walk.
func (a *Analyzer) isKnownErrorDecl(name string) bool {
	return a.errorDecls[name] || a.isErrorDefinition(name)
}

// mergeErrorDecls extends the analyzer's package-level error declaration set
// with the current file's own declarations. The package set (if provided) is
// copied, never mutated — it is shared across per-file analyzers.
func (a *Analyzer) mergeErrorDecls(own map[string]bool) {
	if len(a.errorDecls) == 0 {
		a.errorDecls = own

		return
	}

	merged := make(map[string]bool, len(a.errorDecls)+len(own))
	maps.Copy(merged, a.errorDecls)
	maps.Copy(merged, own)
	a.errorDecls = merged
}

// applyNodeReferenceCounts copies the per-name reference-site counts from the
// hierarchy metrics onto the nodes, so renderers can annotate labels without
// reaching back into the metrics maps. Idempotent; called after the final
// metrics are known (buildHierarchy and FinalizeHierarchy).
func applyNodeReferenceCounts(h *types.ErrorHierarchy) {
	if h == nil {
		return
	}

	for name, node := range h.AllNodes {
		node.InlineWraps = h.Metrics.WrapSitesByError[name]
		node.Checks = h.Metrics.CheckSitesByError[name]
	}
}
