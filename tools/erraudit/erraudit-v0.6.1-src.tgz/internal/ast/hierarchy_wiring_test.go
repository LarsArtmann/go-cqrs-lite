package ast

import (
	"go/token"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestBuildHierarchy_RemovesCyclicRelationships(t *testing.T) {
	fset := token.NewFileSet()
	analyzer := NewAnalyzer(fset, "main", "test.go")

	analyzer.namedErrors = []types.NamedError{
		{Name: "ErrA"},
		{Name: "ErrB"},
	}

	// ErrA wraps ErrB, AND ErrB wraps ErrA — a cycle
	analyzer.relationships = []types.ErrorRelationship{
		{Parent: "ErrA", Child: "ErrB", RelationshipType: types.RelationshipTypeWraps, Depth: 1},
		{Parent: "ErrB", Child: "ErrA", RelationshipType: types.RelationshipTypeWraps, Depth: 2},
	}

	hierarchy := analyzer.buildHierarchy()

	// The second relationship (ErrB→ErrA) should have been dropped
	assert.Len(t, hierarchy.Relationships, 1, "cyclic relationship should be removed")
	assert.Equal(t, "ErrA", hierarchy.Relationships[0].Parent)
	assert.Equal(t, "ErrB", hierarchy.Relationships[0].Child)
}

func TestBuildHierarchy_DeduplicatesRelationships(t *testing.T) {
	fset := token.NewFileSet()
	analyzer := NewAnalyzer(fset, "main", "test.go")

	analyzer.namedErrors = []types.NamedError{
		{Name: "ErrParent"},
		{Name: "ErrChild"},
	}

	// Three relationships, two are exact duplicates
	analyzer.relationships = []types.ErrorRelationship{
		{Parent: "ErrParent", Child: "ErrChild", RelationshipType: types.RelationshipTypeWraps, Depth: 1},
		{Parent: "ErrParent", Child: "ErrChild", RelationshipType: types.RelationshipTypeWraps, Depth: 1},
		{Parent: "ErrParent", Child: "ErrOther", RelationshipType: types.RelationshipTypeWraps, Depth: 1},
	}

	hierarchy := analyzer.buildHierarchy()

	assert.Len(t, hierarchy.Relationships, 2, "duplicate relationship should be removed")
}

func TestBuildHierarchy_ComputesGraphCorrectDepths(t *testing.T) {
	fset := token.NewFileSet()
	analyzer := NewAnalyzer(fset, "main", "test.go")

	analyzer.namedErrors = []types.NamedError{
		{Name: "ErrRoot"},
		{Name: "ErrMiddle"},
		{Name: "ErrLeaf"},
	}

	// Chain: ErrRoot wraps ErrMiddle wraps ErrLeaf
	// rel.Depth values are deliberately wrong (traversal-order) to prove
	// the enrichment overrides them with graph-correct values.
	analyzer.relationships = []types.ErrorRelationship{
		{Parent: "ErrRoot", Child: "ErrMiddle", RelationshipType: types.RelationshipTypeWraps, Depth: 99},
		{Parent: "ErrMiddle", Child: "ErrLeaf", RelationshipType: types.RelationshipTypeWraps, Depth: 99},
	}

	hierarchy := analyzer.buildHierarchy()

	// ErrRoot is a root (never a child) → depth 0
	assert.Equal(t, uint(0), hierarchy.AllNodes["ErrRoot"].Depth, "root should have depth 0")
	// ErrMiddle is one level below root → depth 1
	assert.Equal(t, uint(1), hierarchy.AllNodes["ErrMiddle"].Depth, "middle should have depth 1")
	// ErrLeaf is two levels below root → depth 2
	assert.Equal(t, uint(2), hierarchy.AllNodes["ErrLeaf"].Depth, "leaf should have depth 2")

	// MaxDepth should be 2 (the deepest node), not 99
	assert.Equal(t, uint(2), hierarchy.Metrics.MaxDepth, "MaxDepth should reflect graph structure")
	assert.Equal(t, "ErrLeaf", hierarchy.Metrics.DeepestError, "DeepestError should be the leaf")
}

func TestBuildHierarchy_SingleNodeDepthZero(t *testing.T) {
	fset := token.NewFileSet()
	analyzer := NewAnalyzer(fset, "main", "test.go")

	analyzer.namedErrors = []types.NamedError{
		{Name: "ErrLonely"},
	}

	hierarchy := analyzer.buildHierarchy()

	assert.Equal(t, uint(0), hierarchy.AllNodes["ErrLonely"].Depth)
	assert.Equal(t, uint(0), hierarchy.Metrics.MaxDepth)
}

func TestRemoveCyclicRelationships_PreservesAcyclicChain(t *testing.T) {
	fset := token.NewFileSet()
	analyzer := NewAnalyzer(fset, "main", "test.go")
	tracker := NewRelationshipTracker(analyzer)

	// A → B → C is a valid chain (no cycle)
	analyzer.relationships = makeRelationships(
		[2]string{"A", "B"},
		[2]string{"B", "C"},
	)

	tracker.RemoveCyclicRelationships()

	assert.Len(t, analyzer.relationships, 2, "acyclic chain should be preserved")
}

func TestRemoveCyclicRelationships_DropsCyclicEdge(t *testing.T) {
	fset := token.NewFileSet()
	analyzer := NewAnalyzer(fset, "main", "test.go")
	tracker := NewRelationshipTracker(analyzer)

	// A → B → C → A closes a cycle; the last edge should be dropped
	analyzer.relationships = makeRelationships(
		[2]string{"A", "B"},
		[2]string{"B", "C"},
		[2]string{"C", "A"},
	)

	tracker.RemoveCyclicRelationships()

	require.Len(t, analyzer.relationships, 2, "one cyclic edge should be dropped")

	// The first two (A→B, B→C) are kept; C→A is the cycle-closer and dropped
	assert.Equal(t, "A", analyzer.relationships[0].Parent)
	assert.Equal(t, "B", analyzer.relationships[1].Parent)
}

func TestRemoveCyclicRelationships_SelfCycle(t *testing.T) {
	fset := token.NewFileSet()
	analyzer := NewAnalyzer(fset, "main", "test.go")
	tracker := NewRelationshipTracker(analyzer)

	// A → A is a self-cycle
	analyzer.relationships = []types.ErrorRelationship{
		{Parent: "A", Child: "A", RelationshipType: types.RelationshipTypeWraps},
	}

	tracker.RemoveCyclicRelationships()

	assert.Empty(t, analyzer.relationships, "self-cycle should be removed")
}

func TestRemoveCyclicRelationships_EmptySlice(t *testing.T) {
	fset := token.NewFileSet()
	analyzer := NewAnalyzer(fset, "main", "test.go")
	tracker := NewRelationshipTracker(analyzer)

	analyzer.relationships = nil

	tracker.RemoveCyclicRelationships()

	assert.Empty(t, analyzer.relationships)
}

func TestRemoveCyclicRelationships_SingleRelationship(t *testing.T) {
	fset := token.NewFileSet()
	analyzer := NewAnalyzer(fset, "main", "test.go")
	tracker := NewRelationshipTracker(analyzer)

	analyzer.relationships = makeRelationships(
		[2]string{"ErrParent", "ErrChild"},
	)

	tracker.RemoveCyclicRelationships()

	require.Len(t, analyzer.relationships, 1)
	assert.Equal(t, "ErrParent", analyzer.relationships[0].Parent)
	assert.Equal(t, "ErrChild", analyzer.relationships[0].Child)
}

func TestRemoveCyclicRelationships_PreservesOrder(t *testing.T) {
	fset := token.NewFileSet()
	analyzer := NewAnalyzer(fset, "main", "test.go")
	tracker := NewRelationshipTracker(analyzer)

	analyzer.relationships = makeRelationships(
		[2]string{"A", "B"},
		[2]string{"C", "D"},
		[2]string{"E", "F"},
	)

	tracker.RemoveCyclicRelationships()

	require.Len(t, analyzer.relationships, 3)
	assert.Equal(t, "A", analyzer.relationships[0].Parent)
	assert.Equal(t, "C", analyzer.relationships[1].Parent)
	assert.Equal(t, "E", analyzer.relationships[2].Parent)
}

func TestEnrichHierarchyDepths_DeterministicDeepestError(t *testing.T) {
	fset := token.NewFileSet()
	analyzer := NewAnalyzer(fset, "main", "test.go")

	analyzer.namedErrors = []types.NamedError{
		{Name: "ErrZebra"},
		{Name: "ErrAlpha"},
		{Name: "ErrRoot"},
	}

	// Both ErrZebra and ErrAlpha are at depth 1 (children of ErrRoot)
	// DeepestError should be ErrAlpha (lexicographically first)
	analyzer.relationships = []types.ErrorRelationship{
		{Parent: "ErrRoot", Child: "ErrZebra", RelationshipType: types.RelationshipTypeWraps},
		{Parent: "ErrRoot", Child: "ErrAlpha", RelationshipType: types.RelationshipTypeWraps},
	}

	hierarchy := analyzer.buildHierarchy()

	assert.Equal(t, uint(1), hierarchy.Metrics.MaxDepth)
	assert.Equal(t, "ErrAlpha", hierarchy.Metrics.DeepestError,
		"tie should be broken by lexicographic order")
}

func TestFinalizeHierarchy_DeduplicatesCrossFileRelationships(t *testing.T) {
	hierarchy := &types.ErrorHierarchy{
		AllNodes: map[string]*types.ErrorNode{
			"ErrRoot":  {Name: "ErrRoot", Children: []*types.ErrorNode{}},
			"ErrChild": {Name: "ErrChild", Children: []*types.ErrorNode{}},
		},
		Relationships: []types.ErrorRelationship{
			{Parent: "ErrRoot", Child: "ErrChild", RelationshipType: types.RelationshipTypeWraps},
			{Parent: "ErrRoot", Child: "ErrChild", RelationshipType: types.RelationshipTypeWraps},
		},
		NamedErrors: []types.NamedError{{Name: "ErrRoot"}, {Name: "ErrChild"}},
		Metrics:     types.HierarchyMetrics{WrapCount: make(map[string]uint)},
	}

	FinalizeHierarchy(hierarchy)

	assert.Len(t, hierarchy.Relationships, 1, "cross-file duplicate should be removed")
	assert.Equal(t, uint(1), hierarchy.Metrics.TotalRelationships)
}

func TestFinalizeHierarchy_RemovesCrossFileCycles(t *testing.T) {
	hierarchy := &types.ErrorHierarchy{
		AllNodes: map[string]*types.ErrorNode{
			"ErrA": {Name: "ErrA", Children: []*types.ErrorNode{}},
			"ErrB": {Name: "ErrB", Children: []*types.ErrorNode{}},
		},
		Relationships: []types.ErrorRelationship{
			{Parent: "ErrA", Child: "ErrB", RelationshipType: types.RelationshipTypeWraps},
			{Parent: "ErrB", Child: "ErrA", RelationshipType: types.RelationshipTypeWraps},
		},
		NamedErrors: []types.NamedError{{Name: "ErrA"}, {Name: "ErrB"}},
		Metrics:     types.HierarchyMetrics{WrapCount: make(map[string]uint)},
	}

	FinalizeHierarchy(hierarchy)

	assert.Len(t, hierarchy.Relationships, 1, "cross-file cycle should leave one edge")
}

func TestFinalizeHierarchy_RecomputesDepths(t *testing.T) {
	hierarchy := &types.ErrorHierarchy{
		AllNodes: map[string]*types.ErrorNode{
			"ErrRoot":   {Name: "ErrRoot", Depth: 99, Children: []*types.ErrorNode{}},
			"ErrMiddle": {Name: "ErrMiddle", Depth: 99, Children: []*types.ErrorNode{}},
			"ErrLeaf":   {Name: "ErrLeaf", Depth: 99, Children: []*types.ErrorNode{}},
		},
		Relationships: []types.ErrorRelationship{
			{Parent: "ErrRoot", Child: "ErrMiddle", RelationshipType: types.RelationshipTypeWraps},
			{Parent: "ErrMiddle", Child: "ErrLeaf", RelationshipType: types.RelationshipTypeWraps},
		},
		NamedErrors: []types.NamedError{
			{Name: "ErrRoot"}, {Name: "ErrMiddle"}, {Name: "ErrLeaf"},
		},
		Metrics: types.HierarchyMetrics{WrapCount: make(map[string]uint)},
	}

	FinalizeHierarchy(hierarchy)

	assert.Equal(t, uint(0), hierarchy.AllNodes["ErrRoot"].Depth)
	assert.Equal(t, uint(1), hierarchy.AllNodes["ErrMiddle"].Depth)
	assert.Equal(t, uint(2), hierarchy.AllNodes["ErrLeaf"].Depth)
	assert.Equal(t, uint(2), hierarchy.Metrics.MaxDepth)
	assert.Equal(t, "ErrLeaf", hierarchy.Metrics.DeepestError)
}

func TestFinalizeHierarchy_NilSafe(t *testing.T) {
	FinalizeHierarchy(nil)

	hierarchy := &types.ErrorHierarchy{
		AllNodes: map[string]*types.ErrorNode{},
		Metrics:  types.HierarchyMetrics{WrapCount: make(map[string]uint)},
	}
	FinalizeHierarchy(hierarchy)
}

// TestFinalizeHierarchy_SummaryMetrics verifies branching and chain metrics
// are derived from the cleaned, merged relationship set.
func TestFinalizeHierarchy_SummaryMetrics(t *testing.T) {
	hierarchy := &types.ErrorHierarchy{
		AllNodes: map[string]*types.ErrorNode{
			"Root":       {Name: "Root", Depth: 0},
			"ChildA":     {Name: "ChildA", Depth: 1},
			"ChildB":     {Name: "ChildB", Depth: 1},
			"ChildC":     {Name: "ChildC", Depth: 1},
			"Grandchild": {Name: "Grandchild", Depth: 2},
		},
		Relationships: []types.ErrorRelationship{
			{Parent: "Root", Child: "ChildA", Depth: 1},
			{Parent: "Root", Child: "ChildB", Depth: 1},
			{Parent: "Root", Child: "ChildC", Depth: 1},
			{Parent: "ChildA", Child: "Grandchild", Depth: 2},
		},
		NamedErrors: []types.NamedError{
			{Name: "Root"}, {Name: "ChildA"}, {Name: "ChildB"}, {Name: "ChildC"}, {Name: "Grandchild"},
		},
		Metrics: types.HierarchyMetrics{WrapCount: make(map[string]uint)},
	}

	FinalizeHierarchy(hierarchy)
	m := hierarchy.Metrics

	// Root has 3 children, ChildA has 1: avg = (3+1)/2 = 2.0
	assert.Equal(t, 2.0, m.AvgBranchingFactor, "AvgBranchingFactor should be 2.0")

	assert.Equal(t, "Root", m.MaxBranchingParent, "MaxBranchingParent should be Root")
	assert.Equal(t, uint(3), m.MaxBranchingCount, "MaxBranchingCount should be 3")

	// Deepest node is Grandchild (depth 2); chain length = 3 (Root→ChildA→Grandchild)
	assert.Equal(t, uint(3), m.LongestChainLength, "LongestChainLength should be 3")
	assert.Equal(t, "Root", m.LongestChainRoot, "LongestChainRoot should be Root")
}
