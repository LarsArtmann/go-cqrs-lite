package ast

// analyzer_violation_test.go contains tests for violation detection
// including errorf analysis, panic analysis, and metric detection.

import (
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
)

// helperNoViolationExpected tests that a specific violation type is NOT detected.
// Use this for negative test cases where we expect no violations of a certain type.
func helperNoViolationExpected(
	t *testing.T,
	code string,
	violationType types.ErrorType,
	errMsg string,
) {
	t.Helper()
	helperAnalysisTest(t, code, func(analyzer *Analyzer, graph *types.ErrorGraph) {
		for _, v := range graph.Violations {
			if v.Type == violationType {
				t.Error(errMsg)
			}
		}
	})
}

func TestAnalyzer_MetricDetection(t *testing.T) {
	tests := []ViolationTestCase{
		BlankIdentifierTestCase(),
		SilentSwallowTestCase(),
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			helperViolationTestWithMetric(t,
				tt.imports, tt.violationCode,
				tt.expectedViolation, tt.metricField, tt.expectedMetric)
		})
	}
}

func TestAnalyzer_analyzeErrorf(t *testing.T) {
	t.Run("ErrorWrappingWithW", func(t *testing.T) {
		code := `
package main

import (
	"fmt"
	"errors"
)

func wrap(err error) error {
	return fmt.Errorf("wrapped: %w", err)
}`
		helperAnalysisTest(t, code, func(analyzer *Analyzer, graph *types.ErrorGraph) {
			// Should find error wrapping (not a violation)
			helperErrorTypeCheck(t, graph, types.ErrorTypeWrapping, "error wrapping")

			// Verify message is correct
			found := false

			for _, errInfo := range graph.Errors {
				if errInfo.Type == types.ErrorTypeWrapping {
					found = true

					if errInfo.Message != "Error wrapping with %w" {
						t.Errorf(
							"Expected message to be about error wrapping, got: %s",
							errInfo.Message,
						)
					}

					break
				}
			}

			if !found {
				t.Error("Expected to find error wrapping")
			}
		})
	})

	t.Run("ErrorNotWrappedWithV", func(t *testing.T) {
		code := `
package main

import (
	"fmt"
	"errors"
)

func badWrap(err error) error {
	return fmt.Errorf("bad: %v", err)
}`
		helperAnalysisTest(t, code, func(analyzer *Analyzer, graph *types.ErrorGraph) {
			helperGraphViolationCheck(
				t,
				graph,
				types.ErrorTypeUnwrapped,
				func(v *types.ErrorViolation) {
					if v.Severity != types.SeverityMedium {
						t.Errorf("Expected medium severity, got '%s'", v.Severity)
					}

					if v.Suggestion == "" {
						t.Error("Expected non-empty suggestion")
					}
				},
			)
		})
	})
}

func TestAnalyzer_analyzePanic(t *testing.T) {
	t.Run("PanicOnError", func(t *testing.T) {
		code := `
package main

import (
	"errors"
)

func badFunc(err error) {
	if err != nil {
		panic(err)
	}
}`
		helperAnalysisTest(t, code, func(analyzer *Analyzer, graph *types.ErrorGraph) {
			helperGraphViolationCheck(
				t,
				graph,
				types.ErrorTypePanic,
				func(v *types.ErrorViolation) {
					if v.Severity != types.SeverityHigh {
						t.Errorf("Expected high severity, got '%s'", v.Severity)
					}

					if v.Suggestion == "" {
						t.Error("Expected non-empty suggestion")
					}

					assertMessageContains(t, v.Message, "panic")
				},
			)
		})
	})

	t.Run("PanicWithNonError", func(t *testing.T) {
		code := `
package main

func badFunc() {
	panic("something")
}`
		helperNoViolationExpected(t, code, types.ErrorTypePanic,
			"Unexpectedly found panic violation for non-error panic")
	})
}

func TestAnalyzer_blankIdentifierWithCapturedError(t *testing.T) {
	t.Run("NoViolationForUnderscoreWithErrCaptured", func(t *testing.T) {
		code := `
package main

import "database/sql"

func DeleteRecord(db *sql.DB) error {
	_, err := db.Exec("DELETE FROM t WHERE id = $1", 1)
	return err
}`
		helperNoViolationExpected(
			t,
			code,
			types.ErrorTypeIgnored,
			"False positive: _, err := db.Exec(...) should NOT be flagged — error IS captured in err",
		)
	})

	t.Run("ViolationForUnderscoreWithoutErrorCapture", func(t *testing.T) {
		code := `
package main

import "os"

func badFunc() {
	_, _ = os.Open("file.txt")
}`
		helperAnalysisTest(t, code, func(analyzer *Analyzer, graph *types.ErrorGraph) {
			count := 0
			for _, v := range graph.Violations {
				if v.Type == types.ErrorTypeIgnored {
					count++
				}
			}
			if count == 0 {
				t.Error("Expected ignored error violation for _, _ := os.Open(...)")
			}
			if count > 1 {
				t.Errorf(
					"Expected exactly 1 ignored violation for multi-blank assignment, got %d",
					count,
				)
			}
		})
	})

	t.Run("NoDuplicateViolationsForMultiBlankAssignment", func(t *testing.T) {
		code := `
package main

import "fmt"

func Format(f fmt.State, msg string) {
	_, _ = fmt.Fprint(f, msg)
	_, _, _ = fmt.Fprintf(f, "%s %s", "a", "b")
}`
		helperAnalysisTest(t, code, func(analyzer *Analyzer, graph *types.ErrorGraph) {
			violationByKey := make(map[string]int)
			for _, v := range graph.Violations {
				violationByKey[v.Key()]++
			}
			for key, count := range violationByKey {
				if count > 1 {
					t.Errorf("Duplicate violation: key=%s count=%d", key, count)
				}
			}
		})
	})
}

func helperTypeAwareAnalyze(t *testing.T, code string) *types.ErrorGraph {
	t.Helper()

	fset, file, info, pkg := loadTestPackageTypes(t, code)
	analyzer := NewAnalyzer(
		fset,
		pkg.Name(),
		"test.go",
		WithTypeResolver(NewTypeResolver(info, pkg)),
	)

	return analyzer.Analyze(file)
}

func helperAssertNoErrorTypeIgnored(t *testing.T, graph *types.ErrorGraph, context string) {
	t.Helper()

	for _, v := range graph.Violations {
		if v.Type == types.ErrorTypeIgnored {
			t.Errorf("False positive: %s, got violation at %s", context, v.Position)
		}
	}
}

func helperAssertHasErrorTypeIgnored(t *testing.T, graph *types.ErrorGraph, errMsg string) {
	t.Helper()

	found := false
	for _, v := range graph.Violations {
		if v.Type == types.ErrorTypeIgnored {
			found = true
		}
	}
	if !found {
		t.Error(errMsg)
	}
}

func TestAnalyzer_typeAwareBlankIdentifier(t *testing.T) {
	tests := []struct {
		name           string
		code           string
		wantIgnoredErr bool
		context        string
	}{
		{
			name: "NonErrorReturnNotFlaggedWithTypeInfo",
			code: `
package testpkg

func returnsIntString() (int, string) { return 0, "" }

func example() {
	_, _ = returnsIntString()
}`,
			wantIgnoredErr: false,
			context:        "returnsIntString returns (int, string), not error",
		},
		{
			name: "ErrorReturnFlaggedWithTypeInfo",
			code: `
package testpkg

import "os"

func badFunc() {
	_, _ = os.Open("file.txt")
}`,
			wantIgnoredErr: true,
			context:        "Expected ignored error violation for _ = os.Open(...) with type info",
		},
		{
			name: "MapLookupBoolNotFlagged",
			code: `
package testpkg

func example() {
	m := map[string]int{"a": 1}
	_, ok := m["b"]
	_ = ok
}`,
			wantIgnoredErr: false,
			context:        "map lookup returns (int, bool), not error",
		},
		{
			name: "MultiReturnSecondIsError",
			code: `
package testpkg

import "os"

func badFunc() {
	_, _ = os.ReadFile("file.txt")
}`,
			wantIgnoredErr: true,
			context:        "Expected ignored error violation for _ = os.ReadFile(...) — second return is error",
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			graph := helperTypeAwareAnalyze(t, tc.code)
			if tc.wantIgnoredErr {
				helperAssertHasErrorTypeIgnored(t, graph, tc.context)
			} else {
				helperAssertNoErrorTypeIgnored(t, graph, tc.context)
			}
		})
	}
}
