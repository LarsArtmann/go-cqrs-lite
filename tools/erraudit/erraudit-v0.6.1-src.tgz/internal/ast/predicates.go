package ast

import (
	"go/ast"
	"go/token"
	"slices"
	"strings"
)

const (
	errorIdentifierSubstr = "err"
	errorIdentifierName   = "err"
	nilLiteral            = "nil"
	minErrorfArgs         = 2 // fmt.Errorf needs format string + at least one arg for wrapping
	snippetContextLines   = 2 // lines of context around a snippet position

	// Shared string constants used across AST analysis (satisfies goconst).
	errorInterfaceName = "error"
	errorsPkg          = "errors"
	fmtPkg             = "fmt"
	methodNew          = "New"
	methodWrap         = "Wrap"
	methodWrapf        = "Wrapf"
	methodErrorf       = "Errorf"
	methodUnwrap       = "Unwrap"
	logVarName         = "log"
)

// Predicate functions for AST type checking
// These are small, focused boolean checks for AST nodes

// isGenericErrorInterface checks if a field type is the bare "error" interface
// (not a specific/custom error type like ValidationError).
func (a *Analyzer) isGenericErrorInterface(field *ast.Field) bool {
	if field.Type == nil {
		return false
	}

	if ident, ok := field.Type.(*ast.Ident); ok && ident.Name == errorInterfaceName {
		return true
	}

	return false
}

// errorReturningInterfaceMethods lists method names from Go standard library
// interfaces whose signatures dictate returning the bare error type.
// Flagging these as "should return a specific error type" is always a false
// positive because the developer cannot change the return type without breaking
// the interface contract.
//
//nolint:gochecknoglobals // immutable lookup table for interface method names
var errorReturningInterfaceMethods = map[string]bool{
	// encoding/json
	"MarshalJSON": true, "UnmarshalJSON": true,
	// encoding (Text/Binary/XML)
	"MarshalText": true, "UnmarshalText": true,
	"MarshalBinary": true, "UnmarshalBinary": true,
	"MarshalXML": true, "UnmarshalXML": true,
	"MarshalXMLAttr": true, "UnmarshalXMLAttr": true,
	// io
	"Read": true, "Write": true, "Close": true, "Seek": true,
	"ReadAt": true, "WriteAt": true, "ReadFrom": true, "WriteTo": true,
	"WriteString": true, "ReadByte": true, "WriteByte": true,
	"ReadRune": true, "UnreadRune": true, "UnreadByte": true,
	// error interface
	methodUnwrap: true,
	// flag.Value
	"Set": true,
}

// isInterfaceMethodWithFixedSignature returns true if the function name matches
// a standard library interface method whose return signature requires the bare
// error type.
func isInterfaceMethodWithFixedSignature(name string) bool {
	return errorReturningInterfaceMethods[name]
}

// isConstructorOrFactory returns true if the function name follows Go
// conventions for error constructors (New*, Wrap*) or parse/factory functions
// (Parse*). These are idiomatic patterns where returning the bare error
// interface is expected and changing to a specific type would be non-idiomatic.
func isConstructorOrFactory(name string) bool {
	lower := strings.ToLower(name)

	return strings.HasPrefix(lower, "new") ||
		strings.HasPrefix(lower, "wrap") ||
		strings.HasPrefix(lower, "parse")
}

// createsErrorInternally returns true if the function body contains calls that
// create or wrap errors (errors.New, fmt.Errorf, or any .Wrap/.Wrapf call).
// Functions that merely propagate errors from other calls are pure forwarders
// and should not be flagged for generic_return.
func (a *Analyzer) createsErrorInternally(fn *ast.FuncDecl) bool {
	creates := false

	ast.Inspect(fn, func(n ast.Node) bool {
		if creates {
			return false
		}

		call, ok := n.(*ast.CallExpr)
		if !ok {
			return true
		}

		if a.isErrorCreatingCall(call) {
			creates = true

			return false
		}

		if sel, ok := call.Fun.(*ast.SelectorExpr); ok {
			method := sel.Sel.Name
			if method == methodWrap || method == methodWrapf {
				creates = true

				return false
			}
		}

		return true
	})

	return creates
}

// hasGenericErrorReturn checks if a function should be flagged for returning
// the generic error interface instead of a specific error type.
//
// Three false-positive filters are applied:
//  1. Standard interface methods (MarshalJSON, Read, Write, etc.) are excluded
//     because their signatures are dictated by the interface contract.
//  2. Constructors and factory functions (New*, Wrap*, Parse*) are excluded
//     because returning bare error is the idiomatic Go pattern.
//  3. Pure forwarders (functions that don't create errors internally) are
//     excluded because defining a custom error type adds noise without value.
func (a *Analyzer) hasGenericErrorReturn(fn *ast.FuncDecl) bool {
	if fn.Type.Results == nil || fn.Name == nil {
		return false
	}

	hasBareError := slices.ContainsFunc(fn.Type.Results.List, func(field *ast.Field) bool {
		return a.isGenericErrorInterface(field)
	})
	if !hasBareError {
		return false
	}

	name := fn.Name.Name

	if isInterfaceMethodWithFixedSignature(name) {
		return false
	}

	if isConstructorOrFactory(name) {
		return false
	}

	if !a.createsErrorInternally(fn) {
		return false
	}

	return true
}

// isErrorIdentifier checks if an expression is an error identifier.
func (a *Analyzer) isErrorIdentifier(expr ast.Expr) bool {
	if ident, ok := expr.(*ast.Ident); ok {
		name := strings.ToLower(ident.Name)

		return name == errorIdentifierName || strings.Contains(name, errorIdentifierSubstr)
	}

	return false
}

// looksLikeErrorName reports whether an identifier name reads as an error
// variable: exact "err", or any name containing "err" (case-insensitive).
// Covers the conventional spellings: err, statErr, registerErr, errFoo, etc.
// Used to decide whether a `_` shares an assignment with a captured error.
func looksLikeErrorName(name string) bool {
	lower := strings.ToLower(name)

	return lower == errorIdentifierName || strings.Contains(lower, errorIdentifierSubstr)
}

// presenceFlagNames lists identifier names conventionally used for the
// boolean "present/ok" result in the multi-value comma-ok idiom and in
// user-defined (T, bool) accessors. When the non-blank LHS of a two-value
// assignment is one of these names, the call is overwhelmingly a presence
// check, not an error return, and the blank discards a value — not an error.
//
//nolint:gochecknoglobals // immutable lookup table for presence-flag names
var presenceFlagNames = map[string]bool{
	"ok": true, "found": true, "exists": true, "present": true, "has": true,
}

// isPresenceFlagName reports whether name is a conventional presence-flag
// identifier (ok, found, exists, present, has).
func isPresenceFlagName(name string) bool {
	return presenceFlagNames[name]
}

// isPackageMethodCall checks if a call expression is pkg.Method (e.g., fmt.Errorf, errors.As).
func (a *Analyzer) isPackageMethodCall(call *ast.CallExpr, pkg, method string) bool {
	if sel, ok := call.Fun.(*ast.SelectorExpr); ok {
		if ident, ok := sel.X.(*ast.Ident); ok {
			return ident.Name == pkg && sel.Sel.Name == method
		}
	}

	return false
}

// isErrorfCall checks if a call expression is fmt.Errorf.
func (a *Analyzer) isErrorfCall(call *ast.CallExpr) bool {
	return a.isPackageMethodCall(call, fmtPkg, methodErrorf)
}

// isPanicCall checks if a call expression is panic.
func (a *Analyzer) isPanicCall(call *ast.CallExpr) bool {
	if ident, ok := call.Fun.(*ast.Ident); ok {
		return ident.Name == "panic"
	}

	return false
}

// isLogFatalCall checks if a call expression is log.Fatal/Fatalf/Fatalln.
func (a *Analyzer) isLogFatalCall(call *ast.CallExpr) bool {
	if sel, ok := call.Fun.(*ast.SelectorExpr); ok {
		if ident, ok := sel.X.(*ast.Ident); ok {
			return ident.Name == logVarName &&
				(sel.Sel.Name == "Fatal" || sel.Sel.Name == "Fatalf" || sel.Sel.Name == "Fatalln")
		}
	}

	return false
}

// isErrorCreatingCall checks if a call creates an error.
func (a *Analyzer) isErrorCreatingCall(call *ast.CallExpr) bool {
	return a.isPackageMethodCall(call, "errors", "New") ||
		a.isPackageMethodCall(call, "errors", "Join") ||
		a.isErrorfCall(call)
}

// isIdentifierOnSide checks if a specific side of a binary expression is a named identifier.
func isIdentifierOnSide(expr *ast.BinaryExpr, side, name string) bool {
	var ident *ast.Ident
	if side == "X" {
		ident, _ = expr.X.(*ast.Ident)
	} else {
		ident, _ = expr.Y.(*ast.Ident)
	}

	return ident != nil && ident.Name == name
}

// isIdentifierComparison checks if a binary expression compares an identifier against a value
// Returns true if (left == identName AND right == valueName) OR (left == valueName AND right == identName).
func (a *Analyzer) isIdentifierComparison(expr *ast.BinaryExpr, identName, valueName string) bool {
	return isIdentifierOnSide(expr, "X", identName) && isIdentifierOnSide(expr, "Y", valueName) ||
		isIdentifierOnSide(expr, "X", valueName) && isIdentifierOnSide(expr, "Y", identName)
}

// identName returns the identifier name from an expression, or empty string.
func identName(expr ast.Expr) string {
	if ident, ok := expr.(*ast.Ident); ok {
		return ident.Name
	}

	return ""
}

// errorIdentName extracts the error variable name from a binary expression
// (e.g., "err" from "err != nil").
func errorIdentName(expr *ast.BinaryExpr) string {
	if name := identName(expr.X); name != "" && name != nilLiteral {
		return name
	}

	if name := identName(expr.Y); name != "" && name != nilLiteral {
		return name
	}

	return ""
}

// isErrorCheck checks if a binary expression is an error check (err != nil).
func (a *Analyzer) isErrorCheck(expr *ast.BinaryExpr) bool {
	if expr.Op != token.NEQ {
		return false
	}

	return a.isIdentifierComparison(expr, errorIdentifierSubstr, nilLiteral)
}

// isEmptyBlock checks if a block statement is empty.
func (a *Analyzer) isEmptyBlock(block *ast.BlockStmt) bool {
	return block == nil || len(block.List) == 0
}

// isLoggingFunctionName checks if a function name is a logging/print function.
func isLoggingFunctionName(name string) bool {
	return name == "Println" || name == "Printf" || name == "Print" ||
		name == "Fprintln" || name == "Fprintf"
}

// isLoggingCall checks if call is a logging/printing call.
func (a *Analyzer) isLoggingCall(call *ast.CallExpr) bool {
	// Check for log.Println, fmt.Println, log.Printf, fmt.Printf, etc.
	if ident, ok := call.Fun.(*ast.Ident); ok {
		return isLoggingFunctionName(ident.Name)
	}

	if sel, ok := call.Fun.(*ast.SelectorExpr); ok {
		if xIdent, ok := sel.X.(*ast.Ident); ok {
			if xIdent.Name == logVarName || xIdent.Name == fmtPkg {
				return isLoggingFunctionName(sel.Sel.Name)
			}
		}
	}

	return false
}

// isErrorSwallowed checks if error is swallowed in the block (logged but not handled).
// errName is the name of the error variable from the `if errName != nil` condition;
// it is used to detect whether the block actually uses the error (e.g. appends it to
// a collection, wraps it, or passes it to a logger) before deciding it is swallowed.
func (a *Analyzer) isErrorSwallowed(block *ast.BlockStmt, errName string) bool {
	if block == nil || len(block.List) == 0 {
		return false
	}

	// If the error (or a value DERIVED from it via assignment, field store, or
	// composite literal) reaches a NON-LOGGING call operand anywhere in the
	// block — e.g. append(providerErrors, err), errors.Wrap(err, ...),
	// entry.Err = err; append(entries, entry) — the error is being collected or
	// wrapped for later return, not swallowed. Skip swallow classification.
	// See errorPreserved for the lightweight intra-block data-flow check.
	if errName != "" && a.errorPreserved(block, errName) {
		return false
	}

	for i, stmt := range block.List {
		if a.isLoggedAndSwallowed(stmt, block, i) {
			return true
		}

		if isContinueOrBreak(stmt) {
			return true
		}
	}

	return false
}

// errorPreserved reports whether the error (errName) — or any value derived
// from it via assignment, field store, or composite literal within the block —
// reaches an argument of a NON-LOGGING call expression. This is a lightweight
// intra-block data-flow (taint) check that recognizes "collect and surface"
// patterns the direct-operand test misses, e.g.:
//
//	if err != nil {
//	    entry.Err = err                  // err taints `entry`
//	    entries = append(entries, entry) // tainted `entry` reaches a call operand
//	    continue
//	}
//
// Logging calls (log.Print, fmt.Println, etc.) are deliberately excluded — they
// observe the error but do not preserve it for the caller, so log-then-return-nil
// is still a swallow (handled separately by isLoggedAndSwallowed).
func (a *Analyzer) errorPreserved(block *ast.BlockStmt, errName string) bool {
	tainted := errorTaintSet(block, errName)
	if len(tainted) == 0 {
		return false
	}

	preserved := false

	ast.Inspect(block, func(n ast.Node) bool {
		if preserved {
			return false
		}

		call, ok := n.(*ast.CallExpr)
		if !ok {
			return true
		}

		// Skip logging/printing calls — they observe the error but do not
		// preserve it. Those are handled separately by isLoggedAndSwallowed.
		if a.isLoggingCall(call) {
			return true
		}

		for _, arg := range call.Args {
			if exprReferencesAnyIdent(arg, tainted) {
				preserved = true

				return false
			}
		}

		return true
	})

	return preserved
}

// errorConsumedByCall reports whether the error (errName) — or any value
// derived from it within the block — is passed as an argument to ANY call
// expression in the block. Unlike errorPreserved, logging calls count: in a
// function that cannot return an error, passing the error to a call (log
// output, structured logger, metrics counter) IS the handling — the error is
// observed and has nowhere further to go, so it is not a swallow.
//
// See docs/feedback/2026-09-04_00-00_silent-swallow-void-func-escape-hatch-and-ignored-vs-errcheck-close-deadlock.md
// (Item 1): log-and-continue in a fire-and-forget producer goroutine is the
// only correct handling for a checked error in a void function.
func errorConsumedByCall(block *ast.BlockStmt, errName string) bool {
	tainted := errorTaintSet(block, errName)
	if len(tainted) == 0 {
		return false
	}

	consumed := false

	ast.Inspect(block, func(n ast.Node) bool {
		if consumed {
			return false
		}

		call, ok := n.(*ast.CallExpr)
		if !ok {
			return true
		}

		for _, arg := range call.Args {
			if exprReferencesAnyIdent(arg, tainted) {
				consumed = true

				return false
			}
		}

		return true
	})

	return consumed
}

// errorTaintSet returns the set of identifier names that the error (errName)
// flows into within the block, via assignment, field store, or composite
// literal. The result always includes errName itself. Propagation is a single
// forward pass over statements; taint grows monotonically (a derived value can
// itself taint later assignments).
func errorTaintSet(block *ast.BlockStmt, errName string) map[string]bool {
	tainted := make(map[string]bool)
	if errName == "" {
		return tainted
	}

	tainted[errName] = true

	for _, stmt := range block.List {
		assign, ok := stmt.(*ast.AssignStmt)
		if !ok {
			continue
		}

		// Does any RHS expression reference an already-tainted identifier?
		rhsTainted := false

		for _, rhs := range assign.Rhs {
			if exprReferencesAnyIdent(rhs, tainted) {
				rhsTainted = true

				break
			}
		}

		if !rhsTainted {
			continue
		}

		// Taint the base object of each LHS so subsequent uses are tracked.
		for _, lhs := range assign.Lhs {
			if name := baseIdent(lhs); name != "" {
				tainted[name] = true
			}
		}
	}

	return tainted
}

// exprReferencesAnyIdent reports whether expr contains an *ast.Ident whose name
// is present in names.
func exprReferencesAnyIdent(expr ast.Expr, names map[string]bool) bool {
	found := false

	ast.Inspect(expr, func(n ast.Node) bool {
		if found {
			return false
		}

		if ident, ok := n.(*ast.Ident); ok && names[ident.Name] {
			found = true

			return false
		}

		return true
	})

	return found
}

// baseIdent returns the base identifier name of an assignment LHS expression
// (e.g. "x" for x, x.f, x.f.g, m[k], m[k].f), or "" if there is no base
// identifier (e.g. a bare composite literal or function call on the LHS).
func baseIdent(expr ast.Expr) string {
	switch e := expr.(type) {
	case *ast.Ident:
		return e.Name
	case *ast.SelectorExpr:
		return baseIdent(e.X)
	case *ast.IndexExpr:
		return baseIdent(e.X)
	default:
		return ""
	}
}

// isLoggedAndSwallowed detects log/fmt.Println(err) followed by return nil.
func (a *Analyzer) isLoggedAndSwallowed(stmt ast.Stmt, block *ast.BlockStmt, i int) bool {
	callExpr, ok := stmt.(*ast.ExprStmt)
	if !ok {
		return false
	}

	call, ok := callExpr.X.(*ast.CallExpr)
	if !ok || !a.isLoggingCall(call) {
		return false
	}

	if i+1 >= len(block.List) {
		return false
	}

	ret, ok := block.List[i+1].(*ast.ReturnStmt)
	if !ok {
		return false
	}

	return returnHasAllNilResults(ret)
}

// returnHasAllNilResults returns true if the return statement has no results
// or all results are nil identifiers.
func returnHasAllNilResults(ret *ast.ReturnStmt) bool {
	if len(ret.Results) == 0 {
		return true
	}

	for _, res := range ret.Results {
		ident, ok := res.(*ast.Ident)
		if !ok || ident.Name != nilLiteral {
			return false
		}
	}

	return true
}

// isContinueOrBreak returns true if the statement is a continue or break.
func isContinueOrBreak(stmt ast.Stmt) bool {
	branch, ok := stmt.(*ast.BranchStmt)
	if !ok {
		return false
	}

	return branch.Tok == token.CONTINUE || branch.Tok == token.BREAK
}

// hasErrorReturn reports whether fn declares an `error` result. Used to decide
// whether a checked-but-not-returned error can be propagated: when there is no
// error return, classifying a defensive break/continue as a CRITICAL swallow is
// wrong because the error has nowhere to go.
func hasErrorReturn(ft *ast.FuncType) bool {
	if ft == nil || ft.Results == nil {
		return false
	}

	return slices.ContainsFunc(ft.Results.List, func(field *ast.Field) bool {
		return isBareErrorType(field.Type)
	})
}

// isBareErrorType reports whether an AST type expression spells the built-in
// `error` interface (ident "error"), as opposed to a concrete custom type.
func isBareErrorType(expr ast.Expr) bool {
	ident, ok := expr.(*ast.Ident)

	return ok && ident.Name == errorInterfaceName
}

// returnTypeLooksLikeError reports whether the given AST return type expression
// plausibly represents an error — either the bare error interface or a named
// type whose name contains "error" (e.g., *MyError, pkg.ValidationError).
// Used by the signature-aware blank-identifier check to avoid suppressing real
// error returns when type info is unavailable. Conservative: returns true for
// any type whose name contains "error" so that potential error types are never
// silently suppressed.
func returnTypeLooksLikeError(expr ast.Expr) bool {
	switch t := expr.(type) {
	case *ast.Ident:
		return strings.Contains(strings.ToLower(t.Name), errorInterfaceName)
	case *ast.StarExpr:
		return returnTypeLooksLikeError(t.X)
	case *ast.SelectorExpr:
		return strings.Contains(strings.ToLower(t.Sel.Name), errorInterfaceName)
	default:
		return false
	}
}

// callFuncName extracts the function or method name from a call expression's
// Fun field. Returns the bare identifier name for direct calls (e.g., "foo"
// from foo()), the selector name for method/package calls (e.g., "Get" from
// x.Get()), or "" for unrecognizable shapes.
func callFuncName(call *ast.CallExpr) string {
	switch fun := call.Fun.(type) {
	case *ast.Ident:
		return fun.Name
	case *ast.SelectorExpr:
		return fun.Sel.Name
	default:
		return ""
	}
}

// blankIsLikelyNonError applies AST-only heuristics to detect the comma-ok /
// map-index / type-assertion patterns where a blank identifier in a non-error
// position is being flagged without type information. Returns true when the
// blank at blankIndex is very likely NOT discarding an error.
//
// Recognized patterns (only when type info is unavailable):
//
//   - Map index expression: `_, ok := m[key]` never returns an error.
//   - Type assertion: `_, ok := x.(T)` never returns an error.
//
// Each pattern is a strong signal that the call has no error return. Used as a
// conservative guard to suppress false positives before the flag-all fallback.
// The presence-flag name check (ok/found/exists) for general two-value calls
// is handled at the AssignStmt level in detectBlankAssignmentViolation, where
// the sibling LHS identifier is available.
func blankIsLikelyNonError(call *ast.CallExpr, blankIndex int) bool {
	if blankIndex != 0 {
		return false
	}

	switch fun := call.Fun.(type) {
	case *ast.IndexExpr:
		// Map/slice index comma-ok: `v, ok := m[key]`. Never returns error.
		return true
	case *ast.ParenExpr:
		// Parenthesised form: unwrap and re-check the inner expression.
		inner := call
		inner.Fun = fun.X

		return blankIsLikelyNonError(inner, blankIndex)
	default:
		return false
	}
}

// stdlibNoErrorReturnFuncs lists qualified stdlib package-level functions
// whose complete return list contains no error value. Without type info the
// blank-identifier check cannot resolve these signatures and would
// conservatively flag every blank position (e.g. the middle `after` value of
// strings.Cut, or a deliberately discarded fmt.Sprintf result). Key format is
// "pkg.Func"; the package name is verified against the file's stdlib imports
// before the table is consulted, so a project package imported under a
// stdlib name does not match. Method calls are deliberately excluded — a
// receiver's type is unknowable without type info.
//
//nolint:gochecknoglobals // immutable lookup table for stdlib no-error signatures
var stdlibNoErrorReturnFuncs = map[string]bool{
	"fmt.Sprint":   true,
	"fmt.Sprintf":  true,
	"fmt.Sprintln": true,
	"strings.Cut":  true,
	// strings.CutPrefix / CutSuffix return (string, bool) — no error.
	"strings.CutPrefix": true,
	"strings.CutSuffix": true,
}

// calleeIsStdlibNoError reports whether call is a qualified pkg.Func call
// where pkg is a stdlib import of file and pkg.Func is known to return no
// error at any position. Only meaningful when type info is unavailable.
func calleeIsStdlibNoError(call *ast.CallExpr, file *ast.File) bool {
	sel, ok := call.Fun.(*ast.SelectorExpr)
	if !ok {
		return false
	}

	pkgIdent, ok := sel.X.(*ast.Ident)
	if !ok {
		return false
	}

	if !stdlibNoErrorReturnFuncs[pkgIdent.Name+"."+sel.Sel.Name] {
		return false
	}

	return isStdlibImport(file, pkgIdent.Name)
}
