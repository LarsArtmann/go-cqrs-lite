package ast

import (
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
)

func findOopsMisusedWViolations(t *testing.T, graph *types.ErrorGraph) []types.ErrorViolation {
	t.Helper()

	var result []types.ErrorViolation

	for _, v := range graph.Violations {
		if v.Type == types.ErrorTypeOopsMisusedW {
			result = append(result, v)
		}
	}

	return result
}

func TestOopsMisusedW_WrapfWithPercentW(t *testing.T) {
	t.Parallel()

	code := `package main

import "github.com/samber/oops"

func process(err, other error) error {
	return oops.Wrapf(err, "failed: %w", other)
}`
	graph := helperParseWithOopsEnforcement(t, code, true)

	violations := findOopsMisusedWViolations(t, graph)
	if assert.Len(t, violations, 1, "should flag %%w in oops.Wrapf") {
		assert.Contains(t, violations[0].Message, "does NOT chain")
		assert.Contains(t, violations[0].Suggestion, "%s")
	}
}

func TestOopsMisusedW_WrapfWithoutPercentW(t *testing.T) {
	t.Parallel()

	code := `package main

import "github.com/samber/oops"

func process(err error) error {
	return oops.Wrapf(err, "processing failed")
}`
	graph := helperParseWithOopsEnforcement(t, code, true)

	violations := findOopsMisusedWViolations(t, graph)
	assert.Empty(t, violations, "Wrapf without %%w should not be flagged")
}

func TestOopsMisusedW_ErrorfWithPercentW(t *testing.T) {
	t.Parallel()

	// oops.Errorf("msg: %w", err) is CORRECT — %w chains in Errorf
	code := `package main

import "github.com/samber/oops"

func process(err error) error {
	return oops.Errorf("failed: %w", err)
}`
	graph := helperParseWithOopsEnforcement(t, code, true)

	violations := findOopsMisusedWViolations(t, graph)
	assert.Empty(t, violations, "Errorf with %%w is correct and should NOT be flagged")
}

func TestOopsMisusedW_ErrorfWithPercentS(t *testing.T) {
	t.Parallel()

	code := `package main

import "github.com/samber/oops"

func process(arg string) error {
	return oops.Errorf("failed: %s", arg)
}`
	graph := helperParseWithOopsEnforcement(t, code, true)

	violations := findOopsMisusedWViolations(t, graph)
	assert.Empty(t, violations, "Errorf with %%s should not be flagged")
}

func TestOopsMisusedW_NotFlaggedWhenOff(t *testing.T) {
	t.Parallel()

	code := `package main

import "github.com/samber/oops"

func process(err, other error) error {
	return oops.Wrapf(err, "failed: %w", other)
}`
	graph := helperParseWithOopsEnforcement(t, code, false)

	violations := findOopsMisusedWViolations(t, graph)
	assert.Empty(t, violations, "should not detect when enforcement is off")
}
