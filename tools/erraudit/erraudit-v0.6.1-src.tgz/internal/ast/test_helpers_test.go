package ast

// test_helpers.go contains shared test helper functions used across all analyzer test files.
// These functions provide common setup and assertion logic to reduce code duplication.

import (
	"go/parser"
	"go/token"
	"strings"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
)

// helperParseAndAnalyze performs the common setup for test analysis:
// creates file set, parses code, creates analyzer, and runs analysis.
func helperParseAndAnalyze(t *testing.T, code string) (*Analyzer, *types.ErrorGraph) {
	t.Helper()

	return helperParseAndAnalyzeWithOptions(t, code)
}

// helperParseAndAnalyzeWithOptions is like helperParseAndAnalyze but accepts
// AnalyzerOption values (e.g., WithNoSuppress) for testing flag-dependent behaviour.
func helperParseAndAnalyzeWithOptions(
	t *testing.T,
	code string,
	opts ...AnalyzerOption,
) (*Analyzer, *types.ErrorGraph) {
	t.Helper()

	fset := token.NewFileSet()

	node, err := parser.ParseFile(fset, "", code, parser.AllErrors)
	if err != nil {
		t.Fatalf("Failed to parse code: %v", err)
	}

	analyzer := NewAnalyzer(fset, "main", "test.go", opts...)
	graph := analyzer.Analyze(node)

	return analyzer, graph
}

// helperViolationTest executes a violation test with the given code and expected violation type.
func helperViolationTest(
	t *testing.T,
	code string,
	expectedViolationType types.ErrorType,
	metricCheck func(*types.ErrorMetrics),
) {
	t.Helper()

	_, graph := helperParseAndAnalyze(t, code)

	found := false

	for _, violation := range graph.Violations {
		if violation.Type == expectedViolationType {
			found = true

			if violation.Message == "" {
				t.Error("Expected non-empty violation message")
			}

			break
		}
	}

	if !found {
		t.Errorf("Expected to find %v violation", expectedViolationType)
	}

	if metricCheck != nil {
		metricCheck(&graph.Metrics)
	}
}

// helperGraphViolationCheck checks that graph.Violations contains a violation of the expected type
// with optional additional checks on message, severity, and suggestion.
func helperGraphViolationCheck(
	t *testing.T,
	graph *types.ErrorGraph,
	expectedType types.ErrorType,
	checks ...func(*types.ErrorViolation),
) {
	t.Helper()

	found := false

	for _, violation := range graph.Violations {
		if violation.Type == expectedType {
			found = true

			if violation.Message == "" {
				t.Error("Expected non-empty violation message")
			}

			for _, check := range checks {
				check(&violation)
			}

			break
		}
	}

	if !found {
		t.Errorf("Expected to find %v violation", expectedType)
	}
}

// helperAnalysisTest executes a basic analysis test without violation checking.
func helperAnalysisTest(t *testing.T, code string, assertion func(*Analyzer, *types.ErrorGraph)) {
	t.Helper()

	analyzer, graph := helperParseAndAnalyze(t, code)

	assertion(analyzer, graph)
}

// helperErrorTypeCheck asserts that the error graph contains an error of the given type.
func helperErrorTypeCheck(
	t *testing.T,
	graph *types.ErrorGraph,
	expectedType types.ErrorType,
	typeName string,
) {
	t.Helper()

	found := false

	for _, errInfo := range graph.Errors {
		if errInfo.Type == expectedType {
			found = true

			break
		}
	}

	if !found {
		t.Errorf("Expected to find %s", typeName)
	}
}

// assertMessage asserts that a message contains the expected content.
// This helper reduces code duplication in test assertion logic.
func assertMessageContains(
	t *testing.T,
	message string,
	expectedContent string,
) {
	t.Helper()

	if !strings.Contains(message, expectedContent) {
		t.Errorf("Expected message to mention %s, got '%s'", expectedContent, message)
	}
}

// helperErrorTypeTest is a convenience function for testing specific error types.
// It parses the code, analyzes it, and asserts that the expected error type is found.
func helperErrorTypeTest(t *testing.T, code string, expectedType types.ErrorType, typeName string) {
	t.Helper()

	helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
		helperErrorTypeCheck(t, graph, expectedType, typeName)
	})
}

// createViolationTestCode creates a complete test package with the given imports and violation code.
func createViolationTestCode(imports, violationCode string) string {
	return `
package main

import (
` + imports + `)

func badExample() {
	` + violationCode + `
}`
}

// helperViolationTestWithMetric creates violation test code and runs metric validation
// This reduces boilerplate for tests that verify both violations and metrics.
func helperViolationTestWithMetric(
	t *testing.T,
	imports, violationCode string,
	expectedViolationType types.ErrorType,
	metricField string,
	metricCheck func(uint) bool,
) {
	t.Helper()

	code := createViolationTestCode(imports, violationCode)

	helperViolationTest(t, code, expectedViolationType, func(m *types.ErrorMetrics) {
		var metricValue uint

		switch metricField {
		case "IgnoredErrors":
			metricValue = m.IgnoredErrors
		case "SilentSwallows":
			metricValue = m.SilentSwallows
		default:
			t.Errorf("Unknown metric field: %s", metricField)

			return
		}

		if !metricCheck(metricValue) {
			t.Errorf("Expected %s metric check to pass, got %d", metricField, metricValue)
		}
	})
}

// ViolationTestCase represents a standardized test case for error violation detection.
type ViolationTestCase struct {
	name              string
	imports           string
	violationCode     string
	expectedViolation types.ErrorType
	metricField       string
	expectedMetric    func(uint) bool
}

// NewViolationTestCase creates a standardized test case for error violations
// This reduces boilerplate for testing error handling patterns.
func NewViolationTestCase(
	name, imports, violationCode string,
	expectedViolation types.ErrorType,
	metricField string,
	expectedMetric func(uint) bool,
) ViolationTestCase {
	return ViolationTestCase{
		name:              name,
		imports:           imports,
		violationCode:     violationCode,
		expectedViolation: expectedViolation,
		metricField:       metricField,
		expectedMetric:    expectedMetric,
	}
}

// BlankIdentifierTestCase creates a standardized test case for blank identifier violations
// This reduces boilerplate for testing blank identifier error ignoring patterns.
func BlankIdentifierTestCase() ViolationTestCase {
	return NewViolationTestCase(
		"blank identifier ignores error",
		"\t\"os\"\n",
		"\t// Violation: Ignoring error with blank identifier\n\tfile, _ := os.Open(\"file.txt\")\n\tdefer file.Close()",
		types.ErrorTypeIgnored,
		"IgnoredErrors",
		func(v uint) bool { return v > 0 },
	)
}

// helperAssertTotalNonZero asserts that the graph's TotalErrors is non-zero
// This reduces code duplication when verifying analysis metrics.
func helperAssertTotalNonZero(t *testing.T, graph *types.ErrorGraph) {
	t.Helper()

	if graph.Metrics.TotalErrors == 0 {
		t.Error("Expected non-zero total errors")
	}
}

// SilentSwallowTestCase creates a standardized test case for silent swallowing violations
// This reduces boilerplate for testing checked-but-dropped error patterns.
// The fixture is an EMPTY if-err-nil block: an empty block is always a swallow,
// even in a void function. (log-then-continue/return in a void function is
// accepted handling since the 2026-09-04 feedback — the error is consumed by
// the logging call — so it no longer produces a violation here.)
func SilentSwallowTestCase() ViolationTestCase {
	return NewViolationTestCase(
		"silent swallowing ignores error",
		"\t\"errors\"\n\t\"log\"\n",
		"\terr := errors.New(\"test error\")\n\t// Violation: Silent swallowing - checked then completely dropped\n\tif err != nil {\n\t}",
		types.ErrorTypeSilentSwallow,
		"SilentSwallows",
		func(v uint) bool { return v > 0 },
	)
}
