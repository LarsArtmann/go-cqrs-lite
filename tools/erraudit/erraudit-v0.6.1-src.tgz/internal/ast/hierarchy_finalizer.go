package ast

import (
	"path/filepath"
	"sort"
	"strings"

	"github.com/larsartmann/erraudit/pkg/types"
)

// FinalizeHierarchy runs post-merge cleanup on a combined error hierarchy.
// It deduplicates relationships (removing cross-file duplicates), removes
// cycles (preventing cross-file cyclic edges), recomputes graph-correct
// node depths, rebuilds root errors, recomputes metrics, and derives
// branching/chain summary statistics.
//
// Called by the analyzer merger after combining per-file hierarchies.
// Per-file analysis already runs these steps in buildHierarchy; this
// function handles the additional issues introduced by merging.
func FinalizeHierarchy(h *types.ErrorHierarchy) {
	if h == nil || len(h.AllNodes) == 0 {
		return
	}

	h.Relationships = dedupeRelationships(h.Relationships)
	h.Relationships = removeCycles(h.Relationships)

	childToParents := buildChildToParents(h.Relationships)

	finalizeDepths(h, childToParents)
	finalizeRootErrors(h, childToParents)
	finalizeMetrics(h)
	finalizeSummary(h, childToParents)

	resolveSelectorReferences(h)

	// Reference-site counts are merged (summed) on the metrics; copy them
	// onto the final node set so renderers can annotate labels.
	applyNodeReferenceCounts(h)
}

// resolveSelectorReferences attributes qualified (pkg.Sel) references —
// recorded during per-file analysis against selectors from other packages —
// to named errors discovered in the merged graph. A reference resolves only
// when exactly one discovered named error matches both the identifier and
// the declaring package's directory basename; anything ambiguous or unknown
// stays unattributed (e.g. sql.ErrNoRows, or two packages sharing a dir
// name). The transient selector maps (counts and site refs) are consumed in
// the process.
func resolveSelectorReferences(h *types.ErrorHierarchy) {
	if len(h.Metrics.SelectorWrapSites) == 0 && len(h.Metrics.SelectorCheckSites) == 0 &&
		len(h.Metrics.SelectorWrapSiteRefs) == 0 && len(h.Metrics.SelectorCheckSiteRefs) == 0 {
		return
	}

	type declKey struct {
		packageDir string
		name       string
	}

	declarations := make(map[declKey]int, len(h.NamedErrors))
	for _, namedErr := range h.NamedErrors {
		declarations[declKey{
			packageDir: packageDirBaseName(namedErr.Position.Filename),
			name:       namedErr.Name,
		}]++
	}

	attributeCount := func(key string) (string, bool) {
		qualifier, sel, ok := strings.Cut(key, ".")
		if !ok {
			return "", false
		}

		if declarations[declKey{packageDir: qualifier, name: sel}] == 1 {
			return sel, true
		}

		return "", false
	}

	attributeCounts := func(qualified map[string]uint) map[string]uint {
		resolved := make(map[string]uint, len(qualified))

		for key, count := range qualified {
			if sel, ok := attributeCount(key); ok {
				resolved[sel] += count
			}
		}

		return resolved
	}

	attributeRefs := func(qualified map[string][]types.ErrorSiteRef) map[string][]types.ErrorSiteRef {
		resolved := make(map[string][]types.ErrorSiteRef, len(qualified))

		for key, refs := range qualified {
			if sel, ok := attributeCount(key); ok {
				resolved[sel] = append(resolved[sel], refs...)
			}
		}

		return resolved
	}

	for name, count := range attributeCounts(h.Metrics.SelectorWrapSites) {
		if h.Metrics.WrapSitesByError == nil {
			h.Metrics.WrapSitesByError = make(map[string]uint)
		}

		h.Metrics.WrapSitesByError[name] += count
	}

	for name, count := range attributeCounts(h.Metrics.SelectorCheckSites) {
		if h.Metrics.CheckSitesByError == nil {
			h.Metrics.CheckSitesByError = make(map[string]uint)
		}

		h.Metrics.CheckSitesByError[name] += count
	}

	for name, refs := range attributeRefs(h.Metrics.SelectorWrapSiteRefs) {
		if h.Metrics.WrapSiteRefs == nil {
			h.Metrics.WrapSiteRefs = make(map[string][]types.ErrorSiteRef)
		}

		h.Metrics.WrapSiteRefs[name] = append(h.Metrics.WrapSiteRefs[name], refs...)
	}

	for name, refs := range attributeRefs(h.Metrics.SelectorCheckSiteRefs) {
		if h.Metrics.CheckSiteRefs == nil {
			h.Metrics.CheckSiteRefs = make(map[string][]types.ErrorSiteRef)
		}

		h.Metrics.CheckSiteRefs[name] = append(h.Metrics.CheckSiteRefs[name], refs...)
	}

	h.Metrics.SelectorWrapSites = nil
	h.Metrics.SelectorCheckSites = nil
	h.Metrics.SelectorWrapSiteRefs = nil
	h.Metrics.SelectorCheckSiteRefs = nil
}

// packageDirBaseName returns the basename of the directory containing the
// file, used to match a qualified reference's package identifier against the
// declaring package. Empty for empty or root-level paths.
func packageDirBaseName(path string) string {
	if path == "" {
		return ""
	}

	dir := filepath.ToSlash(filepath.Dir(filepath.ToSlash(path)))
	if dir == "." || dir == "/" {
		return ""
	}

	return filepath.Base(dir)
}

// buildChildToParents constructs the child→parents adjacency map from
// a relationship slice.
func buildChildToParents(rels []types.ErrorRelationship) map[string][]string {
	m := make(map[string][]string, len(rels))

	for _, rel := range rels {
		m[rel.Child] = append(m[rel.Child], rel.Parent)
	}

	return m
}

// finalizeDepths recomputes graph-correct node depths and updates
// MaxDepth/DeepestError deterministically (lexicographic tie-breaking).
func finalizeDepths(h *types.ErrorHierarchy, childToParents map[string][]string) {
	names := make([]string, 0, len(h.AllNodes))
	for name := range h.AllNodes {
		names = append(names, name)
	}

	sort.Strings(names)

	depths := computeDepths(childToParents, names)

	var maxDepth uint

	var deepestError string

	for _, name := range names {
		h.AllNodes[name].Depth = depths[name]

		if depths[name] > maxDepth {
			maxDepth = depths[name]
			deepestError = name
		}
	}

	h.Metrics.MaxDepth = maxDepth
	h.Metrics.DeepestError = deepestError
}

// computeDepths computes the depth of every node by delegating each parent-chain
// walk to the shared assignChainDepths (same logic the tracker's
// GetRelationshipDepth uses). Results are memoized across nodes within this call.
func computeDepths(
	childToParents map[string][]string,
	names []string,
) map[string]uint {
	depths := make(map[string]uint, len(names))

	for _, start := range names {
		assignChainDepths(childToParents, start, depths)
	}

	return depths
}

// finalizeRootErrors rebuilds the root error list from cleaned relationships.
// Roots are nodes with no parents. Sorted by name for deterministic output.
func finalizeRootErrors(h *types.ErrorHierarchy, childToParents map[string][]string) {
	var rootNames []string

	for name := range h.AllNodes {
		if len(childToParents[name]) == 0 {
			rootNames = append(rootNames, name)
		}
	}

	sort.Strings(rootNames)

	h.RootErrors = make([]*types.ErrorNode, 0, len(rootNames))

	for _, name := range rootNames {
		h.RootErrors = append(h.RootErrors, h.AllNodes[name])
	}
}

// finalizeMetrics recomputes relationship-derived metrics from cleaned data.
func finalizeMetrics(h *types.ErrorHierarchy) {
	h.Metrics.TotalNamedErrors = uint(len(h.NamedErrors))
	h.Metrics.TotalRelationships = uint(len(h.Relationships))

	h.Metrics.SentinelErrors = uint(countErrorKinds(h.NamedErrors, types.ErrorKindSentinel))
	h.Metrics.CustomErrorTypes = uint(countErrorKinds(h.NamedErrors, types.ErrorKindCustom))

	wrapCount := make(map[string]uint)
	for _, rel := range h.Relationships {
		wrapCount[rel.Child]++
		wrapCount[rel.Parent]++
	}

	h.Metrics.WrapCount = wrapCount
	h.Metrics.MostWrappedError, h.Metrics.MostWrappedErrorOccurrences = types.MostWrappedFromCounts(wrapCount)
}

// finalizeSummary derives branching and chain metrics from the cleaned,
// merged relationship set. Mirrors enrichHierarchySummary (per-file) so both
// paths produce identical values for the same graph: chain length and root
// come from buildChainToRoot(DeepestError) — the same shared walk the
// tracker's GetErrorChain uses — not from the MaxDepth invariant.
func finalizeSummary(h *types.ErrorHierarchy, childToParents map[string][]string) {
	parentToChildren := make(map[string][]string, len(h.Relationships))
	totalChildren := 0

	for _, rel := range h.Relationships {
		parentToChildren[rel.Parent] = append(parentToChildren[rel.Parent], rel.Child)
		totalChildren++
	}

	if len(parentToChildren) > 0 {
		h.Metrics.AvgBranchingFactor = float64(totalChildren) / float64(len(parentToChildren))
	}

	parent, count := maxBranching(parentToChildren)
	h.Metrics.MaxBranchingParent = parent
	h.Metrics.MaxBranchingCount = uint(count)

	if h.Metrics.DeepestError != "" {
		chain := buildChainToRoot(childToParents, h.Metrics.DeepestError)
		h.Metrics.LongestChainLength = uint(len(chain))

		if len(chain) > 0 {
			h.Metrics.LongestChainRoot = chain[0]
		}
	}
}
