package ast

import (
	"go/parser"
	"go/token"
	"os"
	"path/filepath"
	"testing"
)

// Benchmark the improvement of file caching for code snippets.
func BenchmarkAnalyzer_CodeSnippetCaching(b *testing.B) {
	// Create a temp file with violations
	tmpFile := filepath.Join(b.TempDir(), "benchmark_snippet.go")

	code := `package main

import "fmt"

func test1() error {
	return fmt.Errorf("error: %v", err) // violation 1
}

func test2() error {
	return fmt.Errorf("error: %v", err2) // violation 2
}

func test3() error {
	return fmt.Errorf("error: %v", err3) // violation 3
}
`
	if err := os.WriteFile(tmpFile, []byte(code), 0o644); err != nil {
		b.Fatalf("Failed to create temp file: %v", err)
	}
	// Note: t.TempDir() handles cleanup automatically

	fset := token.NewFileSet()

	node, err := parser.ParseFile(fset, tmpFile, nil, parser.AllErrors)
	if err != nil {
		b.Fatalf("Failed to parse: %v", err)
	}

	b.ResetTimer()
	b.ReportAllocs()

	for b.Loop() {
		analyzer := NewAnalyzer(fset, "main", tmpFile)
		graph := analyzer.Analyze(node)
		// 3 unwrapped violations (%v instead of %w) + 3 generic return violations = 6 total
		if len(graph.Violations) != 6 {
			b.Fatalf(
				"Expected 6 violations (3 unwrapped + 3 generic return), got %d",
				len(graph.Violations),
			)
		}
	}
}
