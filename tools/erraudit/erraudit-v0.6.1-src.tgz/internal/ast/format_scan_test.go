package ast

import (
	"go/ast"
	"go/token"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestFormatStringLiteral(t *testing.T) {
	newCall := func(firstArg ast.Expr) *ast.CallExpr {
		return &ast.CallExpr{Args: []ast.Expr{firstArg}}
	}

	tests := []struct {
		name      string
		call      *ast.CallExpr
		wantValue string
		wantOK    bool
	}{
		{
			name:      "interpreted string literal",
			call:      newCall(&ast.BasicLit{Kind: token.STRING, Value: `"db fail: %w"`}),
			wantValue: "db fail: %w",
			wantOK:    true,
		},
		{
			name:      "raw string literal is the same kind of format string",
			call:      newCall(&ast.BasicLit{Kind: token.STRING, Value: "`db fail: %w`"}),
			wantValue: "db fail: %w",
			wantOK:    true,
		},
		{
			name:      "raw string without verbs",
			call:      newCall(&ast.BasicLit{Kind: token.STRING, Value: "`quota exceeded`"}),
			wantValue: "quota exceeded",
			wantOK:    true,
		},
		{
			name:      "empty interpreted string",
			call:      newCall(&ast.BasicLit{Kind: token.STRING, Value: `""`}),
			wantValue: "",
			wantOK:    true,
		},
		{
			name:      "empty raw string",
			call:      newCall(&ast.BasicLit{Kind: token.STRING, Value: "``"}),
			wantValue: "",
			wantOK:    true,
		},
		{
			name:   "non-literal first arg has no statically known format",
			call:   newCall(ast.NewIdent("formatVar")),
			wantOK: false,
		},
		{
			name:   "int literal is not a format string",
			call:   newCall(&ast.BasicLit{Kind: token.INT, Value: "42"}),
			wantOK: false,
		},
		{
			name:   "no args",
			call:   &ast.CallExpr{},
			wantOK: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, ok := formatStringLiteral(tt.call)
			assert.Equal(t, tt.wantOK, ok, "ok mismatch")
			assert.Equal(t, tt.wantValue, got, "value mismatch")
		})
	}
}

func TestFormatStringLiteralBothQuoteStylesYieldSameFormat(t *testing.T) {
	quoted := &ast.CallExpr{Args: []ast.Expr{
		&ast.BasicLit{Kind: token.STRING, Value: `"db fail: %w"`},
	}}
	raw := &ast.CallExpr{Args: []ast.Expr{
		&ast.BasicLit{Kind: token.STRING, Value: "`db fail: %w`"},
	}}

	quotedFormat, quotedOK := formatStringLiteral(quoted)
	rawFormat, rawOK := formatStringLiteral(raw)

	require.True(t, quotedOK)
	require.True(t, rawOK)
	assert.Equal(t, quotedFormat, rawFormat)
}

func TestWrapArgIndices(t *testing.T) {
	tests := []struct {
		name        string
		format      string
		wantIndices []int
		wantOK      bool
	}{
		{"single %w", "%w", []int{0}, true},
		{"two %w", "%w: %w", []int{0, 1}, true},
		{"%w after %s", "connecting to %s: %w", []int{1}, true},
		{"literal %% does not consume arg", "100%% done: %w", []int{0}, true},
		{"no %w", "failed: %v", nil, true},
		{"empty format", "", nil, true},
		{"flags and width before %w", "%-20s: %w", []int{1}, true},
		{"precision before %w", "%.2f: %w", []int{1}, true},
		{"star width", "%*s: %w", []int{1}, true},
		{"three %w", "%w | %w | %w", []int{0, 1, 2}, true},
		{"trailing lone percent", "oops %", nil, true},
		{"explicit indexing is unreliable", "%[1]w", nil, false},
		{"explicit indexing mid-string", "%s: %[1]w", nil, false},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, ok := wrapArgIndices(tt.format)
			assert.Equal(t, tt.wantOK, ok, "ok mismatch")
			assert.Equal(t, tt.wantIndices, got, "indices mismatch")
		})
	}
}
