package ast

import (
	"go/parser"
	"go/token"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestDetectDeferredClose_BasicPattern(t *testing.T) {
	t.Parallel()

	code := `package main

import "os"

func process() error {
	file, err := os.Open("test.txt")
	if err != nil {
		return err
	}
	defer file.Close()
	return nil
}
`
	violations := analyzeForDeferredTest(t, code)
	closeViolations := filterByType(violations, types.ErrorTypeDeferredCloseIgnored)
	require.Len(t, closeViolations, 1, "should detect defer file.Close()")
	assert.Contains(t, closeViolations[0].Message, "file.Close()")
}

func TestDetectDeferredClose_NoMatchForOtherMethods(t *testing.T) {
	t.Parallel()

	code := `package main

func process() {
	defer doSomething()
	defer cleanup()
	defer logger.Sync()
}
`
	violations := analyzeForDeferredTest(t, code)
	closeViolations := filterByType(violations, types.ErrorTypeDeferredCloseIgnored)
	assert.Empty(t, closeViolations)
}

func TestDetectDeferredClose_NoFalsePositiveOnAssignment(t *testing.T) {
	t.Parallel()

	code := `package main

import "os"

func process() error {
	file, err := os.Open("test.txt")
	if err != nil {
		return err
	}
	err = file.Close()
	if err != nil {
		return err
	}
	return nil
}
`
	violations := analyzeForDeferredTest(t, code)
	closeViolations := filterByType(violations, types.ErrorTypeDeferredCloseIgnored)
	assert.Empty(t, closeViolations, "file.Close() without defer should not match")
}

func TestDetectDeferredClose_MultipleDefers(t *testing.T) {
	t.Parallel()

	code := `package main

import "os"

func process() error {
	file1, _ := os.Open("a.txt")
	defer file1.Close()
	file2, _ := os.Open("b.txt")
	defer file2.Close()
	return nil
}
`
	violations := analyzeForDeferredTest(t, code)
	closeViolations := filterByType(violations, types.ErrorTypeDeferredCloseIgnored)
	assert.Len(t, closeViolations, 2, "should detect both deferred closes")
}

func TestDetectDeferredClose_Severity(t *testing.T) {
	t.Parallel()

	code := `package main

import "os"

func process() {
	file, _ := os.Open("test.txt")
	defer file.Close()
}
`
	violations := analyzeForDeferredTest(t, code)
	closeViolations := filterByType(violations, types.ErrorTypeDeferredCloseIgnored)
	require.Len(t, closeViolations, 1)
	assert.Equal(t, "warning", string(closeViolations[0].Severity))
}

func analyzeForDeferredTest(t *testing.T, code string) []types.ErrorViolation {
	t.Helper()

	fset := token.NewFileSet()
	node, err := parser.ParseFile(fset, "test.go", code, parser.AllErrors|parser.ParseComments)
	require.NoError(t, err)

	analyzer := NewAnalyzer(fset, "main", "test.go", WithEnforceDeferredClose(true))
	graph := analyzer.Analyze(node)

	return graph.Violations
}

func filterByType(violations []types.ErrorViolation, vt types.ErrorType) []types.ErrorViolation {
	var result []types.ErrorViolation

	for _, v := range violations {
		if v.Type == vt {
			result = append(result, v)
		}
	}

	return result
}
