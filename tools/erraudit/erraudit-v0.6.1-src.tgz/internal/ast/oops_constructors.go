package ast

// samber/oops constructor registry and detection helpers.
//
// oops (github.com/samber/oops) is a structured-error library that provides
// context chaining, stack traces, and rich error metadata. This file defines
// the API surface used for:
//   - Exempting oops calls from stdlib constructor enforcement
//     (--enforce-samber-oops).
//   - Detecting oops-specific anti-patterns (redundant nil guards, etc.).

import (
	"go/ast"
	"strings"

	"github.com/larsartmann/erraudit/pkg/oopspattern"
)

const oopsPackageName = "oops"

// oopsWrapMethods are oops functions that return nil when the input error is
// nil: Wrap and Wrapf (and their generic multi-return variants Wrap2..Wrap10,
// Wrapf2..Wrapf10). These are the functions where a preceding `if err != nil`
// guard is redundant.
//
//nolint:gochecknoglobals // immutable lookup table
var oopsWrapMethods = map[string]bool{
	methodWrap:  true,
	methodWrapf: true,
}

// isOopsWrapMethod reports whether methodName is an oops function that returns
// nil for nil input (Wrap, Wrapf, or their generic N-ary variants).
func isOopsWrapMethod(methodName string) bool {
	if oopsWrapMethods[methodName] {
		return true
	}

	// Generic multi-return wrappers: Wrap2..Wrap10, Wrapf2..Wrapf10
	if strings.HasPrefix(methodName, "Wrap") {
		rest := methodName[4:] // after "Wrap"
		if rest == "" || strings.HasPrefix(rest, "f") {
			suffix := strings.TrimPrefix(rest, "f")
			if suffix != "" && oopspattern.IsAllDigits(suffix) {
				return true
			}
		}
	}

	return false
}

// isOopsCall reports whether call is a samber/oops function invocation.
// Checks the package selector against "oops" (the canonical package name from
// `import "github.com/samber/oops"`).
//
// Known limitation: aliased imports (e.g. `import o "github.com/samber/oops"`)
// are NOT matched because the selector would be "o", not "oops". Matching by
// method name alone (Wrap, Errorf, etc.) would cause false positives — too many
// packages export methods with these names. The correct fix is type-aware
// resolution via go/types when --type-aware is active, which resolves the
// actual import path regardless of alias. This is a planned future enhancement.
func isOopsCall(call *ast.CallExpr) bool {
	pkg, _, ok := callSelector(
		call,
	)
	if !ok {
		return false
	}

	return pkg == oopsPackageName
}

// isOopsWrapCall reports whether call is an oops.Wrap or oops.Wrapf invocation
// oopsSuggestionFor generates a context-aware replacement suggestion for a
// stdlib constructor when samber/oops enforcement is active. The suggestion
// varies based on:
//   - errors.New → oops.Errorf (or oops.New)
//   - fmt.Errorf with %w → oops.Wrapf(err, "msg") — strips %w because Wrapf
//     takes err as its first argument, not via a format verb.
//   - fmt.Errorf without %w → oops.Errorf("msg")
//   - errors.Join → oops.Join(errs...)
func oopsSuggestionFor(call *ast.CallExpr, constructorType string) string {
	switch constructorType {
	case "errors.New":
		return `Replace with oops.Errorf("message") or oops.New("message")`

	case "fmt.Errorf":
		if formatStr := extractFormatString(call); formatStr != "" && strings.Contains(formatStr, "%w") {
			return "Replace with oops.Wrapf(err, \"message\") — oops.Wrapf takes err as first arg, not via %w"
		}

		return `Replace with oops.Errorf("message")`

	case "errors.Join":
		return "Replace with oops.Join(err1, err2, ...)"

	default:
		return "Replace with the appropriate oops constructor (see github.com/samber/oops)"
	}
}

// extractFormatString returns the format string literal from an fmt.Errorf call,
// or "" when the first argument is not a string literal.
func extractFormatString(call *ast.CallExpr) string {
	if len(call.Args) == 0 {
		return ""
	}

	return stringLiteralValue(call.Args[0])
}

// oopsEnforcePolicy is the enforcement policy for samber/oops. When active,
// stdlib error constructors are flagged with oops-specific suggestions.
//
//nolint:gochecknoglobals // immutable policy, avoids per-file allocation
var oopsEnforcePolicy = enforcePolicy{
	libraryName:   "samber/oops",
	isExempt:      isOopsCall,
	suggestionFor: oopsSuggestionFor,
}
