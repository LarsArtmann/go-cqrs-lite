package ast

// Benchmark test code - uses inline constants for self-contained benchmarks.
// Note: Could be extracted to shared testdata files if benchmarks grow significantly.
// Specific operation benchmarks (violation detection, hierarchy building) can be added as needed.

import (
	"fmt"
	"go/ast"
	"go/parser"
	"go/token"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
)

// Benchmark test code - a realistic Go file with error handling.
const benchmarkCode = `package main

import (
	"errors"
	"fmt"
)

func process(data string) error {
	if data == "" {
		return errors.New("empty data")
	}
	
	result, err := validate(data)
	if err != nil {
		return fmt.Errorf("validation failed: %w", err)
	}
	
	if err := save(result); err != nil {
		return fmt.Errorf("save failed: %v", err) // Bad: should use %w
	}
	
	return nil
}

func validate(input string) (string, error) {
	if len(input) < 5 {
		return "", fmt.Errorf("input too short: %d", len(input))
	}
	return input, nil
}

func save(data string) error {
	if data == "invalid" {
		return errors.New("cannot save invalid data")
	}
	fmt.Println("saved:", data)
	return nil
}

func main() {
	if err := process("test"); err != nil {
		panic(err) // Bad: should not panic
	}
}
`

// parseBenchmarkCode parses benchmark source code and returns the AST node.
func parseBenchmarkCode(b *testing.B, filename, code string) *ast.File {
	fset := token.NewFileSet()

	node, err := parser.ParseFile(fset, filename, code, parser.AllErrors)
	if err != nil {
		b.Fatalf("Failed to parse benchmark code: %v", err)
	}

	return node
}

// runAnalyzerBenchmark runs the analyzer benchmark loop with the given AST node.
func runAnalyzerBenchmark(b *testing.B, node *ast.File) {
	for b.Loop() {
		analyzer := NewAnalyzer(token.NewFileSet(), "main", "")
		_ = analyzer.Analyze(node)
	}
}

func BenchmarkAnalyzer_Analyze(b *testing.B) {
	node := parseBenchmarkCode(b, "benchmark.go", benchmarkCode)

	b.ResetTimer()
	runAnalyzerBenchmark(b, node)
}

func BenchmarkAnalyzer_Memory(b *testing.B) {
	node := parseBenchmarkCode(b, "benchmark.go", benchmarkCode)

	b.ReportAllocs()
	b.ResetTimer()
	runAnalyzerBenchmark(b, node)
}

// Large file benchmark.
const largeBenchmarkCode = `package main

import (
	"errors"
	"fmt"
)

func process1(data string) error {
	if data == "" {
		return errors.New("empty data")
	}
	result, err := validate1(data)
	if err != nil {
		return fmt.Errorf("validation failed: %w", err)
	}
	if err := save1(result); err != nil {
		return fmt.Errorf("save failed: %v", err)
	}
	return nil
}

func validate1(input string) (string, error) {
	if len(input) < 5 {
		return "", fmt.Errorf("input too short: %d", len(input))
	}
	return input, nil
}

func save1(data string) error {
	if data == "invalid" {
		return errors.New("cannot save invalid data")
	}
	return nil
}

func process2(data string) error {
	if data == "" {
		return errors.New("empty data")
	}
	result, err := validate2(data)
	if err != nil {
		return fmt.Errorf("validation failed: %w", err)
	}
	if err := save2(result); err != nil {
		return fmt.Errorf("save failed: %v", err)
	}
	return nil
}

func validate2(input string) (string, error) {
	if len(input) < 5 {
		return "", fmt.Errorf("input too short: %d", len(input))
	}
	return input, nil
}

func save2(data string) error {
	if data == "invalid" {
		return errors.New("cannot save invalid data")
	}
	return nil
}

func process3(data string) error {
	if data == "" {
		return errors.New("empty data")
	}
	result, err := validate3(data)
	if err != nil {
		return fmt.Errorf("validation failed: %w", err)
	}
	if err := save3(result); err != nil {
		return fmt.Errorf("save failed: %v", err)
	}
	return nil
}

func validate3(input string) (string, error) {
	if len(input) < 5 {
		return "", fmt.Errorf("input too short: %d", len(input))
	}
	return input, nil
}

func save3(data string) error {
	if data == "invalid" {
		return errors.New("cannot save invalid data")
	}
	return nil
}

func process4(data string) error {
	if data == "" {
		return errors.New("empty data")
	}
	result, err := validate4(data)
	if err != nil {
		return fmt.Errorf("validation failed: %w", err)
	}
	if err := save4(result); err != nil {
		return fmt.Errorf("save failed: %v", err)
	}
	return nil
}

func validate4(input string) (string, error) {
	if len(input) < 5 {
		return "", fmt.Errorf("input too short: %d", len(input))
	}
	return input, nil
}

func save4(data string) error {
	if data == "invalid" {
		return errors.New("cannot save invalid data")
	}
	return nil
}

func process5(data string) error {
	if data == "" {
		return errors.New("empty data")
	}
	result, err := validate5(data)
	if err != nil {
		return fmt.Errorf("validation failed: %w", err)
	}
	if err := save5(result); err != nil {
		return fmt.Errorf("save failed: %v", err)
	}
	return nil
}

func validate5(input string) (string, error) {
	if len(input) < 5 {
		return "", fmt.Errorf("input too short: %d", len(input))
	}
	return input, nil
}

func save5(data string) error {
	if data == "invalid" {
		return errors.New("cannot save invalid data")
	}
	return nil
}
`

func BenchmarkAnalyzer_LargeFile(b *testing.B) {
	node := parseBenchmarkCode(b, "large.go", largeBenchmarkCode)

	b.ResetTimer()
	b.ReportAllocs()

	runAnalyzerBenchmark(b, node)
}

// Benchmark specific operations.
func BenchmarkAnalyzer_visitOperations(b *testing.B) {
	node := parseBenchmarkCode(b, "benchmark.go", benchmarkCode)

	analyzer := NewAnalyzer(token.NewFileSet(), "main", "benchmark.go")

	b.ResetTimer()
	b.ReportAllocs()

	for b.Loop() {
		ast.Walk(analyzer, node)
	}
}

// BenchmarkRelationshipTracker benchmarks branching factor calculations.
func BenchmarkRelationshipTracker_BranchingFactor(b *testing.B) {
	// Create tracker with diamond pattern (10 branches converging to 1)
	const branchCount = 10
	tracker := &RelationshipTracker{
		analyzer: &Analyzer{
			namedErrors:   make([]types.NamedError, 0, branchCount+2),
			relationships: make([]types.ErrorRelationship, 0, branchCount),
		},
	}

	// Add base error
	tracker.analyzer.namedErrors = append(
		tracker.analyzer.namedErrors,
		types.NamedError{Name: "ErrBase"},
	)
	tracker.analyzer.relationships = append(
		tracker.analyzer.relationships,
		types.ErrorRelationship{Parent: "ErrBase", Child: "ErrChild1"},
	)

	// Add branching errors all wrapping the same child
	for i := 2; i <= branchCount; i++ {
		name := fmt.Sprintf("ErrBranch%d", i)
		tracker.analyzer.namedErrors = append(
			tracker.analyzer.namedErrors,
			types.NamedError{Name: name},
		)
		tracker.analyzer.relationships = append(
			tracker.analyzer.relationships,
			types.ErrorRelationship{Parent: name, Child: "ErrChild1"},
		)
	}

	tracker.buildCache()

	b.ResetTimer()
	b.ReportAllocs()

	for b.Loop() {
		_ = tracker.GetBranchingFactor()
	}
}

// BenchmarkRelationshipTracker_GetSiblings benchmarks sibling discovery.
func BenchmarkRelationshipTracker_GetSiblings(b *testing.B) {
	tracker := &RelationshipTracker{
		analyzer: &Analyzer{
			namedErrors: []types.NamedError{
				{Name: "ErrNotFound"},
				{Name: "ErrUserNotFound"},
				{Name: "ErrProductNotFound"},
				{Name: "ErrOrderNotFound"},
				{Name: "ErrItemNotFound"},
			},
			relationships: []types.ErrorRelationship{
				{Parent: "ErrUserNotFound", Child: "ErrNotFound"},
				{Parent: "ErrProductNotFound", Child: "ErrNotFound"},
				{Parent: "ErrOrderNotFound", Child: "ErrNotFound"},
				{Parent: "ErrItemNotFound", Child: "ErrNotFound"},
			},
		},
	}

	tracker.buildCache()

	b.ResetTimer()
	b.ReportAllocs()

	for b.Loop() {
		_ = tracker.GetSiblings("ErrUserNotFound")
	}
}

// BenchmarkRelationshipTracker_HasCyclicDependency benchmarks cycle detection.
func BenchmarkRelationshipTracker_HasCyclicDependency(b *testing.B) {
	// Create a chain: A -> B -> C -> D
	relationships := []types.ErrorRelationship{
		{Parent: "A", Child: "B"},
		{Parent: "B", Child: "C"},
		{Parent: "C", Child: "D"},
	}

	b.ResetTimer()
	b.ReportAllocs()

	for b.Loop() {
		// Test adding E -> A (should NOT create cycle)
		tracker := &RelationshipTracker{}
		_ = tracker.HasCyclicDependency("E", "A", relationships)
		// Test adding D -> A (SHOULD create cycle)
		_ = tracker.HasCyclicDependency("D", "A", relationships)
	}
}

// BenchmarkRelationshipTracker_GetHierarchySummary benchmarks comprehensive stats.
func BenchmarkRelationshipTracker_GetHierarchySummary(b *testing.B) {
	// Create a complex hierarchy with multiple branches
	const branchCount = 20
	tracker := &RelationshipTracker{
		analyzer: &Analyzer{
			namedErrors:   make([]types.NamedError, 0, branchCount+3),
			relationships: make([]types.ErrorRelationship, 0, branchCount+5),
		},
	}

	// Add root
	tracker.analyzer.namedErrors = append(
		tracker.analyzer.namedErrors,
		types.NamedError{Name: "ErrRoot"},
	)

	// Add middle layer
	for i := 1; i <= 5; i++ {
		name := fmt.Sprintf("ErrMiddle%d", i)
		tracker.analyzer.namedErrors = append(
			tracker.analyzer.namedErrors,
			types.NamedError{Name: name},
		)
		tracker.analyzer.relationships = append(
			tracker.analyzer.relationships,
			types.ErrorRelationship{Parent: name, Child: "ErrRoot"},
		)

		// Add leaf errors for each middle layer
		for j := 1; j <= 4; j++ {
			leafName := fmt.Sprintf("ErrLeaf%d_%d", i, j)
			tracker.analyzer.namedErrors = append(
				tracker.analyzer.namedErrors,
				types.NamedError{Name: leafName},
			)
			tracker.analyzer.relationships = append(
				tracker.analyzer.relationships,
				types.ErrorRelationship{Parent: leafName, Child: name},
			)
		}
	}

	tracker.buildCache()

	b.ResetTimer()
	b.ReportAllocs()

	for b.Loop() {
		_ = tracker.GetHierarchySummary()
	}
}
