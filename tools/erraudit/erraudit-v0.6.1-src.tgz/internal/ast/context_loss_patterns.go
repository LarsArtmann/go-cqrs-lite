package ast

// Variable classification patterns for context-loss detection.
//
// This file uses an ALLOWLIST approach: only variables whose names match
// business-context suffixes (e.g. *ID, *Name, *Path) are considered
// candidates for context-loss detection. This replaces the former 100+ entry
// infrastructure denylist, which grew with every dogfooding run and could
// never be complete.
//
// The allowlist is naturally bounded because business-context naming follows
// Go conventions (camelCase with descriptive suffixes). Variables that don't
// match any suffix (ctx, db, logger, mu, i, x, data, etc.) are silently
// rejected — no denylist needed.

import (
	"slices"
	"strings"
)

// businessContextSuffixes are name suffixes that indicate a variable carries
// diagnostic value for error messages. Only variables matching at least one
// suffix are considered for context-loss detection.
//
// The suffixes are case-sensitive to match Go naming conventions:
//   - "ID" matches userID, orderID, requestID
//   - "Id" matches userId, orderId
//   - "Name" matches userName, templateName
//
//nolint:gochecknoglobals // immutable pattern list
var businessContextSuffixes = []string{
	// Identifiers
	"ID", "Id", "UUID", "Uuid",
	// Human-readable labels
	"Name", "Type",
	// File and resource locations
	"Path", "FilePath", "Filename", "Dir", "Directory",
	"URL", "Url", "URI", "Uri",
	// Network locations
	"Addr", "Address", "Host", "Port", "Endpoint",
	// Scalar quantities
	"Count", "Total", "Amount", "Size", "Number", "Num",
	"Index", "Idx", "Line", "LineNum",
	// Financial
	"Balance", "Price", "Cost", "Fee",
	// Temporal diagnostics
	"Timestamp", "Duration",
	// Diagnostic codes
	"Code", "Status", "Reason", "Message",
	// Versioning
	"Version",
	// Access identifiers (checked after credential rejection)
	"Key", "Token", "Email",
}

// criticalContextSuffixes indicate identity-critical variables. Losing these
// on an error path severely degrades diagnosability. Triggers SeverityHigh.
//
//nolint:gochecknoglobals // immutable pattern list
var criticalContextSuffixes = []string{
	"ID", "Id", "UUID", "Uuid",
}

// diagnosticContextSuffixes indicate infrastructure-diagnostic variables
// (paths, hosts, ports, endpoints). Losing these triggers SeverityHigh.
//
//nolint:gochecknoglobals // immutable pattern list
var diagnosticContextSuffixes = []string{
	"Path", "FilePath", "Filename", "Dir", "Directory",
	"URL", "Url", "URI", "Uri",
	"Addr", "Address", "Host", "Port", "Endpoint",
}

// credentialVariables are variable names that must NEVER appear in error
// messages for security reasons. Losing them is always correct.
// Checked via exact case-insensitive match before the allowlist gate.
//
//nolint:gochecknoglobals // immutable pattern list
var credentialVariables = []string{
	"password", "passwd", "secret", "token", "apiKey", "apikey",
	"privateKey", "publicKey", "credentials", "authToken", "accessToken",
	"refreshToken", "sessionId", "csrfToken", "bearer", "authorization",
	"pwd", "passphrase", "sshKey", "tlsCert", "tlsKey", "cert", "key",
}

// isBusinessContextVar reports whether name matches a business-context suffix.
// This is the primary gate for context-loss detection — only variables whose
// names suggest diagnostic value are considered.
func isBusinessContextVar(name string) bool {
	return hasAnySuffix(name, businessContextSuffixes)
}

// isCredentialVariable reports whether name matches a credential pattern
// (case-insensitive exact match). Credentials must never appear in errors.
func isCredentialVariable(name string) bool {
	lower := strings.ToLower(name)

	return slices.Contains(credentialVariables, lower)
}

// isCriticalContextVar reports whether name matches a critical-context suffix.
// Uses suffix matching so any variable ending in ID/Id/UUID is escalated.
func isCriticalContextVar(name string) bool {
	return hasAnySuffix(name, criticalContextSuffixes)
}

// isDiagnosticContextVar reports whether name matches a diagnostic-context
// suffix (paths, hosts, ports, endpoints).
func isDiagnosticContextVar(name string) bool {
	return hasAnySuffix(name, diagnosticContextSuffixes)
}

// hasAnySuffix reports whether name ends with any of the given suffixes.
func hasAnySuffix(name string, suffixes []string) bool {
	for _, suffix := range suffixes {
		if strings.HasSuffix(name, suffix) {
			return true
		}
	}

	return false
}
