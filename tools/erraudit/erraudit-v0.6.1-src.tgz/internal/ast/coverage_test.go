package ast

// coverage_test.go contains tests to improve code coverage for uncovered functions

import (
	"go/parser"
	"go/token"
	"os"
	"path/filepath"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestFileCache_Get(t *testing.T) {
	cache := NewFileCache()

	// Test Get on empty cache
	lines, ok := cache.Get("nonexistent.go")
	assert.False(t, ok)
	assert.Nil(t, lines)

	// Test Get after Load
	tmpDir := t.TempDir()
	tmpFile := filepath.Join(tmpDir, "test.go")
	err := os.WriteFile(tmpFile, []byte("line1\nline2"), 0o644)
	require.NoError(t, err)

	_, err = cache.Load(tmpFile)
	require.NoError(t, err)

	lines, ok = cache.Get(tmpFile)
	assert.True(t, ok)
	assert.Equal(t, []string{"line1", "line2"}, lines)
}

func TestFileCache_Load(t *testing.T) {
	// Create a temp file for testing
	tmpDir := t.TempDir()
	tmpFile := filepath.Join(tmpDir, "test.go")
	content := "package main\n\nfunc main() {}"
	err := os.WriteFile(tmpFile, []byte(content), 0o644)
	require.NoError(t, err)

	cache := NewFileCache()

	// Test Load new file
	lines, err := cache.Load(tmpFile)
	require.NoError(t, err)
	assert.Equal(t, []string{"package main", "", "func main() {}"}, lines)

	// Test Load cached file (should return from cache)
	lines2, err := cache.Load(tmpFile)
	require.NoError(t, err)
	assert.Equal(t, lines, lines2)

	// Test Load nonexistent file
	_, err = cache.Load("nonexistent.go")
	assert.Error(t, err)
}

func TestFileCache_Clear(t *testing.T) {
	cache := NewFileCache()

	tmpDir := t.TempDir()
	tmpFile := filepath.Join(tmpDir, "test.go")
	err := os.WriteFile(tmpFile, []byte("line1"), 0o644)
	require.NoError(t, err)

	_, err = cache.Load(tmpFile)
	require.NoError(t, err)
	assert.True(t, cache.Has(tmpFile))

	cache.Clear()

	assert.False(t, cache.Has(tmpFile))
}

func TestFileCache_Has(t *testing.T) {
	cache := NewFileCache()

	assert.False(t, cache.Has("test.go"))

	tmpDir := t.TempDir()
	tmpFile := filepath.Join(tmpDir, "test.go")
	err := os.WriteFile(tmpFile, []byte("line1"), 0o644)
	require.NoError(t, err)

	_, err = cache.Load(tmpFile)
	require.NoError(t, err)

	assert.True(t, cache.Has(tmpFile))
	assert.False(t, cache.Has("other.go"))
}

func TestViolationDetector_DetectAllViolations(t *testing.T) {
	code := `
package main

import (
	"errors"
	"fmt"
)

func badWrap(err error) error {
	return fmt.Errorf("bad: %v", err)
}

func panicOnError(err error) {
	if err != nil {
		panic(err)
	}
}

func ignoreError() {
	_, _ = errors.New("ignored")
}
`
	fset := token.NewFileSet()
	node, err := parser.ParseFile(fset, "", code, parser.AllErrors)
	require.NoError(t, err)

	analyzer := NewAnalyzer(fset, "main", "test.go")
	graph := analyzer.Analyze(node)

	violations := graph.Violations
	assert.NotEmpty(t, violations, "Expected violations to be detected")
}

// makeRelationships is a test helper for creating relationship slices
// Each argument is expected to be an array of {parent, child} string pairs.
func makeRelationships(pairs ...[2]string) []types.ErrorRelationship {
	rels := make([]types.ErrorRelationship, 0, len(pairs))
	for _, pair := range pairs {
		rels = append(rels, types.ErrorRelationship{
			Parent:           pair[0],
			Child:            pair[1],
			RelationshipType: types.RelationshipTypeWraps,
		})
	}

	return rels
}

func TestRelationshipTracker_GetWrappedErrors(t *testing.T) {
	fset := token.NewFileSet()
	analyzer := NewAnalyzer(fset, "main", "test.go")
	tracker := NewRelationshipTracker(analyzer)

	// Add some relationships
	analyzer.relationships = makeRelationships(
		[2]string{"ErrBase", "ErrWrapped"},
		[2]string{"ErrBase", "ErrAnother"},
	)

	children := tracker.GetWrappedErrors("ErrBase")
	assert.Len(t, children, 2)
	assert.Contains(t, children, "ErrWrapped")
	assert.Contains(t, children, "ErrAnother")

	// Non-existent parent
	children = tracker.GetWrappedErrors("NonExistent")
	assert.Empty(t, children)
}

func TestRelationshipTracker_GetRootErrors(t *testing.T) {
	fset := token.NewFileSet()
	analyzer := NewAnalyzer(fset, "main", "test.go")
	tracker := NewRelationshipTracker(analyzer)

	// Add named errors
	analyzer.namedErrors = []types.NamedError{
		{Name: "ErrRoot1"},
		{Name: "ErrRoot2"},
		{Name: "ErrChild"},
	}

	// Add relationship - ErrChild wraps ErrRoot1
	analyzer.relationships = []types.ErrorRelationship{
		{Parent: "ErrRoot1", Child: "ErrChild", RelationshipType: types.RelationshipTypeWraps},
	}

	roots := tracker.GetRootErrors()
	assert.Len(t, roots, 2) // ErrRoot1 and ErrRoot2 are roots
	assert.Contains(t, roots, "ErrRoot1")
	assert.Contains(t, roots, "ErrRoot2")
	assert.NotContains(t, roots, "ErrChild")
}

func TestRelationshipTracker_GetRelationshipDepth(t *testing.T) {
	fset := token.NewFileSet()
	analyzer := NewAnalyzer(fset, "main", "test.go")
	tracker := NewRelationshipTracker(analyzer)

	// Create a chain: ErrRoot -> ErrMiddle -> ErrLeaf
	analyzer.relationships = makeRelationships(
		[2]string{"ErrRoot", "ErrMiddle"},
		[2]string{"ErrMiddle", "ErrLeaf"},
	)

	// Build cache first
	tracker.buildCache()

	depth := tracker.GetRelationshipDepth("ErrLeaf")
	assert.Equal(t, uint(2), depth)

	depth = tracker.GetRelationshipDepth("ErrMiddle")
	assert.Equal(t, uint(1), depth)

	depth = tracker.GetRelationshipDepth("ErrRoot")
	assert.Equal(t, uint(0), depth)

	// Test caching - second call should use cache
	depth = tracker.GetRelationshipDepth("ErrLeaf")
	assert.Equal(t, uint(2), depth)
}

func TestRelationshipTracker_HasCyclicDependency(t *testing.T) {
	fset := token.NewFileSet()
	analyzer := NewAnalyzer(fset, "main", "test.go")
	tracker := NewRelationshipTracker(analyzer)

	existingRels := []types.ErrorRelationship{
		{Parent: "A", Child: "B", RelationshipType: types.RelationshipTypeWraps},
		{Parent: "B", Child: "C", RelationshipType: types.RelationshipTypeWraps},
	}

	// Adding D -> A should not create cycle
	hasCycle := tracker.HasCyclicDependency("A", "D", existingRels)
	assert.False(t, hasCycle)

	// Adding A -> D would create cycle (D -> A -> B -> C, then adding A -> D)
	// Wait, let me think about this more carefully
	// existingRels: A -> B -> C
	// new: A -> D
	// childToParent: B->A, C->B, D->A
	// Check if parent (A) is reachable from child (D)
	// From A, we go to parent... A has no parent, so no cycle
	// Actually this doesn't create a cycle

	// Let me test with a real cycle scenario
	// existingRels: A -> B
	// new: B -> A would create cycle
	hasCycle = tracker.HasCyclicDependency("B", "A", []types.ErrorRelationship{
		{Parent: "A", Child: "B", RelationshipType: types.RelationshipTypeWraps},
	})
	assert.True(t, hasCycle)

	// longer chain: A -> B -> C, adding C -> A creates cycle
	hasCycle = tracker.HasCyclicDependency("C", "A", []types.ErrorRelationship{
		{Parent: "A", Child: "B", RelationshipType: types.RelationshipTypeWraps},
		{Parent: "B", Child: "C", RelationshipType: types.RelationshipTypeWraps},
	})
	assert.True(t, hasCycle)
}

func TestRelationshipTracker_GetErrorChain(t *testing.T) {
	fset := token.NewFileSet()
	analyzer := NewAnalyzer(fset, "main", "test.go")
	tracker := NewRelationshipTracker(analyzer)

	// Create a chain: ErrRoot -> ErrMiddle -> ErrLeaf
	analyzer.relationships = makeRelationships(
		[2]string{"ErrRoot", "ErrMiddle"},
		[2]string{"ErrMiddle", "ErrLeaf"},
	)

	chain := tracker.GetErrorChain("ErrLeaf")
	assert.Equal(t, []string{"ErrRoot", "ErrMiddle", "ErrLeaf"}, chain)

	chain = tracker.GetErrorChain("ErrMiddle")
	assert.Equal(t, []string{"ErrRoot", "ErrMiddle"}, chain)

	chain = tracker.GetErrorChain("ErrRoot")
	assert.Equal(t, []string{"ErrRoot"}, chain)
}

func TestRelationshipTracker_GetStatistics(t *testing.T) {
	fset := token.NewFileSet()
	analyzer := NewAnalyzer(fset, "main", "test.go")
	tracker := NewRelationshipTracker(analyzer)

	analyzer.namedErrors = []types.NamedError{
		{Name: "ErrRoot"},
		{Name: "ErrChild"},
	}
	analyzer.relationships = []types.ErrorRelationship{
		{Parent: "ErrRoot", Child: "ErrChild", RelationshipType: types.RelationshipTypeWraps},
		{Parent: "ErrRoot", Child: "ErrAlias", RelationshipType: types.RelationshipTypeAliases},
	}

	stats := tracker.GetStatistics()

	assert.Equal(t, 2, stats["totalRelationships"])
	assert.Equal(t, 1, stats["wraps"])
	assert.Equal(t, 1, stats["aliases"])
	assert.Equal(t, 2, stats["totalNamedErrors"])
	assert.Equal(t, 1, stats["rootErrors"]) // ErrRoot is root, ErrChild is not
}

func TestRelationshipTracker_ConsolidateDuplicateRelationships(t *testing.T) {
	fset := token.NewFileSet()
	analyzer := NewAnalyzer(fset, "main", "test.go")
	tracker := NewRelationshipTracker(analyzer)

	// Add duplicate relationships
	analyzer.relationships = []types.ErrorRelationship{
		{Parent: "A", Child: "B", RelationshipType: types.RelationshipTypeWraps},
		{Parent: "A", Child: "B", RelationshipType: types.RelationshipTypeWraps}, // duplicate
		{Parent: "A", Child: "C", RelationshipType: types.RelationshipTypeWraps},
	}

	tracker.ConsolidateDuplicateRelationships()

	assert.Len(t, analyzer.relationships, 2)
}

func TestAnalyzer_WithFileCache(t *testing.T) {
	cache := NewFileCache()

	tmpDir := t.TempDir()
	tmpFile := filepath.Join(tmpDir, "existing.go")
	err := os.WriteFile(tmpFile, []byte("line1"), 0o644)
	require.NoError(t, err)

	_, err = cache.Load(tmpFile)
	require.NoError(t, err)

	fset := token.NewFileSet()
	analyzer := NewAnalyzer(fset, "main", "test.go", WithFileCache(cache))

	// Verify the cache is used
	assert.Same(t, cache, analyzer.fileCache)
	assert.True(t, analyzer.fileCache.Has(tmpFile))
}

func TestAnalyzer_AnalyzeLogFatal(t *testing.T) {
	code := `
package main

import "log"

func fatalOnError(err error) {
	if err != nil {
		log.Fatal(err)
	}
}
`
	fset := token.NewFileSet()
	node, err := parser.ParseFile(fset, "", code, parser.AllErrors)
	require.NoError(t, err)

	analyzer := NewAnalyzer(fset, "main", "test.go")
	analyzer.Analyze(node)

	// Check that log.Fatal violation was detected
	found := false

	for _, v := range analyzer.violations {
		if v.Type == types.ErrorTypePanic && v.Severity == types.SeverityHigh {
			found = true

			break
		}
	}

	assert.True(t, found, "Expected to find log.Fatal violation")
}

func TestAnalyzer_TrackScopeVar(t *testing.T) {
	fset := token.NewFileSet()
	analyzer := NewAnalyzer(fset, "main", "test.go")

	analyzer.trackScopeVar("errVar1")
	analyzer.trackScopeVar("errVar2")

	assert.True(t, analyzer.isErrorInScope("errVar1"))
	assert.True(t, analyzer.isErrorInScope("errVar2"))
	assert.False(t, analyzer.isErrorInScope("nonexistent"))
}

func TestAnalyzer_IsErrorDefinition(t *testing.T) {
	fset := token.NewFileSet()
	analyzer := NewAnalyzer(fset, "main", "test.go")

	analyzer.namedErrors = []types.NamedError{
		{Name: "ErrNotFound"},
		{Name: "ErrInvalid"},
	}

	assert.True(t, analyzer.isErrorDefinition("ErrNotFound"))
	assert.True(t, analyzer.isErrorDefinition("ErrInvalid"))
	assert.False(t, analyzer.isErrorDefinition("ErrUnknown"))
}

func TestBuildLineSnippet(t *testing.T) {
	lines := []string{"line1", "line2", "line3", "line4", "line5"}

	snippet := buildLineSnippet(lines, 3, 1, 5)
	assert.Contains(t, snippet, "1 line1")
	assert.Contains(t, snippet, "2 line2")
	assert.Contains(t, snippet, "> 3 line3") // Current line marked
	assert.Contains(t, snippet, "4 line4")
	assert.Contains(t, snippet, "5 line5")
}

func TestExtractCodeSnippet(t *testing.T) {
	// Create a temp file for testing
	tmpDir := t.TempDir()
	tmpFile := filepath.Join(tmpDir, "test.go")
	content := "package main\n\nfunc main() {}\n"
	err := os.WriteFile(tmpFile, []byte(content), 0o644)
	require.NoError(t, err)

	// Parse the file
	fset := token.NewFileSet()
	node, err := parser.ParseFile(fset, tmpFile, nil, parser.AllErrors)
	require.NoError(t, err)

	analyzer := NewAnalyzer(fset, "main", tmpFile)

	// Get position of the function declaration
	pos := node.Pos()
	snippet := analyzer.extractCodeSnippet(pos, 1)

	assert.NotEmpty(t, snippet)
	assert.Contains(t, snippet, "package main")
}

func TestExtractCodeSnippet_NoPos(t *testing.T) {
	fset := token.NewFileSet()
	analyzer := NewAnalyzer(fset, "main", "test.go")

	snippet := analyzer.extractCodeSnippet(token.NoPos, 2)
	assert.Empty(t, snippet)
}
