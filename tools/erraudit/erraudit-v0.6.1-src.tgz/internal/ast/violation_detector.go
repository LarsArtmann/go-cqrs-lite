// Package ast provides AST-based error analysis.
package ast

import (
	"fmt"
	"go/ast"
	"go/token"
	"log/slog"

	"github.com/larsartmann/erraudit/pkg/extension/hooks"
	"github.com/larsartmann/erraudit/pkg/types"
)

// Violation messages.
const (
	msgFmtGenericErrorReturn          = "Function %q returns generic error interface instead of specific error type"
	suggestionFmtSpecificError        = "Define a specific error type (e.g., %sError) and return that instead of error"
	msgErrorPropagation               = "Error propagation"
	msgFunctionReturnsError           = "Function returns error"
	msgErrorAssignedFromCall          = "Error assigned from function call"
	msgErrorIgnoredWithBlank          = "Error may be ignored using blank identifier"
	suggestionFmtCheckError           = "Check error from %s instead of using _"
	msgErrorNotHandledEmpty           = "Error checked but not handled (empty if block)"
	suggestionHandleOrLog             = "Handle the error or log it"
	msgErrorNotHandledSwallowed       = "Error checked but not handled properly (error is swallowed)"
	suggestionReturnInsteadOfNil      = "Return the error instead of returning nil or a different value"
	msgErrorCheckedNoErrorReturn      = "Error checked but enclosing function has no error return"
	suggestionChangeSignatureOrHandle = "Handle the error locally, or change the function signature to return error so it can propagate"
	msgErrorCheckFound                = "Error check found"

	// Confidence tiers for violation detection. Higher values indicate
	// detections based on direct AST patterns; lower values indicate
	// naming heuristics or advisory suggestions.
	confidenceViolation  = 0.95 // panic, ignored, silent_swallow
	confidencePattern    = 0.85 // unwrapped, wrapping
	confidenceStandard   = 0.80 // return, assignment, check, propagation
	confidenceAdvisory   = 0.70 // legacy_as
	confidenceSuggestion = 0.60 // generic_return, legacy_is

	// twoValuedAssignment is the LHS count for the comma-ok / (T, bool) accessor
	// pattern where a presence-flag sibling suppresses blank-identifier flagging.
	twoValuedAssignment = 2
)

// violationConfidence returns a heuristic confidence score (0.0–1.0) for a violation type.
// High-confidence detections are based on direct AST patterns (panic, ignored, silent_swallow).
// Lower-confidence detections use naming heuristics (generic_return, legacy_as).
func violationConfidence(violationType types.ErrorType) types.Confidence {
	switch violationType {
	case types.ErrorTypePanic, types.ErrorTypeIgnored, types.ErrorTypeSilentSwallow:
		return types.NewConfidence(confidenceViolation)
	case types.ErrorTypeUnwrapped, types.ErrorTypeWrapping:
		return types.NewConfidence(confidencePattern)
	case types.ErrorTypeReturn, types.ErrorTypeAssignment, types.ErrorTypeCheck, types.ErrorTypePropagation:
		return types.NewConfidence(confidenceStandard)
	case types.ErrorTypeLegacyAs:
		return types.NewConfidence(confidenceAdvisory)
	case types.ErrorTypeGenericReturn, types.ErrorTypeLegacyIs, types.ErrorTypeDeferredCloseIgnored:
		return types.NewConfidence(confidenceSuggestion)
	case types.ErrorTypeContextLoss, types.ErrorTypeStdlibConstructor, types.ErrorTypeOopsRedundantGuard,
		types.ErrorTypeOopsMisusedW, types.ErrorTypeSentinelConcreteType,
		types.ErrorTypeUncodedConstructor:
		return types.NewConfidence(confidenceStandard)
	default:
		return types.NewConfidence(confidenceStandard)
	}
}

// ViolationDetector detects error handling violations.
type ViolationDetector struct {
	analyzer     *Analyzer
	typeResolver *TypeResolver
	blankCallee  *blankCalleeClassifier
}

// NewViolationDetector creates a new violation detector.
func NewViolationDetector(analyzer *Analyzer) *ViolationDetector {
	return &ViolationDetector{
		analyzer:     analyzer,
		typeResolver: analyzer.typeResolver,
		blankCallee:  newBlankCalleeClassifier(analyzer),
	}
}

// addErrorInfo creates and appends an error info record with the given parameters.
func (d *ViolationDetector) addErrorInfo(
	pos token.Pos,
	errorType types.ErrorType,
	message, functionName string,
) {
	d.analyzer.errors = append(
		d.analyzer.errors,
		createErrorInfo(
			d.analyzer.fset,
			pos,
			errorType,
			message,
			functionName,
			d.analyzer.pkgName,
			d.analyzer.fileName,
		),
	)
}

// addViolation creates and appends a violation with the given parameters.
// Skips if an identical violation (same Key) already exists.
func (d *ViolationDetector) addViolation(
	violationType types.ErrorType,
	severity types.Severity,
	message, suggestion string,
	node ast.Node,
	errorName string,
) {
	violation := types.NewErrorViolation(
		d.analyzer.fset, node.Pos(), node.End(),
		violationType, severity,
		message, suggestion, errorName,
		violationConfidence(violationType),
	)

	// Deduplicate: skip if a violation with the same key already exists.
	for _, existing := range d.analyzer.violations {
		if existing.Key() == violation.Key() {
			return
		}
	}

	// Execute pre-violation hook
	preData, cancelled, preErr := hooks.Fire(d.analyzer.ctx, hooks.HookPreViolation, &hooks.PreViolationData{
		Violation: violation,
		File:      d.analyzer.fileName,
	})
	if preErr != nil {
		slog.Warn("pre-violation hook failed", "error", preErr, "file", d.analyzer.fileName)
	}

	// Check if hook cancelled the violation
	if cancelled {
		return
	}

	// Use modified violation if hook changed it (via in-place pointer modification)
	if modified, ok := preData.Violation.(types.ErrorViolation); ok {
		violation = modified
	}

	d.analyzer.violations = append(d.analyzer.violations, violation)

	// Execute post-violation hook
	if _, _, postErr := hooks.Fire(d.analyzer.ctx, hooks.HookPostViolation, &hooks.PostViolationData{
		Violation: violation,
		Added:     true,
	}); postErr != nil {
		slog.Warn("post-violation hook failed", "error", postErr, "file", d.analyzer.fileName)
	}
}

// DetectViolationsInFunction analyzes a function for error violations.
func (d *ViolationDetector) DetectViolationsInFunction(fn *ast.FuncDecl) {
	if fn.Type.Results == nil {
		return
	}

	// Check if function returns generic error interface (instead of specific type)
	// Low severity: returning the error interface is standard Go practice.
	// This is a design suggestion, not a correctness issue — confidence is only 0.60.
	// Opt-in only (--enforce-generic-return) — disabled by default since Go's
	// idiom is bare error returns.
	if d.analyzer.enforceGenericReturn && d.analyzer.hasGenericErrorReturn(fn) {
		funcName := fn.Name.Name
		d.addViolation(
			types.ErrorTypeGenericReturn,
			types.SeverityLow,
			fmt.Sprintf(msgFmtGenericErrorReturn, funcName),
			fmt.Sprintf(suggestionFmtSpecificError, funcName),
			fn,
			funcName,
		)
	}

	// Return statement analysis is handled by DetectViolationsInReturnStmt during the main walk
	// No nested ast.Inspect needed - reduces allocations and improves performance
}

// DetectViolationsInCallExpr analyzes a call expression for violations.
func (d *ViolationDetector) DetectViolationsInCallExpr(call *ast.CallExpr) {
	// Check for error wrapping: fmt.Errorf("%w", err)
	if d.analyzer.isErrorfCall(call) {
		d.analyzer.analyzeErrorf(call)
	}

	// Check for panic on errors
	if d.analyzer.isPanicCall(call) {
		d.analyzer.analyzePanic(call)
	}

	// Check for log.Fatal on errors
	if d.analyzer.isLogFatalCall(call) {
		d.analyzer.analyzeLogFatal(call)
	}
}

// DetectViolationsInReturnStmt analyzes a return statement for violations.
func (d *ViolationDetector) DetectViolationsInReturnStmt(ret *ast.ReturnStmt) {
	for _, result := range ret.Results {
		// Check for error identifier
		if d.analyzer.isErrorIdentifier(result) {
			d.addErrorInfo(
				result.Pos(),
				types.ErrorTypePropagation,
				msgErrorPropagation,
				d.analyzer.getContainingFunctionName(result),
			)
		}

		// Check for error creation via function call
		if call, ok := result.(*ast.CallExpr); ok {
			if d.analyzer.isErrorCreatingCall(call) {
				d.addErrorInfo(
					result.Pos(),
					types.ErrorTypeReturn,
					msgFunctionReturnsError,
					d.analyzer.getCallName(call),
				)
			}
		}
	}
}

// DetectViolationsInAssignStmt analyzes an assignment for violations.
func (d *ViolationDetector) DetectViolationsInAssignStmt(assign *ast.AssignStmt) {
	capturesError := d.assignmentCapturesError(assign)

	for i, lhs := range assign.Lhs {
		ident, ok := lhs.(*ast.Ident)
		if !ok {
			continue
		}

		if looksLikeErrorName(ident.Name) {
			d.detectErrorAssignmentViolation(assign, i)
		} else if ident.Name == "_" && !capturesError {
			d.detectBlankAssignmentViolation(assign, i)
		}
	}
}

// assignmentCall returns the call assigned to the i-th LHS element.
func (d *ViolationDetector) assignmentCall(assign *ast.AssignStmt, i int) (*ast.CallExpr, bool) {
	if len(assign.Rhs) == 0 {
		return nil, false
	}

	call, ok := assign.Rhs[d.rhsIndexForLHS(assign, i)].(*ast.CallExpr)

	return call, ok
}

// detectErrorAssignmentViolation flags error = someFunc() patterns.
func (d *ViolationDetector) detectErrorAssignmentViolation(assign *ast.AssignStmt, i int) {
	call, ok := d.assignmentCall(assign, i)
	if !ok {
		return
	}

	d.addErrorInfo(
		assign.Pos(),
		types.ErrorTypeAssignment,
		msgErrorAssignedFromCall,
		d.analyzer.getCallName(call),
	)
}

// detectBlankAssignmentViolation flags _ = someFunc() when the return is an error.
func (d *ViolationDetector) detectBlankAssignmentViolation(assign *ast.AssignStmt, i int) {
	if !d.assignmentIsErrorCall(assign, i) {
		return
	}

	// AST-only guard for the comma-ok / (T, bool) accessor pattern when type
	// info is unavailable: when the sibling LHS identifier is a conventional
	// presence-flag name (ok, found, exists, present, has), the call is almost
	// certainly a presence check returning (T, bool) — not (T, error). Skip
	// flagging; the blank is discarding a value, not an error.
	//
	// Bypassed when --no-suppress is on so the user can audit all potential
	// violations.
	if !d.analyzer.noSuppress && (d.typeResolver == nil || !d.typeResolver.Available()) {
		if siblingIsPresenceFlag(assign, i) {
			return
		}
	}

	call, _ := d.assignmentCall(assign, i)

	// AST-only guard for deferred teardown: `_ = x.Close()` inside a deferred
	// closure is the standard explicit spelling. A deferred function cannot
	// return an error to the caller, and bare `defer x.Close()` is rejected by
	// golangci-lint's errcheck for concrete types, so the closure form is the
	// only spelling that satisfies both tools. Aligned with erraudit's own
	// deferred-close default (--enforce-deferred-close off).
	//
	// Bypassed when --no-suppress is on so the user can audit all potential
	// violations.
	//
	// See docs/feedback/2026-09-04_00-00_silent-swallow-void-func-escape-hatch-and-ignored-vs-errcheck-close-deadlock.md
	// (Item 2).
	if !d.analyzer.noSuppress && isCloseMethodCall(call) &&
		d.analyzer.insideDeferredClosure(assign.Pos()) {
		return
	}

	d.addViolation(
		types.ErrorTypeIgnored,
		types.SeverityMedium,
		msgErrorIgnoredWithBlank,
		fmt.Sprintf(suggestionFmtCheckError, d.analyzer.getCallName(call)),
		assign,
		"_",
	)
}

// siblingIsPresenceFlag reports whether any non-blank LHS identifier in a
// multi-value assignment is a conventional presence-flag name (ok, found,
// exists, present, has). Used to suppress false positives on patterns like
// `_, ok := h.Get(name)` or `_, val, ok := callSelector(call)` where the
// callee returns (T, bool) or (T1, T2, bool), not (..., error).
//
// Go convention places bool success flags as the final return value. When a
// presence-flag name appears among the siblings, it strongly indicates the
// function follows the comma-ok pattern rather than returning error.
func siblingIsPresenceFlag(assign *ast.AssignStmt, blankIndex int) bool {
	if len(assign.Lhs) < twoValuedAssignment {
		return false
	}

	for i, lhs := range assign.Lhs {
		if i == blankIndex {
			continue
		}

		if ident, ok := lhs.(*ast.Ident); ok && isPresenceFlagName(ident.Name) {
			return true
		}
	}

	return false
}

// assignmentIsErrorCall reports whether the i-th LHS element is assigned an
// error-returning call. Used by detectBlankAssignmentViolation to gate on
// both "is a call" and "returns error" in one shot.
func (d *ViolationDetector) assignmentIsErrorCall(assign *ast.AssignStmt, i int) bool {
	call, ok := d.assignmentCall(assign, i)

	return ok && d.isBlankReceivingError(call, i)
}

// assignmentCapturesError checks whether any LHS identifier captures an error
// variable. The check is a case-insensitive substring match on "err" so that
// conventional spellings (err, statErr, registerErr, errFoo) are all recognized
// — the previous exact match on "err" missed everything else and caused false
// positives on `_, statErr := os.Stat(...)` (the error IS captured in statErr).
func (d *ViolationDetector) assignmentCapturesError(assign *ast.AssignStmt) bool {
	for _, lhs := range assign.Lhs {
		if ident, ok := lhs.(*ast.Ident); ok {
			if looksLikeErrorName(ident.Name) {
				return true
			}
		}
	}

	return false
}

// rhsIndexForLHS returns the RHS index corresponding to the i-th LHS element.
// For multi-return assignments with a single RHS call, all LHS map to RHS[0].
func (d *ViolationDetector) rhsIndexForLHS(assign *ast.AssignStmt, i int) int {
	if i >= len(assign.Rhs) {
		return 0
	}

	return i
}

// isBlankReceivingError checks whether the blank identifier at position blankIndex
// is receiving an error return value from the given call expression.
// Returns true (flag it) when type info is unavailable AND no AST heuristic
// rules out an error return (e.g. comma-ok / presence-flag pattern, a curated
// stdlib signature, or a same-file/cross-file function whose return type at
// blankIndex is provably not error).
// Returns true only when the actual return type is error when type info is available.
//
// When analyzer.noSuppress is true (from --no-suppress), all AST heuristics are
// bypassed and every blank assignment to a call is flagged — the user is
// explicitly auditing for potential violations.
func (d *ViolationDetector) isBlankReceivingError(call *ast.CallExpr, blankIndex int) bool {
	if d.typeResolver != nil && d.typeResolver.Available() {
		return d.typeResolver.ReturnTypeIsError(call, blankIndex)
	}

	// --no-suppress: bypass all AST heuristics, flag everything.
	if d.analyzer.noSuppress {
		return true
	}

	// Default mode: the ordered precision ladder decides (comma-ok shape →
	// stdlib no-error table → declared signature → conservative flag). Only
	// a proven not-error verdict suppresses; anything unproven stays flagged.
	verdict, _ := d.blankCallee.classify(call, blankIndex)

	return verdict == blankCalleeFlag
}

// DetectViolationsInIfStmt analyzes an if statement for violations.
func (d *ViolationDetector) DetectViolationsInIfStmt(ifStmt *ast.IfStmt) {
	if ifStmt.Cond == nil {
		return
	}

	// Check for: if err != nil
	if binaryExpr, ok := ifStmt.Cond.(*ast.BinaryExpr); ok {
		if d.analyzer.isErrorCheck(binaryExpr) {
			d.classifyErrorCheck(ifStmt, binaryExpr)
		}
	}
}

// classifyErrorCheck emits the appropriate violation/info for an `if err != nil`
// block. The severity depends on (a) whether the error is handled at all and
// (b) whether the enclosing function can return an error:
//
//   - Empty block → CRITICAL swallow (the error is checked and then ignored).
//   - Swallowed (log-then-return-nil, or bare continue/break without using err)
//     and the function CAN return error → CRITICAL swallow.
//   - Swallowed but the function CANNOT return error → WARNING with a
//     signature-change suggestion (the error has nowhere to go; the fix is to
//     change the signature, not to `return err`).
//   - Otherwise → informational ErrorTypeCheck (no violation).
func (d *ViolationDetector) classifyErrorCheck(ifStmt *ast.IfStmt, binaryExpr *ast.BinaryExpr) {
	errName := errorIdentName(binaryExpr)

	if d.analyzer.isEmptyBlock(ifStmt.Body) {
		// Empty `if err != nil {}` — always a swallow regardless of enclosing
		// signature; the error is checked and then completely ignored.
		d.addViolation(
			types.ErrorTypeSilentSwallow,
			types.SeverityHigh,
			msgErrorNotHandledEmpty,
			suggestionHandleOrLog,
			ifStmt,
			errName,
		)

		return
	}

	// Void function (innermost scope has no error return) + the error passed
	// as an argument to any call inside the block (log.Printf, logger.Error,
	// append, errors.Is, ...): the error is CONSUMED. In a function that
	// cannot return an error, passing the error to a call is the handling —
	// there is nothing further it can do — so this is an informational check,
	// not a swallow. Bypassed by --no-suppress so the site stays auditable.
	//
	// See docs/feedback/2026-09-04_00-00_silent-swallow-void-func-escape-hatch-and-ignored-vs-errcheck-close-deadlock.md
	// (Item 1): log-and-continue in a fire-and-forget producer goroutine is
	// the only correct handling; before this guard the site required a nolint.
	if !d.analyzer.noSuppress && !hasErrorReturn(d.analyzer.currentFuncType()) &&
		errorConsumedByCall(ifStmt.Body, errName) {
		d.addErrorInfo(
			ifStmt.Pos(),
			types.ErrorTypeCheck,
			msgErrorCheckFound,
			d.analyzer.getContainingFunctionName(ifStmt),
		)

		return
	}

	if !d.analyzer.isErrorSwallowed(ifStmt.Body, errName) {
		d.addErrorInfo(
			ifStmt.Pos(),
			types.ErrorTypeCheck,
			msgErrorCheckFound,
			d.analyzer.getContainingFunctionName(ifStmt),
		)

		return
	}

	// The error is swallowed (log-then-return-nil or bare continue/break).
	// When the enclosing function has no error return, the error cannot be
	// propagated by `return err` — downgrade from CRITICAL to WARNING and
	// suggest a signature change instead.
	severity := types.SeverityHigh
	message := msgErrorNotHandledSwallowed
	suggestion := suggestionReturnInsteadOfNil

	if !hasErrorReturn(d.analyzer.currentFuncType()) {
		severity = types.SeverityLow
		message = msgErrorCheckedNoErrorReturn
		suggestion = suggestionChangeSignatureOrHandle
	}

	d.addViolation(
		types.ErrorTypeSilentSwallow,
		severity,
		message,
		suggestion,
		ifStmt,
		errName,
	)
}

// AddCodeSnippetsToViolations adds code snippets to all violations.
func (d *ViolationDetector) AddCodeSnippetsToViolations() {
	for i := range d.analyzer.violations {
		if d.analyzer.violations[i].SnippetPos.IsValid() {
			d.analyzer.violations[i].CodeSnippet = d.analyzer.extractCodeSnippet(
				d.analyzer.violations[i].SnippetPos,
				snippetContextLines,
			)
		}
	}
}

// closeMethodName is the method we check for in deferred-close detection.
const closeMethodName = "Close"

// isCloseMethodCall reports whether the call is a method call named Close
// (x.Close()). Used to recognize resource teardown in the deferred-closure
// blank-assignment exemption.
func isCloseMethodCall(call *ast.CallExpr) bool {
	if call == nil {
		return false
	}

	sel, ok := call.Fun.(*ast.SelectorExpr)

	return ok && sel.Sel.Name == closeMethodName
}

// DetectDeferredClose flags `defer x.Close()` patterns where the Close return
// value (error) is silently discarded. This is advisory (SeverityLow) because
// `defer f.Close()` is standard Go cleanup practice — the violation surfaces
// it so users can audit whether Close errors matter for their resource type
// (e.g., *bufio.Writer.Close flushes and can lose data).
//
// When type-aware mode is active, the receiver type is checked against
// io.Closer. Types that provably do NOT implement io.Closer are skipped
// (their Close method doesn't return error), eliminating false positives.
// Unresolved types fall back to the method-name heuristic.
func (d *ViolationDetector) DetectDeferredClose(deferStmt *ast.DeferStmt) {
	sel, ok := deferStmt.Call.Fun.(*ast.SelectorExpr)
	if !ok {
		return
	}

	if sel.Sel.Name != closeMethodName {
		return
	}

	if d.typeResolver != nil {
		switch d.typeResolver.ExprImplementsCloser(sel.X) {
		case ErrorTypeDoesNotImplement:
			return
		case ErrorTypeUnresolved:
			// Fall back to method-name heuristic below
		case ErrorTypeImplements:
			// Confirmed, flag it
		}
	}

	d.addViolation(
		types.ErrorTypeDeferredCloseIgnored,
		types.SeverityLow,
		fmt.Sprintf("defer %s.Close() ignores Close error", exprName(sel.X)),
		"Capture the Close error or wrap it with the function's other errors",
		deferStmt,
		"",
	)
}

// exprName returns a best-effort string representation of an expression for
// use in violation messages. Falls back to "<expr>" for complex expressions.
func exprName(expr ast.Expr) string {
	if name := identName(expr); name != "" {
		return name
	}

	return "<expr>"
}
