package ast

// Opt-in enforcement detector: flags stdlib error constructors (errors.New,
// fmt.Errorf, errors.Join) as violations when a target error library is
// enforced (--enforce-go-error-family or --enforce-samber-oops). This is an
// opt-in policy — erraudit is neutral by default and does not judge constructor
// choice.
//
// The enforcement framework is pluggable: each target library registers an
// enforcePolicy that knows how to (a) exempt its own calls and (b) generate
// context-aware replacement suggestions. Adding a new enforcement target is
// just one new policy function.

import (
	"fmt"
	"go/ast"
	"strings"

	"github.com/larsartmann/erraudit/pkg/types"
)

const enforceConfidence = 0.90

// enforcePolicy describes a target error library that stdlib constructors
// should be migrated to. Each policy knows how to identify calls that already
// use the target library (exemption) and how to generate a replacement
// suggestion for stdlib constructors.
type enforcePolicy struct {
	// libraryName is the human-readable name used in violation messages
	// (e.g. "go-error-family", "samber/oops").
	libraryName string

	// isExempt reports whether call already uses this target library and
	// therefore should NOT be flagged.
	isExempt func(call *ast.CallExpr) bool

	// suggestionFor generates a replacement suggestion for the given stdlib
	// constructor call. constructorType is one of "errors.New", "fmt.Errorf",
	// "errors.Join". The call is passed so the suggestion can inspect arguments
	// (e.g. check for %w in fmt.Errorf to suggest Wrapf vs Errorf).
	suggestionFor func(call *ast.CallExpr, constructorType string) string
}

// errorFamilySuggestionFor generates the go-error-family replacement suggestion.
func errorFamilySuggestionFor(_ *ast.CallExpr, _ string) string {
	return "Replace with errorfamily.NewRejection(code, msg) or the appropriate family constructor"
}

// errorFamilyEnforcePolicy is the enforcement policy for go-error-family.
//
//nolint:gochecknoglobals // immutable policy, avoids per-file allocation
var errorFamilyEnforcePolicy = enforcePolicy{
	libraryName:   "go-error-family",
	isExempt:      isErrorFamilyCall,
	suggestionFor: errorFamilySuggestionFor,
}

// matchStdlibConstructor returns the canonical constructor name for a pkg.method
// pair, or "" when the call is not a stdlib error constructor.
func matchStdlibConstructor(pkg, method string) string {
	switch {
	case pkg == errorsPkg && method == methodNew:
		return "errors.New"
	case pkg == fmtPkg && method == methodErrorf:
		return "fmt.Errorf"
	case pkg == errorsPkg && method == "Join":
		return "errors.Join"
	default:
		return ""
	}
}

// isStdlibImport reports whether the identifier (e.g. "errors", "fmt")
// resolves to the standard library package of the same name in the given file.
// This prevents false positives when a project package is imported under the
// same name (e.g. `errors "github.com/.../pkg/errors"`).
func isStdlibImport(file *ast.File, ident string) bool {
	for _, imp := range file.Imports {
		importPath := strings.Trim(imp.Path.Value, "\"")

		var localName string
		if imp.Name != nil {
			localName = imp.Name.Name
		} else if _, after, ok := strings.CutLast(importPath, "/"); ok {
			localName = after
		} else {
			localName = importPath
		}

		if localName == ident {
			return importPath == ident
		}
	}

	return false
}

// detectEnforcedStdlib walks the AST and emits a violation for every stdlib
// error constructor (errors.New, fmt.Errorf, errors.Join) when one or more
// enforcement policies are active. Calls that already use an enforced target
// library are exempt. The first policy in the slice determines the message
// wording and suggestion text.
//
// Import resolution: when node is *ast.File, the detector verifies that the
// selector ("errors"/"fmt") actually refers to the stdlib import — not a
// project package imported under the same name. This prevents false positives
// on files that import e.g. pkg/errors as "errors".
func detectEnforcedStdlib(a *Analyzer, node ast.Node, policies []enforcePolicy) {
	if len(policies) == 0 {
		return
	}

	file, _ := node.(*ast.File)

	primary := policies[0]

	ast.Inspect(node, func(n ast.Node) bool {
		call, ok := n.(*ast.CallExpr)
		if !ok {
			return true
		}

		// Skip calls that already use any enforced target library
		for _, p := range policies {
			if p.isExempt(call) {
				return true
			}
		}

		pkg, method, ok := callSelector(call)
		if !ok {
			return true
		}

		constructorType := matchStdlibConstructor(pkg, method)
		if constructorType == "" {
			return true
		}

		// When we have full file context, verify that the selector actually
		// resolves to the stdlib import. This prevents false positives where
		// a project package is imported under the name "errors" or "fmt".
		if file != nil && !isStdlibImport(file, pkg) {
			return true
		}

		message := fmt.Sprintf("%s used — project enforces %s", constructorType, primary.libraryName)
		suggestion := primary.suggestionFor(call, constructorType)

		violation := types.NewErrorViolation(
			a.fset, call.Pos(), call.End(),
			types.ErrorTypeStdlibConstructor, types.SeverityMedium,
			message, suggestion, constructorType,
			types.NewConfidence(enforceConfidence),
		)

		a.appendViolation(violation)

		return true
	})
}
