package ast

// Tests for the detector-policy changes requested by
// docs/feedback/2026-09-04_00-00_silent-swallow-void-func-escape-hatch-and-ignored-vs-errcheck-close-deadlock.md.
//
// Item 1: in a function (or closure) with no error return, an error passed as
// an argument to any call inside the `if err != nil` block is CONSUMED —
// log-and-continue/return is the only correct handling and must not be a
// silent_swallow violation.
//
// Item 2: `_ = x.Close()` inside a deferred closure is exempt from the
// `ignored` rule — a deferred function cannot return an error, and bare
// `defer x.Close()` is rejected by golangci-lint's errcheck for concrete
// types, so the closure form is the only spelling both tools accept.

import (
	"strings"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
)

// Item 1, exact repro shape from the feedback: background producer loop in a
// void function, log-and-continue. Must not be a violation.
func TestFeedback20260904_SilentSwallow_VoidFuncLogAndContinue_NotFlagged(t *testing.T) {
	code := `
package main

import "log"

type patch struct{}

func newSignalsPatch(total int) (*patch, error) { return nil, nil }

func startProducer() {
	for i := range 10 {
		countPatch, err := newSignalsPatch(i)
		if err != nil {
			log.Printf("producer: marshal count signals: %v", err)
			continue
		}
		_ = countPatch
	}
}
`
	helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
		if v := helperFindViolation(graph, types.ErrorTypeSilentSwallow); v != nil {
			t.Fatalf("log-and-continue in void producer must not be a violation, got: %q", v.Message)
		}
	})
}

// Item 1 companion: the consumed error still surfaces as an informational
// check, so the site remains visible in the analysis accounting.
func TestFeedback20260904_SilentSwallow_VoidFuncLogAndContinue_EmitsCheckInfo(t *testing.T) {
	code := `
package main

import "log"

func step() error { return nil }

func producer() {
	for {
		err := step()
		if err != nil {
			log.Printf("skip: %v", err)
			continue
		}
		return
	}
}
`
	helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
		found := false

		for _, info := range graph.Errors {
			if info.Type == types.ErrorTypeCheck {
				found = true

				break
			}
		}

		if !found {
			t.Error("Expected an informational check for the consumed error site")
		}
	})
}

// Item 1 companion: a structured (non-log/fmt) logger also consumes the error.
func TestFeedback20260904_SilentSwallow_VoidFuncStructuredLogger_NotFlagged(t *testing.T) {
	code := `
package main

type logger struct{}

func (logger) Error(msg string, kv ...any) {}

func step() error { return nil }

func worker(lg logger) {
	err := step()
	if err != nil {
		lg.Error("worker failed", "err", err)
		return
	}
}
`
	helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
		if v := helperFindViolation(graph, types.ErrorTypeSilentSwallow); v != nil {
			t.Fatalf("structured-logger consumption in void func must not be a violation, got: %q", v.Message)
		}
	})
}

// Item 1 boundary: in an ERROR-returning function, log-and-continue is still a
// CRITICAL swallow — the error could have been propagated instead.
func TestFeedback20260904_SilentSwallow_ErrorReturnFuncLogAndContinue_StillCritical(t *testing.T) {
	code := `
package main

import "log"

func step() error { return nil }

func producer() error {
	for {
		err := step()
		if err != nil {
			log.Printf("skip: %v", err)
			continue
		}
		return nil
	}
}
`
	helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
		v := helperFindViolation(graph, types.ErrorTypeSilentSwallow)
		if v == nil {
			t.Fatal("Expected silent_swallow for log-and-continue in error-returning function")
		}

		if v.Severity != types.SeverityHigh {
			t.Errorf("Log-and-continue with error return available must be CRITICAL; got %s", v.Severity)
		}
	})
}

// Item 1 boundary: in a void function, dropping the error WITHOUT any call
// (bare continue) is still a swallow at WARNING — nothing consumed it.
func TestFeedback20260904_SilentSwallow_VoidFuncBareContinue_StillWarning(t *testing.T) {
	code := `
package main

func step() (int, error) { return 0, nil }

func producer() int {
	count := 0
	for {
		n, err := step()
		if err != nil {
			continue
		}
		count += n
		if count > 10 {
			return count
		}
	}
}
`
	helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
		v := helperFindViolation(graph, types.ErrorTypeSilentSwallow)
		if v == nil {
			t.Fatal("Expected silent_swallow for bare continue with unconsumed error in void function")
		}

		if v.Severity == types.SeverityHigh {
			t.Errorf("Void-function swallow must not be CRITICAL; got %s", v.Severity)
		}

		if !strings.Contains(strings.ToLower(v.Message), "no error return") {
			t.Errorf("Expected downgrade message to mention 'no error return', got: %q", v.Message)
		}
	})
}

// Item 2: the closure form of deferred teardown must not be flagged.
func TestFeedback20260904_Ignored_DeferredClosureClose_Exempt(t *testing.T) {
	code := `
package main

type stream struct{}

func (s *stream) Close() error { return nil }

func run() {
	s := &stream{}
	defer func() { _ = s.Close() }()
}
`
	helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
		if v := helperFindViolation(graph, types.ErrorTypeIgnored); v != nil {
			t.Fatalf("`_ = x.Close()` in deferred closure must not be a violation, got: %q", v.Message)
		}
	})
}

// Item 2 boundary: blank Close OUTSIDE a deferred closure is still flagged.
func TestFeedback20260904_Ignored_PlainBlankClose_StillFlagged(t *testing.T) {
	code := `
package main

import "os"

func run() {
	f, _ := os.Open("data.txt")
	_ = f.Close()
}
`
	helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
		if helperFindViolation(graph, types.ErrorTypeIgnored) == nil {
			t.Fatal("Expected ignored violation for `_ = f.Close()` outside deferred closure")
		}
	})
}

// Item 2 boundary: only Close is exempt — other blank-assigned calls inside
// deferred closures remain flagged.
func TestFeedback20260904_Ignored_DeferredClosureNonClose_StillFlagged(t *testing.T) {
	code := `
package main

func flush() error { return nil }

func run() {
	defer func() { _ = flush() }()
}
`
	helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
		if helperFindViolation(graph, types.ErrorTypeIgnored) == nil {
			t.Fatal("Expected ignored violation for `_ = flush()` inside deferred closure (only Close is exempt)")
		}
	})
}

// Item 2 boundary: the exemption covers Close inside deferred closures only —
// a plain goroutine closure is not deferred and stays flagged.
func TestFeedback20260904_Ignored_GoroutineClosureClose_StillFlagged(t *testing.T) {
	code := `
package main

type stream struct{}

func (s *stream) Close() error { return nil }

func run() {
	s := &stream{}
	go func() { _ = s.Close() }()
}
`
	helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
		if helperFindViolation(graph, types.ErrorTypeIgnored) == nil {
			t.Fatal("Expected ignored violation for `_ = s.Close()` in goroutine closure (not deferred)")
		}
	})
}

// Item 2: --no-suppress bypasses the exemption so all potential violations can
// be audited (consistent with the other AST heuristics).
func TestFeedback20260904_Ignored_DeferredClosureClose_NoSuppressBypasses(t *testing.T) {
	code := `
package main

type stream struct{}

func (s *stream) Close() error { return nil }

func run() {
	s := &stream{}
	defer func() { _ = s.Close() }()
}
`
	_, graph := helperParseAndAnalyzeWithOptions(t, code, WithNoSuppress(true))

	if helperFindViolation(graph, types.ErrorTypeIgnored) == nil {
		t.Fatal("Expected ignored violation with --no-suppress (exemption bypassed for auditing)")
	}
}

// Item 2 edge, pinned 2026-09-22 (TODO_LIST b4): a synchronous callback DEFINED
// inside a deferred closure inherits the exemption — span membership is
// positional, so the callback's body lies within the outer deferred span. That
// is intentional: the enclosing deferred closure cannot return an error, so
// any Close discard in its subtree is teardown by design, and `_ = x.Close()`
// is the only spelling golangci's errcheck also accepts there. See the
// collectDeferredClosureSpans doc comment in analyzer.go.
func TestFeedback20260904_Ignored_DeferredClosureNestedSyncCallback_InheritsExempt(t *testing.T) {
	code := `
package main

type stream struct{}

func (s *stream) Close() error { return nil }

func run() {
	s := &stream{}
	defer func() {
		flush := func() { _ = s.Close() }
		flush()
	}()
}
`
	helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
		if v := helperFindViolation(graph, types.ErrorTypeIgnored); v != nil {
			t.Fatalf("sync callback inside a deferred closure must inherit the Close exemption, got: %q", v.Message)
		}
	})
}

// Item 2 edge, companion pin: a nested defer statement inside a deferred
// closure is collected as its own span (ast.Inspect visits the whole subtree),
// so its Close discard is exempt for the same reason as the outer one.
func TestFeedback20260904_Ignored_NestedDeferredInsideDeferredClose_Exempt(t *testing.T) {
	code := `
package main

type stream struct{}

func (s *stream) Close() error { return nil }

func run() {
	s := &stream{}
	defer func() {
		defer func() { _ = s.Close() }()
	}()
}
`
	helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
		if v := helperFindViolation(graph, types.ErrorTypeIgnored); v != nil {
			t.Fatalf("nested deferred Close inside a deferred closure must be exempt, got: %q", v.Message)
		}
	})
}
