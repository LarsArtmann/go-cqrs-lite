package ast

import (
	"github.com/larsartmann/erraudit/pkg/types"
)

// Compile-time interface assertions to ensure implementations satisfy their interfaces.
var (
	_ types.ViolationDetector    = (*ViolationDetector)(nil)
	_ types.NamedErrorDiscoverer = (*NamedErrorDiscoverer)(nil)
	_ types.RelationshipTracker  = (*RelationshipTracker)(nil)
	_ types.Analyzer             = (*Analyzer)(nil)
	_ types.HierarchyBuilder     = (*HierarchyBuilder)(nil)
	_ types.MetricsCalculator    = (*MetricsCalculator)(nil)
)
