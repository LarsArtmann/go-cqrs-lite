package ast

import (
	"go/parser"
	"go/token"
	"strings"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
)

// Tests for inline error-usage tracking: function-body wrap sites
// (fmt.Errorf %w, errors.Join) and errors.Is check sites that reference
// named errors, including forward references and cross-package selectors.

func TestUsageTrackIdentWrapSite(t *testing.T) {
	code := `package main

import (
	"errors"
	"fmt"
)

func wrap() error {
	return fmt.Errorf("ctx: %w", ErrThing)
}

var ErrThing = errors.New("thing")
`
	_, graph := helperParseAndAnalyze(t, code)

	if got := graph.Hierarchy.Metrics.InlineWrapSites; got != 1 {
		t.Errorf("InlineWrapSites = %d, want 1", got)
	}

	if got := graph.Hierarchy.Metrics.WrapSitesByError["ErrThing"]; got != 1 {
		t.Errorf("WrapSitesByError[ErrThing] = %d, want 1 (forward reference must resolve)", got)
	}
}

func TestUsageTrackRuntimeOperandNotAttributed(t *testing.T) {
	code := `package main

import (
	"errors"
	"fmt"
)

var ErrThing = errors.New("thing")

func wrap(err error) error {
	return fmt.Errorf("ctx: %w", err)
}
`
	_, graph := helperParseAndAnalyze(t, code)

	if got := graph.Hierarchy.Metrics.InlineWrapSites; got != 1 {
		t.Errorf("InlineWrapSites = %d, want 1 (site counts regardless of operand)", got)
	}

	if got := len(graph.Hierarchy.Metrics.WrapSitesByError); got != 0 {
		t.Errorf("WrapSitesByError = %d entries, want 0 (runtime operand must not be attributed)", got)
	}
}

func TestUsageTrackSelectorWrapAndCheck(t *testing.T) {
	code := `package server

import (
	"errors"
	"fmt"

	"example.com/store"
)

func handle(err error) error {
	if errors.Is(err, store.ErrNotFound) {
		return fmt.Errorf("load: %w", store.ErrNotFound)
	}

	return nil
}
`
	_, graph := helperParseAndAnalyze(t, code)

	if got := graph.Hierarchy.Metrics.SelectorCheckSites["store.ErrNotFound"]; got != 1 {
		t.Errorf("SelectorCheckSites[store.ErrNotFound] = %d, want 1", got)
	}

	if got := graph.Hierarchy.Metrics.SelectorWrapSites["store.ErrNotFound"]; got != 1 {
		t.Errorf("SelectorWrapSites[store.ErrNotFound] = %d, want 1", got)
	}
}

func TestUsageTrackIdentCheck(t *testing.T) {
	code := `package main

import (
	"errors"
	"fmt"
)

var ErrThing = errors.New("thing")

func isThing(err error) bool {
	return errors.Is(err, ErrThing)
}

var _ = fmt.Sprintf
`
	_, graph := helperParseAndAnalyze(t, code)

	if got := graph.Hierarchy.Metrics.CheckSitesByError["ErrThing"]; got != 1 {
		t.Errorf("CheckSitesByError[ErrThing] = %d, want 1", got)
	}
}

func TestUsagePackageLevelWrapNotInline(t *testing.T) {
	code := `package main

import (
	"errors"
	"fmt"
)

var ErrBase = errors.New("base")

var ErrWrapped = fmt.Errorf("ctx: %w", ErrBase)
`
	_, graph := helperParseAndAnalyze(t, code)

	if got := graph.Hierarchy.Metrics.InlineWrapSites; got != 0 {
		t.Errorf(
			"InlineWrapSites = %d, want 0 (package-level decls are hierarchy relationships, not inline sites)",
			got,
		)
	}

	if got := graph.Hierarchy.Metrics.TotalRelationships; got != 1 {
		t.Errorf("TotalRelationships = %d, want 1", got)
	}
}

func TestUsageNonErrorfCallsIgnored(t *testing.T) {
	code := `package main

import (
	"errors"
	"fmt"
)

var ErrThing = errors.New("thing")

func f() {
	fmt.Println("no %w here")
	_ = errors.New("unused")
}
`
	_, graph := helperParseAndAnalyze(t, code)

	if got := graph.Hierarchy.Metrics.InlineWrapSites; got != 0 {
		t.Errorf("InlineWrapSites = %d, want 0", got)
	}

	if got := len(graph.Hierarchy.Metrics.CheckSitesByError); got != 0 {
		t.Errorf("CheckSitesByError = %d entries, want 0", got)
	}
}

func TestUsageTrackFamilyWrapConstructor(t *testing.T) {
	code := `package main

import (
	"errors"

	errorfamily "github.com/larsartmann/go-error-family"
)

var ErrInput = errors.New("input")

func reject() error {
	return errorfamily.WrapRejection(ErrInput, "value.invalid", "bad value")
}
`
	_, graph := helperParseAndAnalyze(t, code)

	if got := graph.Hierarchy.Metrics.InlineWrapSites; got != 1 {
		t.Errorf("InlineWrapSites = %d, want 1 (errorfamily.Wrap* is a wrap site)", got)
	}

	if got := graph.Hierarchy.Metrics.WrapSitesByError["ErrInput"]; got != 1 {
		t.Errorf("WrapSitesByError[ErrInput] = %d, want 1 (first argument is the wrapped cause)", got)
	}
}

func TestUsageTrackOopsWrapRuntimeOperand(t *testing.T) {
	code := `package main

import (
	"errors"

	"github.com/samber/oops"
)

var ErrThing = errors.New("thing")

func wrap(err error) error {
	return oops.Wrapf(err, "ctx for %s", "thing")
}
`
	_, graph := helperParseAndAnalyze(t, code)

	if got := graph.Hierarchy.Metrics.InlineWrapSites; got != 1 {
		t.Errorf("InlineWrapSites = %d, want 1 (oops.Wrapf is a wrap site)", got)
	}

	if got := len(graph.Hierarchy.Metrics.WrapSitesByError); got != 0 {
		t.Errorf("WrapSitesByError = %d entries, want 0 (runtime operand must not be attributed)", got)
	}
}

func TestUsageTrackOopsWrapSelectorOperand(t *testing.T) {
	code := `package server

import (
	"errors"

	"github.com/samber/oops"

	"example.com/store"
)

func wrap(err error) error {
	return oops.Wrap(store.ErrNotFound, "load failed")
}

var _ = errors.New
`
	_, graph := helperParseAndAnalyze(t, code)

	if got := graph.Hierarchy.Metrics.InlineWrapSites; got != 1 {
		t.Errorf("InlineWrapSites = %d, want 1", got)
	}

	if got := graph.Hierarchy.Metrics.SelectorWrapSites["store.ErrNotFound"]; got != 1 {
		t.Errorf("SelectorWrapSites[store.ErrNotFound] = %d, want 1", got)
	}
}

func TestUsagePackageLevelFamilyWrapNotInline(t *testing.T) {
	code := `package main

import (
	"errors"

	errorfamily "github.com/larsartmann/go-error-family"
)

var ErrInput = errors.New("input")

var ErrValueInvalid error = errorfamily.WrapRejection(ErrInput, "value.invalid", "invalid value")
`
	_, graph := helperParseAndAnalyze(t, code)

	if got := graph.Hierarchy.Metrics.InlineWrapSites; got != 0 {
		t.Errorf(
			"InlineWrapSites = %d, want 0 (package-level decls are hierarchy relationships, not inline sites)",
			got,
		)
	}
}

func TestUsageTrackAsCheck(t *testing.T) {
	code := `package main

import (
	"errors"
	"fmt"
)

type MyError struct{ code string }

func (e *MyError) Error() string { return e.code }

func asThing(err error) bool {
	var target *MyError

	return errors.As(err, &target)
}

var _ = fmt.Sprintf
`
	_, graph := helperParseAndAnalyze(t, code)

	if got := graph.Hierarchy.Metrics.TypeCheckSites; got != 1 {
		t.Errorf("TypeCheckSites = %d, want 1", got)
	}
}

func TestCollectErrorDecls(t *testing.T) {
	code := `package main

import (
	"errors"
	"fmt"
	"time"
)

var (
	ErrA = errors.New("a")
	ErrB = fmt.Errorf("b")
	ErrC = errors.Join(ErrA, ErrB)
	NotAnError = time.Now
	bare      = 42
)

const ErrConst = "constant-string-not-error"
`
	fset := token.NewFileSet()
	node, err := parser.ParseFile(fset, "", code, parser.AllErrors)
	if err != nil {
		t.Fatalf("parse: %v", err)
	}

	names := collectErrorDecls(node)

	for _, want := range []string{"ErrA", "ErrB", "ErrC"} {
		if !names[want] {
			t.Errorf("collectErrorDecls missing %q; got %v", want, names)
		}
	}

	for _, unwanted := range []string{"NotAnError", "bare", "ErrConst"} {
		if names[unwanted] {
			t.Errorf("collectErrorDecls must not include %q", unwanted)
		}
	}
}

func TestPackageErrorDeclsOptionEnablesCrossFileReference(t *testing.T) {
	// The current file references ErrFromOtherFile; the declaration lives in
	// a sibling file, provided via WithPackageErrorDecls (package mode).
	code := `package main

import (
	"errors"
	"fmt"
)

func wrap() error {
	return fmt.Errorf("ctx: %w", ErrFromOtherFile)
}
`
	_, graph := helperParseAndAnalyzeWithOptions(t, code, WithPackageErrorDecls(map[string]bool{
		"ErrFromOtherFile": true,
	}))

	if got := graph.Hierarchy.Metrics.WrapSitesByError["ErrFromOtherFile"]; got != 1 {
		t.Errorf(
			"WrapSitesByError[ErrFromOtherFile] = %d, want 1 (package decl set must resolve cross-file reference)",
			got,
		)
	}
}

func TestResolveSelectorReferences(t *testing.T) {
	h := &types.ErrorHierarchy{
		AllNodes: map[string]*types.ErrorNode{
			"ErrNotFound": {Name: "ErrNotFound"},
		},
		NamedErrors: []types.NamedError{
			{Name: "ErrNotFound", Position: token.Position{Filename: "/proj/internal/store/store.go"}},
		},
		Metrics: types.HierarchyMetrics{
			SelectorCheckSites: map[string]uint{
				"store.ErrNotFound": 2,
				"sql.ErrNoRows":     5,
			},
			SelectorWrapSites: map[string]uint{
				"store.ErrNotFound": 1,
			},
			CheckSitesByError: map[string]uint{},
			WrapSitesByError:  map[string]uint{},
		},
	}

	FinalizeHierarchy(h)

	if got := h.Metrics.CheckSitesByError["ErrNotFound"]; got != 2 {
		t.Errorf("CheckSitesByError[ErrNotFound] = %d, want 2 (selector resolved)", got)
	}

	if got := h.Metrics.WrapSitesByError["ErrNotFound"]; got != 1 {
		t.Errorf("WrapSitesByError[ErrNotFound] = %d, want 1 (selector resolved)", got)
	}

	if _, exists := h.Metrics.CheckSitesByError["ErrNoRows"]; exists {
		t.Error("unknown qualified reference (sql.ErrNoRows) must stay unattributed")
	}

	if h.Metrics.SelectorCheckSites != nil || h.Metrics.SelectorWrapSites != nil {
		t.Error("transient selector maps must be consumed by resolution")
	}

	if got := h.AllNodes["ErrNotFound"].Checks; got != 2 {
		t.Errorf("node Checks = %d, want 2 (copied onto node)", got)
	}
}

func TestResolveSelectorReferencesAmbiguousDropped(t *testing.T) {
	h := &types.ErrorHierarchy{
		AllNodes: map[string]*types.ErrorNode{
			"ErrX": {Name: "ErrX"},
		},
		NamedErrors: []types.NamedError{
			{Name: "ErrX", Position: token.Position{Filename: "/proj/a/util/util.go"}},
			{Name: "ErrX", Position: token.Position{Filename: "/proj/b/util/util.go"}},
		},
		Metrics: types.HierarchyMetrics{
			SelectorCheckSites: map[string]uint{"util.ErrX": 3},
			CheckSitesByError:  map[string]uint{},
		},
	}

	FinalizeHierarchy(h)

	if got := h.Metrics.CheckSitesByError["ErrX"]; got != 0 {
		t.Errorf("CheckSitesByError[ErrX] = %d, want 0 (ambiguous package dir must not resolve)", got)
	}
}

func TestUsageTrackSiteRefsRecordPositionAndFunction(t *testing.T) {
	code := `package main

import (
	"errors"
	"fmt"
)

var ErrThing = errors.New("thing")

func wrapIt() error {
	return fmt.Errorf("ctx: %w", ErrThing)
}

func checkIt(err error) bool {
	return errors.Is(err, ErrThing)
}
`
	_, graph := helperParseAndAnalyze(t, code)

	metrics := graph.Hierarchy.Metrics

	wrapRefs := metrics.WrapSiteRefs["ErrThing"]
	if len(wrapRefs) != 1 {
		t.Fatalf("len(WrapSiteRefs[ErrThing]) = %d, want 1", len(wrapRefs))
	}

	if got := metrics.WrapSitesByError["ErrThing"]; got != uint(len(wrapRefs)) {
		t.Errorf("WrapSitesByError = %d, refs = %d (counts and site refs must agree)", got, len(wrapRefs))
	}

	if wrapRefs[0].Function != "wrapIt" {
		t.Errorf("wrap site Function = %q, want %q", wrapRefs[0].Function, "wrapIt")
	}

	if line := codeLineContaining(code, "%w"); wrapRefs[0].Position.Line != line {
		t.Errorf("wrap site line = %d, want %d", wrapRefs[0].Position.Line, line)
	}

	checkRefs := metrics.CheckSiteRefs["ErrThing"]
	if len(checkRefs) != 1 {
		t.Fatalf("len(CheckSiteRefs[ErrThing]) = %d, want 1", len(checkRefs))
	}

	if checkRefs[0].Function != "checkIt" {
		t.Errorf("check site Function = %q, want %q", checkRefs[0].Function, "checkIt")
	}

	if line := codeLineContaining(code, "errors.Is"); checkRefs[0].Position.Line != line {
		t.Errorf("check site line = %d, want %d", checkRefs[0].Position.Line, line)
	}
}

func TestUsageTrackJoinSiteRef(t *testing.T) {
	code := `package main

import (
	"errors"
)

var ErrA = errors.New("a")

func joinIt() error {
	return errors.Join(ErrA)
}
`
	_, graph := helperParseAndAnalyze(t, code)

	refs := graph.Hierarchy.Metrics.WrapSiteRefs["ErrA"]
	if len(refs) != 1 {
		t.Fatalf("len(WrapSiteRefs[ErrA]) = %d, want 1", len(refs))
	}

	if refs[0].Function != "joinIt" {
		t.Errorf("join site Function = %q, want %q", refs[0].Function, "joinIt")
	}
}

func TestUsageTrackSelectorSiteRefsResolveInFinalizer(t *testing.T) {
	code := `package server

import (
	"errors"
	"fmt"
)

func wrapStore() error {
	return fmt.Errorf("store: %w", store.ErrNotFound)
}
`
	_, graph := helperParseAndAnalyze(t, code)

	metrics := graph.Hierarchy.Metrics

	if len(metrics.SelectorWrapSiteRefs["store.ErrNotFound"]) != 1 {
		t.Fatalf("selector wrap site ref not recorded for store.ErrNotFound")
	}

	h := graph.Hierarchy
	h.NamedErrors = append(h.NamedErrors, types.NamedError{
		Name:     "ErrNotFound",
		Position: token.Position{Filename: "/project/store/errors.go"},
	})
	h.AllNodes = map[string]*types.ErrorNode{
		"ErrNotFound": {Name: "ErrNotFound"},
	}

	FinalizeHierarchy(h)

	refs := h.Metrics.WrapSiteRefs["ErrNotFound"]
	if len(refs) != 1 {
		t.Fatalf("len(WrapSiteRefs[ErrNotFound]) after finalize = %d, want 1 (selector ref must resolve)", len(refs))
	}

	if h.Metrics.SelectorWrapSiteRefs != nil {
		t.Errorf("SelectorWrapSiteRefs must be cleared after finalize")
	}
}

// codeLineContaining returns the 1-based line number of the first line of
// code containing substr.
func codeLineContaining(code, substr string) int {
	for i, line := range strings.Split(code, "\n") {
		if strings.Contains(line, substr) {
			return i + 1
		}
	}

	return -1
}
