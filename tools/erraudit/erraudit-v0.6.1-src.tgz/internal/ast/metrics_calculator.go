package ast

import (
	"github.com/larsartmann/erraudit/pkg/types"
)

// MetricsCalculator calculates error metrics from analysis results.
type MetricsCalculator struct {
	errors     []types.ErrorInfo
	violations []types.ErrorViolation
	wrapDepth  uint
}

// NewMetricsCalculator creates a new metrics calculator.
func NewMetricsCalculator(
	errors []types.ErrorInfo,
	violations []types.ErrorViolation,
	wrapDepth uint,
) *MetricsCalculator {
	return &MetricsCalculator{
		errors:     errors,
		violations: violations,
		wrapDepth:  wrapDepth,
	}
}

// Calculate computes the error metrics.
func (mc *MetricsCalculator) Calculate() types.ErrorMetrics {
	metrics := types.ErrorMetrics{
		MostCommonErrors: make(map[string]uint),
		WrapDepth:        mc.wrapDepth,
	}

	for _, err := range mc.errors {
		mc.countErrorType(&metrics, err)
		metrics.MostCommonErrors[err.Message]++
	}

	for _, violation := range mc.violations {
		mc.countViolationType(&metrics, violation)
	}

	return metrics
}

// countErrorType updates metrics counters for an error info entry.
func (mc *MetricsCalculator) countErrorType(metrics *types.ErrorMetrics, err types.ErrorInfo) {
	metrics.TotalErrors++

	switch err.Type {
	case types.ErrorTypeReturn:
		metrics.ErrorReturns++
	case types.ErrorTypeWrapping:
		metrics.ErrorWraps++
	case types.ErrorTypeAssignment, types.ErrorTypeUnwrapped, types.ErrorTypeCheck,
		types.ErrorTypePropagation, types.ErrorTypePanic, types.ErrorTypeSilentSwallow,
		types.ErrorTypeIgnored, types.ErrorTypeGenericReturn,
		types.ErrorTypeLegacyAs, types.ErrorTypeLegacyIs,
		types.ErrorTypeContextLoss, types.ErrorTypeStdlibConstructor, types.ErrorTypeOopsRedundantGuard,
		types.ErrorTypeOopsMisusedW,
		types.ErrorTypeDeferredCloseIgnored, types.ErrorTypeSentinelConcreteType,
		types.ErrorTypeUncodedConstructor:
		// No specific metric for these types
	}
}

// countViolationType updates metrics counters for a violation entry.
func (mc *MetricsCalculator) countViolationType(metrics *types.ErrorMetrics, violation types.ErrorViolation) {
	switch violation.Type {
	case types.ErrorTypePanic:
		metrics.PanicsOnErrors++
	case types.ErrorTypeSilentSwallow:
		metrics.SilentSwallows++
	case types.ErrorTypeIgnored:
		metrics.IgnoredErrors++
	case types.ErrorTypeReturn, types.ErrorTypeAssignment, types.ErrorTypeWrapping,
		types.ErrorTypeUnwrapped, types.ErrorTypeCheck, types.ErrorTypePropagation,
		types.ErrorTypeGenericReturn, types.ErrorTypeLegacyAs, types.ErrorTypeLegacyIs,
		types.ErrorTypeContextLoss, types.ErrorTypeStdlibConstructor, types.ErrorTypeOopsRedundantGuard,
		types.ErrorTypeOopsMisusedW,
		types.ErrorTypeDeferredCloseIgnored, types.ErrorTypeSentinelConcreteType,
		types.ErrorTypeUncodedConstructor:
		// No specific metric for these types
	}
}
