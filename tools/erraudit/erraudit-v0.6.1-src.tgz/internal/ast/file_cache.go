package ast

import (
	"os"
	"strings"
	"sync"

	"github.com/larsartmann/erraudit/internal/cache"
	apierrors "github.com/larsartmann/erraudit/pkg/errors"
)

const (
	DefaultMaxCachedFiles    = 1000
	DefaultMaxCacheSizeBytes = 50 * 1024 * 1024
)

type fileCacheEntry struct {
	lines []string
	size  int64
}

// FileCache caches file contents to avoid repeated disk reads.
type FileCache struct {
	cache.Base[fileCacheEntry]

	mu       sync.Mutex
	maxFiles int
	maxSize  int64
}

// FileCacheOption is a functional option for configuring the FileCache.
type FileCacheOption func(*FileCache)

// WithMaxFiles sets the maximum number of files to cache.
func WithMaxFiles(maxCount int) FileCacheOption {
	return func(fc *FileCache) {
		fc.maxFiles = maxCount
	}
}

// WithMaxSize sets the maximum total cache size in bytes.
func WithMaxSize(maxCacheSize int64) FileCacheOption {
	return func(fc *FileCache) {
		fc.maxSize = maxCacheSize
	}
}

// NewFileCache creates a new file cache with default limits.
func NewFileCache(opts ...FileCacheOption) *FileCache {
	fc := &FileCache{
		maxFiles: DefaultMaxCachedFiles,
		maxSize:  DefaultMaxCacheSizeBytes,
	}

	//art-dupl:accept standard Go functional-options idiom — 3-line loop, unrelated packages, different option types
	for _, opt := range opts {
		opt(fc)
	}

	fc.InitWithSizeTracking(fc.maxFiles, func(e fileCacheEntry) int64 { return e.size })

	return fc
}

// Get returns cached file lines for the given filename.
func (fc *FileCache) Get(filename string) ([]string, bool) {
	entry, ok := fc.Store().GetIfPresent(filename)
	if !ok {
		return nil, false
	}

	return entry.lines, true
}

// Load reads and caches a file's contents.
func (fc *FileCache) Load(filename string) ([]string, error) {
	fc.mu.Lock()
	defer fc.mu.Unlock()

	if entry, ok := fc.Store().GetIfPresent(filename); ok {
		return entry.lines, nil
	}

	source, err := os.ReadFile(filename)
	if err != nil {
		return nil, apierrors.Wrap(err, "failed to read file %s from cache", filename)
	}

	size := int64(len(source))
	lines := strings.Split(string(source), "\n")

	if size <= fc.maxSize && fc.TotalSize()+size <= fc.maxSize {
		fc.Store().Set(filename, fileCacheEntry{lines: lines, size: size})
		fc.AddSize(size)
	}

	fc.Store().CleanUp()

	return lines, nil
}

// Clear removes all cached entries.
func (fc *FileCache) Clear() {
	fc.Base.Clear()
}

// Has checks if a file is cached.
func (fc *FileCache) Has(filename string) bool {
	_, ok := fc.Store().GetIfPresent(filename)

	return ok
}

// Stats returns cache statistics.
func (fc *FileCache) Stats() FileCacheStats {
	base := fc.Base.Stats()

	return FileCacheStats{
		BaseStats:        base,
		MaxFiles:         fc.maxFiles,
		MaxSize:          fc.maxSize,
		UtilizationSize:  float64(base.TotalSize) / float64(fc.maxSize),
		UtilizationFiles: float64(base.KeyCount) / float64(fc.maxFiles),
	}
}

// FileCacheStats contains cache statistics.
type FileCacheStats struct {
	cache.BaseStats

	MaxFiles         int
	MaxSize          int64
	UtilizationSize  float64
	UtilizationFiles float64
}
