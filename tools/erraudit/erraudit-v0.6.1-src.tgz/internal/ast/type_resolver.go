package ast

import (
	"go/ast"
	"go/types"
	"strings"
)

// TypeResolver answers type queries against a go/types.Info snapshot.
// When available, it enables type-aware violation detection (e.g., distinguishing
// an ignored error return from an ignored non-error return).
// When nil or missing type info, callers should fall back to heuristic detection.
type TypeResolver struct {
	info *types.Info
	pkg  *types.Package
}

// NewTypeResolver creates a TypeResolver from go/types info.
// Both parameters must be non-nil for type resolution to work.
func NewTypeResolver(info *types.Info, pkg *types.Package) *TypeResolver {
	return &TypeResolver{info: info, pkg: pkg}
}

// Available returns true if type info is present and usable.
func (r *TypeResolver) Available() bool {
	return r != nil && r.info != nil && r.pkg != nil
}

// ReturnTypeIsError checks whether the return value at position resultIndex
// of the given call expression implements the error interface.
// Returns false if type info is unavailable (caller should fall back to heuristic).
func (r *TypeResolver) ReturnTypeIsError(call *ast.CallExpr, resultIndex int) bool {
	if !r.Available() {
		return false
	}

	tv, ok := r.info.Types[call]
	if !ok {
		return false
	}

	resultType := tv.Type

	// For multi-return functions, the type is a *types.Tuple.
	if tuple, ok := resultType.(*types.Tuple); ok {
		if resultIndex < tuple.Len() {
			resultType = tuple.At(resultIndex).Type()
		} else {
			return false
		}
	}

	return implementsError(resultType)
}

// implementsError checks whether a type satisfies the error interface
// (has method Error() string).
func implementsError(t types.Type) bool {
	errorInterface, ok := types.Universe.Lookup("error").Type().Underlying().(*types.Interface)
	if !ok {
		return false
	}

	return types.Implements(t, errorInterface)
}

// ErrorTypeStatus describes whether a type-checker resolved an expression's
// type and whether that type implements the error interface. The tri-state
// distinguishes "resolved and rejected" from "couldn't resolve" so callers
// can decide whether to fall back to a heuristic.
type ErrorTypeStatus int

const (
	// ErrorTypeUnresolved means the type checker has no type info for the
	// expression (e.g., cross-package type from an unresolved import, or
	// type-checking errors). Callers should fall back to heuristic detection.
	ErrorTypeUnresolved ErrorTypeStatus = iota
	// ErrorTypeImplements means the type is resolved and implements error.
	ErrorTypeImplements
	// ErrorTypeDoesNotImplement means the type is resolved but does NOT
	// implement error.
	ErrorTypeDoesNotImplement
)

// ExprTypeErrorStatus returns the resolved status of an expression's type
// with respect to the error interface. Returns ErrorTypeUnresolved when
// type info is unavailable or the expression's type couldn't be resolved.
func (r *TypeResolver) ExprTypeErrorStatus(expr ast.Expr) ErrorTypeStatus {
	if !r.Available() {
		return ErrorTypeUnresolved
	}

	tv, ok := r.info.Types[expr]
	if !ok {
		return ErrorTypeUnresolved
	}

	if implementsError(tv.Type) {
		return ErrorTypeImplements
	}

	return ErrorTypeDoesNotImplement
}

// ExprImplementsError checks whether the type of the given expression
// implements the error interface. Returns false when type info is unavailable
// or the expression has no recorded type. Used by NamedErrorDiscoverer to
// verify naming-heuristic matches against actual type information.
func (r *TypeResolver) ExprImplementsError(expr ast.Expr) bool {
	return r.ExprTypeErrorStatus(expr) == ErrorTypeImplements
}

// NamedErrorTypeName returns the type name of expr when its resolved type is a
// named type that implements the error interface. Pointer types are unwrapped
// (*MyError → MyError). Returns "" when type info is unavailable, the
// expression has no resolved type, the underlying type is not named, or it does
// not implement error.
//
// Unlike the AST-based name extraction in extractCustomErrorTypeName (which
// only handles bare identifiers and struct literals), this works for ANY
// expression shape — including selector expressions (pkg.MyError{}) and
// constructor calls (pkg.NewValidationError()) — because it reads the resolved
// go/types.Type directly.
func (r *TypeResolver) NamedErrorTypeName(expr ast.Expr) string {
	if !r.Available() {
		return ""
	}

	tv, ok := r.info.Types[expr]
	if !ok {
		return ""
	}

	return namedErrorTypeName(tv.Type)
}

// namedErrorTypeName extracts a readable type name from a go/types.Type when
// the type (or its pointer element) implements the error interface. The actual
// type is checked first so that pointer-receiver methods are honored: if
// (*MyError).Error() exists but MyError has no value receiver, only *MyError
// satisfies error. The pointer is then unwrapped to return the bare name
// ("MyError") for display consistency.
//
// Predeclared types (notably the built-in error interface) are excluded —
// they have no package and are not custom error types.
func namedErrorTypeName(t types.Type) string {
	if !implementsError(t) {
		return ""
	}

	named, ok := derefNamed(t)
	if !ok {
		return ""
	}

	// Exclude predeclared types (error, comparable, etc.) which have no
	// package — they are not user-defined custom error types.
	if named.Obj().Pkg() == nil {
		return ""
	}

	return named.Obj().Name()
}

// derefNamed unwraps a single layer of pointer indirection and asserts the
// result is a named type. Returns the named type and true on success; nil and
// false otherwise. Centralizes the pointer-unwrap + named-type-check pattern
// used by namedErrorTypeName and IsInfrastructureType.
func derefNamed(t types.Type) (*types.Named, bool) {
	if ptr, ok := t.(*types.Pointer); ok {
		t = ptr.Elem()
	}

	named, ok := t.(*types.Named)

	return named, ok
}

// IdentType returns the resolved go/types.Type for an identifier's declaration,
// or nil if type info is unavailable or the identifier has no recorded
// definition. Used by the context-loss detector for type-based infrastructure
// rejection.
func (r *TypeResolver) IdentType(ident *ast.Ident) types.Type {
	if !r.Available() || ident == nil {
		return nil
	}

	if obj, ok := r.info.Defs[ident]; ok && obj != nil {
		return obj.Type()
	}

	return nil
}

// IsInfrastructureType reports whether t is a known infrastructure type that
// should never be flagged as business context. Checks the type's package path
// and name against known infrastructure packages (context, io, sync, etc.).
// Also checks the type name against infrastructure suffixes (*Store, *Repository,
// *Client, etc.) regardless of package — these are common patterns in
// third-party libraries. Pointers are unwrapped before checking.
func IsInfrastructureType(t types.Type) bool {
	if t == nil {
		return false
	}

	named, ok := derefNamed(t)
	if !ok {
		return false
	}

	obj := named.Obj()
	if obj == nil || obj.Pkg() == nil {
		return false
	}

	if isInfrastructurePkgType(obj.Pkg().Path(), obj.Name()) {
		return true
	}

	return isInfrastructureTypeName(obj.Name())
}

// infrastructureTypeSuffixes lists type-name suffixes that indicate an
// infrastructure type from any package. These are common Go naming patterns
// for infrastructure components (data stores, network clients, concurrency
// primitives) that should never be flagged as business context.
//
//nolint:gochecknoglobals // immutable lookup list
var infrastructureTypeSuffixes = []string{
	"Store", "Repository", "Repo",
	"Client", "Server",
	"Manager", "Handler", "Dispatcher",
	"Publisher", "Subscriber", "Consumer", "Producer",
	"Pool", "Queue",
	"Cache", "Locker",
	"Factory", "Builder",
}

// isInfrastructureTypeName reports whether a type name matches an
// infrastructure pattern suffix, regardless of package. This catches
// third-party infrastructure types that don't come from stdlib packages.
func isInfrastructureTypeName(typeName string) bool {
	for _, suffix := range infrastructureTypeSuffixes {
		if strings.HasSuffix(typeName, suffix) {
			return true
		}
	}

	return false
}

// isInfrastructurePkgType classifies a type by its package path and name.
func isInfrastructurePkgType(pkgPath, typeName string) bool {
	switch pkgPath {
	case "context":
		return typeName == "Context" || typeName == "CancelFunc"
	case "io":
		return strings.HasSuffix(typeName, "Reader") ||
			strings.HasSuffix(typeName, "Writer") ||
			strings.HasSuffix(typeName, "Closer") ||
			strings.HasSuffix(typeName, "Seeker")
	case "sync", "sync/atomic":
		return true
	case "log", "log/slog":
		return true
	case "database/sql":
		return true
	case "net/http":
		switch typeName {
		case "Request", "ResponseWriter", "Header", "Client", "Server",
			"Handler", "ServeMux", "Cookie":
			return true
		}
	case "fmt":
		return typeName == "Stringer"
	case "encoding/json", "encoding/xml", "encoding/gob":
		return strings.HasSuffix(typeName, "Encoder") ||
			strings.HasSuffix(typeName, "Decoder")
	case "go/ast", "go/token", "go/types", "go/parser", "go/format":
		return true
	case "os":
		switch typeName {
		case "File", "FileInfo", "DirEntry":
			return true
		}
	}

	return false
}

// ExprImplementsCloser checks whether the type of the given expression
// implements io.Closer (has a Close() error method). Returns an
// ErrorTypeStatus so callers can distinguish "resolved and confirmed"
// from "couldn't resolve" and fall back to heuristics accordingly.
func (r *TypeResolver) ExprImplementsCloser(expr ast.Expr) ErrorTypeStatus {
	if !r.Available() {
		return ErrorTypeUnresolved
	}

	t := r.exprType(expr)
	if t == nil {
		return ErrorTypeUnresolved
	}

	if typeHasCloseError(t) {
		return ErrorTypeImplements
	}

	return ErrorTypeDoesNotImplement
}

// exprType resolves the go/types.Type for an expression, checking the
// Types, Uses, and Defs maps for maximum coverage across expression shapes.
func (r *TypeResolver) exprType(expr ast.Expr) types.Type {
	if tv, ok := r.info.Types[expr]; ok {
		return tv.Type
	}

	if ident, ok := expr.(*ast.Ident); ok {
		if obj, ok := r.info.Uses[ident]; ok && obj != nil {
			return obj.Type()
		}

		if obj, ok := r.info.Defs[ident]; ok && obj != nil {
			return obj.Type()
		}
	}

	return nil
}

// typeHasCloseError checks whether the type (or its pointer type) has a
// Close() method that returns error, matching the io.Closer interface.
// Both value and pointer method sets are checked because Go allows calling
// pointer-receiver methods on addressable values.
func typeHasCloseError(t types.Type) bool {
	if hasCloseMethod(t) {
		return true
	}

	if _, isPtr := t.(*types.Pointer); !isPtr {
		return hasCloseMethod(types.NewPointer(t))
	}

	return false
}

// hasCloseMethod checks whether the type's method set contains a Close()
// method returning exactly one value of type error.
func hasCloseMethod(t types.Type) bool {
	ms := types.NewMethodSet(t)
	if ms == nil {
		return false
	}

	sel := ms.Lookup(nil, "Close")
	if sel == nil {
		return false
	}

	fn, ok := sel.Type().(*types.Signature)
	if !ok || fn.Results().Len() != 1 {
		return false
	}

	return implementsError(fn.Results().At(0).Type())
}
