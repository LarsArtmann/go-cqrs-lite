package ast

import (
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
)

// findNamedError returns a pointer to the NamedError with the given name, or
// nil when not found. Shared by errorfamily discovery tests.
func findNamedError(t *testing.T, a *Analyzer, name string) *types.NamedError {
	t.Helper()

	for i := range a.namedErrors {
		if a.namedErrors[i].Name == name {
			return &a.namedErrors[i]
		}
	}

	t.Fatalf("named error %q not found among %d errors", name, len(a.namedErrors))

	return nil
}

// TestErrorFamily_GenericNew verifies that errorfamily.New is discovered as a
// standalone named error with Kind=ErrorKindFamilyNew and the message extracted
// from the correct argument position (index 2 for the generic constructor).
func TestErrorFamily_GenericNew(t *testing.T) {
	code := `package main

import "github.com/larsartmann/go-error-family"

var ErrGeneric = errorfamily.New(errorfamily.Rejection, "REJ_001", "input rejected")
`
	a, _ := helperParseAndAnalyze(t, code)

	err := findNamedError(t, a, "ErrGeneric")
	assert.Equal(t, types.ErrorKindFamilyNew, err.Kind, "generic New must be classified as FamilyNew")
	assert.Equal(t, "input rejected", err.Message, "message must be extracted from args[2]")
}

// TestErrorFamily_GenericNewf verifies that errorfamily.Newf works identically
// to New (message format string at the same index).
func TestErrorFamily_GenericNewf(t *testing.T) {
	code := `package main

import "github.com/larsartmann/go-error-family"

var ErrFmt = errorfamily.Newf(errorfamily.Conflict, "CON_001", "conflict on %s", "resource")
`
	a, _ := helperParseAndAnalyze(t, code)

	err := findNamedError(t, a, "ErrFmt")
	assert.Equal(t, types.ErrorKindFamilyNew, err.Kind)
	assert.Equal(t, "conflict on %s", err.Message)
}

// TestErrorFamily_GenericWrap verifies that errorfamily.Wrap records both the
// named error (Kind=ErrorKindFamilyWrap) and a wraps relationship to the first
// argument (the wrapped cause).
func TestErrorFamily_GenericWrap(t *testing.T) {
	code := `package main

import (
	"errors"
	"github.com/larsartmann/go-error-family"
)

var ErrBase = errors.New("base")
var ErrWrapped = errorfamily.Wrap(ErrBase, errorfamily.Conflict, "CON_002", "wrapped base")
`
	a, _ := helperParseAndAnalyze(t, code)

	err := findNamedError(t, a, "ErrWrapped")
	assert.Equal(t, types.ErrorKindFamilyWrap, err.Kind, "generic Wrap must be classified as FamilyWrap")
	assert.Equal(t, "wrapped base", err.Message, "message must be extracted from args[3]")
	assert.Equal(t, "ErrBase", err.ParentName, "ParentName must be the wrapped cause")

	rels := wrapsRels(t, a)
	assertWrapsChild(t, rels, "ErrWrapped", "ErrBase")
}

// TestErrorFamily_GenericWrapf verifies the formatted variant of Wrap.
func TestErrorFamily_GenericWrapf(t *testing.T) {
	code := `package main

import (
	"errors"
	"github.com/larsartmann/go-error-family"
)

var ErrBase = errors.New("base")
var ErrWrapF = errorfamily.Wrapf(ErrBase, errorfamily.Transient, "TRN_001", "transient: %s", "timeout")
`
	a, _ := helperParseAndAnalyze(t, code)

	err := findNamedError(t, a, "ErrWrapF")
	assert.Equal(t, types.ErrorKindFamilyWrap, err.Kind)
	assert.Equal(t, "ErrBase", err.ParentName)

	assertWrapsChild(t, wrapsRels(t, a), "ErrWrapF", "ErrBase")
}

// TestErrorFamily_WrapOnce verifies that WrapOnce is detected as a wrap variant.
func TestErrorFamily_WrapOnce(t *testing.T) {
	code := `package main

import (
	"errors"
	"github.com/larsartmann/go-error-family"
)

var ErrBase = errors.New("base")
var ErrOnce = errorfamily.WrapOnce(ErrBase, errorfamily.Corruption, "COR_001", "corrupted")
`
	a, _ := helperParseAndAnalyze(t, code)

	err := findNamedError(t, a, "ErrOnce")
	assert.Equal(t, types.ErrorKindFamilyWrap, err.Kind)
	assert.Equal(t, "ErrBase", err.ParentName)
}

// TestErrorFamily_WrapOncef verifies the formatted variant of WrapOnce.
func TestErrorFamily_WrapOncef(t *testing.T) {
	code := `package main

import (
	"errors"
	"github.com/larsartmann/go-error-family"
)

var ErrBase = errors.New("base")
var ErrOnceF = errorfamily.WrapOncef(ErrBase, errorfamily.Infrastructure, "INF_001", "infra: %s", "down")
`
	a, _ := helperParseAndAnalyze(t, code)

	err := findNamedError(t, a, "ErrOnceF")
	assert.Equal(t, types.ErrorKindFamilyWrap, err.Kind)
	assert.Equal(t, "ErrBase", err.ParentName)
}

// TestErrorFamily_FamilySpecificNew verifies that all 6 family-specific New*
// constructors are detected as ErrorKindFamilyNew regardless of package alias.
func TestErrorFamily_FamilySpecificNew(t *testing.T) {
	tests := []struct {
		name     string
		callExpr string
	}{
		{"NewRejection", `errorfamily.NewRejection("REJ_001", "rejected")`},
		{"NewConflict", `errorfamily.NewConflict("CON_001", "conflict")`},
		{"NewTransient", `errorfamily.NewTransient("TRN_001", "transient")`},
		{"NewCorruption", `errorfamily.NewCorruption("COR_001", "corrupted")`},
		{"NewInfrastructure", `errorfamily.NewInfrastructure("INF_001", "infra down")`},
		{"NewOrchestration", `errorfamily.NewOrchestration("ORC_001", "internal bug")`},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			code := `package main

import "github.com/larsartmann/go-error-family"

var ErrTest = ` + tc.callExpr + `
`
			a, _ := helperParseAndAnalyze(t, code)

			err := findNamedError(t, a, "ErrTest")
			assert.Equal(t, types.ErrorKindFamilyNew, err.Kind, "%s must be FamilyNew", tc.name)
		})
	}
}

// TestErrorFamily_FamilySpecificWrap verifies that all 6 family-specific Wrap*
// constructors are detected as ErrorKindFamilyWrap with wraps relationships.
func TestErrorFamily_FamilySpecificWrap(t *testing.T) {
	tests := []struct {
		name     string
		callExpr string
	}{
		{"WrapRejection", `errorfamily.WrapRejection(ErrBase, "REJ_001", "rejected")`},
		{"WrapConflict", `errorfamily.WrapConflict(ErrBase, "CON_001", "conflict")`},
		{"WrapTransient", `errorfamily.WrapTransient(ErrBase, "TRN_001", "transient")`},
		{"WrapCorruption", `errorfamily.WrapCorruption(ErrBase, "COR_001", "corrupted")`},
		{"WrapInfrastructure", `errorfamily.WrapInfrastructure(ErrBase, "INF_001", "infra")`},
		{"WrapOrchestration", `errorfamily.WrapOrchestration(ErrBase, "ORC_001", "internal")`},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			code := `package main

import (
	"errors"
	"github.com/larsartmann/go-error-family"
)

var ErrBase = errors.New("base")
var ErrTest = ` + tc.callExpr + `
`
			a, _ := helperParseAndAnalyze(t, code)

			err := findNamedError(t, a, "ErrTest")
			assert.Equal(t, types.ErrorKindFamilyWrap, err.Kind, "%s must be FamilyWrap", tc.name)
			assert.Equal(t, "ErrBase", err.ParentName, "%s must wrap ErrBase", tc.name)

			assertWrapsChild(t, wrapsRels(t, a), "ErrTest", "ErrBase")
		})
	}
}

// TestErrorFamily_FormattedWrapVariants verifies the Wrap*f formatted variants
// for all 6 families.
func TestErrorFamily_FormattedWrapVariants(t *testing.T) {
	tests := []struct {
		name     string
		callExpr string
	}{
		{"WrapRejectionf", `errorfamily.WrapRejectionf(ErrBase, "REJ_001", "rejected: %s", "input")`},
		{"WrapConflictf", `errorfamily.WrapConflictf(ErrBase, "CON_001", "conflict: %s", "v1")`},
		{"WrapTransientf", `errorfamily.WrapTransientf(ErrBase, "TRN_001", "transient: %s", "timeout")`},
		{"WrapCorruptionf", `errorfamily.WrapCorruptionf(ErrBase, "COR_001", "corrupted: %s", "data")`},
		{"WrapInfrastructuref", `errorfamily.WrapInfrastructuref(ErrBase, "INF_001", "infra: %s", "db")`},
		{"WrapOrchestrationf", `errorfamily.WrapOrchestrationf(ErrBase, "ORC_001", "bug: %s", "logic")`},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			code := `package main

import (
	"errors"
	"github.com/larsartmann/go-error-family"
)

var ErrBase = errors.New("base")
var ErrTest = ` + tc.callExpr + `
`
			a, _ := helperParseAndAnalyze(t, code)

			err := findNamedError(t, a, "ErrTest")
			assert.Equal(t, types.ErrorKindFamilyWrap, err.Kind, "%s must be FamilyWrap", tc.name)
			assert.Equal(t, "ErrBase", err.ParentName)
		})
	}
}

// TestErrorFamily_ImportAlias verifies that family-specific constructors work
// with import aliases (e.g., ef.NewRejection instead of errorfamily.NewRejection).
func TestErrorFamily_ImportAlias(t *testing.T) {
	code := `package main

import ef "github.com/larsartmann/go-error-family"

var ErrAliased = ef.NewRejection("REJ_001", "rejected via alias")
`
	a, _ := helperParseAndAnalyze(t, code)

	err := findNamedError(t, a, "ErrAliased")
	assert.Equal(t, types.ErrorKindFamilyNew, err.Kind, "aliased family-specific constructor must be detected")
	assert.Equal(t, "rejected via alias", err.Message)
}

// TestErrorFamily_ImportAliasWrap verifies aliased Wrap* constructors.
func TestErrorFamily_ImportAliasWrap(t *testing.T) {
	code := `package main

import (
	"errors"
	ef "github.com/larsartmann/go-error-family"
)

var ErrBase = errors.New("base")
var ErrAliasedWrap = ef.WrapConflict(ErrBase, "CON_001", "aliased wrap")
`
	a, _ := helperParseAndAnalyze(t, code)

	err := findNamedError(t, a, "ErrAliasedWrap")
	assert.Equal(t, types.ErrorKindFamilyWrap, err.Kind)
	assert.Equal(t, "ErrBase", err.ParentName)
	assertWrapsChild(t, wrapsRels(t, a), "ErrAliasedWrap", "ErrBase")
}

// TestErrorFamily_GenericNotAliased verifies that generic constructors (New,
// Wrap) are NOT matched when the package name is not "errorfamily" (avoiding
// false positives with other packages that define New/Wrap).
func TestErrorFamily_GenericNotAliased(t *testing.T) {
	code := `package main

import "somelib"

var ErrOther = somelib.New("not errorfamily")
`
	a, _ := helperParseAndAnalyze(t, code)

	for _, ne := range a.namedErrors {
		if ne.Name == "ErrOther" {
			assert.NotEqual(t, types.ErrorKindFamilyNew, ne.Kind,
				"generic New from non-errorfamily package must NOT be classified as FamilyNew")
		}
	}
}

// TestErrorFamily_MixedStdlibAndFamily verifies that a codebase mixing stdlib
// constructors and errorfamily constructors produces the correct hierarchy with
// all node types.
func TestErrorFamily_MixedStdlibAndFamily(t *testing.T) {
	code := `package main

import (
	"errors"
	"fmt"
	"github.com/larsartmann/go-error-family"
)

var ErrSentinel = errors.New("sentinel")
var ErrErrorf = fmt.Errorf("wrapped: %w", ErrSentinel)
var ErrFamilyNew = errorfamily.NewRejection("REJ_001", "family new")
var ErrFamilyWrap = errorfamily.Wrap(ErrFamilyNew, errorfamily.Conflict, "CON_001", "family wrap")
`
	a, _ := helperParseAndAnalyze(t, code)

	// Verify sentinel
	sentinel := findNamedError(t, a, "ErrSentinel")
	assert.Equal(t, types.ErrorKindSentinel, sentinel.Kind)

	// Verify fmt.Errorf wrap
	errorf := findNamedError(t, a, "ErrErrorf")
	assert.Equal(t, types.ErrorKindErrorf, errorf.Kind)
	assert.Equal(t, "ErrSentinel", errorf.ParentName)

	// Verify errorfamily new
	familyNew := findNamedError(t, a, "ErrFamilyNew")
	assert.Equal(t, types.ErrorKindFamilyNew, familyNew.Kind)

	// Verify errorfamily wrap
	familyWrap := findNamedError(t, a, "ErrFamilyWrap")
	assert.Equal(t, types.ErrorKindFamilyWrap, familyWrap.Kind)
	assert.Equal(t, "ErrFamilyNew", familyWrap.ParentName)

	// Verify all wraps relationships exist
	rels := wrapsRels(t, a)
	assertWrapsChild(t, rels, "ErrErrorf", "ErrSentinel")
	assertWrapsChild(t, rels, "ErrFamilyWrap", "ErrFamilyNew")
}

// TestErrorFamily_BranchingMetrics verifies that errorfamily wraps participate
// in the hierarchy metrics correctly. Since each errorfamily Wrap* wraps exactly
// one error, branching stays at 1.0 for pure wraps — but the relationships
// must still be counted and the hierarchy depth tracked.
func TestErrorFamily_BranchingMetrics(t *testing.T) {
	code := `package main

import (
	"errors"
	"github.com/larsartmann/go-error-family"
)

var ErrA = errors.New("a")
var ErrB = errorfamily.WrapRejection(ErrA, "REJ_001", "rej")
var ErrC = errorfamily.WrapConflict(ErrA, "CON_001", "conf")
`
	a, graph := helperParseAndAnalyze(t, code)

	// Both wraps relationships must exist
	rels := wrapsRels(t, a)
	assert.Len(t, rels, 2, "two Wrap* calls must produce two wraps relationships")
	assertWrapsChild(t, rels, "ErrB", "ErrA")
	assertWrapsChild(t, rels, "ErrC", "ErrA")

	// Hierarchy must have at least depth 1 (ErrA at depth 0, ErrB/ErrC at depth 1)
	m := graph.Hierarchy.Metrics
	assert.GreaterOrEqual(t, m.MaxDepth, uint(1), "nested wraps must produce depth >= 1")
}

// TestErrorFamily_NoStdlibRegression verifies that stdlib error detection is
// completely unchanged after adding errorfamily support.
func TestErrorFamily_NoStdlibRegression(t *testing.T) {
	code := `package main

import (
	"errors"
	"fmt"
)

var ErrA = errors.New("a")
var ErrB = errors.New("b")
var ErrJoined = errors.Join(ErrA, ErrB)
var ErrWrapped = fmt.Errorf("wrapped: %w", ErrA)
`
	a, _ := helperParseAndAnalyze(t, code)

	assert.Equal(t, types.ErrorKindSentinel, findNamedError(t, a, "ErrA").Kind)
	assert.Equal(t, types.ErrorKindSentinel, findNamedError(t, a, "ErrB").Kind)
	assert.Equal(t, types.ErrorKindJoin, findNamedError(t, a, "ErrJoined").Kind)
	assert.Equal(t, types.ErrorKindErrorf, findNamedError(t, a, "ErrWrapped").Kind)

	rels := wrapsRels(t, a)
	assert.Len(t, rels, 3, "Join(2) + Errorf(1) = 3 wraps relationships")
}

// TestErrorFamily_HierarchyDepth verifies that deeply nested errorfamily wraps
// produce correct depth tracking in the hierarchy.
func TestErrorFamily_HierarchyDepth(t *testing.T) {
	code := `package main

import (
	"errors"
	"github.com/larsartmann/go-error-family"
)

var ErrRoot = errors.New("root")
var ErrL1 = errorfamily.Wrap(ErrRoot, errorfamily.Rejection, "R1", "level 1")
var ErrL2 = errorfamily.Wrap(ErrL1, errorfamily.Conflict, "C1", "level 2")
var ErrL3 = errorfamily.Wrap(ErrL2, errorfamily.Transient, "T1", "level 3")
`
	_, graph := helperParseAndAnalyze(t, code)

	m := graph.Hierarchy.Metrics
	assert.GreaterOrEqual(t, m.MaxDepth, uint(3), "three nested wraps must produce depth >= 3")
}
