package ast

import (
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
)

// newTestTracker creates a RelationshipTracker with the given named errors and relationships.
func newTestTracker(errors []string, relationships [][2]string) *RelationshipTracker {
	namedErrors := make([]types.NamedError, len(errors))
	for i, name := range errors {
		namedErrors[i] = types.NamedError{Name: name}
	}
	rels := make([]types.ErrorRelationship, len(relationships))
	for i, r := range relationships {
		rels[i] = types.ErrorRelationship{Parent: r[0], Child: r[1]}
	}
	return &RelationshipTracker{
		analyzer: &Analyzer{
			namedErrors:   namedErrors,
			relationships: rels,
		},
	}
}

// chainTestTracker returns a tracker with A->B->C->D and X->Y relationships.
func chainTestTracker() *RelationshipTracker {
	return newTestTracker(
		[]string{"A", "B", "C", "D", "X", "Y"},
		[][2]string{
			{"A", "B"}, {"B", "C"}, {"C", "D"}, {"X", "Y"},
		},
	)
}

// notFoundFanOutTracker returns a tracker where three sibling errors all wrap ErrNotFound.
// Used for tests that exercise the "siblings" and "siblings count" APIs.
func notFoundFanOutTracker() *RelationshipTracker {
	return newTestTracker(
		[]string{"ErrNotFound", "ErrUserNotFound", "ErrProductNotFound", "ErrOrderNotFound"},
		[][2]string{
			{"ErrUserNotFound", "ErrNotFound"},
			{"ErrProductNotFound", "ErrNotFound"},
			{"ErrOrderNotFound", "ErrNotFound"},
		},
	)
}

// chainTracker returns a RelationshipTracker with a linear chain of `chainLen` errors
// (ErrA0 -> ErrA1 -> ... -> ErrA{chainLen-1}). Used for benchmark and stress tests.
func chainTracker(chainLen int) *RelationshipTracker {
	names := make([]string, chainLen)
	for i := range names {
		names[i] = "Err" + string(rune('A'+i%26)) + string(rune('0'+i/26))
	}

	rels := make([][2]string, chainLen-1)
	for i := range chainLen - 1 {
		rels[i] = [2]string{names[i], names[i+1]}
	}

	return newTestTracker(names, rels)
}

func TestRelationshipTracker_GetSiblings(t *testing.T) {
	tracker := notFoundFanOutTracker()

	// Force cache rebuild
	tracker.buildCache()

	// ErrNotFound has no siblings (it's the base error, never a wrapper)
	siblings := tracker.GetSiblings("ErrNotFound")
	assert.Nil(t, siblings)

	// ErrUserNotFound has siblings: ErrProductNotFound and ErrOrderNotFound
	siblings = tracker.GetSiblings("ErrUserNotFound")
	assert.Contains(t, siblings, "ErrProductNotFound")
	assert.Contains(t, siblings, "ErrOrderNotFound")
	assert.NotContains(t, siblings, "ErrUserNotFound")
}

func TestRelationshipTracker_GetSiblingsCount(t *testing.T) {
	tracker := notFoundFanOutTracker()
	tracker.buildCache()

	// ErrNotFound has no parent, so no siblings
	assert.Equal(t, 0, tracker.GetSiblingsCount("ErrNotFound"))

	// ErrUserNotFound has 2 siblings
	assert.Equal(t, 2, tracker.GetSiblingsCount("ErrUserNotFound"))
}

func TestRelationshipTracker_GetBranchingFactor(t *testing.T) {
	chain := func(parentChild ...string) []types.ErrorRelationship {
		if len(parentChild)%2 != 0 {
			panic("chain requires pairs")
		}
		rels := make([]types.ErrorRelationship, 0, len(parentChild)/2)
		for i := 0; i < len(parentChild); i += 2 {
			rels = append(rels, types.ErrorRelationship{Parent: parentChild[i], Child: parentChild[i+1]})
		}
		return rels
	}

	tests := []struct {
		name           string
		relationships  []types.ErrorRelationship
		expectedFactor float64
	}{
		{
			name:           "no relationships",
			relationships:  nil,
			expectedFactor: 0,
		},
		{
			name:           "linear chain",
			relationships:  chain("A", "B", "B", "C", "C", "D"),
			expectedFactor: 1.0, // Each parent has exactly 1 child
		},
		{
			name: "branching hierarchy",
			relationships: chain(
				// ErrNotFound wraps 3 specific errors, giving branching factor of 3
				"ErrNotFound", "ErrUserNotFound",
				"ErrNotFound", "ErrProductNotFound",
				"ErrNotFound", "ErrOrderNotFound",
			),
			expectedFactor: 3.0, // ErrNotFound has 3 children
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			tracker := &RelationshipTracker{
				analyzer: &Analyzer{
					relationships: tt.relationships,
				},
			}
			tracker.buildCache()

			factor := tracker.GetBranchingFactor()
			assert.Equal(t, tt.expectedFactor, factor)
		})
	}
}

func TestRelationshipTracker_GetMaxBranchingFactor(t *testing.T) {
	tracker := &RelationshipTracker{
		analyzer: &Analyzer{
			relationships: []types.ErrorRelationship{
				{Parent: "ErrUserNotFound", Child: "ErrNotFound"},
				{Parent: "ErrProductNotFound", Child: "ErrNotFound"},
				{Parent: "ErrOrderNotFound", Child: "ErrNotFound"},
				{Parent: "ErrCreateUserFailed", Child: "ErrValidationFailed"},
				{Parent: "ErrUpdateUserFailed", Child: "ErrValidationFailed"},
			},
		},
	}
	tracker.buildCache()

	// GetMaxBranchingFactor returns the parent with the most children
	// All parents have exactly 1 child (ErrNotFound or ErrValidationFailed)
	_, count := tracker.GetMaxBranchingFactor()
	assert.Equal(t, 1, count) // All have 1 child
}

func TestRelationshipTracker_GetLongestChain(t *testing.T) {
	tracker := chainTestTracker()
	tracker.buildCache()

	chain := tracker.GetLongestChain()
	// The longest chain is A -> B -> C -> D
	assert.Equal(t, []string{"A", "B", "C", "D"}, chain)
}

func TestRelationshipTracker_GetHierarchyDepth(t *testing.T) {
	tracker := chainTestTracker()
	tracker.buildCache()

	depth := tracker.GetHierarchyDepth()
	// B has depth 1, C has depth 2, D has depth 3
	assert.Equal(t, uint(3), depth)
}

func TestRelationshipTracker_GetHierarchySummary(t *testing.T) {
	tracker := newTestTracker(
		[]string{"ErrBase", "ErrLevel1A", "ErrLevel1B", "ErrLevel2", "ErrLevel3"},
		[][2]string{
			{"ErrLevel1A", "ErrBase"},
			{"ErrLevel1B", "ErrBase"},
			{"ErrLevel2", "ErrLevel1A"},
			{"ErrLevel3", "ErrLevel2"},
		},
	)
	tracker.buildCache()

	summary := tracker.GetHierarchySummary()

	assert.Equal(t, 5, summary.TotalErrors)
	assert.Equal(t, 4, summary.TotalRelationships)
	// Root errors: ErrLevel1B, ErrLevel3 (ErrBase is wrapped)
	assert.Equal(t, 2, summary.RootErrors)
	// childToParent only stores last parent for each child
	// ErrBase -> ErrLevel1A (overwritten), ErrLevel1A -> ErrLevel2, ErrLevel2 -> ErrLevel3
	// Max depth from root: ErrLevel3(0) -> ErrLevel2(1) -> ErrLevel1A(2) -> ErrBase(3)
	// But since childToParent overwrites, ErrBase's parent is ErrLevel1A
	// ErrLevel1A's parent is ErrLevel2, ErrLevel2's parent is ErrLevel3
	// Max depth = 3 (for ErrBase)
	assert.Equal(t, uint(3), summary.MaxDepth)
	assert.InDelta(t, 1.0, summary.AvgBranchingFactor, 0.01) // 4/4 = 1.0
	// All parents have exactly 1 child
	assert.Equal(t, 1, summary.MaxBranchingCount)
	// Longest chain: ErrLevel3 -> ErrLevel2 -> ErrLevel1A -> ErrBase (4 nodes)
	assert.Equal(t, 4, summary.LongestChainLength)
	assert.Equal(t, "ErrLevel3", summary.LongestChainRoot)
}

func TestGetRelationshipDepth_MultiParent(t *testing.T) {
	// DAG: Root has no parent. Middle has two parents: Root and DirectParent.
	// DirectParent's parent is Root.
	// childToParents: Middle -> [Root, DirectParent], DirectParent -> [Root]
	// GetRelationshipDepth follows parents[0], so depth depends on relationship order.
	// This test documents that behavior: depth = length via first-parent chain.
	tracker := newTestTracker(
		[]string{"Root", "DirectParent", "Middle"},
		[][2]string{
			{"DirectParent", "Middle"}, // Middle's first parent is DirectParent
			{"Root", "Middle"},         // Middle's second parent is Root
			{"Root", "DirectParent"},   // DirectParent's parent is Root
		},
	)

	// Middle -> DirectParent -> Root: depth = 2
	depth := tracker.GetRelationshipDepth("Middle")
	assert.Equal(t, uint(2), depth, "depth via first parent chain (Middle -> DirectParent -> Root)")

	// DirectParent -> Root: depth = 1
	depth = tracker.GetRelationshipDepth("DirectParent")
	assert.Equal(t, uint(1), depth)

	// Root has no parents: depth = 0
	depth = tracker.GetRelationshipDepth("Root")
	assert.Equal(t, uint(0), depth)
}

func TestGetRelationshipDepth_CachesIntermediates(t *testing.T) {
	// Chain: D -> C -> B -> A (A is root)
	tracker := newTestTracker(
		[]string{"A", "B", "C", "D"},
		[][2]string{
			{"C", "D"},
			{"B", "C"},
			{"A", "B"},
		},
	)

	// Query D first — should cache D, C, B, A
	depth := tracker.GetRelationshipDepth("D")
	assert.Equal(t, uint(3), depth)

	// All intermediate nodes should now be cached
	// Querying C should return cached value without re-traversing
	depth = tracker.GetRelationshipDepth("C")
	assert.Equal(t, uint(2), depth)

	depth = tracker.GetRelationshipDepth("B")
	assert.Equal(t, uint(1), depth)

	depth = tracker.GetRelationshipDepth("A")
	assert.Equal(t, uint(0), depth)
}

func BenchmarkGetRelationshipDepth_DeepChain(b *testing.B) {
	const chainLen = 100

	tracker := chainTracker(chainLen)
	names := tracker.analyzer.namedErrors

	b.ResetTimer()
	b.ReportAllocs()

	for b.Loop() {
		// Query the deepest node — exercises full chain traversal on first call,
		// then cache hits for subsequent calls
		_ = tracker.GetRelationshipDepth(names[chainLen-1].Name)
	}
}

func BenchmarkGetHierarchyDepth_AllNodes(b *testing.B) {
	// Build a chain of 50 errors to benchmark GetHierarchyDepth which calls
	// GetRelationshipDepth for every named error.
	tracker := chainTracker(50)

	b.ResetTimer()
	b.ReportAllocs()

	for b.Loop() {
		tracker.invalidateCache()
		_ = tracker.GetHierarchyDepth()
	}
}

func TestForEachNamedError_IteratesAllErrors(t *testing.T) {
	tracker := chainTestTracker()

	var visited []string
	tracker.forEachNamedError(func(name string) {
		visited = append(visited, name)
	})

	assert.Equal(t, []string{"A", "B", "C", "D", "X", "Y"}, visited)
}

func TestForEachNamedError_BuildsCacheBeforeIterating(t *testing.T) {
	tracker := chainTestTracker()
	assert.False(t, tracker.cacheBuilt, "cache should not be built yet")

	tracker.forEachNamedError(func(_ string) {})

	assert.True(t, tracker.cacheBuilt, "cache should be built after forEachNamedError")
}

func TestForEachNamedError_EmptyNamedErrors(t *testing.T) {
	tracker := newTestTracker(nil, nil)

	callCount := 0
	tracker.forEachNamedError(func(_ string) {
		callCount++
	})

	assert.Equal(t, 0, callCount)
}

func TestForEachNamedError_CallbackReceivesCorrectNames(t *testing.T) {
	tracker := notFoundFanOutTracker()

	names := make(map[string]bool)
	tracker.forEachNamedError(func(name string) {
		names[name] = true
	})

	assert.True(t, names["ErrNotFound"])
	assert.True(t, names["ErrUserNotFound"])
	assert.True(t, names["ErrProductNotFound"])
	assert.True(t, names["ErrOrderNotFound"])
	assert.Len(t, names, 4)
}

func TestHasCyclicDependency_SameLengthDifferentSliceDoesNotUseCache(t *testing.T) {
	// Regression test for the latent bug where the cache fast path was
	// triggered by length alone. The tracker has A->B->C (3 rels), and we
	// pass a DIFFERENT 3-relationship set (X->Y, Y->Z, Z->W). With the old
	// length-only check, the BFS would traverse the WRONG graph (A->B->C)
	// and miss the cycle in the external set.
	tracker := newTestTracker(
		[]string{"A", "B", "C", "W", "X", "Y", "Z"},
		[][2]string{
			{"A", "B"}, {"B", "C"}, // tracker's own relationships (length 2)
		},
	)

	// External set with a cycle: W->X->Y->Z->W would be cyclic if we add W->Z.
	// Use a DIFFERENT slice with the SAME length as the tracker's relationships.
	externalRels := []types.ErrorRelationship{
		{Parent: "X", Child: "Y"},
		{Parent: "Y", Child: "Z"},
	}

	// Adding Z->X against the external set creates a cycle:
	// childToParents: Y->X, Z->Y, X->Z. From X: X->Z->Y->X = cycle.
	hasCycle := tracker.HasCyclicDependency("Z", "X", externalRels)
	assert.True(
		t,
		hasCycle,
		"cycle in external set must be detected even when length matches tracker's own relationships",
	)

	// Sanity: adding W->X (W is not in the external set) should NOT create a cycle.
	hasCycle = tracker.HasCyclicDependency("W", "X", externalRels)
	assert.False(t, hasCycle, "no cycle when adding a disconnected node")
}

func TestHasCyclicDependency_OwnSliceUsesCache(t *testing.T) {
	// When the caller passes the tracker's own relationship slice, the cache
	// fast path should be used (verified by data-pointer identity).
	tracker := newTestTracker(
		[]string{"A", "B", "C"},
		[][2]string{
			{"A", "B"}, {"B", "C"},
		},
	)

	// Adding C->A against the tracker's own relationships creates a cycle.
	hasCycle := tracker.HasCyclicDependency("C", "A", tracker.analyzer.relationships)
	assert.True(t, hasCycle)

	// Adding D->A does not create a cycle.
	hasCycle = tracker.HasCyclicDependency("D", "A", tracker.analyzer.relationships)
	assert.False(t, hasCycle)
}

func TestGetErrorChain_CacheReuse(t *testing.T) {
	tracker := chainTestTracker()
	tracker.buildCache()

	first := tracker.GetErrorChain("D")
	assert.Equal(t, []string{"A", "B", "C", "D"}, first)

	// Second call returns the exact same backing array (memoized).
	second := tracker.GetErrorChain("D")
	assert.True(t, len(first) > 0 && &first[0] == &second[0],
		"GetErrorChain should return cached slice on second call")
}

func TestGetErrorChain_CacheInvalidation(t *testing.T) {
	tracker := chainTestTracker() // A->B->C->D
	tracker.buildCache()

	chain := tracker.GetErrorChain("D")
	assert.Equal(t, []string{"A", "B", "C", "D"}, chain)

	// Add a new root above A: E->A
	tracker.analyzer.relationships = append(
		tracker.analyzer.relationships,
		types.ErrorRelationship{Parent: "E", Child: "A"},
	)
	tracker.analyzer.namedErrors = append(
		tracker.analyzer.namedErrors,
		types.NamedError{Name: "E"},
	)
	tracker.invalidateCache()

	// After invalidation, the chain should reflect the new root.
	chain = tracker.GetErrorChain("D")
	assert.Equal(t, []string{"E", "A", "B", "C", "D"}, chain)
}

func TestGetSiblings_CacheReuse(t *testing.T) {
	tracker := notFoundFanOutTracker()
	tracker.buildCache()

	first := tracker.GetSiblings("ErrUserNotFound")
	assert.Contains(t, first, "ErrProductNotFound")
	assert.Contains(t, first, "ErrOrderNotFound")

	second := tracker.GetSiblings("ErrUserNotFound")
	assert.True(t, len(first) > 0 && &first[0] == &second[0],
		"GetSiblings should return cached slice on second call")
}

func TestGetSiblings_CacheNilResult(t *testing.T) {
	tracker := notFoundFanOutTracker()
	tracker.buildCache()

	// ErrNotFound wraps nothing → nil siblings.
	first := tracker.GetSiblings("ErrNotFound")
	assert.Nil(t, first)

	// Second call should also return nil from cache (not recompute).
	// The key must exist in the cache map (comma-ok distinguishes nil-value
	// from missing-key).
	_, ok := tracker.siblingsCache["ErrNotFound"]
	assert.True(t, ok, "nil siblings result should be cached")

	second := tracker.GetSiblings("ErrNotFound")
	assert.Nil(t, second)
}

func TestGetSiblings_CacheInvalidation(t *testing.T) {
	tracker := notFoundFanOutTracker() // 3 errors wrap ErrNotFound
	tracker.buildCache()

	siblings := tracker.GetSiblings("ErrUserNotFound")
	assert.Len(t, siblings, 2)

	// Add a fourth sibling wrapping ErrNotFound.
	tracker.analyzer.relationships = append(
		tracker.analyzer.relationships,
		types.ErrorRelationship{Parent: "ErrPaymentNotFound", Child: "ErrNotFound"},
	)
	tracker.analyzer.namedErrors = append(
		tracker.analyzer.namedErrors,
		types.NamedError{Name: "ErrPaymentNotFound"},
	)
	tracker.invalidateCache()

	siblings = tracker.GetSiblings("ErrUserNotFound")
	assert.Len(t, siblings, 3)
	assert.Contains(t, siblings, "ErrPaymentNotFound")
}
