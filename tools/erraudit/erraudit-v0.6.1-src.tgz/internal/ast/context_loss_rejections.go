package ast

// FP rejection pipeline and loss classifiers for context-loss detection.
// Mirrors the branching-flow tracker's loss pipeline but adapted to erraudit's
// AST-first approach (string-based pattern matching is minimized in favor of
// direct AST inspection).

import (
	"go/ast"
	"go/token"
	"slices"
	"strings"

	"github.com/larsartmann/erraudit/pkg/types"
)

// ============================================================================
// FP REJECTION STEPS
// ============================================================================

// rejectBlankIdentifier suppresses the blank identifier.
func rejectBlankIdentifier(name string) bool {
	return name == "_"
}

// rejectCredential suppresses secret/credential variables — these must NEVER
// appear in error messages for security reasons.
func rejectCredential(name string) bool {
	return isCredentialVariable(name)
}

// rejectInfrastructureType uses go/types (when available) to suppress variables
// whose resolved type is a known infrastructure type (context.Context,
// io.Reader, *sync.Mutex, *sql.DB, etc.). This is a safety net that catches
// cases where a variable's name matches a business suffix but its type reveals
// it is infrastructure. When type info is unavailable, this is a no-op.
func (d *ContextLossDetector) rejectInfrastructureType(cv contextVar) bool {
	resolver := d.analyzer.typeResolver
	if resolver == nil || !resolver.Available() {
		return false
	}

	t := resolver.IdentType(cv.ident)

	return IsInfrastructureType(t)
}

// typeKindInfo holds the resolved type characteristics of a variable.
type typeKindInfo struct {
	isBool       bool
	isFunc       bool
	isAny        bool
	isInterface  bool
	isVoid       bool
	isCollection bool
	isPointer    bool
}

// classifyTypeKind inspects an AST type expression to determine its kind.
// When a type resolver is available, it can use go/types for more accuracy.
func classifyTypeKind(typeExpr ast.Expr) typeKindInfo {
	if typeExpr == nil {
		return typeKindInfo{}
	}

	switch t := typeExpr.(type) {
	case *ast.Ident:
		switch t.Name {
		case "bool":
			return typeKindInfo{isBool: true}
		case "string", "int", "int32", "int64", "uint", "uint32", "uint64",
			"float32", "float64", "byte", "rune", "complex64", "complex128":
			return typeKindInfo{}
		}
	case *ast.FuncType:
		return typeKindInfo{isFunc: true}
	case *ast.InterfaceType:
		if t.Methods == nil || len(t.Methods.List) == 0 {
			return typeKindInfo{isAny: true}
		}

		return typeKindInfo{isInterface: true}
	case *ast.ArrayType, *ast.MapType:
		return typeKindInfo{isCollection: true}
	case *ast.StarExpr:
		return typeKindInfo{isPointer: true}
	case *ast.Ellipsis:
		return typeKindInfo{isCollection: true}
	}

	// Try go/types resolution when available

	return typeKindInfo{}
}

// rejectByTypeKind rejects variables whose types are rarely useful as error
// context (bool, func, any, collection, pointer). This is a pragmatic FP
// filter — these types either can't be meaningfully included in error messages
// or are infrastructure in nature.
func rejectByTypeKind(kind typeKindInfo) bool {
	return kind.isBool || kind.isFunc || kind.isAny || kind.isCollection || kind.isPointer
}

// isKnownPrimitiveType reports whether typeExpr is a known Go primitive type
// (int, string, float, etc.). Returns false for nil (unknown) and non-ident
// types (pointers, structs, interfaces) — those are likely nil/zero on the
// error path when co-assigned with the error variable.
func isKnownPrimitiveType(typeExpr ast.Expr) bool {
	if typeExpr == nil {
		return false
	}

	ident, ok := typeExpr.(*ast.Ident)
	if !ok {
		return false
	}

	return slices.Contains(primitiveTypeNames, ident.Name)
}

// primitiveTypeNames lists all Go predeclared primitive type names.
//
//nolint:gochecknoglobals // immutable lookup list
var primitiveTypeNames = []string{
	"int", "int8", "int16", "int32", "int64",
	"uint", "uint8", "uint16", "uint32", "uint64",
	"float32", "float64", "string", "byte", "rune",
}

// rejectCoAssignedWithErr suppresses variables that were assigned in the same
// := statement as the error variable. On the error path, these variables are
// typically nil/zero (e.g. `tmpl, err := template.New(...).Parse(...)` — tmpl
// is nil when Parse fails). Only suppressed for non-primitive types, since
// primitives like int may carry useful zero values.
func rejectCoAssignedWithErr(cv contextVar) bool {
	if !cv.coAssignedWithErr {
		return false
	}

	return !isKnownPrimitiveType(cv.typeExpr)
}

// rejectContextIncluded checks whether a variable is already referenced in the
// error expression. If it is, it's not lost — the developer included it.
//
// Two checks are performed:
//  1. The variable name appears as an identifier in the error expression
//     (e.g., Wrap(err, "failed: %s", path) with variable "path").
//  2. The variable name appears as a word in a string literal in the error
//     expression (e.g., "failed to load config" with variable "config").
//     This catches the common pattern where the message describes the context
//     conceptually without passing the variable as a format argument.
func (d *ContextLossDetector) rejectContextIncluded(varName string, errExpr ast.Expr) bool {
	if len(varName) < minVarNameLenForStringMatch {
		return false
	}

	found := false

	ast.Inspect(errExpr, func(n ast.Node) bool {
		if found {
			return false
		}

		if ident, ok := n.(*ast.Ident); ok && ident.Name == varName {
			found = true

			return false
		}

		if lit, ok := n.(*ast.BasicLit); ok && lit.Kind == token.STRING {
			if varNameInStringLit(lit.Value, varName) {
				found = true

				return false
			}
		}

		return true
	})

	return found
}

// minVarNameLenForStringMatch is the minimum variable name length for the
// string-literal matching heuristic. Short names (e.g., "id", "x") produce
// too many false matches in error message strings.
const minVarNameLenForStringMatch = 4

// varNameInStringLit checks whether a variable name appears as a complete word
// (bounded by non-alphanumeric characters or string boundaries) inside a
// Go string literal value (including surrounding quotes).
func varNameInStringLit(litValue, varName string) bool {
	if len(litValue) < len(varName) {
		return false
	}

	lower := strings.ToLower(litValue)
	target := strings.ToLower(varName)

	idx := strings.Index(lower, target)
	if idx < 0 {
		return false
	}

	// Check word boundary before the match.
	if idx > 0 {
		before := lower[idx-1]
		if isAlphaNum(before) {
			return false
		}
	}

	// Check word boundary after the match.
	afterIdx := idx + len(target)
	if afterIdx < len(lower) {
		after := lower[afterIdx]
		if isAlphaNum(after) {
			return false
		}
	}

	return true
}

func isAlphaNum(c byte) bool {
	return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')
}

// rejectSentinelReturn suppresses returns that reference a sentinel error
// (e.g., return ErrNotFound, return pkg.ErrNotFound). These are intentional
// design choices, not context losses — the developer chose a pre-defined error
// with inherent meaning.
func rejectSentinelReturn(errExpr ast.Expr) bool {
	switch e := errExpr.(type) {
	case *ast.SelectorExpr:
		// Cross-package: pkg.ErrFoo
		return isSentinelName(e.Sel.Name)
	case *ast.Ident:
		// Same-package: ErrFoo
		return isSentinelName(e.Name)
	default:
		return false
	}
}

// isSentinelName reports whether name follows the Go sentinel error convention:
// starts with "Err" followed by an uppercase letter (ErrNotFound, ErrInvalid).
func isSentinelName(name string) bool {
	return strings.HasPrefix(name, "Err") && len(name) > 3 && name[3] >= 'A' && name[3] <= 'Z'
}

// ============================================================================
// LOSS CLASSIFIERS (first match wins)
// ============================================================================

// classifyVariadicSpread detects error returns using variadic spread (e.g.,
// fmt.Errorf("...", args...)). The context variable may be inside the spread,
// so we can't be certain it's lost. Classified as delayed recovery.
func (d *ContextLossDetector) classifyVariadicSpread(errExpr ast.Expr, severity types.Severity) *contextLossResult {
	call, ok := errExpr.(*ast.CallExpr)
	if !ok {
		return nil
	}

	for _, arg := range call.Args {
		if ellipsis, ok := arg.(*ast.Ellipsis); ok {
			_ = ellipsis

			return &contextLossResult{
				subtype:     types.ContextLossDelayed,
				description: "variable may be lost in variadic spread",
				severity:    capAtMedium(severity),
				recoverable: true,
			}
		}
	}

	return nil
}

// classifyErrorFamily detects error returns using go-error-family constructors.
// These constructors accept code and message strings but may not include the
// context variable. Classified as delayed recovery.
func (d *ContextLossDetector) classifyErrorFamily(errExpr ast.Expr, severity types.Severity) *contextLossResult {
	call, ok := errExpr.(*ast.CallExpr)
	if !ok {
		return nil
	}

	if !isErrorFamilyCall(call) {
		return nil
	}

	return &contextLossResult{
		subtype:     types.ContextLossDelayed,
		description: "go-error-family constructor does not include context variable",
		severity:    severity,
		recoverable: true,
	}
}

// classifyImmediateLoss detects bare `return err` patterns where all context
// is dropped. The error chain is preserved but all business context (IDs,
// paths, flags) is lost. Classified as immediate, unrecoverable.
func (d *ContextLossDetector) classifyImmediateLoss(errExpr ast.Expr, severity types.Severity) *contextLossResult {
	ident, ok := errExpr.(*ast.Ident)
	if !ok {
		return nil
	}

	name := strings.ToLower(ident.Name)
	if name == errorIdentifierName || name == errorInterfaceName || strings.HasSuffix(name, errorIdentifierSubstr) {
		return &contextLossResult{
			subtype:     types.ContextLossImmediate,
			description: "bare error propagation drops all context",
			severity:    severity,
			recoverable: false,
		}
	}

	return nil
}

// classifyWrappingLoss detects fmt.Errorf("%w", err) wrapping patterns where
// the context variable is not included in the format string. Classified as
// wrapping, recoverable — the fix is to add the variable to the message.
func (d *ContextLossDetector) classifyWrappingLoss(errExpr ast.Expr, severity types.Severity) *contextLossResult {
	call, ok := errExpr.(*ast.CallExpr)
	if !ok {
		return nil
	}

	pkg, method, _ := callSelector(
		call,
	)
	if pkg != fmtPkg || method != methodErrorf {
		return nil
	}

	formatValue, ok := formatStringLiteral(call)
	if !ok || !strings.Contains(formatValue, "%w") {
		return nil
	}

	return &contextLossResult{
		subtype:     types.ContextLossWrapping,
		description: "wrapping without including context variable in message",
		severity:    severity,
		recoverable: true,
	}
}

// capAtMedium ensures severity does not exceed Medium. Used for variadic
// spread where the loss is uncertain.
func capAtMedium(severity types.Severity) types.Severity {
	if severity.Ordinal() > types.SeverityMedium.Ordinal() {
		return types.SeverityMedium
	}

	return severity
}
