package ast

import (
	"fmt"
	"go/parser"
	"go/token"
	"strings"
	"testing"

	"pgregory.net/rapid"
)

// validOopsCodeGen generates random but syntactically-valid Go source code
// that exercises various patterns relevant to oops enforcement. Every output
// is guaranteed to parse successfully.
func validOopsCodeGen() *rapid.Generator[string] {
	return rapid.Custom(func(rt *rapid.T) string {
		useOopsImport := rapid.Bool().Draw(rt, "useOops")
		useErrorsImport := rapid.Bool().Draw(rt, "useErrors")
		errName := rapid.SampledFrom([]string{"err", "e", "result"}).Draw(rt, "errName")
		wrapMethod := rapid.SampledFrom([]string{"Wrap", "Wrapf", "Errorf"}).Draw(rt, "wrapMethod")
		hasGuard := rapid.Bool().Draw(rt, "hasGuard")
		hasReturnNil := rapid.Bool().Draw(rt, "hasReturnNil")

		var imports []string

		if useOopsImport {
			imports = append(imports, `"github.com/samber/oops"`)
		}

		if useErrorsImport {
			imports = append(imports, `"errors"`)
		}

		importBlock := ""
		if len(imports) > 0 {
			if len(imports) == 1 {
				importBlock = fmt.Sprintf("import %s\n", imports[0])
			} else {
				importBlock = fmt.Sprintf("import (\n%s\n)\n", strings.Join(imports, "\n"))
			}
		}

		var body strings.Builder
		body.WriteString(fmt.Sprintf("\t%s := step()\n", errName))
		body.WriteString(fmt.Sprintf("\t_ = %s\n", errName))

		if hasGuard && useOopsImport {
			body.WriteString(fmt.Sprintf("\tif %s != nil {\n", errName))
			body.WriteString(fmt.Sprintf("\t\treturn oops.%s(%s)\n", wrapMethod, errName))
			body.WriteString("\t}\n")
			if hasReturnNil {
				body.WriteString("\treturn nil\n")
			} else {
				body.WriteString("\treturn step()\n")
			}
		} else {
			body.WriteString("\treturn nil\n")
		}

		return fmt.Sprintf(`package main

%sfunc process() error {
%s}

func step() error { return nil }
`, importBlock, body.String())
	})
}

// TestOopsEnforcement_NoFalsePositivesWhenOff verifies that with enforcement
// OFF, random valid Go code never produces oops-related violations.
func TestOopsEnforcement_NoFalsePositivesWhenOff(t *testing.T) {
	rapid.Check(t, func(rt *rapid.T) {
		code := validOopsCodeGen().Draw(rt, "code")

		fset := token.NewFileSet()
		node, err := parser.ParseFile(fset, "test.go", code, parser.AllErrors)
		if err != nil {
			return // skip unparseable code (shouldn't happen with our generator)
		}

		analyzer := NewAnalyzer(fset, "main", "test.go")
		graph := analyzer.Analyze(node)

		for _, v := range graph.Violations {
			if v.Type == "oops_redundant_guard" {
				rt.Fatalf("oops_redundant_guard produced when enforcement is OFF: %s", v.Message)
			}

			if v.Type == "stdlib_constructor" && strings.Contains(v.Message, "samber/oops") {
				rt.Fatalf("samber/oops enforcement message when flag is OFF: %s", v.Message)
			}
		}
	})
}

// TestOopsEnforcement_NoPanicOnAnyInput verifies the analyzer never panics
// on any valid Go source, regardless of enforcement flag state.
func TestOopsEnforcement_NoPanicOnAnyInput(t *testing.T) {
	rapid.Check(t, func(rt *rapid.T) {
		code := validOopsCodeGen().Draw(rt, "code")
		enforce := rapid.Bool().Draw(rt, "enforce")

		fset := token.NewFileSet()
		node, err := parser.ParseFile(fset, "test.go", code, parser.AllErrors)
		if err != nil {
			return
		}

		opts := []AnalyzerOption{}
		if enforce {
			opts = append(opts, WithEnforceSamberOops(true))
		}

		analyzer := NewAnalyzer(fset, "main", "test.go", opts...)
		_ = analyzer.Analyze(node)
	})
}

// BenchmarkOopsRedundantGuard_Off measures the overhead of the anti-pattern
// detector when enforcement is OFF. Expected: near-zero overhead.
func BenchmarkOopsRedundantGuard_Off(b *testing.B) {
	code := `package main

import "github.com/samber/oops"

func process() error {
	err := step()
	if err != nil {
		return oops.Wrap(err)
	}
	return nil
}

func step() error { return nil }`

	fset := token.NewFileSet()
	node, _ := parser.ParseFile(fset, "test.go", code, parser.AllErrors)

	for b.Loop() {
		analyzer := NewAnalyzer(fset, "main", "test.go")
		_ = analyzer.Analyze(node)
	}
}

// BenchmarkOopsRedundantGuard_On measures the overhead of the anti-pattern
// detector when enforcement is ON.
func BenchmarkOopsRedundantGuard_On(b *testing.B) {
	code := `package main

import "github.com/samber/oops"

func process() error {
	err := step()
	if err != nil {
		return oops.Wrap(err)
	}
	return nil
}

func step() error { return nil }`

	fset := token.NewFileSet()
	node, _ := parser.ParseFile(fset, "test.go", code, parser.AllErrors)

	for b.Loop() {
		analyzer := NewAnalyzer(fset, "main", "test.go", WithEnforceSamberOops(true))
		_ = analyzer.Analyze(node)
	}
}
