package ast

// blank_callee_classifier_test.go pins the default-mode blank-identifier
// precision ladder (2026-09-22): the rungs, their EXACT evaluation order,
// and the first-suppress-wins short circuit. Before the classifier
// extraction the ladder lived as sequential ifs inside
// isBlankReceivingError, where reordering was invisible to tests.

import (
	"go/ast"
	"go/parser"
	"go/token"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestBlankCalleeClassifier_ProductionLadderOrder(t *testing.T) {
	classifier := newBlankCalleeClassifier(&Analyzer{})

	names := make([]string, 0, len(classifier.heuristics))
	for _, h := range classifier.heuristics {
		names = append(names, h.name)
	}

	assert.Equal(t,
		[]string{"comma-ok shape", "stdlib no-error table", "declared signature"},
		names,
		"the production rung order is load-bearing: cheap shape checks before table lookups",
	)
}

func TestBlankCalleeClassifier_FirstSuppressWinsAndShortCircuits(t *testing.T) {
	var evaluated []string

	rung := func(name string, verdict blankCalleeVerdict) blankCalleeHeuristic {
		return blankCalleeHeuristic{
			name: name,
			classify: func(*ast.CallExpr, int) blankCalleeVerdict {
				evaluated = append(evaluated, name)

				return verdict
			},
		}
	}

	classifier := &blankCalleeClassifier{
		heuristics: []blankCalleeHeuristic{
			rung("first-flag", blankCalleeFlag),
			rung("second-suppress", blankCalleeSuppress),
			rung("third-suppress", blankCalleeSuppress),
		},
	}

	verdict, decided := classifier.classify(&ast.CallExpr{}, 0)

	assert.Equal(t, blankCalleeSuppress, verdict)
	assert.Equal(t, "second-suppress", decided, "the FIRST suppress verdict must win")
	assert.Equal(t, []string{"first-flag", "second-suppress"}, evaluated,
		"evaluation must stop at the first suppress verdict (short circuit)")
}

func TestBlankCalleeClassifier_AllFlagFallsThrough(t *testing.T) {
	classifier := &blankCalleeClassifier{
		heuristics: []blankCalleeHeuristic{
			{name: "always-flag", classify: func(*ast.CallExpr, int) blankCalleeVerdict {
				return blankCalleeFlag
			}},
		},
	}

	verdict, decided := classifier.classify(&ast.CallExpr{}, 0)

	assert.Equal(t, blankCalleeFlag, verdict, "no rung proved not-error → conservative flag")
	assert.Empty(t, decided)
}

// TestBlankCalleeClassifier_ProductionRungsDecide pins each production rung
// on a real parsed fixture: the stdlib table suppresses strings.Cut's first
// blank, the declared-signature table suppresses a same-file (int, int)
// callee, and an unknown callee falls through to the conservative flag.
func TestBlankCalleeClassifier_ProductionRungsDecide(t *testing.T) {
	const src = `package testfixture

import "strings"

func use(s string) {
	_, after, _ := strings.Cut(s, ",")
	_, n := getCount()
	_, x := mystery()
	_ = after
	_ = n
	_ = x
}

func getCount() (int, int) { return 0, 0 }
`

	fset := token.NewFileSet()
	file, err := parser.ParseFile(fset, "fixture.go", src, parser.SkipObjectResolution)
	require.NoError(t, err)

	analyzer := &Analyzer{currentFile: file}
	analyzer.funcSigs = CollectFuncSigs([]*ast.File{file})
	classifier := newBlankCalleeClassifier(analyzer)

	stringsCut := &ast.CallExpr{Fun: &ast.SelectorExpr{
		X:   &ast.Ident{Name: "strings"},
		Sel: &ast.Ident{Name: "Cut"},
	}}
	getCount := &ast.CallExpr{Fun: &ast.Ident{Name: "getCount"}}
	mystery := &ast.CallExpr{Fun: &ast.Ident{Name: "mystery"}}

	tests := []struct {
		name       string
		call       *ast.CallExpr
		blankIndex int
		want       blankCalleeVerdict
		wantRung   string
	}{
		{
			name:       "stdlib no-error table rung",
			call:       stringsCut,
			blankIndex: 0,
			want:       blankCalleeSuppress,
			wantRung:   "stdlib no-error table",
		},
		{
			name:       "declared signature rung",
			call:       getCount,
			blankIndex: 1,
			want:       blankCalleeSuppress,
			wantRung:   "declared signature",
		},
		{name: "unknown callee stays flagged", call: mystery, blankIndex: 0, want: blankCalleeFlag, wantRung: ""},
		{name: "out-of-range index stays flagged", call: getCount, blankIndex: 5, want: blankCalleeFlag, wantRung: ""},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			verdict, rung := classifier.classify(tt.call, tt.blankIndex)
			assert.Equal(t, tt.want, verdict)
			assert.Equal(t, tt.wantRung, rung)
		})
	}
}
