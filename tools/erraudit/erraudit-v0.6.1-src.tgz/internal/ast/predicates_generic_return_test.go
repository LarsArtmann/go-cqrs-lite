package ast

// predicates_generic_return_test.go contains tests for the generic_return
// false-positive filters: interface method exclusion, constructor/factory
// exclusion, and the creator-only heuristic.

import (
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
)

func TestGenericReturn_StandardInterfaceMethodExcluded(t *testing.T) {
	tests := []struct {
		name string
		code string
	}{
		{
			name: "MarshalJSON",
			code: `package main

import "encoding/json"

type T struct{}

func (t T) MarshalJSON() ([]byte, error) {
	return json.Marshal(t)
}`,
		},
		{
			name: "UnmarshalJSON",
			code: `package main

import "encoding/json"

type T struct{}

func (t *T) UnmarshalJSON(data []byte) error {
	return json.Unmarshal(data, t)
}`,
		},
		{
			name: "Read",
			code: `package main

func (r myReader) Read(p []byte) (int, error) {
	return 0, nil
}`,
		},
		{
			name: "Write",
			code: `package main

func (w myWriter) Write(p []byte) (int, error) {
	return len(p), nil
}`,
		},
		{
			name: "Close",
			code: `package main

func (c myCloser) Close() error {
	return nil
}`,
		},
		{
			name: "Unwrap",
			code: `package main

func (e myError) Unwrap() error {
	return nil
}`,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			helperNoViolationExpected(
				t,
				tt.code,
				types.ErrorTypeGenericReturn,
				"Standard interface method should NOT be flagged as generic_return",
			)
		})
	}
}

func TestGenericReturn_ConstructorExcluded(t *testing.T) {
	tests := []struct {
		name string
		code string
	}{
		{
			name: "New",
			code: `package main

import "errors"

func New() error {
	return errors.New("created")
}`,
		},
		{
			name: "NewError",
			code: `package main

import "errors"

func NewError(msg string) error {
	return errors.New(msg)
}`,
		},
		{
			name: "Wrap",
			code: `package main

import "fmt"

func Wrap(err error) error {
	return fmt.Errorf("wrapped: %w", err)
}`,
		},
		{
			name: "wrapError (unexported)",
			code: `package main

import "fmt"

func wrapError(err error) error {
	return fmt.Errorf("wrapped: %w", err)
}`,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			helperNoViolationExpected(
				t,
				tt.code,
				types.ErrorTypeGenericReturn,
				"Constructor/wrapper function should NOT be flagged as generic_return",
			)
		})
	}
}

func TestGenericReturn_ParseFunctionExcluded(t *testing.T) {
	tests := []struct {
		name string
		code string
	}{
		{
			name: "ParseSeverity (exported)",
			code: `package main

import "errors"

func ParseSeverity(input string) (string, error) {
	if input == "" {
		return "", errors.New("empty input")
	}
	return input, nil
}`,
		},
		{
			name: "parseType (unexported)",
			code: `package main

import "errors"

func parseType(input string) (string, error) {
	if input == "" {
		return "", errors.New("empty")
	}
	return input, nil
}`,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			helperNoViolationExpected(
				t,
				tt.code,
				types.ErrorTypeGenericReturn,
				"Parse function should NOT be flagged as generic_return",
			)
		})
	}
}

func TestGenericReturn_PureForwarderExcluded(t *testing.T) {
	tests := []struct {
		name string
		code string
	}{
		{
			name: "forward parameter error",
			code: `package main

func proxy(err error) error {
	return err
}`,
		},
		{
			name: "forward from call",
			code: `package main

func handler() error {
	err := doSomething()
	return err
}

func doSomething() error {
	return nil
}`,
		},
		{
			name: "forward through conditional",
			code: `package main

func guard(err error) error {
	if err != nil {
		return err
	}
	return nil
}`,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			helperNoViolationExpected(
				t,
				tt.code,
				types.ErrorTypeGenericReturn,
				"Pure forwarder should NOT be flagged as generic_return",
			)
		})
	}
}

func TestGenericReturn_ErrorCreatorStillFlagged(t *testing.T) {
	tests := []struct {
		name string
		code string
	}{
		{
			name: "errors.New creator",
			code: `package main

import "errors"

func doWork() error {
	return errors.New("work failed")
}`,
		},
		{
			name: "fmt.Errorf creator",
			code: `package main

import "fmt"

func fail() error {
	return fmt.Errorf("something broke")
}`,
		},
		{
			name: "errors.Join creator",
			code: `package main

import "errors"

var ErrA = errors.New("a")
var ErrB = errors.New("b")

func multiError() error {
	return errors.Join(ErrA, ErrB)
}`,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, graph := helperParseAndAnalyzeWithOptions(t, tt.code, WithEnforceGenericReturn(true))
			found := false
			for _, v := range graph.Violations {
				if v.Type == types.ErrorTypeGenericReturn {
					found = true
					break
				}
			}
			if !found {
				t.Errorf("Expected generic_return violation for error-creating function %q", tt.name)
			}
		})
	}
}

func TestGenericReturn_OffByDefault(t *testing.T) {
	code := `package main

import "errors"

func doWork() error {
	return errors.New("work failed")
}`

	_, graph := helperParseAndAnalyze(t, code)
	for _, v := range graph.Violations {
		if v.Type == types.ErrorTypeGenericReturn {
			t.Errorf("generic_return should NOT fire by default (opt-in only); got: %s", v.Message)
		}
	}
}
