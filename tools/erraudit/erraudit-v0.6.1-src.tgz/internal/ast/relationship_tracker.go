package ast

import (
	"slices"
	"unsafe"

	"github.com/larsartmann/erraudit/pkg/types"
)

// RelationshipTracker manages error relationships and scope.
type RelationshipTracker struct {
	analyzer *Analyzer

	// Cached adjacency maps for O(1) lookups
	parentToChildren map[string][]string // parent -> children
	childToParents   map[string][]string // child -> parents (a child can have multiple parents)
	depthCache       map[string]uint     // error name -> depth
	chainCache       map[string][]string // error name -> full root-to-error chain
	siblingsCache    map[string][]string // error name -> sibling error names
	cacheBuilt       bool
}

// NewRelationshipTracker creates a new relationship tracker.
func NewRelationshipTracker(analyzer *Analyzer) *RelationshipTracker {
	return &RelationshipTracker{analyzer: analyzer}
}

// resetCaches reinitializes the adjacency maps and all derived caches. Called
// from the constructor, buildCache (when rebuilding), and invalidateCache (when
// relationships change) — keeping the three sites consistent.
func (t *RelationshipTracker) resetCaches() {
	t.parentToChildren = make(map[string][]string)
	t.childToParents = make(map[string][]string)
	t.depthCache = make(map[string]uint)
	t.chainCache = make(map[string][]string)
	t.siblingsCache = make(map[string][]string)
}

// buildCache builds the adjacency maps from relationships.
func (t *RelationshipTracker) buildCache() {
	if t.cacheBuilt {
		return
	}

	// Clear any existing cache
	t.resetCaches()

	for _, rel := range t.analyzer.relationships {
		t.parentToChildren[rel.Parent] = append(t.parentToChildren[rel.Parent], rel.Child)
		t.childToParents[rel.Child] = append(t.childToParents[rel.Child], rel.Parent)
	}

	t.cacheBuilt = true
}

// invalidateCache clears the cache when relationships change.
func (t *RelationshipTracker) invalidateCache() {
	t.cacheBuilt = false
	t.resetCaches()
}

// forEachNamedError ensures the relationship cache is built and invokes fn
// for each named error's name. Centralizes the cache-ensure + iterate prelude
// shared by GetRootErrors, GetLongestChain, and GetHierarchyDepth.
func (t *RelationshipTracker) forEachNamedError(fn func(name string)) {
	t.buildCache()

	for _, err := range t.analyzer.namedErrors {
		fn(err.Name)
	}
}

// GetWrappedErrors returns all errors that wrap a specific error.
func (t *RelationshipTracker) GetWrappedErrors(parentName string) []string {
	t.buildCache()

	return t.parentToChildren[parentName]
}

// GetRootErrors returns errors that have no parent (not wrapped).
func (t *RelationshipTracker) GetRootErrors() []string {
	var roots []string

	t.forEachNamedError(func(name string) {
		if len(t.childToParents[name]) == 0 {
			roots = append(roots, name)
		}
	})

	return roots
}

// GetRelationshipDepth calculates the depth of an error in the hierarchy.
// Delegates the parent-chain walk to assignChainDepths (shared with
// computeDepths in the finalizer), using depthCache as the persistent
// memoization map so repeated calls reuse prior results.
func (t *RelationshipTracker) GetRelationshipDepth(errorName string) uint {
	t.buildCache()

	if depth, ok := t.depthCache[errorName]; ok {
		return depth
	}

	assignChainDepths(t.childToParents, errorName, t.depthCache)

	return t.depthCache[errorName]
}

// HasCyclicDependency checks if adding a relationship would create a cycle.
//
// When existingRelationships is the tracker's own relationship slice (verified
// by backing-array identity, not just length), the cached adjacency map is used
// for O(1) lookups instead of rebuilding from the slice. A same-length slice
// from a different source correctly falls back to the rebuild path — this was
// a latent bug when only length was compared.
func (t *RelationshipTracker) HasCyclicDependency(
	parent, child string,
	existingRelationships []types.ErrorRelationship,
) bool {
	// Fast path: use cached adjacency map when the caller passed the
	// tracker's own relationship slice (same backing array + length).
	if t.analyzer != nil && sameBackingArray(existingRelationships, t.analyzer.relationships) {
		t.buildCache()

		return bfsReachable(t.childToParents, parent, child)
	}

	// Fallback: rebuild from external slice for custom relationship sets
	// or when the tracker has no analyzer (e.g. bare-struct benchmarks).
	childToParents := make(map[string][]string, len(existingRelationships))
	for _, rel := range existingRelationships {
		childToParents[rel.Child] = append(childToParents[rel.Child], rel.Parent)
	}

	childToParents[child] = append(childToParents[child], parent)

	return bfsReachable(childToParents, parent, child)
}

// sameBackingArray reports whether two slices share the same underlying array
// and have the same length. Two empty slices are NOT considered the same
// (they may come from different sources), which is safe because an empty
// relationship set produces the same result either way.
func sameBackingArray[T any](a, b []T) bool {
	if len(a) != len(b) || len(a) == 0 {
		return false
	}

	return unsafe.SliceData(a) == unsafe.SliceData(b)
}

// bfsReachable reports whether target is reachable from start by following
// parent links (child-to-parent direction) in the adjacency map.
func bfsReachable(childToParents map[string][]string, start, target string) bool {
	visited := make(map[string]bool)
	queue := []string{start}

	for len(queue) > 0 {
		current := queue[0]
		queue = queue[1:]

		if current == target {
			return true
		}

		if visited[current] {
			continue
		}

		visited[current] = true
		queue = append(queue, childToParents[current]...)
	}

	return false
}

// assignChainDepths walks the parent chain from start toward a root (or a node
// whose depth is already cached in depths), then assigns depths to every node
// along the path. The depths map serves as both the memoization cache and the
// output: intermediate nodes in a shared chain are computed only once.
//
// Uses parents[0] for traversal — consistent across all callers. Shared by
// computeDepths (batch, hierarchy_finalizer.go) and
// RelationshipTracker.GetRelationshipDepth (single-node, instance cache).
func assignChainDepths(childToParents map[string][]string, start string, depths map[string]uint) {
	if _, ok := depths[start]; ok {
		return
	}

	var path []string

	visited := make(map[string]bool)

	current := start

	for !visited[current] {
		if d, ok := depths[current]; ok {
			for i, v := range slices.Backward(path) {
				depths[v] = d + uint(len(path)-i)
			}

			return
		}

		visited[current] = true
		path = append(path, current)

		parents := childToParents[current]
		if len(parents) == 0 {
			for i, v := range slices.Backward(path) {
				depths[v] = uint(len(path) - 1 - i)
			}

			return
		}

		current = parents[0]
	}
}

// buildChainToRoot returns the ordered chain from the root ancestor of start
// down to start itself: [root, ..., start]. Traversal follows parents[0],
// consistent with assignChainDepths. Cycle-safe via a visited set. Shared by
// RelationshipTracker.GetErrorChain (cached, instance-backed) and
// finalizeSummary (uncached, map-backed) so per-file and post-merge paths
// produce identical chains for the same graph.
func buildChainToRoot(childToParents map[string][]string, start string) []string {
	var chain []string

	current := start

	visited := make(map[string]bool)

	for !visited[current] {
		visited[current] = true
		chain = append(chain, current)

		parents := childToParents[current]
		if len(parents) == 0 {
			break
		}

		current = parents[0]
	}

	slices.Reverse(chain)

	return chain
}

// GetErrorChain returns the complete chain from root to the error.
// Results are memoized: repeated calls for the same error name return the
// cached slice without re-walking the parent chain. The returned slice is
// shared and must not be mutated by callers.
func (t *RelationshipTracker) GetErrorChain(errorName string) []string {
	t.buildCache()

	if cached, ok := t.chainCache[errorName]; ok {
		return cached
	}

	chain := buildChainToRoot(t.childToParents, errorName)
	t.chainCache[errorName] = chain

	return chain
}

// GetStatistics returns statistics about the error relationships.
func (t *RelationshipTracker) GetStatistics() map[string]int {
	t.buildCache()

	stats := make(map[string]int)

	// Count by relationship type
	wraps := 0
	aliases := 0
	maxDepth := uint(0)

	for _, rel := range t.analyzer.relationships {
		if rel.RelationshipType == types.RelationshipTypeWraps {
			wraps++
		} else {
			aliases++
		}

		depth := t.GetRelationshipDepth(rel.Parent)
		if depth > maxDepth {
			maxDepth = depth
		}
	}

	stats["totalRelationships"] = len(t.analyzer.relationships)
	stats["wraps"] = wraps
	stats["aliases"] = aliases
	stats["maxDepth"] = int(maxDepth)
	stats["totalNamedErrors"] = len(t.analyzer.namedErrors)
	stats["rootErrors"] = len(t.GetRootErrors())

	return stats
}

// dedupeRelationships removes duplicate parent→child relationships,
// preserving first occurrence and order.
func dedupeRelationships(rels []types.ErrorRelationship) []types.ErrorRelationship {
	seen := make(map[string]bool, len(rels))

	unique := make([]types.ErrorRelationship, 0, len(rels))

	for _, rel := range rels {
		key := rel.Parent + "->" + rel.Child
		if !seen[key] {
			seen[key] = true

			unique = append(unique, rel)
		}
	}

	return unique
}

// removeCycles filters out relationships that would create cycles.
// Relationships are processed in order; when adding an edge would close
// a cycle, it is dropped. Uses an incrementally-maintained adjacency map
// so each reachability check is a single BFS — no per-iteration map rebuild.
func removeCycles(rels []types.ErrorRelationship) []types.ErrorRelationship {
	childToParents := make(map[string][]string, len(rels))
	clean := make([]types.ErrorRelationship, 0, len(rels))

	for _, rel := range rels {
		childToParents[rel.Child] = append(childToParents[rel.Child], rel.Parent)

		if bfsReachable(childToParents, rel.Parent, rel.Child) {
			parents := childToParents[rel.Child]
			childToParents[rel.Child] = parents[:len(parents)-1]

			continue
		}

		clean = append(clean, rel)
	}

	return clean
}

// ConsolidateDuplicateRelationships removes duplicate relationships.
func (t *RelationshipTracker) ConsolidateDuplicateRelationships() {
	t.analyzer.relationships = dedupeRelationships(t.analyzer.relationships)
	t.invalidateCache()
}

// RemoveCyclicRelationships filters out relationships that would create
// cycles in the error hierarchy. Relationships are processed in order;
// when adding a relationship would close a cycle, it is dropped.
//
// This prevents infinite loops during hierarchy tree construction and
// depth computation. In valid Go code, circular error wrapping cannot
// occur (the compiler rejects circular variable initialization), so this
// is a safety net for edge cases like cross-file analysis or analyzer bugs.
func (t *RelationshipTracker) RemoveCyclicRelationships() {
	t.analyzer.relationships = removeCycles(t.analyzer.relationships)
	t.invalidateCache()
}

// GetSiblings returns all errors that share the same child (sibling relationships).
// Errors are siblings if they wrap the same child.
// For example, if ErrUserNotFound and ErrProductNotFound both wrap ErrNotFound,
// they are siblings because they share the same child (ErrNotFound).
// Results are memoized: repeated calls for the same error name return the
// cached slice without re-scanning all relationships. The returned slice is
// shared and must not be mutated by callers.
func (t *RelationshipTracker) GetSiblings(errorName string) []string {
	t.buildCache()

	if cached, ok := t.siblingsCache[errorName]; ok {
		return cached
	}

	siblings := t.computeSiblings(errorName)
	t.siblingsCache[errorName] = siblings

	return siblings
}

// computeSiblings scans all relationships for errors that wrap any of the
// same children as errorName.
func (t *RelationshipTracker) computeSiblings(errorName string) []string {
	// Find what errorName wraps (its child in the relationship)
	children := t.parentToChildren[errorName]
	if len(children) == 0 {
		return nil // This error wraps nothing, so no siblings
	}

	// Find all other errors that wrap any of the same children
	var siblings []string

	siblingsMap := make(map[string]bool)

	for _, child := range children {
		// Find all parents that wrap this child
		for _, parent := range t.childToParents[child] {
			if parent != errorName && !siblingsMap[parent] {
				siblings = append(siblings, parent)
				siblingsMap[parent] = true
			}
		}
	}

	return siblings
}

// GetSiblingsCount returns the number of siblings an error has.
func (t *RelationshipTracker) GetSiblingsCount(errorName string) int {
	return len(t.GetSiblings(errorName))
}

// GetBranchingFactor returns the average number of children per parent.
// This indicates how "branchy" the error hierarchy is.
func (t *RelationshipTracker) GetBranchingFactor() float64 {
	t.buildCache()

	if len(t.parentToChildren) == 0 {
		return 0
	}

	totalChildren := 0
	for _, children := range t.parentToChildren {
		totalChildren += len(children)
	}

	return float64(totalChildren) / float64(len(t.parentToChildren))
}

// GetMaxBranchingFactor returns the maximum number of children for any single parent.
// This identifies the most "popular" parent error. Ties break to the
// lexicographically smallest parent name for deterministic output.
func (t *RelationshipTracker) GetMaxBranchingFactor() (string, int) {
	t.buildCache()

	parent, count := maxBranching(t.parentToChildren)

	return parent, count
}

// maxBranching returns the parent with the most children and that count,
// breaking ties lexicographically (smallest name wins). Shared by the tracker
// (GetMaxBranchingFactor) and the finalizer (finalizeSummary).
func maxBranching(parentToChildren map[string][]string) (string, int) {
	maxCount := 0
	maxParent := ""

	for parent, children := range parentToChildren {
		switch {
		case len(children) > maxCount:
			maxCount = len(children)
			maxParent = parent
		case len(children) == maxCount && maxCount > 0 && parent < maxParent:
			maxParent = parent
		}
	}

	return maxParent, maxCount
}

// GetLongestChain returns the longest chain of wrapping relationships.
func (t *RelationshipTracker) GetLongestChain() []string {
	var longestChain []string

	t.forEachNamedError(func(name string) {
		chain := t.GetErrorChain(name)
		if len(chain) > len(longestChain) {
			longestChain = chain
		}
	})

	return longestChain
}

// GetHierarchyDepth returns the maximum depth of the hierarchy.
func (t *RelationshipTracker) GetHierarchyDepth() uint {
	maxDepth := uint(0)

	t.forEachNamedError(func(name string) {
		depth := t.GetRelationshipDepth(name)
		if depth > maxDepth {
			maxDepth = depth
		}
	})

	return maxDepth
}

// GetHierarchySummary returns a comprehensive summary of the error hierarchy.
func (t *RelationshipTracker) GetHierarchySummary() HierarchySummary {
	t.buildCache()

	summary := HierarchySummary{
		TotalErrors:        len(t.analyzer.namedErrors),
		TotalRelationships: len(t.analyzer.relationships),
		RootErrors:         len(t.GetRootErrors()),
		MaxDepth:           t.GetHierarchyDepth(),
	}

	// Calculate branching statistics
	summary.AvgBranchingFactor = t.GetBranchingFactor()
	summary.MaxBranchingParent, summary.MaxBranchingCount = t.GetMaxBranchingFactor()

	// Get longest chain
	longestChain := t.GetLongestChain()
	summary.LongestChainLength = len(longestChain)

	summary.LongestChainRoot = ""
	if len(longestChain) > 0 {
		summary.LongestChainRoot = longestChain[0]
	}

	return summary
}

// HierarchySummary provides a comprehensive summary of the error hierarchy.
type HierarchySummary struct {
	TotalErrors        int
	TotalRelationships int
	RootErrors         int
	MaxDepth           uint
	AvgBranchingFactor float64
	MaxBranchingParent string
	MaxBranchingCount  int
	LongestChainLength int
	LongestChainRoot   string
}
