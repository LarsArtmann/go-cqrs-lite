package ast

import (
	"github.com/larsartmann/erraudit/pkg/types"
)

// HierarchyBuilder constructs the error hierarchy from discovered errors.
type HierarchyBuilder struct {
	namedErrors   []types.NamedError
	relationships []types.ErrorRelationship
}

// NewHierarchyBuilder creates a new hierarchy builder.
func NewHierarchyBuilder(
	namedErrors []types.NamedError,
	relationships []types.ErrorRelationship,
) *HierarchyBuilder {
	return &HierarchyBuilder{
		namedErrors:   namedErrors,
		relationships: relationships,
	}
}

// Build constructs the error hierarchy.
func (hb *HierarchyBuilder) Build() *types.ErrorHierarchy {
	hierarchy := &types.ErrorHierarchy{
		AllNodes:      make(map[string]*types.ErrorNode),
		Relationships: hb.relationships,
		NamedErrors:   hb.namedErrors,
		Metrics: types.HierarchyMetrics{
			WrapCount: make(map[string]uint),
		},
	}

	// First pass: create all nodes
	for _, namedErr := range hb.namedErrors {
		node := &types.ErrorNode{
			Name:        namedErr.Name,
			Message:     namedErr.Message,
			Kind:        namedErr.Kind,
			Position:    namedErr.Position,
			Children:    make([]*types.ErrorNode, 0),
			Depth:       0,
			Occurrences: 1,
		}
		hierarchy.AllNodes[namedErr.Name] = node
		hierarchy.RootErrors = append(hierarchy.RootErrors, node)
	}

	// Second pass: link parent-child relationships and tally wrap counts.
	for _, rel := range hb.relationships {
		if parentNode, ok := hierarchy.AllNodes[rel.Parent]; ok {
			if childNode, ok := hierarchy.AllNodes[rel.Child]; ok {
				parentNode.Children = append(parentNode.Children, childNode)
				childNode.Depth = rel.Depth + 1

				// Remove child from root errors if it has a parent
				hierarchy.RootErrors = removeErrorNode(hierarchy.RootErrors, rel.Child)

				// Tally both endpoints so MostWrappedError reflects total
				// participation in wrapping relationships — consistent with
				// FinalizeHierarchy (which also counts parent + child).
				hierarchy.Metrics.WrapCount[rel.Child]++
				hierarchy.Metrics.WrapCount[rel.Parent]++
			}
		}
	}

	// Calculate metrics
	hierarchy.Metrics.TotalNamedErrors = uint(len(hb.namedErrors))
	hierarchy.Metrics.TotalRelationships = uint(len(hb.relationships))
	hierarchy.Metrics.SentinelErrors = uint(
		countErrorKinds(hb.namedErrors, types.ErrorKindSentinel),
	)
	hierarchy.Metrics.CustomErrorTypes = uint(
		countErrorKinds(hb.namedErrors, types.ErrorKindCustom),
	)
	mostWrapped, mostWrappedCount := types.MostWrappedFromCounts(hierarchy.Metrics.WrapCount)
	hierarchy.Metrics.MostWrappedError = mostWrapped
	hierarchy.Metrics.MostWrappedErrorOccurrences = mostWrappedCount

	for _, rel := range hb.relationships {
		if rel.Depth > hierarchy.Metrics.MaxDepth {
			hierarchy.Metrics.MaxDepth = rel.Depth
			hierarchy.Metrics.DeepestError = rel.Parent
		}
	}

	return hierarchy
}

// removeErrorNode removes a node from the slice by name.
func removeErrorNode(nodes []*types.ErrorNode, name string) []*types.ErrorNode {
	for i, node := range nodes {
		if node.Name == name {
			return append(nodes[:i], nodes[i+1:]...)
		}
	}

	return nodes
}

// countErrorKinds counts errors of a specific kind.
func countErrorKinds(errors []types.NamedError, kind types.ErrorKind) int {
	count := 0

	for _, err := range errors {
		if err.Kind == kind {
			count++
		}
	}

	return count
}
