package ast

// analyzer_basic_test.go contains basic analyzer tests covering core functionality
// including error detection, wrapping, checking, and metrics calculation.

import (
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
)

func TestAnalyzer_Analyze(t *testing.T) {
	code := `
package main

import (
	"errors"
	"fmt"
)

func process() error {
	return errors.New("error")
}

func wrapError(err error) error {
	return fmt.Errorf("wrapped: %w", err)
}

func badWrap(err error) error {
	return fmt.Errorf("bad: %v", err)
}

func panicOnError(err error) {
	if err != nil {
		panic(err)
	}
}

func checkError(err error) error {
	if err != nil {
		return fmt.Errorf("check: %w", err)
	}
	return nil
}`

	helperAnalysisTest(t, code, func(analyzer *Analyzer, graph *types.ErrorGraph) {
		// Verify graph is created
		if graph == nil {
			t.Fatal("Expected graph to be created")
		}

		// Verify package name
		if graph.Package != "main" {
			t.Errorf("Expected package 'main', got '%s'", graph.Package)
		}

		// Verify errors are detected
		if len(graph.Errors) == 0 {
			t.Error("Expected to find errors")
		}
	})
}

func TestAnalyzer_ErrorReturns(t *testing.T) {
	code := `
package main

import "errors"

func returnsError() error {
	return errors.New("test error")
}`

	helperErrorTypeTest(t, code, types.ErrorTypeReturn, "error return")
}

func TestAnalyzer_ErrorWrapping(t *testing.T) {
	code := `
package main

import "fmt"

func wrap(err error) error {
	return fmt.Errorf("wrapped: %w", err)
}`

	helperErrorTypeTest(t, code, types.ErrorTypeWrapping, "error wrapping")
}

func TestAnalyzer_ErrorCheck(t *testing.T) {
	code := `
package main

func process(err error) error {
	if err != nil {
		return err
	}
	return nil
}`

	helperErrorTypeTest(t, code, types.ErrorTypeCheck, "error check")
}

func TestAnalyzer_BadWrapping(t *testing.T) {
	code := `
package main

import "fmt"

func badWrap(err error) error {
	return fmt.Errorf("bad: %v", err)
}`

	helperViolationTest(t, code, types.ErrorTypeUnwrapped, nil)
}

func TestAnalyzer_PanicOnError(t *testing.T) {
	code := `
package main

func panicOnError(err error) {
	if err != nil {
		panic(err)
	}
}`

	helperViolationTest(t, code, types.ErrorTypePanic, nil)
}

func TestAnalyzer_Metrics(t *testing.T) {
	code := `
package main

import (
	"errors"
	"fmt"
)

func f1() error {
	return errors.New("e1")
}

func f2() error {
	err := f1()
	return fmt.Errorf("e2: %w", err)
}`

	helperAnalysisTest(t, code, func(analyzer *Analyzer, graph *types.ErrorGraph) {
		// Verify metrics
		helperAssertTotalNonZero(t, graph)

		if graph.Metrics.ErrorReturns == 0 {
			t.Error("Expected non-zero error returns")
		}

		if graph.Metrics.ErrorWraps == 0 {
			t.Error("Expected non-zero error wraps")
		}
	})
}
