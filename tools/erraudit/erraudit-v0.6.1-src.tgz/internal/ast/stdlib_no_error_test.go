package ast

// stdlib_no_error_test.go contains regression tests for the stdlib
// no-error-return table in predicates.go (2026-09-11).
//
// Without type info (the default `erraudit ./...` mode), the blank-identifier
// check could not resolve stdlib signatures and conservatively flagged every
// blank position — including non-error values like the middle `after` return
// of strings.Cut or a deliberately discarded fmt.Sprintf result. The table
// (stdlibNoErrorReturnFuncs) closes that FP class for curated stdlib
// functions, verified against the file's imports so a project package
// imported under a stdlib name still resolves conservatively.
//
//   - TestStdlibNoErrorReturn_CutMiddleBlank_NotFlagged            (the reported FP)
//   - TestStdlibNoErrorReturn_SprintfDiscard_NotFlagged
//   - TestStdlibNoErrorReturn_ProjectPackageUnderStdlibName_StillFlagged
//   - TestStdlibNoErrorReturn_NoSuppress_StillFlagged
//   - TestStdlibNoErrorReturn_ErrorReturningStdlib_StillFlagged

import (
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
)

func TestStdlibNoErrorReturn_CutMiddleBlank_NotFlagged(t *testing.T) {
	code := `
package main

import "strings"

func parse(spec string) string {
	if beforeReason, _, hasReason := strings.Cut(spec, "//"); hasReason {
		spec = beforeReason
	}
	return spec
}`
	helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
		helperAssertNoViolationsOf(t, graph, types.ErrorTypeIgnored,
			"strings.Cut middle blank discards a string, not an error")
	})
}

func TestStdlibNoErrorReturn_SprintfDiscard_NotFlagged(t *testing.T) {
	code := `
package main

import "fmt"

func banner(name string) {
	_ = fmt.Sprintf("hello %s", name)
}`
	helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
		helperAssertNoViolationsOf(t, graph, types.ErrorTypeIgnored,
			"fmt.Sprintf returns a single string, no error")
	})
}

func TestStdlibNoErrorReturn_ProjectPackageUnderStdlibName_StillFlagged(t *testing.T) {
	code := `
package main

import "example.com/project/strings"

func parse(spec string) string {
	before, _, sepFound := strings.Cut(spec, ":")
	if sepFound {
		return before
	}
	return spec
}`
	helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
		v := helperFindViolation(graph, types.ErrorTypeIgnored)
		if v == nil {
			t.Errorf("Expected ignored violation: project package imported under " +
				"a stdlib name must resolve conservatively")
		}
	})
}

func TestStdlibNoErrorReturn_NoSuppress_StillFlagged(t *testing.T) {
	code := `
package main

import "strings"

func parse(spec string) string {
	before, _, found := strings.Cut(spec, ":")
	if found {
		return before
	}
	return spec
}`
	_, graph := helperParseAndAnalyzeWithOptions(t, code, WithNoSuppress(true))
	v := helperFindViolation(graph, types.ErrorTypeIgnored)
	if v == nil {
		t.Errorf("Expected ignored violation under --no-suppress: audit mode " +
			"bypasses all suppression heuristics, including the stdlib table")
	}
}

func TestStdlibNoErrorReturn_ErrorReturningStdlib_StillFlagged(t *testing.T) {
	code := `
package main

import "fmt"

func logCount() {
	_, _ = fmt.Println("count")
}`
	helperAnalysisTest(t, code, func(_ *Analyzer, graph *types.ErrorGraph) {
		v := helperFindViolation(graph, types.ErrorTypeIgnored)
		if v == nil {
			t.Errorf("Expected ignored violation: fmt.Println returns (int, error); " +
				"the error position must still be flagged")
		}
	})
}
