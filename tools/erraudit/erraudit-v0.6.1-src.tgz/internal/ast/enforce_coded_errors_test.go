package ast

import (
	"go/parser"
	"go/token"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func analyzeWithCodedErrors(t *testing.T, code string, enforce bool) *types.ErrorGraph {
	t.Helper()

	fset := token.NewFileSet()

	node, err := parser.ParseFile(fset, "", code, parser.AllErrors)
	require.NoError(t, err, "Failed to parse code")

	opts := []AnalyzerOption{}
	if enforce {
		opts = append(opts, WithEnforceCodedErrors(true))
	}

	analyzer := NewAnalyzer(fset, "main", "test.go", opts...)

	return analyzer.Analyze(node)
}

func findUncodedViolations(t *testing.T, graph *types.ErrorGraph) []types.ErrorViolation {
	t.Helper()

	var result []types.ErrorViolation

	for _, v := range graph.Violations {
		if v.Type == types.ErrorTypeUncodedConstructor {
			result = append(result, v)
		}
	}

	return result
}

// TestEnforceCodedErrors_FlagOff verifies neutrality: with enforcement OFF,
// empty-code constructor calls produce zero findings.
func TestEnforceCodedErrors_FlagOff(t *testing.T) {
	t.Parallel()

	code := `package main

import errorfamily "github.com/larsartmann/go-error-family"

var ErrA error = errorfamily.NewRejection("", "uncoded")`

	graph := analyzeWithCodedErrors(t, code, false)

	assert.Empty(t, findUncodedViolations(t, graph), "flag OFF must produce zero uncoded-constructor findings")
}

// TestEnforceCodedErrors_FlagOn verifies that empty-string code literals are
// flagged across constructor shapes (family-specific New/Wrap, formatted
// variants, generic New/Wrap, and empty backtick literals).
func TestEnforceCodedErrors_FlagOn(t *testing.T) {
	t.Parallel()

	code := `package main

import errorfamily "github.com/larsartmann/go-error-family"

var ErrA error = errorfamily.NewRejection("", "uncoded")
var ErrB error = errorfamily.New(errorfamily.Rejection, "", "uncoded generic")
var ErrC error = errorfamily.WrapRejectionf(ErrA, "", "uncoded wrapf %d", 1)
var ErrD error = errorfamily.Wrap(ErrA, errorfamily.Rejection, "", "uncoded generic wrap")
var ErrE error = errorfamily.NewRejection(` + "`" + "`" + `, "uncoded backtick")`

	graph := analyzeWithCodedErrors(t, code, true)

	violations := findUncodedViolations(t, graph)
	assert.Len(t, violations, 5, "all five empty-code constructor calls must be flagged")
}

// TestEnforceCodedErrors_NonLiteralCodeNotFlagged verifies that non-literal
// code arguments (variables, constants, function calls like code inheritance)
// are never flagged — they are deliberate dynamic choices.
func TestEnforceCodedErrors_NonLiteralCodeNotFlagged(t *testing.T) {
	t.Parallel()

	code := `package main

import errorfamily "github.com/larsartmann/go-error-family"

const code = "config.invalid"

var ErrA error = errorfamily.NewRejection(code, "const code")
var ErrB error = errorfamily.WrapRejectionf(ErrA, errorfamily.Code(ErrA), "inherited %s", "code")`

	graph := analyzeWithCodedErrors(t, code, true)

	assert.Empty(t, findUncodedViolations(t, graph), "non-literal code arguments must not be flagged")
}

// TestEnforceCodedErrors_NonEmptyCodeNotFlagged verifies that populated code
// literals pass.
func TestEnforceCodedErrors_NonEmptyCodeNotFlagged(t *testing.T) {
	t.Parallel()

	code := `package main

import errorfamily "github.com/larsartmann/go-error-family"

var ErrA error = errorfamily.NewRejection("config.invalid", "coded")`

	graph := analyzeWithCodedErrors(t, code, true)

	assert.Empty(t, findUncodedViolations(t, graph), "populated code literals must not be flagged")
}

// TestEnforceCodedErrors_AliasedImportNotFlagged verifies that a generic
// constructor name reached through a non-errorfamily selector is not flagged
// (generic constructors require the canonical package name).
func TestEnforceCodedErrors_AliasedImportNotFlagged(t *testing.T) {
	t.Parallel()

	code := `package main

type Rejection string

func New(family Rejection, code, message string) error { return nil }

var err = New(Rejection("x"), "", "some other package named differently")`

	graph := analyzeWithCodedErrors(t, code, true)

	assert.Empty(t, findUncodedViolations(t, graph), "same-shaped constructors from other packages must not be flagged")
}
