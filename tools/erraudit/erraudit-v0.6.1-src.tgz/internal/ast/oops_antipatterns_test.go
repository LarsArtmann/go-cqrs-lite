package ast

import (
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
)

func TestOopsRedundantGuard_WrapPattern(t *testing.T) {
	t.Parallel()

	code := `package main

import "github.com/samber/oops"

func process() error {
	err := step()
	if err != nil {
		return oops.Wrap(err)
	}
	return nil
}

func step() error { return nil }`
	graph := helperParseWithOopsEnforcement(t, code, true)

	violations := findOopsRedundantGuardViolations(t, graph)
	if assert.Len(t, violations, 1, "should detect the redundant nil guard") {
		assert.Equal(t, types.SeverityLow, violations[0].Severity)
		assert.Contains(t, violations[0].Message, "oops.Wrap")
		assert.Contains(t, violations[0].Message, "Redundant")
		assert.Contains(t, violations[0].Suggestion, "return oops.Wrap(err)")
	}
}

func TestOopsRedundantGuard_WrapfPattern(t *testing.T) {
	t.Parallel()

	code := `package main

import "github.com/samber/oops"

func process() error {
	err := step()
	if err != nil {
		return oops.Wrapf(err, "processing failed")
	}
	return nil
}

func step() error { return nil }`
	graph := helperParseWithOopsEnforcement(t, code, true)

	violations := findOopsRedundantGuardViolations(t, graph)
	if assert.Len(t, violations, 1) {
		assert.Contains(t, violations[0].Message, "oops.Wrapf")
		assert.Contains(t, violations[0].Suggestion, "oops.Wrapf(err)")
	}
}

func TestOopsRedundantGuard_NotFlaggedWhenOff(t *testing.T) {
	t.Parallel()

	code := `package main

import "github.com/samber/oops"

func process() error {
	err := step()
	if err != nil {
		return oops.Wrap(err)
	}
	return nil
}

func step() error { return nil }`
	graph := helperParseWithOopsEnforcement(t, code, false)

	violations := findOopsRedundantGuardViolations(t, graph)
	assert.Empty(t, violations, "anti-pattern detection should not run when enforcement is off")
}

func TestOopsRedundantGuard_NotFlaggedWhenFollowedByWork(t *testing.T) {
	t.Parallel()

	// The nil guard is NOT redundant when there is work between the if and the return
	code := `package main

import "github.com/samber/oops"

func process() error {
	err := step()
	if err != nil {
		return oops.Wrap(err)
	}
	cleanup()
	return nil
}

func step() error { return nil }
func cleanup() {}`
	graph := helperParseWithOopsEnforcement(t, code, true)

	violations := findOopsRedundantGuardViolations(t, graph)
	assert.Empty(t, violations, "should not flag when there is work between if and return nil")
}

func TestOopsRedundantGuard_NotFlaggedForNonOopsWrap(t *testing.T) {
	t.Parallel()

	// fmt.Errorf does NOT return nil for nil input — the guard is necessary
	code := `package main

import "fmt"

func process() error {
	err := step()
	if err != nil {
		return fmt.Errorf("failed: %w", err)
	}
	return nil
}

func step() error { return nil }`
	graph := helperParseWithOopsEnforcement(t, code, true)

	violations := findOopsRedundantGuardViolations(t, graph)
	assert.Empty(t, violations, "should not flag non-oops wrap calls")
}

func TestOopsRedundantGuard_NotFlaggedWithElse(t *testing.T) {
	t.Parallel()

	code := `package main

import "github.com/samber/oops"

func process() error {
	err := step()
	if err != nil {
		return oops.Wrap(err)
	} else {
		return nil
	}
}

func step() error { return nil }`
	graph := helperParseWithOopsEnforcement(t, code, true)

	violations := findOopsRedundantGuardViolations(t, graph)
	assert.Empty(t, violations, "should not flag when there is an else clause")
}

func TestOopsRedundantGuard_ErrVarNotFirstArg(t *testing.T) {
	t.Parallel()

	// If the wrap call wraps a DIFFERENT error, the guard is not redundant
	code := `package main

import "github.com/samber/oops"

var ErrSentinel = oops.Errorf("sentinel")

func process() error {
	err := step()
	if err != nil {
		return oops.Wrap(ErrSentinel)
	}
	return nil
}

func step() error { return nil }`
	graph := helperParseWithOopsEnforcement(t, code, true)

	violations := findOopsRedundantGuardViolations(t, graph)
	assert.Empty(t, violations, "should not flag when wrap target differs from guarded variable")
}

func TestOopsRedundantGuard_Wrap2GenericVariant(t *testing.T) {
	t.Parallel()

	code := `package main

import "github.com/samber/oops"

func process() (int, error) {
	err := step()
	if err != nil {
		val, err2 := oops.Wrap2(err)
		return val, err2
	}
	return 0, nil
}

func step() error { return nil }`
	graph := helperParseWithOopsEnforcement(t, code, true)

	violations := findOopsRedundantGuardViolations(t, graph)
	// Wrap2 is a generic multi-return variant — detection should recognize it
	// Note: the current detector checks isOopsWrapCall which handles Wrap2..Wrap10
	// but only flags single-return statements. Wrap2 returns two values so it won't
	// match singleReturnFromBody with len(Results)==1. This test documents that.
	_ = violations // no violation expected for multi-return pattern
}

func TestOopsRedundantGuard_NilNotEqualErrOrdering(t *testing.T) {
	t.Parallel()

	// `nil != err` is valid Go and should be detected the same as `err != nil`
	code := `package main

import "github.com/samber/oops"

func process() error {
	err := step()
	if nil != err {
		return oops.Wrap(err)
	}
	return nil
}

func step() error { return nil }`
	graph := helperParseWithOopsEnforcement(t, code, true)

	violations := findOopsRedundantGuardViolations(t, graph)
	if assert.Len(t, violations, 1, "should detect nil != err ordering") {
		assert.Contains(t, violations[0].Message, "oops.Wrap")
	}
}

func TestOopsRedundantGuard_MultipleGuardsInOneFunction(t *testing.T) {
	t.Parallel()

	code := `package main

import "github.com/samber/oops"

func process() error {
	err1 := step1()
	if err1 != nil {
		return oops.Wrap(err1)
	}
	return nil
}

func step1() error {
	err2 := step2()
	if err2 != nil {
		return oops.Wrap(err2)
	}
	return nil
}

func step2() error { return nil }`
	graph := helperParseWithOopsEnforcement(t, code, true)

	violations := findOopsRedundantGuardViolations(t, graph)
	assert.Len(t, violations, 2, "should detect redundant guards in both functions")
}

func TestOopsRedundantGuard_WrapNilLiteralNotFlagged(t *testing.T) {
	t.Parallel()

	// oops.Wrap(nil) — nil literal, not a variable. The guard checks `err != nil`
	// but the wrap target is nil literal, not the guarded variable. Should NOT flag.
	code := `package main

import "github.com/samber/oops"

func process() error {
	err := step()
	if err != nil {
		return oops.Wrap(nil)
	}
	return nil
}

func step() error { return nil }`
	graph := helperParseWithOopsEnforcement(t, code, true)

	violations := findOopsRedundantGuardViolations(t, graph)
	assert.Empty(t, violations, "should not flag when wrap arg is nil literal, not the guarded variable")
}
