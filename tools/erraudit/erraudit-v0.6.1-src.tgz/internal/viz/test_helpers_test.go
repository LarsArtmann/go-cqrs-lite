package viz

import (
	"go/token"

	"github.com/larsartmann/erraudit/pkg/types"
)

func makeSimpleViolation(
	filename string,
	line int,
	errType types.ErrorType,
	msg string,
) types.ErrorViolation {
	return types.ErrorViolation{
		Position: token.Position{Filename: filename, Line: line, Column: 1},
		Type:     errType,
		Severity: types.SeverityHigh,
		Message:  msg,
	}
}

// makeViolationAt builds a violation with full control over severity and column.
func makeViolationAt(
	filename string,
	line, column int,
	errType types.ErrorType,
	severity types.Severity,
	msg string,
) types.ErrorViolation {
	return types.ErrorViolation{
		Position: token.Position{Filename: filename, Line: line, Column: column},
		Type:     errType,
		Severity: severity,
		Message:  msg,
	}
}

// newTestGraphWithRootSentinel returns an ErrorGraph whose hierarchy has a single
// sentinel root error with the given name.
func newTestGraphWithRootSentinel(name string) *types.ErrorGraph {
	return &types.ErrorGraph{
		Hierarchy: &types.ErrorHierarchy{
			RootErrors: []*types.ErrorNode{
				{Name: name, Kind: types.ErrorKindSentinel},
			},
		},
	}
}

// newTestGraphWithSingleErrorInfo returns an ErrorGraph with Package="test"
// and a single ErrorInfo entry — a common fixture for HTML generator tests.
func newTestGraphWithSingleErrorInfo() *types.ErrorGraph {
	return &types.ErrorGraph{
		Package: "test",
		Errors: []types.ErrorInfo{
			{Type: types.ErrorTypeReturn, Message: "test error"},
		},
	}
}
