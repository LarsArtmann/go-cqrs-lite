package viz

import (
	"strings"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestGetTheme(t *testing.T) {
	tests := []struct {
		name         string
		themeName    string
		expectedName string
	}{
		{
			name:         "returns default theme for empty string",
			themeName:    "",
			expectedName: "default",
		},
		{
			name:         "returns default theme",
			themeName:    "default",
			expectedName: "default",
		},
		{
			name:         "returns dark theme",
			themeName:    "dark",
			expectedName: "dark",
		},
		{
			name:         "returns minimal theme",
			themeName:    "minimal",
			expectedName: "minimal",
		},
		{
			name:         "returns colorful theme",
			themeName:    "colorful",
			expectedName: "colorful",
		},
		{
			name:         "returns default theme for unknown theme",
			themeName:    "unknown",
			expectedName: "default",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			theme := GetTheme(tt.themeName)
			assert.Equal(t, tt.expectedName, theme.Name)
		})
	}
}

func TestAvailableThemes(t *testing.T) {
	themes := AvailableThemes()

	assert.Len(t, themes, 4)
	assert.Contains(t, themes, "default")
	assert.Contains(t, themes, "dark")
	assert.Contains(t, themes, "minimal")
	assert.Contains(t, themes, "colorful")
}

func TestDOTTheme_Structure(t *testing.T) {
	t.Run("default theme has all required fields", func(t *testing.T) {
		theme := ThemeDefault

		assert.NotEmpty(t, theme.Name)
		assert.NotEmpty(t, theme.Graph.Label)
		assert.NotEmpty(t, theme.Graph.RankDir)
		assert.NotEmpty(t, theme.Nodes.Default.Shape)
		assert.NotEmpty(t, theme.Nodes.Sentinel.Shape)
		assert.NotEmpty(t, theme.Nodes.Errorf.Shape)
		assert.NotEmpty(t, theme.Nodes.Custom.Shape)
		assert.NotEmpty(t, theme.Nodes.Wrap.Shape)
		assert.NotEmpty(t, theme.Nodes.New.Shape)
		assert.NotEmpty(t, theme.Edges.ArrowHead)
	})

	t.Run("dark theme has dark background", func(t *testing.T) {
		theme := ThemeDark

		assert.Equal(t, "#1E1E1E", theme.Graph.BgColor)
		assert.Contains(t, []string{"#2D2D2D", "#1B3A1B"}, theme.Nodes.Default.FillColor)
	})

	t.Run("minimal theme has white background", func(t *testing.T) {
		theme := ThemeMinimal

		assert.Equal(t, "white", theme.Graph.BgColor)
		assert.Equal(t, "white", theme.Nodes.Default.FillColor)
	})

	t.Run("colorful theme has varied shapes", func(t *testing.T) {
		theme := ThemeColorful

		assert.Equal(t, "component", theme.Nodes.Sentinel.Shape)
		assert.Equal(t, "note", theme.Nodes.Errorf.Shape)
		assert.Equal(t, "hexagon", theme.Nodes.Custom.Shape)
		assert.Equal(t, "diamond", theme.Nodes.Wrap.Shape)
	})
}

func TestNewDOTVisualizerWithTheme(t *testing.T) {
	graph := &types.ErrorGraph{
		Hierarchy: &types.ErrorHierarchy{
			RootErrors: []*types.ErrorNode{
				{
					Name: "ErrTest",
					Kind: types.ErrorKindSentinel,
				},
			},
		},
	}

	t.Run("uses specified theme", func(t *testing.T) {
		viz := NewDOTVisualizerWithTheme(graph, ThemeDark)
		require.NotNil(t, viz)
		assert.Equal(t, ThemeDark, viz.GetTheme())
	})

	t.Run("default visualizer uses default theme", func(t *testing.T) {
		viz := NewDOTVisualizer(graph)
		require.NotNil(t, viz)
		assert.Equal(t, ThemeDefault, viz.GetTheme())
	})
}

func TestDOTVisualizer_SetTheme(t *testing.T) {
	graph := &types.ErrorGraph{
		Hierarchy: &types.ErrorHierarchy{
			RootErrors: []*types.ErrorNode{},
		},
	}

	viz := NewDOTVisualizer(graph)
	assert.Equal(t, ThemeDefault, viz.GetTheme())

	viz.SetTheme(ThemeDark)
	assert.Equal(t, ThemeDark, viz.GetTheme())

	viz.SetTheme(ThemeMinimal)
	assert.Equal(t, ThemeMinimal, viz.GetTheme())
}

func TestDOTVisualizer_GenerateDOT_ThemeApplied(t *testing.T) {
	graph := &types.ErrorGraph{
		Hierarchy: &types.ErrorHierarchy{
			RootErrors: []*types.ErrorNode{
				{
					Name: "ErrSentinel",
					Kind: types.ErrorKindSentinel,
				},
				{
					Name:    "ErrErrorf",
					Kind:    types.ErrorKindErrorf,
					Message: "error message",
				},
			},
		},
	}

	t.Run("dark theme applies dark background", func(t *testing.T) {
		viz := NewDOTVisualizerWithTheme(graph, ThemeDark)
		output := viz.GenerateDOT()

		assert.Contains(t, output, "#1E1E1E")
		assert.Contains(t, output, "bgcolor")
	})

	t.Run("minimal theme does not use fills", func(t *testing.T) {
		viz := NewDOTVisualizerWithTheme(graph, ThemeMinimal)
		output := viz.GenerateDOT()

		assert.Contains(t, output, "bgcolor=\"white\"")
	})

	t.Run("colorful theme uses vibrant colors", func(t *testing.T) {
		viz := NewDOTVisualizerWithTheme(graph, ThemeColorful)
		output := viz.GenerateDOT()

		assert.Contains(t, output, "#4CAF50")
	})

	t.Run("theme affects node colors based on kind", func(t *testing.T) {
		viz := NewDOTVisualizerWithTheme(graph, ThemeDefault)
		output := viz.GenerateDOT()

		assert.Contains(t, output, colorGreenLightBg)
	})

	t.Run("theme affects edge styling", func(t *testing.T) {
		graphWithChildren := newTestGraphWithHierarchy("ErrParent", "ErrChild")

		viz := NewDOTVisualizerWithTheme(graphWithChildren, ThemeColorful)
		output := viz.GenerateDOT()

		assert.Contains(t, output, "arrowhead=diamond")
		assert.Contains(t, output, "penwidth=2.0")
	})
}

func TestDOTVisualizer_GetNodeAttributes(t *testing.T) {
	viz := NewDOTVisualizer(nil)

	tests := []struct {
		name          string
		kind          types.ErrorKind
		expectedColor string
	}{
		{
			name:          "sentinel uses sentinel color",
			kind:          types.ErrorKindSentinel,
			expectedColor: colorGreenLightBg,
		},
		{
			name:          "errorf uses errorf color",
			kind:          types.ErrorKindErrorf,
			expectedColor: colorBlueLightBg,
		},
		{
			name:          "custom uses custom color",
			kind:          types.ErrorKindCustom,
			expectedColor: colorOrangeLightBg,
		},
		{
			name:          "wrap uses wrap color",
			kind:          types.ErrorKindWrap,
			expectedColor: colorPurpleLightBg,
		},
		{
			name:          "new uses new color",
			kind:          types.ErrorKindNew,
			expectedColor: "#ECEFF1",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			attrs := viz.getNodeAttributes(tt.kind)
			assert.Equal(t, tt.expectedColor, attrs.FillColor)
		})
	}
}

func TestDOTVisualizer_GenerateMermaid_ThemeApplied(t *testing.T) {
	graph := newTestGraphWithRootSentinel("ErrTest")

	t.Run("mermaid output is generated regardless of theme", func(t *testing.T) {
		viz := NewDOTVisualizerWithTheme(graph, ThemeDark)
		output := viz.GenerateMermaid()

		assert.True(t, strings.HasPrefix(output, "```mermaid"))
		assert.Contains(t, output, "graph TD")
		assert.Contains(t, output, "ErrTest")
	})
}
