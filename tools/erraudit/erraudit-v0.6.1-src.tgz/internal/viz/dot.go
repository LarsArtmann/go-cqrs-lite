package viz

import (
	"fmt"
	"strings"

	"github.com/larsartmann/erraudit/pkg/types"
)

// DOT/Mermaid format constants.
const (
	msgGraphNil        = "Error: graph is nil"
	msgGraphNilNewline = msgGraphNil + "\n"
	msgGraphNilJSON    = `{"error": "graph is nil"}`
	msgGraphNilHTML    = "<p>" + msgGraphNil + "</p>"
	// Graph structure.
	dotHeader       = "digraph ErrorHierarchy {\n"
	dotFooter       = "}\n"
	mermaidHeader   = "graph TD\n"
	mermaidFence    = "```mermaid\n"
	mermaidFenceEnd = "```\n"

	// Graph labels.
	attrGraphLabel = "Error Hierarchy Graph"

	// Mermaid styles.
	styleSentinel = ":::sentinel"
	styleWrapped  = ":::wrapped"
	styleCustom   = ":::custom"

	// Error messages.
	msgNoHierarchy = "No hierarchy data available"
)

// DOTVisualizer generates DOT (Graphviz) output for error hierarchies.
type DOTVisualizer struct {
	graph     *types.ErrorGraph
	nodeCount uint
	theme     DOTTheme
}

// NewDOTVisualizer creates a new DOT visualizer with the default theme.
func NewDOTVisualizer(graph *types.ErrorGraph) *DOTVisualizer {
	return &DOTVisualizer{
		graph:     graph,
		nodeCount: 0,
		theme:     ThemeDefault,
	}
}

// NewDOTVisualizerWithTheme creates a new DOT visualizer with a specific theme.
func NewDOTVisualizerWithTheme(graph *types.ErrorGraph, theme DOTTheme) *DOTVisualizer {
	return &DOTVisualizer{
		graph:     graph,
		nodeCount: 0,
		theme:     theme,
	}
}

// SetTheme sets the visualizer's theme.
func (v *DOTVisualizer) SetTheme(theme DOTTheme) {
	v.theme = theme
}

// GetTheme returns the current theme.
func (v *DOTVisualizer) GetTheme() DOTTheme {
	return v.theme
}

// GenerateDOT generates DOT format output for the error hierarchy.
func (v *DOTVisualizer) GenerateDOT() string {
	if v.graph == nil {
		return fmt.Sprintf("%s  label=\"%s\"\n%s", dotHeader, msgGraphNil, dotFooter)
	}

	if v.graph.Hierarchy == nil {
		return fmt.Sprintf("%s  label=\"%s\"\n%s", dotHeader, msgNoHierarchy, dotFooter)
	}

	doc := &dotDocument{
		name:     "ErrorHierarchy",
		comments: []string{v.theme.Graph.Label, "Can be rendered with: dot -Tpng output.dot -o output.png"},
		blocks: []dotBlock{
			{header: "graph", attrs: v.graphAttrs()},
			{header: "node", attrs: v.defaultNodeAttrs()},
		},
	}

	// Generate nodes and edges
	v.nodeCount = 0
	v.appendNodeBlocks(doc, v.graph.Hierarchy.RootErrors, "")

	var builder strings.Builder
	doc.writeTo(&builder)

	return builder.String()
}

// graphAttrs renders the theme's graph-level attributes in DOT.
func (v *DOTVisualizer) graphAttrs() []dotAttr {
	attrs := []dotAttr{
		dotQuotedAttr("label", v.theme.Graph.Label),
		dotIntAttr("fontsize", v.theme.Graph.FontSize),
		dotBareAttr("rankdir", v.theme.Graph.RankDir),
		dotFloatAttr("ranksep", v.theme.Graph.RankSep),
		dotFloatAttr("nodesep", v.theme.Graph.NodeSep),
	}

	if v.theme.Graph.BgColor != "" {
		attrs = append(attrs, dotQuotedAttr("bgcolor", v.theme.Graph.BgColor))
	}

	if v.theme.Graph.FontColor != "" {
		attrs = append(attrs, dotQuotedAttr("fontcolor", v.theme.Graph.FontColor))
	}

	return attrs
}

// defaultNodeAttrs renders the theme's default node attributes in DOT.
func (v *DOTVisualizer) defaultNodeAttrs() []dotAttr {
	defaultNode := v.theme.Nodes.Default

	attrs := []dotAttr{dotBareAttr("shape", defaultNode.Shape)}

	if defaultNode.Style != "" {
		attrs = append(attrs, dotQuotedAttr("style", defaultNode.Style))
	}

	attrs = append(attrs,
		dotIntAttr("fontsize", defaultNode.FontSize),
		dotQuotedAttr("fontname", defaultNode.FontName),
	)

	if defaultNode.FillColor != "" {
		attrs = append(attrs, dotBareAttr("fillcolor", defaultNode.FillColor))
	}

	return attrs
}

// appendNodeBlocks recursively appends node and edge blocks to the document.
func (v *DOTVisualizer) appendNodeBlocks(
	doc *dotDocument,
	nodes []*types.ErrorNode,
	parentID string,
) {
	for _, node := range nodes {
		nodeID := fmt.Sprintf("node%d", v.nodeCount)
		v.nodeCount++

		doc.blocks = append(doc.blocks, dotBlock{
			header: nodeID,
			attrs: []dotAttr{
				dotQuotedAttr("label", v.formatNodeLabel(node)),
				dotBareAttr("fillcolor", v.getNodeColor(node.Kind)),
			},
		})

		if parentID != "" {
			edgeAttrs := []dotAttr{
				dotBareAttr("arrowhead", v.theme.Edges.ArrowHead),
				dotFloatAttr("penwidth", v.theme.Edges.Width),
				dotQuotedAttr("color", v.theme.Edges.Color),
			}

			if v.theme.Edges.Style != "" {
				edgeAttrs = append(edgeAttrs, dotBareAttr("style", v.theme.Edges.Style))
			}

			doc.blocks = append(doc.blocks, dotBlock{
				header: parentID + " -> " + nodeID,
				attrs:  edgeAttrs,
			})
		}

		if len(node.Children) > 0 {
			v.appendNodeBlocks(doc, node.Children, nodeID)
		}
	}
}

// getNodeAttributes returns node attributes based on error kind using the current theme.
func (v *DOTVisualizer) getNodeAttributes(kind types.ErrorKind) NodeAttributes {
	switch kind {
	case types.ErrorKindSentinel:
		return v.theme.Nodes.Sentinel
	case types.ErrorKindErrorf:
		return v.theme.Nodes.Errorf
	case types.ErrorKindCustom:
		return v.theme.Nodes.Custom
	case types.ErrorKindWrap:
		return v.theme.Nodes.Wrap
	case types.ErrorKindJoin:
		return v.theme.Nodes.Wrap
	case types.ErrorKindNew:
		return v.theme.Nodes.New
	case types.ErrorKindFamilyNew:
		return v.theme.Nodes.New
	case types.ErrorKindFamilyWrap:
		return v.theme.Nodes.Wrap
	case types.ErrorKindOopsErrorf:
		return v.theme.Nodes.Errorf
	case types.ErrorKindOopsWrap:
		return v.theme.Nodes.Wrap
	default:
		return v.theme.Nodes.Default
	}
}

// getNodeColor returns a fill color based on error kind (for backward compatibility).
func (v *DOTVisualizer) getNodeColor(kind types.ErrorKind) string {
	return v.getNodeAttributes(kind).FillColor
}

// formatNodeLabel returns the raw label content for a node: the error name,
// plus the message on a second line unless the node is a sentinel. Quoting
// and escaping are applied by the attribute renderer.
func (v *DOTVisualizer) formatNodeLabel(node *types.ErrorNode) string {
	label := node.Name

	if node.Message != "" && node.Kind != types.ErrorKindSentinel {
		label += "\n" + node.Message
	}

	return label
}

// escapeString escapes special characters for DOT/Mermaid quoted strings.
// Backslashes are escaped first so a literal `\"` in the input stays a
// literal backslash followed by an escaped quote.
func (v *DOTVisualizer) escapeString(s string) string {
	s = strings.ReplaceAll(s, `\`, `\\`)
	s = strings.ReplaceAll(s, "\"", `\"`)
	s = strings.ReplaceAll(s, "\n", `\n`)

	return s
}

// GenerateMermaid generates Mermaid diagram format for the error hierarchy.
func (v *DOTVisualizer) GenerateMermaid() string {
	if v.graph == nil {
		return fmt.Sprintf("%s  Error[%s]\n", mermaidHeader, msgGraphNil)
	}

	if v.graph.Hierarchy == nil {
		return fmt.Sprintf("%s  No[%s]\n", mermaidHeader, msgNoHierarchy)
	}

	var builder strings.Builder

	builder.WriteString(mermaidFence)
	builder.WriteString(mermaidHeader)
	fmt.Fprintf(&builder, "    %% %s\n", attrGraphLabel)
	builder.WriteString("    %% View at: https://mermaid.live/\n\n")

	// Write nodes and relationships
	v.writeMermaidNodes(&builder, v.graph.Hierarchy.RootErrors, "")

	builder.WriteString(mermaidFenceEnd)

	return builder.String()
}

// writeMermaidNodes recursively writes nodes in Mermaid format.
func (v *DOTVisualizer) writeMermaidNodes(
	builder *strings.Builder,
	nodes []*types.ErrorNode,
	parentName string,
) {
	for _, node := range nodes {
		// Write node
		nodeLabel := node.Name
		if node.Message != "" && node.Kind != types.ErrorKindSentinel {
			nodeLabel += "\\n" + v.escapeString(node.Message)
		}

		// Determine style based on kind
		style := v.getMermaidStyle(node.Kind)
		fmt.Fprintf(builder, "    %s[%q]%s\n", node.Name, nodeLabel, style)

		// Write edge from parent if exists
		if parentName != "" {
			fmt.Fprintf(builder, "    %s --> %s\n", parentName, node.Name)
		}

		// Recursively write children
		if len(node.Children) > 0 {
			v.writeMermaidNodes(builder, node.Children, node.Name)
		}
	}
}

// getMermaidStyle returns Mermaid style for error kind.
func (v *DOTVisualizer) getMermaidStyle(kind types.ErrorKind) string {
	switch kind {
	case types.ErrorKindSentinel:
		return styleSentinel
	case types.ErrorKindErrorf:
		return styleWrapped
	case types.ErrorKindCustom:
		return styleCustom
	case types.ErrorKindNew:
		return styleSentinel
	case types.ErrorKindWrap:
		return styleWrapped
	case types.ErrorKindJoin:
		return styleWrapped
	case types.ErrorKindFamilyNew:
		return styleSentinel
	case types.ErrorKindFamilyWrap:
		return styleWrapped
	case types.ErrorKindOopsErrorf:
		return styleWrapped
	case types.ErrorKindOopsWrap:
		return styleWrapped
	}

	return ""
}
