package viz

import (
	_ "embed"
	"html/template"
)

//go:embed templates/report.html
var htmlTemplate string

//nolint:gochecknoglobals // parsed template is immutable after init
var htmlGeneratorTemplate = template.Must(template.New("violations").Parse(minifyHTMLCSS(htmlTemplate)))
