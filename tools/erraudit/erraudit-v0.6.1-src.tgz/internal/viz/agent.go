package viz

import (
	"fmt"
	"strings"

	"github.com/larsartmann/erraudit/pkg/finding"
	"github.com/larsartmann/erraudit/pkg/types"
	findingsdk "github.com/larsartmann/go-finding"
)

const msgNoViolationsAgent = "No violations found.\n"

// AgentVisualizer generates token-efficient output optimized for AI coding agents.
//
// Output format:
//
//	file:line:col [SEVERITY] type: message
//	  Fix: suggestion
//	  context_line | code
//	> target_line | code
//	  context_line | code
//
// Violations are grouped by file for efficient batch processing.
type AgentVisualizer struct {
	graph *types.ErrorGraph
}

// NewAgentVisualizer creates a new agent-optimized visualizer.
func NewAgentVisualizer(graph *types.ErrorGraph) *AgentVisualizer {
	return &AgentVisualizer{graph: graph}
}

// GenerateAgentOutput generates the complete agent-friendly output.
func (v *AgentVisualizer) GenerateAgentOutput(violations []types.ErrorViolation) string {
	if len(violations) == 0 {
		if v.graph == nil {
			return msgNoViolationsAgent
		}

		// Coverage evidence belongs in the clean verdict too: "0 violations"
		// must be distinguishable from "scanned 0 files".
		return fmt.Sprintf("%sfiles=%d\n", msgNoViolationsAgent, v.graph.FilesScanned)
	}

	byFile := groupByFile(violations)

	var b strings.Builder

	v.writeHeader(&b, violations)
	v.writeHierarchyLine(&b)
	v.writeFileGroups(&b, byFile)

	return b.String()
}

// GenerateViolations generates a violations report in agent format.
func (v *AgentVisualizer) GenerateViolations(violations []types.ErrorViolation) string {
	return v.GenerateAgentOutput(violations)
}

// GenerateMetrics generates a metrics summary in agent format.
func (v *AgentVisualizer) GenerateMetrics() string {
	if v.graph == nil {
		return "{}\n"
	}

	return fmt.Sprintf(
		"total=%d returns=%d wraps=%d swallows=%d panics=%d ignored=%d max_depth=%d\n",
		v.graph.Metrics.TotalErrors,
		v.graph.Metrics.ErrorReturns,
		v.graph.Metrics.ErrorWraps,
		v.graph.Metrics.SilentSwallows,
		v.graph.Metrics.PanicsOnErrors,
		v.graph.Metrics.IgnoredErrors,
		v.graph.Metrics.WrapDepth,
	)
}

// GenerateSummary generates a summary of violations in agent format.
func (v *AgentVisualizer) GenerateSummary(violations []types.ErrorViolation) string {
	if len(violations) == 0 {
		return "violations=0\n"
	}

	bySeverity := countBySeverity(violations)

	var b strings.Builder
	fmt.Fprintf(&b, "violations=%d", len(violations))

	for _, sev := range types.ValidSeverities() {
		if count, ok := bySeverity[sev]; ok {
			fmt.Fprintf(&b, " %s=%d", strings.ToUpper(string(sev)), count)
		}
	}

	b.WriteString("\n")

	return b.String()
}

func (v *AgentVisualizer) writeHeader(b *strings.Builder, violations []types.ErrorViolation) {
	bySeverity := countBySeverity(violations)

	b.WriteString("# erraudit: ")
	fmt.Fprintf(b, "%d violations found", len(violations))

	parts := make([]string, 0, len(types.ValidSeverities()))
	for _, sev := range types.ValidSeverities() {
		if count, ok := bySeverity[sev]; ok {
			parts = append(parts, fmt.Sprintf("%d %s", count, strings.ToUpper(string(sev))))
		}
	}

	if len(parts) > 0 {
		b.WriteString(" (")
		b.WriteString(strings.Join(parts, ", "))
		b.WriteString(")")
	}

	// Coverage tokens (2026-09-22): scanned-file count is always present so
	// the agent can tell a clean scan from an empty one; skipped modules are
	// appended only when they exist.
	if v.graph != nil {
		fmt.Fprintf(b, ", files=%d", v.graph.FilesScanned)

		if n := len(v.graph.SkippedModules); n > 0 {
			fmt.Fprintf(b, ", modules_skipped=%d", n)
		}
	}

	b.WriteString("\n\n")
}

// writeHierarchyLine writes a compact single-line summary of the hierarchy
// metrics (token-efficient for agent consumption). Omitted entirely when no
// hierarchy data is available so agent output stays lean for violation-free
// or hierarchy-less graphs.
func (v *AgentVisualizer) writeHierarchyLine(b *strings.Builder) {
	NewHierarchyMetricsRenderer(v.graph).AgentLine(b)
}

type fileGroup struct {
	fileName   string
	violations []types.ErrorViolation
}

func (v *AgentVisualizer) writeFileGroups(b *strings.Builder, groups []fileGroup) {
	for i, group := range groups {
		if i > 0 {
			b.WriteString("\n")
		}

		fmt.Fprintf(b, "## %s (%d violations)\n\n", group.fileName, len(group.violations))

		for _, violation := range group.violations {
			v.writeViolation(b, violation)
		}
	}
}

func (v *AgentVisualizer) writeViolation(b *strings.Builder, violation types.ErrorViolation) {
	fileName := violation.Position.Filename

	fmt.Fprintf(
		b, "%s:%d:%d [%s] %s: %s\n",
		fileName,
		violation.Position.Line,
		violation.Position.Column,
		strings.ToUpper(string(violation.Severity)),
		violation.Type,
		violation.Message,
	)

	if violation.Suggestion != "" {
		fmt.Fprintf(b, "  Fix: %s\n", violation.Suggestion)
	}

	if violation.Explanation != "" {
		fmt.Fprintf(b, "  Why: %s\n", violation.Explanation)
	}

	if violation.CodeSnippet != "" {
		v.writeCodeSnippet(b, violation.CodeSnippet)
	}

	b.WriteString("\n")
}

func (v *AgentVisualizer) writeCodeSnippet(b *strings.Builder, snippet string) {
	b.WriteString("  Code:\n")

	for line := range strings.SplitSeq(snippet, "\n") {
		if line == "" {
			continue
		}

		trimmed := strings.TrimLeft(line, " \t")
		if trimmed == "" {
			continue
		}

		indent := line[:len(line)-len(trimmed)]
		prefix := "    "

		if strings.Contains(indent, ">") || trimmed[0:1] == ">" {
			prefix = "  > "
			trimmed = strings.TrimPrefix(trimmed, ">")
			trimmed = strings.TrimLeft(trimmed, " \t")
		}

		b.WriteString(prefix)
		b.WriteString(trimmed)
		b.WriteString("\n")
	}
}

func groupByFile(violations []types.ErrorViolation) []fileGroup {
	if len(violations) == 0 {
		return nil
	}

	// Convert violations to findings and sort by position, then group by file.
	// Sorting first ensures findings within each group are already in order.
	findings := finding.ViolationsToFindings(violations)
	findingsdk.SortByPosition(findings)
	byFile := findingsdk.GroupByFile(findings)

	// Build a lookup keyed by Position.String() to recover original violations.
	violationByPos := make(map[string]types.ErrorViolation, len(violations))
	for _, v := range violations {
		pos := findingsdk.Position{
			File:   findingsdk.FilePath(v.Position.Filename),
			Line:   v.Position.Line,
			Column: v.Position.Column,
		}
		violationByPos[pos.String()] = v
	}

	// Collect filenames in sorted order (SortByPosition sorts by file first).
	seen := make(map[string]struct{}, len(byFile))
	sortedFiles := make([]string, 0, len(byFile))

	for _, f := range findings {
		file := string(f.Position.File)
		if _, ok := seen[file]; !ok {
			seen[file] = struct{}{}
			sortedFiles = append(sortedFiles, file)
		}
	}

	groups := make([]fileGroup, 0, len(byFile))
	for _, fileName := range sortedFiles {
		fileFindings := byFile[findingsdk.FilePath(fileName)]

		groupViolations := make([]types.ErrorViolation, 0, len(fileFindings))
		for _, f := range fileFindings {
			if v, ok := violationByPos[f.Position.String()]; ok {
				groupViolations = append(groupViolations, v)
			}
		}

		groups = append(groups, fileGroup{
			fileName:   fileName,
			violations: groupViolations,
		})
	}

	return groups
}
