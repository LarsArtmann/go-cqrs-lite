package viz

import (
	"encoding/json/v2"
	"fmt"
	"go/token"
	"strings"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
)

// unmarshalOrFail is a test helper that unmarshals JSON and fails the test on error.
func unmarshalOrFail(t *testing.T, jsonStr string, target any) {
	err := json.Unmarshal([]byte(jsonStr), target)
	if err != nil {
		t.Fatalf("Unmarshal failed: %v", err)
	}
}

// test helper functions for DOT visualizer generation.
func dotGenerator(v *DOTVisualizer) string {
	return v.GenerateDOT()
}

func mermaidGenerator(v *DOTVisualizer) string {
	return v.GenerateMermaid()
}

// newTestGraph creates a simple ErrorGraph with a single root error.
func newTestGraph() *types.ErrorGraph {
	return &types.ErrorGraph{
		Package: "test",
		Hierarchy: &types.ErrorHierarchy{
			RootErrors: []*types.ErrorNode{
				{
					Name:    "ErrTest",
					Message: "Test error",
				},
			},
			Metrics: types.HierarchyMetrics{
				TotalNamedErrors: 1,
			},
		},
	}
}

// newTestGraphWithErrors creates an ErrorGraph with errors and metrics.
func newTestGraphWithErrors() *types.ErrorGraph {
	return &types.ErrorGraph{
		Package: "test",
		Errors: []types.ErrorInfo{
			{
				Type:    types.ErrorTypeReturn,
				Message: "Test error",
			},
		},
		Metrics: types.ErrorMetrics{
			TotalErrors: 1,
		},
	}
}

// newTestGraphWithHierarchy creates an ErrorGraph with a simple hierarchy structure.
func newTestGraphWithHierarchy(parentName, childName string) *types.ErrorGraph {
	return &types.ErrorGraph{
		Package: "test",
		Hierarchy: &types.ErrorHierarchy{
			RootErrors: []*types.ErrorNode{
				{
					Name: parentName,
					Kind: types.ErrorKindSentinel,
					Children: []*types.ErrorNode{
						{Name: childName, Kind: types.ErrorKindErrorf},
					},
				},
			},
		},
	}
}

func TestTreeVisualizer_GenerateMetrics(t *testing.T) {
	graph := &types.ErrorGraph{
		Metrics: types.ErrorMetrics{
			TotalErrors:      10,
			ErrorReturns:     5,
			ErrorWraps:       3,
			SilentSwallows:   1,
			PanicsOnErrors:   1,
			IgnoredErrors:    0,
			MostCommonErrors: map[string]uint{"test": 5},
		},
	}

	viz := NewTreeVisualizer(graph)
	output := viz.GenerateMetrics()

	if output == "" {
		t.Error("Expected non-empty metrics output")
	}

	if !contains(output, "Error Metrics") {
		t.Error("Expected metrics header in output")
	}

	if !contains(output, "Total Errors Found: 10") {
		t.Error("Expected total errors count in output")
	}
}

func TestTreeVisualizer_GenerateViolations(t *testing.T) {
	graph := &types.ErrorGraph{}

	violations := []types.ErrorViolation{
		{
			Type:       types.ErrorTypeUnwrapped,
			Severity:   types.SeverityMedium,
			Message:    "Test violation",
			Suggestion: "Fix it",
		},
	}

	viz := NewTreeVisualizer(graph)
	output := viz.GenerateViolations(violations)

	if output == "" {
		t.Error("Expected non-empty violations output")
	}

	if !contains(output, "Test violation") {
		t.Error("Expected violation message in output")
	}

	if !contains(output, "Fix it") {
		t.Error("Expected suggestion in output")
	}
}

func TestTreeVisualizer_GenerateViolations_Empty(t *testing.T) {
	graph := &types.ErrorGraph{}
	violations := []types.ErrorViolation{}

	viz := NewTreeVisualizer(graph)
	output := viz.GenerateViolations(violations)

	if !contains(output, "No violations found") {
		t.Error("Expected no violations message")
	}
}

func TestTreeVisualizer_GenerateSummary(t *testing.T) {
	graph := newTestGraphWithErrors()

	violations := []types.ErrorViolation{}

	viz := NewTreeVisualizer(graph)
	output := viz.GenerateSummary(violations)

	if output == "" {
		t.Error("Expected non-empty summary output")
	}

	if !contains(output, "ERRAUDIT ANALYSIS REPORT") {
		t.Error("Expected report header in output")
	}

	if !contains(output, "Package: test") {
		t.Error("Expected package info in output")
	}
}

func TestJSONVisualizer_GenerateJSON(t *testing.T) {
	graph := newTestGraphWithErrors()

	viz := NewJSONVisualizer(graph)

	output, err := viz.GenerateJSON()
	if err != nil {
		t.Fatalf("Failed to generate JSON: %v", err)
	}

	if output == "" {
		t.Error("Expected non-empty JSON output")
	}

	if !contains(output, `"package"`) {
		t.Error("Expected package field in JSON")
	}

	if !contains(output, `"errors"`) {
		t.Error("Expected errors field in JSON")
	}
}

func TestJSONVisualizer_GenerateJSONWithViolations(t *testing.T) {
	graph := &types.ErrorGraph{
		Package: "test",
	}

	violations := []types.ErrorViolation{
		{
			Type:     types.ErrorTypeUnwrapped,
			Severity: types.SeverityLow,
			Message:  "Test violation",
		},
	}

	viz := NewJSONVisualizer(graph)

	output, err := viz.GenerateJSONWithViolations(violations)
	if err != nil {
		t.Fatalf("Failed to generate JSON with violations: %v", err)
	}

	if !contains(output, `"violations"`) {
		t.Error("Expected violations field in JSON")
	}
}

func TestFormatPosition(t *testing.T) {
	errInfo := types.ErrorInfo{
		Position: token.Position{
			Filename: "test.go",
		},
		Context: types.ErrorContext{
			FileName:   "test.go",
			LineNumber: 42,
		},
	}

	output := FormatPosition(errInfo)

	if output != "test.go:42" {
		t.Errorf("Expected 'test.go:42', got '%s'", output)
	}
}

// Helper function.
func contains(s, substr string) bool {
	return strings.Contains(s, substr)
}

// FormatPosition formats position of error (test helper).
func FormatPosition(errInfo types.ErrorInfo) string {
	if result := formatLocation(
		errInfo.Context.FileName,
		errInfo.Context.LineNumber,
	); result != "" {
		return result
	}

	if result := formatLocation(errInfo.Position.Filename, errInfo.Position.Line); result != "" {
		return result
	}

	return "unknown:unknown"
}

// formatLocation formats filename and line number into "file:line" or returns empty string if invalid.
func formatLocation(filename string, line int) string {
	if filename != "" && line > 0 {
		return fmt.Sprintf("%s:%d", filename, line)
	}

	return ""
}

// newEmptyTestGraph creates an empty test error graph with default package name.
func newEmptyTestGraph() *types.ErrorGraph {
	return &types.ErrorGraph{
		Package: "test",
		Errors:  []types.ErrorInfo{},
	}
}

// testNilHierarchy tests that a visualizer with nil hierarchy returns appropriate message.
// The generateFunc parameter should call the appropriate generator method (GenerateDOT or GenerateMermaid).
func testNilHierarchy(t *testing.T, generateFunc func(*DOTVisualizer) string, methodName string) {
	t.Helper()

	graph := &types.ErrorGraph{
		Package:   "test",
		Hierarchy: nil,
	}

	viz := NewDOTVisualizer(graph)
	output := generateFunc(viz)

	if !contains(output, "No hierarchy data available") {
		t.Errorf("Expected nil hierarchy message from %s, got: %s", methodName, output)
	}
}

// testNilGraphJSON tests that a JSON visualizer with nil graph returns error and empty output.
// The generateFunc parameter should call the appropriate generator method.
func testNilGraphJSON(
	t *testing.T,
	generateFunc func(*JSONVisualizer) (string, error),
	methodName string,
) {
	t.Helper()

	viz := NewJSONVisualizer(nil)

	output, err := generateFunc(viz)
	if err == nil {
		t.Errorf("Expected error for nil graph in %s", methodName)
	}

	if output != "" {
		t.Errorf("Expected empty output for nil graph in %s, got: %s", methodName, output)
	}
}

// testNilGraphDOT tests that a DOT visualizer with nil graph returns appropriate message.
// The generateFunc parameter should call the appropriate generator method.
func testNilGraphDOT(t *testing.T, generateFunc func(*DOTVisualizer) string, methodName string) {
	t.Helper()

	viz := NewDOTVisualizer(nil)
	output := generateFunc(viz)

	if !contains(output, "Error: graph is nil") {
		t.Errorf("Expected nil graph error message from %s, got: %s", methodName, output)
	}
}

// ============================================================================
// Edge Case Tests
// ============================================================================

func TestTreeVisualizer_GenerateErrorHierarchy(t *testing.T) {
	t.Parallel()

	// Test with valid graph containing hierarchy data
	graph := newTestGraph()

	viz := NewTreeVisualizer(graph)
	output := viz.GenerateErrorHierarchy()

	// Should generate tree from hierarchy
	if !contains(output, "Error Hierarchy") {
		t.Errorf("Expected tree header, got: %s", output)
	}
}

func TestTreeVisualizer_GenerateMetrics_NilGraph(t *testing.T) {
	t.Parallel()

	viz := NewTreeVisualizer(nil)
	output := viz.GenerateMetrics()

	if !contains(output, "Error: graph is nil") {
		t.Errorf("Expected nil graph error message, got: %s", output)
	}
}

func TestTreeVisualizer_GenerateSummary_NilGraph(t *testing.T) {
	t.Parallel()

	viz := NewTreeVisualizer(nil)
	output := viz.GenerateSummary(nil)

	if !contains(output, "Error: graph is nil") {
		t.Errorf("Expected nil graph error message, got: %s", output)
	}
}

func TestJSONVisualizer_GenerateJSON_NilGraph(t *testing.T) {
	t.Parallel()
	testNilGraphJSON(
		t,
		func(v *JSONVisualizer) (string, error) { return v.GenerateJSON() },
		"GenerateJSON",
	)
}

func TestJSONVisualizer_GenerateJSONWithViolations_NilGraph(t *testing.T) {
	t.Parallel()
	testNilGraphJSON(
		t,
		func(v *JSONVisualizer) (string, error) { return v.GenerateJSONWithViolations(nil) },
		"GenerateJSONWithViolations",
	)
}

func TestDOTVisualizer_GenerateDOT_NilGraph(t *testing.T) {
	t.Parallel()

	viz := NewDOTVisualizer(nil)
	output := viz.GenerateDOT()

	if !contains(output, "Error: graph is nil") {
		t.Errorf("Expected nil graph error message, got: %s", output)
	}
}

func TestDOTVisualizer_GenerateMermaid_NilGraph(t *testing.T) {
	t.Parallel()
	testNilGraphDOT(
		t,
		mermaidGenerator,
		"GenerateMermaid",
	)
}

func TestDOTVisualizer_NilHierarchy(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name     string
		generate func(*DOTVisualizer) string
	}{
		{
			name:     "GenerateDOT",
			generate: dotGenerator,
		},
		{
			name:     "GenerateMermaid",
			generate: mermaidGenerator,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			testNilHierarchy(t, tt.generate, tt.name)
		})
	}
}

func TestHTMLGenerator_GenerateHTML_NilGraph(t *testing.T) {
	t.Parallel()

	viz := NewHTMLGenerator(nil)
	output := viz.GenerateHTML(nil)

	if !contains(output, "Error: graph is nil") {
		t.Errorf("Expected nil graph error message, got: %s", output)
	}
}

func TestHTMLGenerator_GenerateHTML_EmptyViolations(t *testing.T) {
	t.Parallel()

	graph := newEmptyTestGraph()

	viz := NewHTMLGenerator(graph)
	output := viz.GenerateHTML([]types.ErrorViolation{})

	if output == "" {
		t.Error("Expected non-empty output for empty violations")
	}

	if !contains(output, "<!doctype html>") {
		t.Error("Expected HTML content with DOCTYPE")
	}

	if !contains(output, "No Violations Found") {
		t.Error("Expected 'No Violations Found' message")
	}
}

func TestFormatPosition_ZeroValues(t *testing.T) {
	t.Parallel()

	// Test with empty error info
	errInfo := types.ErrorInfo{}
	output := FormatPosition(errInfo)

	if output != "unknown:unknown" {
		t.Errorf("Expected 'unknown:unknown', got '%s'", output)
	}

	// Test with only filename but no line
	errInfo = types.ErrorInfo{
		Context: types.ErrorContext{
			LineNumber: 0,
		},
	}
	output = FormatPosition(errInfo)

	if output != "unknown:unknown" {
		t.Errorf("Expected 'unknown:unknown', got '%s'", output)
	}

	// Test with only line but no filename
	errInfo = types.ErrorInfo{
		Context: types.ErrorContext{
			LineNumber: 42,
		},
	}
	output = FormatPosition(errInfo)

	if output != "unknown:unknown" {
		t.Errorf("Expected 'unknown:unknown', got '%s'", output)
	}
}

// ============================================================================
// JSON Round-Trip Tests (Property-Based)
// ============================================================================

func TestJSONRoundTrip_ErrorGraph(t *testing.T) {
	t.Parallel()

	original := &types.ErrorGraph{
		Package: "github.com/example/pkg",
		Errors: []types.ErrorInfo{
			{
				Type:    types.ErrorTypeReturn,
				Message: "connection failed",
				Context: types.ErrorContext{
					FunctionName: "Connect",
					LineNumber:   42,
					PackageName:  "service",
				},
			},
			{
				Type:    types.ErrorTypeWrapping,
				Message: "wrapped error",
			},
		},
		Metrics: types.ErrorMetrics{
			TotalErrors:    2,
			ErrorReturns:   1,
			ErrorWraps:     1,
			SilentSwallows: 0,
		},
	}

	// Generate JSON
	viz := NewJSONVisualizer(original)

	jsonStr, err := viz.GenerateJSON()
	if err != nil {
		t.Fatalf("GenerateJSON failed: %v", err)
	}

	// Parse back
	var parsed types.ErrorGraph
	unmarshalOrFail(t, jsonStr, &parsed)

	// Verify key fields match
	if parsed.Package != original.Package {
		t.Errorf("Package mismatch: got %q, want %q", parsed.Package, original.Package)
	}

	if len(parsed.Errors) != len(original.Errors) {
		t.Errorf("Errors count mismatch: got %d, want %d", len(parsed.Errors), len(original.Errors))
	}

	if parsed.Metrics.TotalErrors != original.Metrics.TotalErrors {
		t.Errorf(
			"TotalErrors mismatch: got %d, want %d",
			parsed.Metrics.TotalErrors,
			original.Metrics.TotalErrors,
		)
	}
}

func TestJSONRoundTrip_ErrorViolation(t *testing.T) {
	t.Parallel()

	original := &types.ErrorGraph{
		Package: "test",
	}

	violation := types.ErrorViolation{
		Type:       types.ErrorTypeUnwrapped,
		Severity:   types.SeverityHigh,
		Message:    "unwrapped error detected",
		Suggestion: "use fmt.Errorf with %w to wrap",
	}

	// Generate JSON with violations
	viz := NewJSONVisualizer(original)

	jsonStr, err := viz.GenerateJSONWithViolations([]types.ErrorViolation{violation})
	if err != nil {
		t.Fatalf("GenerateJSONWithViolations failed: %v", err)
	}

	// Parse back into a generic structure
	var parsed struct {
		Violations []types.ErrorViolation `json:"violations"`
	}
	unmarshalOrFail(t, jsonStr, &parsed)

	// Verify
	if len(parsed.Violations) != 1 {
		t.Fatalf("Expected 1 violation, got %d", len(parsed.Violations))
	}

	if parsed.Violations[0].Message != violation.Message {
		t.Errorf(
			"Message mismatch: got %q, want %q",
			parsed.Violations[0].Message,
			violation.Message,
		)
	}

	if parsed.Violations[0].Severity != violation.Severity {
		t.Errorf(
			"Severity mismatch: got %q, want %q",
			parsed.Violations[0].Severity,
			violation.Severity,
		)
	}
}

func TestJSONRoundTrip_Severity(t *testing.T) {
	t.Parallel()

	severities := types.AllSeverities()

	for _, sev := range severities {
		t.Run(string(sev), func(t *testing.T) {
			t.Parallel()

			// Marshal via JSON visualizer
			graph := newEmptyTestGraph()
			violations := []types.ErrorViolation{
				{Type: types.ErrorTypeUnwrapped, Severity: sev, Message: "test"},
			}

			viz := NewJSONVisualizer(graph)

			jsonStr, err := viz.GenerateJSONWithViolations(violations)
			if err != nil {
				t.Fatalf("GenerateJSONWithViolations failed: %v", err)
			}

			// Parse back
			var parsed struct {
				Violations []types.ErrorViolation `json:"violations"`
			}
			unmarshalOrFail(t, jsonStr, &parsed)

			if parsed.Violations[0].Severity != sev {
				t.Errorf(
					"Severity round-trip failed: got %q, want %q",
					parsed.Violations[0].Severity,
					sev,
				)
			}
		})
	}
}
