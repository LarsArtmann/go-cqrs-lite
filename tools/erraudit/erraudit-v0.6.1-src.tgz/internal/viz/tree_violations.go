package viz

import (
	"fmt"
	"maps"
	"slices"
	"strings"

	"github.com/larsartmann/erraudit/pkg/types"
)

const severityHeaderPadding = len(" Severity")

// GenerateViolations generates a violations report.
func (v *TreeVisualizer) GenerateViolations(violations []types.ErrorViolation) string {
	return render(v.graph, msgGraphNilNewline, func(builder *strings.Builder) {
		if len(violations) == 0 {
			builder.WriteString("No violations found! 🎉\n")

			return
		}

		builder.WriteString("Violations Report\n")
		builder.WriteString("=================\n\n")

		bySeverity := groupBySeverity(violations)

		for _, severity := range types.ValidSeverities() {
			if len(bySeverity[severity]) == 0 {
				continue
			}

			severityStr := string(severity)
			builder.WriteString(strings.ToUpper(severityStr))
			builder.WriteString(" Severity\n")
			builder.WriteString(strings.Repeat("=", len(severityStr)+severityHeaderPadding))
			builder.WriteString("\n\n")

			for _, violation := range bySeverity[severity] {
				fmt.Fprintf(builder, "• %s\n", violation.Message)
				fmt.Fprintf(builder, "  Type: %s\n", violation.Type)
				fmt.Fprintf(
					builder,
					"  Location: %s:%d\n",
					violation.Position.Filename,
					violation.Position.Line,
				)

				if violation.Suggestion != "" {
					fmt.Fprintf(builder, "  💡 Suggestion: %s\n", violation.Suggestion)
				}

				if violation.Explanation != "" {
					fmt.Fprintf(builder, "  📖 Explanation: %s\n", violation.Explanation)
				}

				if violation.CodeSnippet != "" {
					builder.WriteString("  Code:\n")

					for line := range strings.SplitSeq(violation.CodeSnippet, "\n") {
						if line != "" {
							fmt.Fprintf(builder, "    %s\n", line)
						}
					}
				}

				builder.WriteString("\n")
			}
		}
	})
}

// GenerateSummary generates a summary of violations.
func (v *TreeVisualizer) GenerateSummary(violations []types.ErrorViolation) string {
	return render(v.graph, msgGraphNilNewline, func(builder *strings.Builder) {
		builder.WriteString("ERRAUDIT ANALYSIS REPORT\n")
		builder.WriteString("========================\n\n")

		if v.graph.Package != "" {
			fmt.Fprintf(builder, "Package: %s\n\n", v.graph.Package)
		}

		builder.WriteString("Summary\n")
		builder.WriteString("=======\n\n")

		fmt.Fprintf(builder, "Total Violations: %d\n", len(violations))
		writeCoverageLine(v.graph, builder)
		builder.WriteString("\n")

		if len(violations) == 0 {
			builder.WriteString("No violations found! 🎉\n\n")
			builder.WriteString("Great job following error handling best practices!\n")

			return
		}

		bySeverity := countBySeverity(violations)
		byType := make(map[string]int)

		for _, v := range violations {
			byType[string(v.Type)]++
		}

		builder.WriteString("By Severity:\n")

		for _, severity := range []types.Severity{types.SeverityHigh, types.SeverityMedium, types.SeverityLow} {
			if bySeverity[severity] > 0 {
				fmt.Fprintf(
					builder,
					"  %s: %d\n",
					strings.ToUpper(string(severity)),
					bySeverity[severity],
				)
			}
		}

		builder.WriteString("\nBy Type:\n")

		for _, typ := range slices.Sorted(maps.Keys(byType)) {
			fmt.Fprintf(builder, "  %s: %d\n", typ, byType[typ])
		}

		hierarchyRenderer := NewHierarchyMetricsRenderer(v.graph)
		if hierarchyRenderer.HasMetrics() {
			builder.WriteString("\nHierarchy Metrics\n")
			builder.WriteString("=================\n\n")
			hierarchyRenderer.TextLines(builder)
		}
	})
}
