package viz

import (
	"fmt"
	"strings"

	"github.com/larsartmann/erraudit/pkg/types"
)

// writeCoverageLine appends the scan-coverage line to the full-format report:
// "Coverage: N files scanned[ · M modules skipped]". The zero-file case is
// deliberately loud (see the empty-scan gotcha): "0 violations" must be
// distinguishable from "scanned 0 files", so the line is written whenever the
// graph exists, regardless of the count. Mirrors the agent format's
// files=/modules_skipped= tokens.
func writeCoverageLine(graph *types.ErrorGraph, builder *strings.Builder) {
	if graph == nil {
		return
	}

	fmt.Fprintf(builder, "Coverage: %d files scanned", graph.FilesScanned)

	if n := len(graph.SkippedModules); n > 0 {
		fmt.Fprintf(builder, " · %d modules skipped", n)
	}

	builder.WriteString("\n")
}
