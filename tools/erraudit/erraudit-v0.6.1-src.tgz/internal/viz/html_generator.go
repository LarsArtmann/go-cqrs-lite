package viz

// The HTML template is embedded via internal/viz/html_template.go (go:embed)
// and its CSS is minified once at template init (css_minify.go).
// Future enhancements: interactive JavaScript features.

import (
	"fmt"
	"html/template"
	"sort"
	"strings"

	"github.com/larsartmann/erraudit/pkg/types"
)

// HTMLGenerator generates HTML reports.
type HTMLGenerator struct {
	graph    *types.ErrorGraph
	template *template.Template
}

// NewHTMLGenerator creates a new HTML visualizer.
func NewHTMLGenerator(graph *types.ErrorGraph) *HTMLGenerator {
	return &HTMLGenerator{
		graph:    graph,
		template: htmlGeneratorTemplate,
	}
}

// GenerateHTML generates an HTML report.
func (v *HTMLGenerator) GenerateHTML(violations []types.ErrorViolation) string {
	if v.graph == nil {
		return msgGraphNilHTML
	}

	stats := v.calculateStats(violations)

	var output strings.Builder

	err := v.template.Execute(&output, struct {
		Graph                *types.ErrorGraph
		Violations           []types.ErrorViolation
		Stats                Stats
		SeverityHigh         types.Severity
		SeverityMedium       types.Severity
		SeverityLow          types.Severity
		HierarchyMetricsHTML template.HTML
	}{
		Graph:          v.graph,
		Violations:     violations,
		Stats:          stats,
		SeverityHigh:   types.SeverityHigh,
		SeverityMedium: types.SeverityMedium,
		SeverityLow:    types.SeverityLow,
		//nolint:gosec // G203: block is fully tool-generated (numeric metrics via strconv), no user input
		HierarchyMetricsHTML: template.HTML(NewHierarchyMetricsRenderer(v.graph).HTML()),
	})
	if err != nil {
		return fmt.Sprintf("Error executing template: %v\n", err)
	}

	return output.String()
}

// Stats represents calculated statistics for HTML report.
type Stats struct {
	TotalViolations int
	BySeverity      map[types.Severity][]types.ErrorViolation
	ByType          map[types.ErrorType][]types.ErrorViolation
}

// sortMapSlicesByLine sorts all slices in a map by line number.
func sortMapSlicesByLine[K comparable, T any](m map[K][]T, getLine func(T) int) {
	for _, slice := range m {
		sort.Slice(slice, func(i, j int) bool {
			return getLine(slice[i]) < getLine(slice[j])
		})
	}
}

func getViolationLine(v types.ErrorViolation) int {
	return v.Position.Line
}

// calculateStats calculates statistics for violations.
func (v *HTMLGenerator) calculateStats(violations []types.ErrorViolation) Stats {
	stats := Stats{
		BySeverity: make(map[types.Severity][]types.ErrorViolation),
		ByType:     make(map[types.ErrorType][]types.ErrorViolation),
	}

	for _, v := range violations {
		stats.BySeverity[v.Severity] = append(stats.BySeverity[v.Severity], v)
		stats.ByType[v.Type] = append(stats.ByType[v.Type], v)
	}

	// Sort violations by severity and type
	sortMapSlicesByLine(stats.BySeverity, getViolationLine)
	sortMapSlicesByLine(stats.ByType, getViolationLine)

	stats.TotalViolations = len(violations)

	return stats
}

// GenerateMetrics generates a metrics summary.
func (v *HTMLGenerator) GenerateMetrics() string {
	return render(v.graph, msgGraphNilHTML, func(builder *strings.Builder) {
		m := v.graph.Metrics

		fmt.Fprintf(builder, `<h2>Error Metrics</h2>
<table class="metrics-table">
  <tr><td>Total Errors Found:</td><td><strong>%d</strong></td></tr>
  <tr><td>Error Returns:</td><td><strong>%d</strong></td></tr>
  <tr><td>Error Wraps:</td><td><strong>%d</strong></td></tr>
  <tr><td>Silent Swallows:</td><td><strong>%d</strong></td></tr>
  <tr><td>Panics on Errors:</td><td><strong>%d</strong></td></tr>
  <tr><td>Ignored Errors:</td><td><strong>%d</strong></td></tr>
  <tr><td>Max Wrap Depth:</td><td><strong>%d</strong></td></tr>
</table>`,
			m.TotalErrors, m.ErrorReturns, m.ErrorWraps,
			m.SilentSwallows, m.PanicsOnErrors, m.IgnoredErrors, m.WrapDepth)

		if len(m.MostCommonErrors) > 0 {
			builder.WriteString(`<h3>Most Common Errors:</h3>
<ul class="common-errors">`)

			type errorCount struct {
				name  string
				count uint
			}

			sorted := make([]errorCount, 0, len(m.MostCommonErrors))
			for errName, count := range m.MostCommonErrors {
				sorted = append(sorted, errorCount{errName, count})
			}

			sort.Slice(sorted, func(i, j int) bool {
				if sorted[i].count != sorted[j].count {
					return sorted[i].count > sorted[j].count
				}

				return sorted[i].name < sorted[j].name
			})

			for _, ec := range sorted {
				fmt.Fprintf(builder, `<li>%s: <strong>%d</strong></li>`,
					template.HTMLEscapeString(ec.name),
					ec.count)
			}

			builder.WriteString(`</ul>`)
		}
	})
}

// GenerateViolations generates a violations report.
func (v *HTMLGenerator) GenerateViolations(violations []types.ErrorViolation) string {
	if v.graph == nil {
		return msgGraphNilHTML
	}

	return v.GenerateHTML(violations)
}

// GenerateSummary generates a summary of violations.
func (v *HTMLGenerator) GenerateSummary(violations []types.ErrorViolation) string {
	if v.graph == nil {
		return msgGraphNilHTML
	}

	if len(violations) == 0 {
		return `<div class="section">
  <h2 class="section-title">No violations found! 🎉</h2>
  <p>Great job following error handling best practices!</p>
</div>`
	}

	return render(v.graph, msgGraphNilHTML, func(builder *strings.Builder) {
		stats := v.calculateStats(violations)

		fmt.Fprintf(builder, `<h2>Summary</h2>
<div class="summary">
  <div class="stat">
    <span class="stat-label">Total Violations:</span>
    <strong>%d</strong>
  </div>
</div>`, len(violations))

		if len(stats.BySeverity) > 0 {
			builder.WriteString(`<h3>By Severity:</h3>
<table class="summary-table">`)

			for _, severity := range []types.Severity{types.SeverityHigh, types.SeverityMedium, types.SeverityLow} {
				if len(stats.BySeverity[severity]) > 0 {
					fmt.Fprintf(builder, `  <tr><td>%s:</td><td><strong>%d</strong></td></tr>`,
						strings.ToUpper(string(severity)), len(stats.BySeverity[severity]))
				}
			}

			builder.WriteString(`</table>`)
		}

		if len(stats.ByType) > 0 {
			builder.WriteString(`<h3>By Type:</h3>
<table class="summary-table">`)

			sortedTypes := make([]types.ErrorType, 0, len(stats.ByType))
			for typ := range stats.ByType {
				sortedTypes = append(sortedTypes, typ)
			}

			sort.Slice(sortedTypes, func(i, j int) bool {
				return string(sortedTypes[i]) < string(sortedTypes[j])
			})

			for _, typ := range sortedTypes {
				violations := stats.ByType[typ]
				fmt.Fprintf(builder, `  <tr><td>%s:</td><td><strong>%d</strong></td></tr>`,
					template.HTMLEscapeString(string(typ)),
					len(violations))
			}

			builder.WriteString(`</table>`)
		}
	})
}
