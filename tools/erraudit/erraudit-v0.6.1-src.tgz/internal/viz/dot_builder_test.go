package viz

import (
	"strings"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
)

func TestEscapeDOTString(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name  string
		input string
		want  string
	}{
		{"plain", "ErrFoo", "ErrFoo"},
		{"quote", `say "hi"`, `say \"hi\"`},
		{"backslash", `path\to`, `path\\to`},
		{
			"backslash before quote stays literal",
			`a\"b`,
			`a\\\"b`,
		},
		{"newline", "line1\nline2", `line1\nline2`},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()
			assert.Equal(t, tc.want, escapeDOTString(tc.input))
		})
	}
}

func TestDotAttrRender(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name string
		attr dotAttr
		want string
	}{
		{"bare", dotBareAttr("shape", "box"), "shape=box"},
		{"quoted", dotQuotedAttr("label", `say "hi"`), `label="say \"hi\""`},
		{"int", dotIntAttr("fontsize", 24), "fontsize=24"},
		{"float", dotFloatAttr("ranksep", 0.5), "ranksep=0.5"},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()
			assert.Equal(t, tc.want, tc.attr.render())
		})
	}
}

func TestDotDocumentWriteTo(t *testing.T) {
	t.Parallel()

	doc := &dotDocument{
		name:     "Test",
		comments: []string{"a comment", "render hint"},
		blocks: []dotBlock{
			{header: "graph", attrs: []dotAttr{dotQuotedAttr("label", "G")}},
			{header: "node0", attrs: []dotAttr{dotBareAttr("shape", "box")}},
			{header: "node0 -> node1", attrs: []dotAttr{dotBareAttr("arrowhead", "vee")}},
		},
	}

	var builder strings.Builder
	doc.writeTo(&builder)

	expected := `digraph Test {
  // a comment
  // render hint

  graph [
    label="G"
  ]

  node0 [
    shape=box
  ]

  node0 -> node1 [
    arrowhead=vee
  ]

}
`
	assert.Equal(t, expected, builder.String())
}

func TestDotDocumentWriteTo_NoComments(t *testing.T) {
	t.Parallel()

	doc := &dotDocument{
		name:   "Bare",
		blocks: []dotBlock{{header: "graph", attrs: []dotAttr{dotBareAttr("rankdir", "TB")}}},
	}

	var builder strings.Builder
	doc.writeTo(&builder)

	assert.Equal(t, "digraph Bare {\n  graph [\n    rankdir=TB\n  ]\n\n}\n", builder.String())
}

func TestGenerateDOT_LabelEscaping(t *testing.T) {
	t.Parallel()

	graph := &types.ErrorGraph{
		Package: "test",
		Hierarchy: &types.ErrorHierarchy{
			RootErrors: []*types.ErrorNode{
				{
					Name:    "ErrTricky",
					Kind:    types.ErrorKindWrap,
					Message: "back\\slash \"quoted\"\nsecond line",
				},
			},
		},
	}

	output := NewDOTVisualizer(graph).GenerateDOT()

	assert.Contains(t, output, `label="ErrTricky\nback\\slash \"quoted\"\nsecond line"`)
}

func TestGenerateDOT_FormatStability(t *testing.T) {
	t.Parallel()

	graph := newTestGraphWithHierarchy("ErrRoot", "ErrChild")
	output := NewDOTVisualizer(graph).GenerateDOT()

	assert.True(t, strings.HasPrefix(output, "digraph ErrorHierarchy {\n"), "must start with digraph header")
	assert.Contains(t, output, "  // Error Hierarchy Graph\n")
	assert.Contains(t, output, "  graph [\n    label=\"Error Hierarchy Graph\"\n")
	assert.Contains(t, output, "  node0 [\n    label=\"ErrRoot\"\n")
	assert.Contains(t, output, "  node0 -> node1 [\n")
	assert.True(t, strings.HasSuffix(output, "\n}\n"), "must close the digraph")
}
