package viz

import (
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestMinifyCSS(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name  string
		input string
		want  string
	}{
		{
			name:  "comment removed",
			input: "/* header */\nbody { color: red; }",
			want:  "body{color: red}",
		},
		{
			name:  "whitespace collapsed and delimiters tightened",
			input: ".a , .b {\n  margin: 0 1px 3px;\n}",
			want:  ".a,.b{margin: 0 1px 3px}",
		},
		{
			name:  "quoted string preserved verbatim",
			input: `body { font-family: "Space  Grotesk", sans-serif; }`,
			want:  `body{font-family: "Space  Grotesk",sans-serif}`,
		},
		{
			name:  "escaped quote inside string preserved",
			input: `h1:before { content: "a\"b"; }`,
			want:  `h1:before{content: "a\"b"}`,
		},
		{
			name:  "trailing semicolon before brace dropped",
			input: "a { b: c; d: e }",
			want:  "a{b: c;d: e}",
		},
		{
			name:  "colon spacing preserved",
			input: "a { color: #fff }",
			want:  "a{color: #fff}",
		},
		{
			name:  "media query semantics preserved",
			input: "@media screen and (max-width: 600px) { .a { top: 0 } }",
			want:  "@media screen and (max-width: 600px){.a{top: 0}}",
		},
		{
			name:  "unterminated comment drops remainder",
			input: "a { b: c } /* trailing",
			want:  "a{b: c}",
		},
		{
			name:  "template actions left untouched",
			input: "body { background: {{.Color }}; }",
			want:  "body { background: {{.Color }}; }",
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()
			assert.Equal(t, tc.want, minifyCSS(tc.input))
		})
	}
}

func TestMinifyHTMLCSS(t *testing.T) {
	t.Parallel()

	doc := "<html><style>\n  /* x */\n  p { color: red; }\n</style><body><style>q{w:e}</style></body></html>"
	got := minifyHTMLCSS(doc)

	assert.Equal(t, "<html><style>p{color: red}</style><body><style>q{w:e}</style></body></html>", got)
}

func TestMinifyHTMLCSS_NoStyleBlock(t *testing.T) {
	t.Parallel()

	doc := "<html><body>plain</body></html>"

	assert.Equal(t, doc, minifyHTMLCSS(doc))
}

// TestEmbeddedTemplateStyleIsMinified verifies the shipped template parses
// from a minified stylesheet: the raw embedded source must shrink and lose
// its comments, and no stray newlines may remain inside the style block.
func TestEmbeddedTemplateStyleIsMinified(t *testing.T) {
	t.Parallel()

	minified := minifyHTMLCSS(htmlTemplate)

	styleStart := strings.Index(minified, "<style>")
	requireTrue := styleStart >= 0
	assert.True(t, requireTrue, "template must contain a style block")

	styleEnd := strings.Index(minified[styleStart:], "</style>")
	style := minified[styleStart : styleStart+styleEnd]

	assert.Less(t, len(style), len(htmlTemplate), "minified style must be smaller than raw template")
	assert.NotContains(t, style, "/*")
	assert.NotContains(t, style, "\n  ")
}
