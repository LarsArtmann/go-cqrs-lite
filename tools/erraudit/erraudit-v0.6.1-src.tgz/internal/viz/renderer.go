package viz

import (
	"strings"

	"github.com/larsartmann/erraudit/pkg/types"
)

// render centralizes the graph-nil guard + strings.Builder boilerplate shared
// across every visualizer's Generate* method. Each renderer receives a fresh
// builder; an early `return` inside the closure exits only the closure, so
// callers must always end with builder writes rather than returning the string
// themselves.
//
// We pass the graph explicitly (rather than a method receiver) because
// TreeVisualizer and HTMLGenerator are distinct types with no shared interface,
// and a shared interface would force every caller to define methods just to
// satisfy the helper. Generics keep the helper free of any such coupling.
func render(graph *types.ErrorGraph, nilMsg string, write func(*strings.Builder)) string {
	if graph == nil {
		return nilMsg
	}

	var b strings.Builder
	write(&b)

	return b.String()
}
