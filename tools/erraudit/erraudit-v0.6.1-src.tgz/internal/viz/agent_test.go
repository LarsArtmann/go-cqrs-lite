package viz

import (
	"go/token"
	"strings"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
)

// makeViolationWithCode creates a violation with code snippet and suggestion.
func makeViolationWithCode(
	filename string,
	line, column int,
	msg, suggestion, code string,
) types.ErrorViolation {
	return types.ErrorViolation{
		Position:    token.Position{Filename: filename, Line: line, Column: column},
		Type:        types.ErrorTypePanic,
		Severity:    types.SeverityHigh,
		Message:     msg,
		Suggestion:  suggestion,
		CodeSnippet: code,
	}
}

// makeViolationWithFileName creates a violation with Position.Filename set.
func makeViolationWithFileName(filename string, line int) types.ErrorViolation {
	return types.ErrorViolation{
		Position: token.Position{Filename: filename, Line: line, Column: 1},
		Type:     types.ErrorTypePanic,
		Severity: types.SeverityHigh,
		Message:  "test",
	}
}

func TestAgentVisualizer_GenerateAgentOutput_EmptyViolations(t *testing.T) {
	viz := NewAgentVisualizer(nil)
	output := viz.GenerateAgentOutput(nil)

	assert.Equal(t, "No violations found.\n", output)
}

func TestAgentVisualizer_GenerateAgentOutput_SingleViolation(t *testing.T) {
	graph := &types.ErrorGraph{Package: "test"}
	violations := []types.ErrorViolation{
		makeViolationWithCode(
			"main.go",
			42,
			5,
			"Panic on error",
			"Return the error instead of panicking",
			"  41 \n> 42 panic(err)\n  43 }",
		),
	}

	viz := NewAgentVisualizer(graph)
	output := viz.GenerateAgentOutput(violations)

	assert.Contains(t, output, "# erraudit: 1 violations found (1 CRITICAL)")
	assert.Contains(t, output, "## main.go (1 violations)")
	assert.Contains(t, output, "main.go:42:5 [CRITICAL] panic: Panic on error")
	assert.Contains(t, output, "Fix: Return the error instead of panicking")
	assert.Contains(t, output, "Code:")
	assert.Contains(t, output, "> 42 panic(err)")
}

func TestAgentVisualizer_GenerateAgentOutput_MultipleFiles(t *testing.T) {
	graph := &types.ErrorGraph{Package: "test"}
	violations := []types.ErrorViolation{
		makeViolationAt("b.go", 10, 1, types.ErrorTypeIgnored, types.SeverityMedium, "Error ignored"),
		makeViolationAt("a.go", 5, 1, types.ErrorTypePanic, types.SeverityHigh, "Panic found"),
		makeViolationAt("a.go", 3, 1, types.ErrorTypeUnwrapped, types.SeverityMedium, "Unwrapped error"),
	}

	viz := NewAgentVisualizer(graph)
	output := viz.GenerateAgentOutput(violations)

	aGoIdx := strings.Index(output, "## a.go")
	bGoIdx := strings.Index(output, "## b.go")
	assert.Less(t, aGoIdx, bGoIdx, "files should be sorted alphabetically")

	assert.Contains(t, output, "a.go:3:1 [ERROR] unwrapped")
	assert.Contains(t, output, "a.go:5:1 [CRITICAL] panic")
	assert.Contains(t, output, "b.go:10:1 [ERROR] ignored")

	assert.Contains(t, output, "3 violations found")
}

func TestAgentVisualizer_GenerateAgentOutput_UsesPositionFilename(t *testing.T) {
	graph := &types.ErrorGraph{Package: "test"}
	violations := []types.ErrorViolation{
		makeViolationWithFileName("explicit_file.go", 1),
	}

	viz := NewAgentVisualizer(graph)
	output := viz.GenerateAgentOutput(violations)

	assert.Contains(t, output, "## explicit_file.go")
	assert.Contains(t, output, "explicit_file.go:1:1")
}

func TestAgentVisualizer_GenerateAgentOutput_NoSuggestion(t *testing.T) {
	graph := &types.ErrorGraph{Package: "test"}
	violations := []types.ErrorViolation{
		types.MakeTestViolation("main.go", 1, types.ErrorTypePanic, types.SeverityHigh, "test"),
	}

	viz := NewAgentVisualizer(graph)
	output := viz.GenerateAgentOutput(violations)

	assert.NotContains(t, output, "Fix:")
}

func TestAgentVisualizer_GenerateAgentOutput_SeverityCounts(t *testing.T) {
	graph := &types.ErrorGraph{Package: "test"}
	violations := []types.ErrorViolation{
		{
			Position: token.Position{Filename: "a.go"},
			Type:     types.ErrorTypePanic,
			Severity: types.SeverityHigh,
			Message:  "h1",
		},
		{
			Position: token.Position{Filename: "b.go"},
			Type:     types.ErrorTypePanic,
			Severity: types.SeverityHigh,
			Message:  "h2",
		},
		{
			Position: token.Position{Filename: "c.go"},
			Type:     types.ErrorTypeIgnored,
			Severity: types.SeverityMedium,
			Message:  "m1",
		},
		{
			Position: token.Position{Filename: "d.go"},
			Type:     types.ErrorTypeReturn,
			Severity: types.SeverityLow,
			Message:  "l1",
		},
	}

	viz := NewAgentVisualizer(graph)
	output := viz.GenerateAgentOutput(violations)

	assert.Contains(t, output, "4 violations found (2 CRITICAL, 1 ERROR, 1 WARNING)")
}

func TestAgentVisualizer_GenerateMetrics(t *testing.T) {
	graph := &types.ErrorGraph{
		Package: "test",
		Metrics: types.ErrorMetrics{
			TotalErrors:    100,
			ErrorReturns:   50,
			ErrorWraps:     20,
			SilentSwallows: 5,
			PanicsOnErrors: 2,
			IgnoredErrors:  10,
			WrapDepth:      3,
		},
	}

	viz := NewAgentVisualizer(graph)
	output := viz.GenerateMetrics()

	assert.Contains(t, output, "total=100")
	assert.Contains(t, output, "returns=50")
	assert.Contains(t, output, "wraps=20")
	assert.Contains(t, output, "swallows=5")
	assert.Contains(t, output, "panics=2")
	assert.Contains(t, output, "ignored=10")
	assert.Contains(t, output, "max_depth=3")
}

func TestAgentVisualizer_GenerateMetrics_NilGraph(t *testing.T) {
	viz := NewAgentVisualizer(nil)
	output := viz.GenerateMetrics()

	assert.Equal(t, "{}\n", output)
}

func TestAgentVisualizer_GenerateSummary(t *testing.T) {
	violations := []types.ErrorViolation{
		{Severity: types.SeverityHigh, Message: "h"},
		{Severity: types.SeverityHigh, Message: "h2"},
		{Severity: types.SeverityMedium, Message: "m"},
	}

	viz := NewAgentVisualizer(nil)
	output := viz.GenerateSummary(violations)

	assert.Contains(t, output, "violations=3")
	assert.Contains(t, output, "CRITICAL=2")
	assert.Contains(t, output, "ERROR=1")
}

func TestAgentVisualizer_GenerateSummary_Empty(t *testing.T) {
	viz := NewAgentVisualizer(nil)
	output := viz.GenerateSummary(nil)

	assert.Equal(t, "violations=0\n", output)
}

func TestAgentVisualizer_GenerateViolations_Interface(t *testing.T) {
	graph := &types.ErrorGraph{Package: "test"}
	violations := []types.ErrorViolation{
		makeSimpleViolation("f.go", 1, types.ErrorTypePanic, "test"),
	}

	viz := NewAgentVisualizer(graph)
	output := viz.GenerateViolations(violations)

	assert.Contains(t, output, "f.go:1:1")
}

func TestAgentVisualizer_WriteCodeSnippet_CleansMarkers(t *testing.T) {
	graph := &types.ErrorGraph{Package: "test"}
	violations := []types.ErrorViolation{
		makeViolationWithCode("f.go", 10, 1, "test", "", "   9 \n> 10 panic(err)\n  11 return nil"),
	}

	viz := NewAgentVisualizer(graph)
	output := viz.GenerateAgentOutput(violations)

	assert.Contains(t, output, "> 10 panic(err)")
	assert.Contains(t, output, "9 ")
	assert.Contains(t, output, "11 return nil")
}

func TestGroupByFile_SortsByLine(t *testing.T) {
	violations := []types.ErrorViolation{
		makeViolationAt("a.go", 20, 1, types.ErrorTypePanic, types.SeverityHigh, "p"),
		makeViolationAt("a.go", 5, 1, types.ErrorTypePanic, types.SeverityHigh, "p"),
		makeViolationAt("a.go", 10, 3, types.ErrorTypePanic, types.SeverityHigh, "p"),
		makeViolationAt("a.go", 10, 1, types.ErrorTypePanic, types.SeverityHigh, "p"),
	}

	groups := groupByFile(violations)

	assert.Len(t, groups, 1)
	assert.Equal(t, "a.go", groups[0].fileName)
	assert.Len(t, groups[0].violations, 4)

	assert.Equal(t, 5, groups[0].violations[0].Position.Line)
	assert.Equal(t, 10, groups[0].violations[1].Position.Line)
	assert.Equal(t, 1, groups[0].violations[1].Position.Column)
	assert.Equal(t, 10, groups[0].violations[2].Position.Line)
	assert.Equal(t, 3, groups[0].violations[2].Position.Column)
	assert.Equal(t, 20, groups[0].violations[3].Position.Line)
}

func TestGroupByFile_SortsByName(t *testing.T) {
	violations := []types.ErrorViolation{
		makeViolationAt("z.go", 1, 0, types.ErrorTypePanic, types.SeverityHigh, "p"),
		makeViolationAt("a.go", 1, 0, types.ErrorTypePanic, types.SeverityHigh, "p"),
		makeViolationAt("m.go", 1, 0, types.ErrorTypePanic, types.SeverityHigh, "p"),
	}

	groups := groupByFile(violations)

	assert.Len(t, groups, 3)
	assert.Equal(t, "a.go", groups[0].fileName)
	assert.Equal(t, "m.go", groups[1].fileName)
	assert.Equal(t, "z.go", groups[2].fileName)
}
