package viz

import (
	"fmt"
	"strconv"
	"strings"
)

// The DOT builder turns graph construction from ad-hoc fmt.Fprintf string
// concatenation into typed documents: attributes carry their own quoting
// rules, blocks render uniformly, and label escaping is handled in exactly
// one place. Output is byte-compatible with the previous string-built
// renderer apart from one deliberate fix: backslashes in labels are now
// escaped before quotes, so labels like `a\"b` no longer corrupt the
// surrounding DOT string literal.

// dotAttr is a single Graphviz attribute. Values are stored raw; quote
// decides whether render wraps the escaped value in double quotes.
type dotAttr struct {
	name  string
	value string
	quote bool
}

// dotBareAttr builds an unquoted attribute (numbers, keywords, pre-styled values).
func dotBareAttr(name, value string) dotAttr {
	return dotAttr{name: name, value: value, quote: false}
}

// dotQuotedAttr builds a quoted attribute whose value is escaped at render time.
func dotQuotedAttr(name, value string) dotAttr {
	return dotAttr{name: name, value: value, quote: true}
}

// dotFloatAttr builds an unquoted numeric attribute with one decimal place.
func dotFloatAttr(name string, value float64) dotAttr {
	return dotBareAttr(name, strconv.FormatFloat(value, 'f', 1, 64))
}

// dotIntAttr builds an unquoted integer attribute.
func dotIntAttr(name string, value int) dotAttr {
	return dotBareAttr(name, strconv.Itoa(value))
}

// render produces the attribute as a single DOT line body, e.g. `label="x"`.
func (a dotAttr) render() string {
	if a.quote {
		return fmt.Sprintf("%s=\"%s\"", a.name, escapeDOTString(a.value))
	}

	return a.name + "=" + a.value
}

// dotBlock is a DOT statement block: a header (graph, node, node0,
// node0 -> node1) followed by one attribute per line inside brackets.
type dotBlock struct {
	header string
	attrs  []dotAttr
}

// writeTo renders the block with the renderer's established indentation:
// two spaces outside, four spaces inside, blank line after.
func (b dotBlock) writeTo(builder *strings.Builder) {
	fmt.Fprintf(builder, "  %s [\n", b.header)

	for _, attr := range b.attrs {
		fmt.Fprintf(builder, "    %s\n", attr.render())
	}

	builder.WriteString("  ]\n\n")
}

// dotDocument is a complete digraph: header comments, attribute blocks,
// node blocks, and edge blocks in emission order.
type dotDocument struct {
	name     string
	comments []string
	blocks   []dotBlock
}

// writeTo renders the document. Comments are followed by a blank line; the
// footer closes the digraph.
func (d *dotDocument) writeTo(builder *strings.Builder) {
	fmt.Fprintf(builder, "digraph %s {\n", d.name)

	for _, comment := range d.comments {
		fmt.Fprintf(builder, "  // %s\n", comment)
	}

	if len(d.comments) > 0 {
		builder.WriteString("\n")
	}

	for _, block := range d.blocks {
		block.writeTo(builder)
	}

	builder.WriteString(dotFooter)
}

// escapeDOTString escapes a value for use inside a DOT double-quoted string.
// Backslashes must be escaped first so an input like `a\"b` produces
// `a\\\"b` (a literal backslash then a literal quote) instead of prematurely
// closing the string literal. Literal newlines become the \n escape sequence.
func escapeDOTString(s string) string {
	s = strings.ReplaceAll(s, `\`, `\\`)
	s = strings.ReplaceAll(s, `"`, `\"`)
	s = strings.ReplaceAll(s, "\n", `\n`)

	return s
}
