package viz

import (
	"fmt"
	"strings"

	"github.com/larsartmann/erraudit/pkg/types"
)

// writeSection writes a section header with an underline and content if the condition is true.
func writeSection(builder *strings.Builder, title string, hasContent bool, writeContent func()) {
	if !hasContent {
		return
	}

	builder.WriteString(title)
	builder.WriteByte('\n')
	builder.WriteString(strings.Repeat("-", len(title)))
	builder.WriteByte('\n')
	writeContent()
}

// GenerateErrorHierarchy generates the error hierarchy tree.
func (v *TreeVisualizer) GenerateErrorHierarchy() string {
	return render(v.graph, msgGraphNilNewline, func(builder *strings.Builder) {
		builder.WriteString("Error Hierarchy Tree\n")
		builder.WriteString("===================\n\n")

		if v.graph.Hierarchy == nil {
			builder.WriteString("No error hierarchy found.\n")

			return
		}

		h := v.graph.Hierarchy

		// Show metrics summary via the shared renderer (branching/chain +
		// inline reference counts — one formatting for all text formats).
		if NewHierarchyMetricsRenderer(v.graph).HasMetrics() {
			NewHierarchyMetricsRenderer(v.graph).TextLines(builder)

			builder.WriteString("\n")
		}

		// Show named errors grouped by kind
		writeSection(builder, "Named Errors", len(h.NamedErrors) > 0, func() {
			writeNamedErrorsTree(builder, h.NamedErrors)
			builder.WriteString("\n")
		})

		// Show relationships
		writeSection(builder, "Error Relationships", len(h.Relationships) > 0, func() {
			writeRelationshipsTree(builder, h.Relationships)
			builder.WriteString("\n")
		})

		// Show hierarchy tree if we have root errors
		writeSection(builder, "Hierarchy Tree", len(h.RootErrors) > 0, func() {
			writeHierarchyNodes(builder, h.RootErrors, "")
		})
	})
}

// writeNamedErrorsTree writes named errors grouped by kind.
func writeNamedErrorsTree(builder *strings.Builder, namedErrors []types.NamedError) {
	// Group by kind
	byKind := make(map[types.ErrorKind][]types.NamedError)
	for _, e := range namedErrors {
		byKind[e.Kind] = append(byKind[e.Kind], e)
	}

	for kind, errors := range byKind {
		fmt.Fprintf(builder, "\n%s:\n", kind)

		for _, e := range errors {
			location := e.FileName
			if e.Position.Line > 0 {
				location = fmt.Sprintf("%s:%d", e.FileName, e.Position.Line)
			}

			fmt.Fprintf(builder, "  %s", e.Name)

			if e.Message != "" {
				fmt.Fprintf(builder, " - %q", e.Message)
			}

			fmt.Fprintf(builder, " (%s)\n", location)
		}
	}
}

// writeRelationshipsTree writes error relationships.
func writeRelationshipsTree(builder *strings.Builder, relationships []types.ErrorRelationship) {
	for i, rel := range relationships {
		prefix := "├── "
		if i == len(relationships)-1 {
			prefix = "└── "
		}

		fmt.Fprintf(builder, "%s%s %s %s (depth: %d)\n",
			prefix,
			rel.Parent,
			rel.RelationshipType,
			rel.Child,
			rel.Depth)
	}
}

// writeHierarchyNodes writes the hierarchy tree recursively.
func writeHierarchyNodes(builder *strings.Builder, nodes []*types.ErrorNode, indent string) {
	for i, node := range nodes {
		isLast := i == len(nodes)-1

		prefix := indent + "├── "
		if isLast {
			prefix = indent + "└── "
		}

		fmt.Fprintf(builder, "%s%s", prefix, node.Name)

		if node.Message != "" {
			fmt.Fprintf(builder, " - %q", node.Message)
		}

		if node.Occurrences > 1 {
			fmt.Fprintf(builder, " (x%d)", node.Occurrences)
		}

		if node.Violations > 0 {
			fmt.Fprintf(builder, " [%d violations]", node.Violations)
		}

		builder.WriteString("\n")

		// Recursively write children
		if len(node.Children) > 0 {
			childIndent := indent
			if isLast {
				childIndent += "    "
			} else {
				childIndent += "│   "
			}

			writeHierarchyNodes(builder, node.Children, childIndent)
		}
	}
}
