package viz

import (
	"flag"
	"go/token"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
)

// updateGolden regenerates the golden files when -update is passed:
//
//	go test ./internal/viz/ -run TestGolden -update
var updateGolden = flag.Bool("update", false, "rewrite golden files")

// goldenViolation builds a deterministic violation for the golden fixture.
func goldenViolation(name string, line int, errType types.ErrorType, sev types.Severity) types.ErrorViolation {
	return types.ErrorViolation{
		Position: token.Position{Filename: "src/" + name + ".go", Line: line, Column: 3},
		Type:     errType,
		Severity: sev,
		Message:  name + " failed",
	}
}

// goldenGraph returns the fixed graph all golden renders are based on.
// NEVER modify this in place: changing it invalidates every golden file, and
// the full diff must be reviewed in the same commit.
func goldenGraph() *types.ErrorGraph {
	root := &types.ErrorNode{
		Name:    "ErrBase",
		Message: "base failure",
		Kind:    types.ErrorKindNew,
		Position: token.Position{
			Filename: "src/errors.go",
			Line:     3,
			Column:   5,
		},
		Depth:       1,
		Occurrences: 1,
	}
	wrapped := &types.ErrorNode{
		Name:    "ErrWrapped",
		Message: "wrapped: base failure",
		Kind:    types.ErrorKindErrorf,
		Position: token.Position{
			Filename: "src/errors.go",
			Line:     7,
			Column:   5,
		},
		Depth:       2,
		Occurrences: 2,
	}
	root.Children = []*types.ErrorNode{wrapped}

	violations := []types.ErrorViolation{
		goldenViolation("alpha", 10, types.ErrorTypeSilentSwallow, types.SeverityHigh),
		goldenViolation("beta", 20, types.ErrorTypeIgnored, types.SeverityMedium),
	}

	return &types.ErrorGraph{
		Package: "golden",
		Errors: []types.ErrorInfo{
			{
				Position: token.Position{Filename: "src/errors.go", Line: 3, Column: 5},
				Type:     types.ErrorTypeReturn,
				Message:  "base failure",
			},
		},
		Violations: violations,
		Hierarchy: &types.ErrorHierarchy{
			RootErrors: []*types.ErrorNode{root},
			Metrics: types.HierarchyMetrics{
				TotalNamedErrors:   2,
				TotalRelationships: 1,
				MaxDepth:           2,
			},
		},
		Metrics: types.ErrorMetrics{
			TotalErrors: 2,
		},
		FilesScanned: 2,
	}
}

func TestGoldenRenders(t *testing.T) {
	t.Parallel()

	graph := goldenGraph()

	renders := map[string]func() string{
		"dot.dot":       NewDOTVisualizer(graph).GenerateDOT,
		"mermaid.txt":   NewDOTVisualizer(graph).GenerateMermaid,
		"hierarchy.txt": NewTreeVisualizer(graph).GenerateErrorHierarchy,
	}

	renders["agent.txt"] = func() string {
		return NewAgentVisualizer(graph).GenerateAgentOutput(graph.Violations)
	}
	renders["full.txt"] = func() string {
		return NewTreeVisualizer(graph).GenerateSummary(graph.Violations)
	}
	renders["tree.txt"] = func() string {
		return NewTreeVisualizer(graph).GenerateViolations(graph.Violations)
	}

	htmlRender := func() string {
		return NewHTMLGenerator(graph).GenerateHTML(graph.Violations)
	}

	renders["report.html"] = htmlRender

	for name, render := range renders {
		t.Run(name, func(t *testing.T) {
			t.Parallel()

			got := render()
			goldenPath := filepath.Join("testdata", "golden", name)

			if *updateGolden {
				if err := os.MkdirAll(filepath.Dir(goldenPath), 0o755); err != nil {
					t.Fatalf("mkdir: %v", err)
				}

				if err := os.WriteFile(goldenPath, []byte(got), 0o644); err != nil {
					t.Fatalf("write golden: %v", err)
				}

				return
			}

			want, err := os.ReadFile(goldenPath)
			if err != nil {
				t.Fatalf("golden file missing (run with -update to seed): %v", err)
			}

			if got != string(want) {
				t.Errorf("render drifted from golden %s:\n--- golden ---\n%s\n--- got ---\n%s",
					name, strings.Clone(string(want)), got)
			}
		})
	}
}
