package viz

import (
	"fmt"
	"strconv"
	"strings"

	"github.com/larsartmann/erraudit/pkg/types"
)

// HierarchyMetricsRenderer renders HierarchyMetrics across text, agent, and
// HTML output formats. It encapsulates the nil-guard logic (graph == nil ||
// hierarchy == nil || no named errors) that was previously duplicated across
// GenerateSummary, GenerateSummaryStats, writeHierarchyLine, and the
// report.html template's {{if}} block.
type HierarchyMetricsRenderer struct {
	metrics *types.HierarchyMetrics
}

// NewHierarchyMetricsRenderer creates a renderer from an ErrorGraph.
// The returned renderer has no metrics when the graph or its hierarchy is nil.
func NewHierarchyMetricsRenderer(graph *types.ErrorGraph) *HierarchyMetricsRenderer {
	if graph == nil || graph.Hierarchy == nil {
		return &HierarchyMetricsRenderer{metrics: nil}
	}

	return &HierarchyMetricsRenderer{metrics: &graph.Hierarchy.Metrics}
}

// HasMetrics returns true when hierarchy metrics are present and contain at
// least one named error. All render methods are no-ops when this returns false.
func (r *HierarchyMetricsRenderer) HasMetrics() bool {
	return r.metrics != nil && r.metrics.TotalNamedErrors > 0
}

// metricsOrNil returns a copy of the metrics when present, or nil when
// HasMetrics() is false. Lets render methods collapse the "guard + deref"
// pattern into a single nil check.
func (r *HierarchyMetricsRenderer) metricsOrNil() *types.HierarchyMetrics {
	if !r.HasMetrics() {
		return nil
	}

	m := *r.metrics

	return &m
}

// TextLines writes the metrics as human-readable "Key: Value" lines to the
// builder. Each non-zero metric produces one line. No-op when HasMetrics() is
// false.
func (r *HierarchyMetricsRenderer) TextLines(builder *strings.Builder) {
	m := r.metricsOrNil()
	if m == nil {
		return
	}

	if m.TotalNamedErrors > 0 {
		builder.WriteString("Total Named Errors: ")
		builder.WriteString(strconv.FormatUint(uint64(m.TotalNamedErrors), 10))
		builder.WriteString("\n")
	}

	if m.TotalRelationships > 0 {
		builder.WriteString("Total Relationships: ")
		builder.WriteString(strconv.FormatUint(uint64(m.TotalRelationships), 10))
		builder.WriteString("\n")
	}

	if m.MaxDepth > 0 {
		builder.WriteString("Max Depth: ")
		builder.WriteString(strconv.FormatUint(uint64(m.MaxDepth), 10))
		builder.WriteString("\n")
	}

	if m.AvgBranchingFactor > 0 {
		builder.WriteString("Avg Branching Factor: ")
		builder.WriteString(strconv.FormatFloat(m.AvgBranchingFactor, 'f', 2, 64))
		builder.WriteString("\n")
	}

	if m.MaxBranchingParent != "" {
		builder.WriteString("Max Branching: ")
		builder.WriteString(m.MaxBranchingParent)
		builder.WriteString(" (")
		builder.WriteString(strconv.FormatUint(uint64(m.MaxBranchingCount), 10))
		builder.WriteString(" children)\n")
	}

	if m.LongestChainLength > 0 {
		builder.WriteString("Longest Chain: ")
		builder.WriteString(strconv.FormatUint(uint64(m.LongestChainLength), 10))
		builder.WriteString(" nodes (root: ")
		builder.WriteString(m.LongestChainRoot)
		builder.WriteString(")\n")
	}

	if m.InlineWrapSites > 0 {
		builder.WriteString("Inline Wrap Sites: ")
		builder.WriteString(strconv.FormatUint(uint64(m.InlineWrapSites), 10))
		builder.WriteString("\n")
	}

	if checkSites := m.TotalCheckSites(); checkSites > 0 {
		builder.WriteString("Sentinel Checks: ")
		builder.WriteString(strconv.FormatUint(uint64(checkSites), 10))
		builder.WriteString("\n")
	}

	if m.TypeCheckSites > 0 {
		builder.WriteString("Type Checks: ")
		builder.WriteString(strconv.FormatUint(uint64(m.TypeCheckSites), 10))
		builder.WriteString("\n")
	}
}

// AgentLine writes a compact "# hierarchy: named=N relationships=N depth=N
// branching=X.X chain=N" line to the builder for token-efficient agent
// consumption. Inline reference totals (wraps=N checks=M) are appended when
// non-zero, mirroring the tree footer's annotation. No-op when HasMetrics()
// is false.
func (r *HierarchyMetricsRenderer) AgentLine(builder *strings.Builder) {
	m := r.metricsOrNil()
	if m == nil {
		return
	}

	fmt.Fprintf(builder, "# hierarchy: named=%d relationships=%d depth=%d branching=%.1f chain=%d",
		m.TotalNamedErrors, m.TotalRelationships, m.MaxDepth, m.AvgBranchingFactor, m.LongestChainLength)

	if m.InlineWrapSites > 0 {
		fmt.Fprintf(builder, " wraps=%d", m.InlineWrapSites)
	}

	if checkSites := m.TotalCheckSites(); checkSites > 0 {
		fmt.Fprintf(builder, " checks=%d", checkSites)
	}

	if m.TypeCheckSites > 0 {
		fmt.Fprintf(builder, " typeChecks=%d", m.TypeCheckSites)
	}

	builder.WriteString("\n")
	builder.WriteString("\n")
}

// HTML renders the hierarchy metrics as the metrics-grid markup used by the
// HTML report: a subtitle heading followed by one metric-item per non-derived
// metric. Returns an empty string when HasMetrics() is false, so the template
// renders nothing where the section would be.
func (r *HierarchyMetricsRenderer) HTML() string {
	m := r.metricsOrNil()
	if m == nil {
		return ""
	}

	var builder strings.Builder

	builder.WriteString(`<h3 class="metrics-subtitle">Hierarchy Metrics</h3>`)
	builder.WriteString(`<div class="metrics-grid">`)

	htmlMetric := func(label, value string) {
		fmt.Fprintf(&builder, `<div class="metric-item"><span class="metric-label">%s</span>`+
			`<span class="metric-value">%s</span></div>`, label, value)
	}

	htmlMetric("Named Errors", strconv.FormatUint(uint64(m.TotalNamedErrors), 10))
	htmlMetric("Relationships", strconv.FormatUint(uint64(m.TotalRelationships), 10))
	htmlMetric("Max Depth", strconv.FormatUint(uint64(m.MaxDepth), 10))
	htmlMetric("Avg Branching", strconv.FormatFloat(m.AvgBranchingFactor, 'f', 2, 64))
	htmlMetric("Max Branching", strconv.FormatUint(uint64(m.MaxBranchingCount), 10))
	htmlMetric("Longest Chain", strconv.FormatUint(uint64(m.LongestChainLength), 10))

	if m.InlineWrapSites > 0 {
		htmlMetric("Inline Wrap Sites", strconv.FormatUint(uint64(m.InlineWrapSites), 10))
	}

	if checkSites := m.TotalCheckSites(); checkSites > 0 {
		htmlMetric("Sentinel Checks", strconv.FormatUint(uint64(checkSites), 10))
	}

	if m.TypeCheckSites > 0 {
		htmlMetric("Type Checks", strconv.FormatUint(uint64(m.TypeCheckSites), 10))
	}

	builder.WriteString(`</div>`)

	return builder.String()
}
