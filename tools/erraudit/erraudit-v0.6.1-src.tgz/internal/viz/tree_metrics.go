package viz

import (
	"fmt"
	"maps"
	"slices"
	"strings"

	"github.com/larsartmann/erraudit/pkg/types"
)

// GenerateMetrics generates a metrics summary.
func (v *TreeVisualizer) GenerateMetrics() string {
	return render(v.graph, msgGraphNilNewline, func(builder *strings.Builder) {
		m := v.graph.Metrics

		builder.WriteString("Error Metrics\n")
		builder.WriteString("=============\n\n")

		fmt.Fprintf(builder, "Total Errors Found: %d\n", m.TotalErrors)
		fmt.Fprintf(builder, "Error Returns: %d\n", m.ErrorReturns)
		fmt.Fprintf(builder, "Error Wraps: %d\n", m.ErrorWraps)
		fmt.Fprintf(builder, "Silent Swallows: %d\n", m.SilentSwallows)
		fmt.Fprintf(builder, "Panics on Errors: %d\n", m.PanicsOnErrors)
		fmt.Fprintf(builder, "Ignored Errors: %d\n", m.IgnoredErrors)
		fmt.Fprintf(builder, "Max Wrap Depth: %d\n", m.WrapDepth)

		builder.WriteString("\nMost Common Errors:\n")

		for _, errName := range slices.Sorted(maps.Keys(m.MostCommonErrors)) {
			fmt.Fprintf(builder, "  - %s: %d\n", errName, m.MostCommonErrors[errName])
		}
	})
}

// GenerateSummaryStats generates summary statistics.
func (v *TreeVisualizer) GenerateSummaryStats(violations []types.ErrorViolation) string {
	return render(v.graph, msgGraphNilNewline, func(builder *strings.Builder) {
		m := v.graph.Metrics

		builder.WriteString("Analysis Summary\n")
		builder.WriteString("===============\n\n")

		fmt.Fprintf(builder, "Total Errors Found: %d\n", m.TotalErrors)
		fmt.Fprintf(builder, "Error Returns: %d\n", m.ErrorReturns)
		fmt.Fprintf(builder, "Error Wraps: %d\n", m.ErrorWraps)
		fmt.Fprintf(builder, "Max Wrap Depth: %d\n", m.WrapDepth)

		// Coverage evidence line: a clean verdict must be distinguishable
		// from a scan that matched nothing (shared renderer, see
		// coverage.go).
		writeCoverageLine(v.graph, builder)

		fmt.Fprintf(builder, "\nTotal Violations: %d\n", len(violations))

		bySeverity := countBySeverity(violations)

		fmt.Fprintf(builder, "  CRITICAL: %d\n", bySeverity[types.SeverityHigh])
		fmt.Fprintf(builder, "  ERROR: %d\n", bySeverity[types.SeverityMedium])
		fmt.Fprintf(builder, "  WARNING: %d\n", bySeverity[types.SeverityLow])

		hierarchyRenderer := NewHierarchyMetricsRenderer(v.graph)
		if hierarchyRenderer.HasMetrics() {
			builder.WriteString("\nHierarchy Metrics\n")
			hierarchyRenderer.TextLines(builder)
		}
	})
}
