package viz

import (
	"encoding/json/jsontext"
	"encoding/json/v2"
	"fmt"

	"github.com/larsartmann/erraudit/pkg/errors"
	"github.com/larsartmann/erraudit/pkg/types"
)

// JSONVisualizer generates JSON output for errors.
type JSONVisualizer struct {
	graph *types.ErrorGraph
}

// NewJSONVisualizer creates a new JSON visualizer.
func NewJSONVisualizer(graph *types.ErrorGraph) *JSONVisualizer {
	return &JSONVisualizer{
		graph: graph,
	}
}

// GenerateJSON generates JSON representation.
func (v *JSONVisualizer) GenerateJSON() (string, error) {
	if v.graph == nil {
		return "", errors.New("graph is nil")
	}

	return v.generateJSON(v.graph)
}

// GenerateJSONWithViolations generates JSON with violations included.
func (v *JSONVisualizer) GenerateJSONWithViolations(
	violations []types.ErrorViolation,
) (string, error) {
	if v.graph == nil {
		return "", errors.New("graph is nil (violations count: 0)")
	}

	data := struct {
		Package    string                 `json:"package"`
		Errors     []types.ErrorInfo      `json:"errors"`
		Metrics    types.ErrorMetrics     `json:"metrics"`
		Violations []types.ErrorViolation `json:"violations"`
	}{
		Package:    v.graph.Package,
		Errors:     v.graph.Errors,
		Metrics:    v.graph.Metrics,
		Violations: violations,
	}

	return v.generateJSON(data)
}

// generateJSON generates JSON from any data structure.
func (v *JSONVisualizer) generateJSON(data any) (string, error) {
	bytes, err := json.Marshal(data, jsontext.WithIndentPrefix(""), jsontext.WithIndent("  "))
	if err != nil {
		return "", errors.Wrap(err, "failed to marshal JSON")
	}

	return string(bytes), nil
}

// marshalOrFallback renders data as JSON, returning a fallback error JSON
// object on failure so callers never propagate a marshal error to their
// public surface. errPrefix is used to label the failure (e.g. "metrics",
// "violations", "summary") in the fallback payload.
func (v *JSONVisualizer) marshalOrFallback(data any, errPrefix string) string {
	jsonStr, err := v.generateJSON(data)
	if err != nil {
		return fmt.Sprintf(`{"error": "failed to generate %s: %v"}`, errPrefix, err)
	}

	return jsonStr
}

// GenerateMetrics generates a metrics summary in JSON format.
func (v *JSONVisualizer) GenerateMetrics() string {
	if v.graph == nil {
		return msgGraphNilJSON
	}

	return v.marshalOrFallback(v.graph.Metrics, "metrics")
}

// GenerateViolations generates a violations report in JSON format.
func (v *JSONVisualizer) GenerateViolations(violations []types.ErrorViolation) string {
	if v.graph == nil {
		return msgGraphNilJSON
	}

	type ViolationsData struct {
		Count      int                    `json:"count"`
		Violations []types.ErrorViolation `json:"violations"`
	}

	return v.marshalOrFallback(ViolationsData{
		Count:      len(violations),
		Violations: violations,
	}, "violations")
}

// GenerateSummary generates a summary of violations in JSON format.
func (v *JSONVisualizer) GenerateSummary(violations []types.ErrorViolation) string {
	if v.graph == nil {
		return msgGraphNilJSON
	}

	type SummaryData struct {
		Package        string             `json:"package,omitempty"`
		ViolationCount int                `json:"violationCount"`
		Metrics        types.ErrorMetrics `json:"metrics"`
	}

	return v.marshalOrFallback(SummaryData{
		Package:        v.graph.Package,
		ViolationCount: len(violations),
		Metrics:        v.graph.Metrics,
	}, "summary")
}
