package viz

import "github.com/larsartmann/erraudit/pkg/types"

// countBySeverity counts violations by severity level.
func countBySeverity(violations []types.ErrorViolation) map[types.Severity]int {
	result := make(map[types.Severity]int, len(types.ValidSeverities()))
	for _, v := range violations {
		result[v.Severity]++
	}

	return result
}

// groupBySeverity groups violations by severity level.
func groupBySeverity(violations []types.ErrorViolation) map[types.Severity][]types.ErrorViolation {
	result := make(map[types.Severity][]types.ErrorViolation, len(types.ValidSeverities()))
	for _, v := range violations {
		result[v.Severity] = append(result[v.Severity], v)
	}

	return result
}
