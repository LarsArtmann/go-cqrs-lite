package viz

import (
	"github.com/larsartmann/erraudit/pkg/types"
)

// TreeVisualizer generates tree-based error visualizations.
type TreeVisualizer struct {
	graph *types.ErrorGraph
}

// NewTreeVisualizer creates a new tree visualizer.
func NewTreeVisualizer(graph *types.ErrorGraph) *TreeVisualizer {
	return &TreeVisualizer{graph: graph}
}
