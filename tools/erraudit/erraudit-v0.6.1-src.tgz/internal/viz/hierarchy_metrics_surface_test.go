package viz

import (
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
)

// graphWithHierarchyMetrics builds a graph with populated HierarchyMetrics for
// testing that hierarchy data surfaces in every output format.
func graphWithHierarchyMetrics() *types.ErrorGraph {
	return &types.ErrorGraph{
		Package: "test",
		Metrics: types.ErrorMetrics{
			TotalErrors:  5,
			ErrorReturns: 3,
			ErrorWraps:   2,
		},
		Hierarchy: &types.ErrorHierarchy{
			NamedErrors: []types.NamedError{
				{Name: "ErrA"}, {Name: "ErrB"}, {Name: "ErrC"},
			},
			Metrics: types.HierarchyMetrics{
				TotalNamedErrors:   3,
				TotalRelationships: 2,
				MaxDepth:           2,
				AvgBranchingFactor: 1.5,
				MaxBranchingParent: "ErrA",
				MaxBranchingCount:  2,
				LongestChainLength: 3,
				LongestChainRoot:   "ErrC",
				InlineWrapSites:    7,
				WrapSitesByError:   map[string]uint{"ErrA": 2},
				CheckSitesByError:  map[string]uint{"ErrA": 4, "ErrB": 1},
				TypeCheckSites:     2,
			},
		},
	}
}

// singleViolation returns a trivial violation so format paths that require
// violations (agent GenerateAgentOutput, HTML template metrics block) activate.
func singleViolation() []types.ErrorViolation {
	return []types.ErrorViolation{
		{Type: types.ErrorTypeUnwrapped, Severity: types.SeverityMedium, Message: "test"},
	}
}

// TestTreeFormat_GenerateSummaryStats_HierarchyMetrics verifies the tree format
// surfaces branching/chain metrics in its Analysis Summary section.
func TestTreeFormat_GenerateSummaryStats_HierarchyMetrics(t *testing.T) {
	viz := NewTreeVisualizer(graphWithHierarchyMetrics())
	output := viz.GenerateSummaryStats(singleViolation())

	assert.Contains(t, output, "Hierarchy Metrics")
	assert.Contains(t, output, "Total Named Errors: 3")
	assert.Contains(t, output, "Avg Branching Factor: 1.50")
	assert.Contains(t, output, "Longest Chain: 3 nodes")
}

// TestReferenceCountsSurfaceInAllTextFormats verifies the inline reference
// totals render in full, hierarchy, tree (stats block), agent, and HTML — the
// four formats that previously showed usage annotations only in tree paths.
func TestReferenceCountsSurfaceInAllTextFormats(t *testing.T) {
	graph := graphWithHierarchyMetrics()
	violations := singleViolation()

	assert.Contains(t, NewTreeVisualizer(graph).GenerateSummary(violations), "Inline Wrap Sites: 7")
	assert.Contains(t, NewTreeVisualizer(graph).GenerateSummaryStats(violations), "Inline Wrap Sites: 7")
	assert.Contains(t, NewTreeVisualizer(graph).GenerateSummaryStats(violations), "Sentinel Checks: 5")
	assert.Contains(t, NewAgentVisualizer(graph).GenerateAgentOutput(violations), "wraps=7")
	assert.Contains(t, NewAgentVisualizer(graph).GenerateAgentOutput(violations), "checks=5")
	assert.Contains(t, NewAgentVisualizer(graph).GenerateAgentOutput(violations), "typeChecks=2")
	assert.Contains(t, NewHTMLGenerator(graph).GenerateHTML(violations), "Inline Wrap Sites")
	assert.Contains(t, NewHTMLGenerator(graph).GenerateHTML(violations), "Sentinel Checks")
	assert.Contains(t, NewHTMLGenerator(graph).GenerateHTML(violations), "Type Checks")
}

// TestReferenceCountsOmittedWhenZero verifies formats stay clean for graphs
// without inline reference activity — no zero-valued annotation lines.
func TestReferenceCountsOmittedWhenZero(t *testing.T) {
	graph := &types.ErrorGraph{
		Package: "test",
		Hierarchy: &types.ErrorHierarchy{
			NamedErrors: []types.NamedError{{Name: "ErrA"}},
			Metrics:     types.HierarchyMetrics{TotalNamedErrors: 1},
		},
	}
	violations := singleViolation()

	assert.NotContains(t, NewTreeVisualizer(graph).GenerateSummaryStats(violations), "Inline Wrap Sites")
	assert.NotContains(t, NewAgentVisualizer(graph).GenerateAgentOutput(violations), "wraps=")
	assert.NotContains(t, NewHTMLGenerator(graph).GenerateHTML(violations), "Sentinel Checks")
}

// TestTreeFormat_GenerateSummaryStats_NoHierarchy verifies no hierarchy section
// appears when the graph has no hierarchy data.
func TestTreeFormat_GenerateSummaryStats_NoHierarchy(t *testing.T) {
	graph := &types.ErrorGraph{
		Metrics: types.ErrorMetrics{TotalErrors: 1},
	}
	viz := NewTreeVisualizer(graph)
	output := viz.GenerateSummaryStats(nil)

	assert.NotContains(t, output, "Hierarchy Metrics")
}

// TestHTMLFormat_GenerateHTML_HierarchyMetrics verifies the HTML report
// includes hierarchy metric values when hierarchy data is present.
func TestHTMLFormat_GenerateHTML_HierarchyMetrics(t *testing.T) {
	viz := NewHTMLGenerator(graphWithHierarchyMetrics())
	output := viz.GenerateHTML(singleViolation())

	assert.Contains(t, output, "Hierarchy Metrics")
	assert.Contains(t, output, "Named Errors")
	assert.Contains(t, output, "Avg Branching")
	assert.Contains(t, output, "1.50")
}

// TestHTMLFormat_GenerateHTML_NoHierarchy verifies the hierarchy section is
// omitted when no hierarchy data is available.
func TestHTMLFormat_GenerateHTML_NoHierarchy(t *testing.T) {
	graph := &types.ErrorGraph{
		Metrics: types.ErrorMetrics{TotalErrors: 1},
	}
	viz := NewHTMLGenerator(graph)
	output := viz.GenerateHTML(singleViolation())

	assert.NotContains(t, output, "Hierarchy Metrics")
}

// TestAgentFormat_GenerateAgentOutput_HierarchyMetrics verifies the agent format
// includes a compact hierarchy summary line.
func TestAgentFormat_GenerateAgentOutput_HierarchyMetrics(t *testing.T) {
	viz := NewAgentVisualizer(graphWithHierarchyMetrics())
	output := viz.GenerateAgentOutput(singleViolation())

	assert.Contains(t, output, "hierarchy:")
	assert.Contains(t, output, "named=3")
	assert.Contains(t, output, "relationships=2")
	assert.Contains(t, output, "depth=2")
	assert.Contains(t, output, "branching=1.5")
	assert.Contains(t, output, "chain=3")
}

// TestAgentFormat_GenerateAgentOutput_NoHierarchy verifies no hierarchy line
// appears when the graph has no hierarchy.
func TestAgentFormat_GenerateAgentOutput_NoHierarchy(t *testing.T) {
	graph := &types.ErrorGraph{Package: "test"}
	viz := NewAgentVisualizer(graph)
	output := viz.GenerateAgentOutput(singleViolation())

	assert.NotContains(t, output, "hierarchy:")
}

// TestHierarchyMetricsRenderer_HTML_Metrics verifies the Go-side HTML block
// carries every metric with the same labels the template previously rendered.
func TestHierarchyMetricsRenderer_HTML_Metrics(t *testing.T) {
	html := NewHierarchyMetricsRenderer(graphWithHierarchyMetrics()).HTML()

	assert.Contains(t, html, "Hierarchy Metrics")
	assert.Contains(t, html, "Named Errors")
	assert.Contains(t, html, ">3</span>")
	assert.Contains(t, html, "Relationships")
	assert.Contains(t, html, "Max Depth")
	assert.Contains(t, html, "Avg Branching")
	assert.Contains(t, html, "1.50")
	assert.Contains(t, html, "Max Branching")
	assert.Contains(t, html, "Longest Chain")
	assert.Contains(t, html, "metrics-grid")
}

// TestHierarchyMetricsRenderer_HTML_EmptyWhenNoMetrics verifies the HTML block
// is empty when there is no hierarchy data, so the template renders nothing.
func TestHierarchyMetricsRenderer_HTML_EmptyWhenNoMetrics(t *testing.T) {
	graph := &types.ErrorGraph{Package: "test"}

	assert.Empty(t, NewHierarchyMetricsRenderer(graph).HTML())
	assert.Empty(t, NewHierarchyMetricsRenderer(nil).HTML())
}
