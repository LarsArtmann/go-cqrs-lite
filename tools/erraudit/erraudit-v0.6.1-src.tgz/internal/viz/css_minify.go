package viz

import "strings"

// The CSS minifier shrinks the embedded report template's inline stylesheet
// at init time so every generated HTML report ships without dead bytes. It
// is deliberately conservative: it only removes CSS comments, collapses
// whitespace runs outside strings, and drops whitespace (and a trailing
// semicolon) around block/declaration delimiters. It never touches quoted
// strings, significant intra-value spaces (e.g. `0 1px 3px`), or colon
// spacing (selector vs. pseudo-class ambiguity).

// minifyHTMLCSS minifies every <style>...</style> block in the document.
// Text outside style blocks is returned unchanged.
func minifyHTMLCSS(doc string) string {
	var result strings.Builder

	for {
		start := strings.Index(doc, "<style>")
		if start < 0 {
			result.WriteString(doc)

			break
		}

		relEnd := strings.Index(doc[start:], "</style>")
		if relEnd < 0 {
			result.WriteString(doc)

			break
		}

		result.WriteString(doc[:start])
		result.WriteString("<style>")
		result.WriteString(minifyCSS(doc[start+len("<style>") : start+relEnd]))
		result.WriteString("</style>")

		doc = doc[start+relEnd+len("</style>"):]
	}

	return result.String()
}

// minifyCSS minifies a CSS source string in a single string- and
// comment-aware pass.
func minifyCSS(css string) string {
	// Leave blocks containing template actions untouched: they are parsed by
	// html/template afterwards, and collapsing bytes around {{...}} actions
	// could corrupt them.
	if strings.Contains(css, "{{") {
		return css
	}

	var result strings.Builder

	result.Grow(len(css))

	pendingSpace := false
	prev := byte(0)

	writeByte := func(b byte) {
		if pendingSpace {
			pendingSpace = false

			// Whitespace is redundant when it touches a block/declaration
			// delimiter on either side, or when nothing has been written yet;
			// everywhere else it is significant and collapses to one space.
			if cssSpaceSignificant(prev, b) {
				result.WriteByte(' ')
			}
		}

		result.WriteByte(b)
		prev = b
	}

	for i := 0; i < len(css); i++ {
		c := css[i]

		switch {
		case strings.HasPrefix(css[i:], "/*"):
			i = endOfCSSComment(css, i)

			pendingSpace = true // a comment separates tokens like whitespace
		case c == '"' || c == '\'':
			quote := c

			writeByte(c)

			for i+1 < len(css) {
				i++
				writeByte(css[i])

				if css[i] == '\\' && i+1 < len(css) {
					i++
					writeByte(css[i])
				} else if css[i] == quote {
					break
				}
			}
		case c == ' ' || c == '\t' || c == '\n' || c == '\r':
			pendingSpace = true
		case c == ';':
			// A semicolon whose next non-whitespace byte is "}" is redundant.
			if next := skipCSSWhitespace(css, i+1); next < len(css) && css[next] == '}' {
				continue
			}

			writeByte(c)
		default:
			writeByte(c)
		}
	}

	return strings.TrimSpace(result.String())
}

// cssSpaceSignificant reports whether a collapsed single space must be kept
// between the previously written byte and the next byte.
func cssSpaceSignificant(prev, next byte) bool {
	if prev == 0 { // start of output
		return false
	}

	return !isCSSDelimiter(prev) && !isCSSDelimiter(next)
}

// isCSSDelimiter reports whether b is a block/declaration delimiter around
// which whitespace is redundant.
func isCSSDelimiter(b byte) bool {
	switch b {
	case '{', '}', ';', ',':
		return true
	default:
		return false
	}
}

// endOfCSSComment returns the index of the '/' opening a "/*" comment at i
// replaced by the index of the '/' closing "*/" (the loop increment then
// skips past the close delimiter). Unterminated comments consume the rest
// of the input.
func endOfCSSComment(css string, i int) int {
	afterOpen := i + len("/*")

	end := strings.Index(css[afterOpen:], "*/")
	if end < 0 {
		return len(css)
	}

	return afterOpen + end + len("*/") - 1
}

// skipCSSWhitespace returns the index of the first non-whitespace byte at or
// after i.
func skipCSSWhitespace(css string, i int) int {
	for i < len(css) {
		switch css[i] {
		case ' ', '\t', '\n', '\r':
			i++
		default:
			return i
		}
	}

	return i
}
