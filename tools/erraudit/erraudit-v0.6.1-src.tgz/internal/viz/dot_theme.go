package viz

// DOTTheme defines the visual theme for DOT graph output.
// It allows customization of colors, fonts, and graph attributes.
type DOTTheme struct {
	Name string

	// Graph attributes
	Graph GraphAttributes

	// Node styling by error kind
	Nodes NodeTheme

	// Edge styling
	Edges EdgeTheme
}

// GraphAttributes defines top-level graph styling.
type GraphAttributes struct {
	Label     string
	FontSize  int
	RankDir   string // TB, LR, BT, RL
	RankSep   float64
	NodeSep   float64
	BgColor   string // Background color
	FontColor string // Graph label color
}

// NodeTheme defines styling for different node types.
type NodeTheme struct {
	Default  NodeAttributes
	Sentinel NodeAttributes
	Errorf   NodeAttributes
	Custom   NodeAttributes
	Wrap     NodeAttributes
	New      NodeAttributes
}

// NodeAttributes defines styling for a single node type.
type NodeAttributes struct {
	Shape       string
	Style       string
	FillColor   string
	FontColor   string
	FontName    string
	FontSize    int
	BorderColor string
	BorderWidth float64
}

// EdgeTheme defines edge styling.
type EdgeTheme struct {
	Color     string
	ArrowHead string
	Width     float64
	Style     string
}

// themePalette holds color configuration for building a theme.
type themePalette struct {
	name                string
	bgColor             string
	fontColor           string
	defaultFill         string
	defaultFontColor    string
	defaultBorderColor  string
	sentinelFill        string
	sentinelFontColor   string
	errorfFill          string
	errorfFontColor     string
	customFill          string
	customFontColor     string
	wrapFill            string
	wrapFontColor       string
	newFill             string
	newFontColor        string
	edgeColor           string
	sentinelBorderWidth float64
	sentinelBorderColor string
	errorfBorderColor   string
	customBorderColor   string
	wrapBorderColor     string
	newBorderColor      string
	defaultFontName     string
	defaultFontSize     int
	defaultShape        string
	defaultStyle        string
	defaultBorderWidth  float64
	edgeArrowHead       string
	edgeWidth           float64
	edgeStyle           string
	graphLabel          string
	graphFontSize       int
	graphRankDir        string
	graphRankSep        float64
	graphNodeSep        float64
	// Per-node-type shape and style overrides
	sentinelShape string
	sentinelStyle string
	errorfShape   string
	errorfStyle   string
	customShape   string
	customStyle   string
	wrapShape     string
	wrapStyle     string
	newShape      string
	newStyle      string
	// Per-node-type border width overrides
	errorfBorderWidth float64
	customBorderWidth float64
	wrapBorderWidth   float64
	newBorderWidth    float64
}

// nodeAttrs creates a NodeAttributes with the given color values and defaults from palette.
func nodeAttrs(
	p themePalette,
	shape, style, fillColor, fontColor, borderColor string,
	borderWidth float64,
) NodeAttributes {
	bw := borderWidth
	if bw == 0 {
		bw = p.defaultBorderWidth
	}

	s := style
	if s == "" {
		s = p.defaultStyle
	}

	sh := shape
	if sh == "" {
		sh = p.defaultShape
	}

	return NodeAttributes{
		Shape:       sh,
		Style:       s,
		FillColor:   fillColor,
		FontColor:   fontColor,
		FontName:    p.defaultFontName,
		FontSize:    p.defaultFontSize,
		BorderColor: borderColor,
		BorderWidth: bw,
	}
}

// newThemeFromPalette creates a DOTTheme from a color palette.
func newThemeFromPalette(p themePalette) DOTTheme {
	return DOTTheme{
		Name: p.name,
		Graph: GraphAttributes{
			Label:     p.graphLabel,
			FontSize:  p.graphFontSize,
			RankDir:   p.graphRankDir,
			RankSep:   p.graphRankSep,
			NodeSep:   p.graphNodeSep,
			BgColor:   p.bgColor,
			FontColor: p.fontColor,
		},
		Nodes: NodeTheme{
			Default: nodeAttrs(
				p,
				"",
				"",
				p.defaultFill,
				p.defaultFontColor,
				p.defaultBorderColor,
				0,
			),
			Sentinel: nodeAttrs(
				p,
				p.sentinelShape,
				p.sentinelStyle,
				p.sentinelFill,
				p.sentinelFontColor,
				p.sentinelBorderColor,
				p.sentinelBorderWidth,
			),
			Errorf: nodeAttrs(
				p,
				p.errorfShape,
				p.errorfStyle,
				p.errorfFill,
				p.errorfFontColor,
				p.errorfBorderColor,
				p.errorfBorderWidth,
			),
			Custom: nodeAttrs(
				p,
				p.customShape,
				p.customStyle,
				p.customFill,
				p.customFontColor,
				p.customBorderColor,
				p.customBorderWidth,
			),
			Wrap: nodeAttrs(
				p,
				p.wrapShape,
				p.wrapStyle,
				p.wrapFill,
				p.wrapFontColor,
				p.wrapBorderColor,
				p.wrapBorderWidth,
			),
			New: nodeAttrs(
				p,
				p.newShape,
				p.newStyle,
				p.newFill,
				p.newFontColor,
				p.newBorderColor,
				p.newBorderWidth,
			),
		},
		Edges: EdgeTheme{
			Color:     p.edgeColor,
			ArrowHead: p.edgeArrowHead,
			Width:     p.edgeWidth,
			Style:     p.edgeStyle,
		},
	}
}

// Default theme constants for common values.
const (
	defaultFontName      = "Helvetica"
	defaultFontSize      = 10
	defaultShape         = "box"
	defaultStyle         = "rounded,filled"
	defaultBorderWidth   = 1.0
	defaultEdgeArrowHead = "vee"
	defaultEdgeWidth     = 1.5
	defaultEdgeStyle     = "solid"
	defaultGraphLabel    = "Error Hierarchy Graph"
	defaultGraphFontSize = 14
	defaultGraphRankDir  = "TB"
	defaultGraphRankSep  = 0.5
	defaultGraphNodeSep  = 0.3
)

// Shared color constants used across multiple themes.
const (
	colorBlack       = "black"
	colorWhite       = "white"
	colorGreen500    = "#4CAF50"
	colorBlue500     = "#2196F3"
	colorOrange500   = "#FF9800"
	colorPurple500   = "#9C27B0"
	colorBlueGrey500 = "#607D8B"
	// Light background fills for default theme (Material Design *50 shades).
	colorGreenLightBg  = "#E8F5E9"
	colorBlueLightBg   = "#E3F2FD"
	colorOrangeLightBg = "#FFF3E0"
	colorPurpleLightBg = "#F3E5F5"
)

// Theme name constants for GetTheme and AvailableThemes.
const (
	themeNameDefault  = "default"
	themeNameDark     = "dark"
	themeNameMinimal  = "minimal"
	themeNameColorful = "colorful"
)

// Node style constants.
const (
	styleFilled = "filled"
)

// Theme-specific layout and width constants.
const (
	borderWidthBold      = 2.0
	minimalGraphFontSize = 12
	minimalRankSep       = 0.4
	minimalNodeSep       = 0.25
	colorfulRankSep      = 0.6
	colorfulNodeSep      = 0.4
	colorSlotsPerNode    = 3 // fill, font, border values per node entry in codedThemes
)

// basePalette returns a themePalette with common default values.
// Theme-specific colors should be overridden after calling this.
func basePalette(name string) themePalette {
	return themePalette{
		name:               name,
		defaultFontName:    defaultFontName,
		defaultFontSize:    defaultFontSize,
		defaultShape:       defaultShape,
		defaultStyle:       defaultStyle,
		defaultBorderWidth: defaultBorderWidth,
		edgeArrowHead:      defaultEdgeArrowHead,
		edgeWidth:          defaultEdgeWidth,
		edgeStyle:          defaultEdgeStyle,
		graphLabel:         defaultGraphLabel,
		graphFontSize:      defaultGraphFontSize,
		graphRankDir:       defaultGraphRankDir,
		graphRankSep:       defaultGraphRankSep,
		graphNodeSep:       defaultGraphNodeSep,
	}
}

// themeColors holds all color values for a theme.
type themeColors struct {
	bgColor             string
	fontColor           string
	defaultFill         string
	defaultFontColor    string
	defaultBorderColor  string
	sentinelFill        string
	sentinelFontColor   string
	sentinelBorderColor string
	sentinelBorderWidth float64
	errorfFill          string
	errorfFontColor     string
	errorfBorderColor   string
	customFill          string
	customFontColor     string
	customBorderColor   string
	wrapFill            string
	wrapFontColor       string
	wrapBorderColor     string
	newFill             string
	newFontColor        string
	newBorderColor      string
	edgeColor           string
}

// applyColors applies color values to a themePalette.
func applyColors(p *themePalette, c themeColors) {
	p.bgColor = c.bgColor
	p.fontColor = c.fontColor
	p.defaultFill = c.defaultFill
	p.defaultFontColor = c.defaultFontColor
	p.defaultBorderColor = c.defaultBorderColor
	p.sentinelFill = c.sentinelFill
	p.sentinelFontColor = c.sentinelFontColor
	p.sentinelBorderColor = c.sentinelBorderColor
	p.sentinelBorderWidth = c.sentinelBorderWidth
	p.errorfFill = c.errorfFill
	p.errorfFontColor = c.errorfFontColor
	p.errorfBorderColor = c.errorfBorderColor
	p.customFill = c.customFill
	p.customFontColor = c.customFontColor
	p.customBorderColor = c.customBorderColor
	p.wrapFill = c.wrapFill
	p.wrapFontColor = c.wrapFontColor
	p.wrapBorderColor = c.wrapBorderColor
	p.newFill = c.newFill
	p.newFontColor = c.newFontColor
	p.newBorderColor = c.newBorderColor
	p.edgeColor = c.edgeColor
}

// createColoredTheme creates a DOTTheme from a name and color configuration.
func createColoredTheme(name string, colors themeColors) DOTTheme {
	p := basePalette(name)
	applyColors(&p, colors)

	return newThemeFromPalette(p)
}

// codedThemes defines all color themes as flat string tables.
// Each entry: {name, bg, font, edge, default..., sentinel..., errorf..., custom..., wrap..., new...}
// where each color triple is: fill, font, border.
//
//nolint:gochecknoglobals // immutable theme lookup table
var codedThemes = [2][4 + 6*3]string{
	{
		themeNameDefault, colorWhite, colorBlack, "#666666",
		"#FAFAFA", colorBlack, "#666666",
		colorGreenLightBg, "#1B5E20", colorGreen500,
		colorBlueLightBg, "#0D47A1", colorBlue500,
		colorOrangeLightBg, "#E65100", colorOrange500,
		colorPurpleLightBg, "#6A1B9A", colorPurple500,
		"#ECEFF1", "#37474F", colorBlueGrey500,
	},
	{
		themeNameDark, "#1E1E1E", "#E0E0E0", "#888888",
		"#2D2D2D", "#E0E0E0", "#555555",
		"#1B3A1B", "#81C784", colorGreen500,
		"#0D2940", "#64B5F6", colorBlue500,
		"#3D2A0D", "#FFB74D", colorOrange500,
		"#2D1A3D", "#CE93D8", colorPurple500,
		"#2A2A2A", "#B0BEC5", colorBlueGrey500,
	},
}

// codedBorderWidths holds the border width per color slot: [default, sentinel, errorf, custom, wrap, new].
//
//nolint:gochecknoglobals // immutable border-width lookup table
var codedBorderWidths = [2][6]float64{
	{1.0, 1.5, 1.0, 1.0, 1.0, 1.0},
	{1.0, 1.5, 1.0, 1.0, 1.0, 1.0},
}

func themeFromCoded(idx int) DOTTheme {
	t := codedThemes[idx]
	w := codedBorderWidths[idx]
	offset := 4 // skip name, bg, font, edge

	pairs := make([]themeColorPair, 0, len(w))
	for i := range w {
		base := offset + i*colorSlotsPerNode
		pairs = append(pairs, themeColorPair{t[base], t[base+1], t[base+2], w[i]})
	}

	return createColoredTheme(
		t[0],
		lightThemeColors(t[1], t[2], pairs[0], pairs[1], pairs[2], pairs[3], pairs[4], pairs[5], t[3]),
	)
}

// themeColorPair holds foreground and background color pair.
type themeColorPair struct {
	fill        string
	font        string
	border      string
	borderWidth float64
}

// lightThemeColors creates themeColors for a light theme variant.
func lightThemeColors(
	bg, font string,
	defaultC, sentinelC, errorfC, customC, wrapC, newC themeColorPair,
	edge string,
) themeColors {
	return themeColors{
		bgColor:             bg,
		fontColor:           font,
		defaultFill:         defaultC.fill,
		defaultFontColor:    defaultC.font,
		defaultBorderColor:  defaultC.border,
		sentinelFill:        sentinelC.fill,
		sentinelFontColor:   sentinelC.font,
		sentinelBorderColor: sentinelC.border,
		sentinelBorderWidth: sentinelC.borderWidth,
		errorfFill:          errorfC.fill,
		errorfFontColor:     errorfC.font,
		errorfBorderColor:   errorfC.border,
		customFill:          customC.fill,
		customFontColor:     customC.font,
		customBorderColor:   customC.border,
		wrapFill:            wrapC.fill,
		wrapFontColor:       wrapC.font,
		wrapBorderColor:     wrapC.border,
		newFill:             newC.fill,
		newFontColor:        newC.font,
		newBorderColor:      newC.border,
		edgeColor:           edge,
	}
}

// Predefined themes.
//
//nolint:gochecknoglobals // Theme definitions are intentionally global for easy access
var (
	// ThemeDefault is the standard light theme.
	ThemeDefault = themeFromCoded(0)

	// ThemeDark is a dark mode theme.
	ThemeDark = themeFromCoded(1)

	// ThemeMinimal is a minimal black and white theme.
	ThemeMinimal = newThemeFromPalette(themePalette{
		name:                themeNameMinimal,
		bgColor:             colorWhite,
		fontColor:           colorBlack,
		defaultFill:         colorWhite,
		defaultFontColor:    colorBlack,
		defaultBorderColor:  colorBlack,
		sentinelFill:        colorWhite,
		sentinelFontColor:   colorBlack,
		sentinelBorderColor: colorBlack,
		sentinelBorderWidth: 1.0,
		sentinelShape:       "ellipse",
		sentinelStyle:       "",
		errorfFill:          colorWhite,
		errorfFontColor:     colorBlack,
		errorfBorderColor:   colorBlack,
		errorfStyle:         "dashed",
		customFill:          colorWhite,
		customFontColor:     colorBlack,
		customBorderColor:   colorBlack,
		customBorderWidth:   borderWidthBold,
		customStyle:         "bold",
		wrapFill:            colorWhite,
		wrapFontColor:       colorBlack,
		wrapBorderColor:     colorBlack,
		wrapStyle:           "dotted",
		newFill:             colorWhite,
		newFontColor:        colorBlack,
		newBorderColor:      colorBlack,
		newStyle:            "",
		edgeColor:           colorBlack,
		defaultFontName:     defaultFontName,
		defaultFontSize:     defaultFontSize,
		defaultShape:        defaultShape,
		defaultStyle:        "rounded",
		defaultBorderWidth:  defaultBorderWidth,
		edgeArrowHead:       "normal",
		edgeWidth:           1.0,
		edgeStyle:           defaultEdgeStyle,
		graphLabel:          "Error Hierarchy",
		graphFontSize:       minimalGraphFontSize,
		graphRankDir:        defaultGraphRankDir,
		graphRankSep:        minimalRankSep,
		graphNodeSep:        minimalNodeSep,
	})

	// ThemeColorful is a vibrant, colorful theme.
	ThemeColorful = newThemeFromPalette(themePalette{
		name:                themeNameColorful,
		bgColor:             colorWhite,
		fontColor:           "#333333",
		defaultFill:         "#F5F5F5",
		defaultFontColor:    "#333333",
		defaultBorderColor:  "#9E9E9E",
		sentinelFill:        colorGreen500,
		sentinelFontColor:   colorWhite,
		sentinelBorderColor: "#2E7D32",
		sentinelBorderWidth: borderWidthBold,
		sentinelShape:       "component",
		sentinelStyle:       styleFilled,
		errorfFill:          colorBlue500,
		errorfFontColor:     colorWhite,
		errorfBorderColor:   "#1565C0",
		errorfBorderWidth:   borderWidthBold,
		errorfShape:         "note",
		errorfStyle:         styleFilled,
		customFill:          colorOrange500,
		customFontColor:     colorWhite,
		customBorderColor:   "#E65100",
		customBorderWidth:   borderWidthBold,
		customShape:         "hexagon",
		customStyle:         styleFilled,
		wrapFill:            colorPurple500,
		wrapFontColor:       colorWhite,
		wrapBorderColor:     "#6A1B9A",
		wrapBorderWidth:     borderWidthBold,
		wrapShape:           "diamond",
		wrapStyle:           styleFilled,
		newFill:             colorBlueGrey500,
		newFontColor:        colorWhite,
		newBorderColor:      "#455A64",
		newBorderWidth:      borderWidthBold,
		newStyle:            styleFilled,
		edgeColor:           "#1565C0",
		defaultFontName:     defaultFontName,
		defaultFontSize:     defaultFontSize,
		defaultShape:        defaultShape,
		defaultStyle:        defaultStyle,
		defaultBorderWidth:  defaultBorderWidth,
		edgeArrowHead:       "diamond",
		edgeWidth:           borderWidthBold,
		edgeStyle:           "bold",
		graphLabel:          defaultGraphLabel,
		graphFontSize:       defaultGraphFontSize,
		graphRankDir:        defaultGraphRankDir,
		graphRankSep:        colorfulRankSep,
		graphNodeSep:        colorfulNodeSep,
	})
)

// GetTheme returns a theme by name, or the default theme if not found.
func GetTheme(name string) DOTTheme {
	switch name {
	case themeNameDark:
		return ThemeDark
	case themeNameMinimal:
		return ThemeMinimal
	case themeNameColorful:
		return ThemeColorful
	default:
		return ThemeDefault
	}
}

// AvailableThemes returns a list of available theme names.
func AvailableThemes() []string {
	return []string{themeNameDefault, themeNameDark, themeNameMinimal, themeNameColorful}
}
