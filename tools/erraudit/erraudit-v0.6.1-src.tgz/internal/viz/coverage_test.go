package viz

import (
	"go/token"
	"strings"
	"testing"

	"github.com/larsartmann/erraudit/pkg/types"
	"github.com/stretchr/testify/assert"
)

// testViolations returns a standard set of test violations for summary tests.
func testViolations(suffix string) []types.ErrorViolation {
	return []types.ErrorViolation{
		{Type: types.ErrorTypeUnwrapped, Severity: types.SeverityHigh, Message: "critical" + suffix},
		{Type: types.ErrorTypeUnwrapped, Severity: types.SeverityHigh, Message: "high2" + suffix},
		{Type: types.ErrorTypeReturn, Severity: types.SeverityMedium, Message: "med" + suffix},
		{Type: types.ErrorTypeReturn, Severity: types.SeverityLow, Message: "warning" + suffix},
	}
}

// testViolationsPair returns a pair of test violations for simpler tests.
func testViolationsPair(msgSuffix string) []types.ErrorViolation {
	return []types.ErrorViolation{
		{
			Type:     types.ErrorTypeUnwrapped,
			Severity: types.SeverityHigh,
			Message:  "unwrapped" + msgSuffix,
		},
		{
			Type:     types.ErrorTypeReturn,
			Severity: types.SeverityMedium,
			Message:  "return" + msgSuffix,
		},
	}
}

// makeViolationWithSuggestion builds a violation with a Suggestion field set.
func makeViolationWithSuggestion(
	filename string,
	line int,
	errType types.ErrorType,
	msg string,
	suggestion string,
) types.ErrorViolation {
	v := makeSimpleViolation(filename, line, errType, msg)
	v.Suggestion = suggestion
	return v
}

// ============================================================================
// DOT Visualizer Tests
// ============================================================================

func TestDOTVisualizer_GenerateDOT_WithHierarchy(t *testing.T) {
	graph := &types.ErrorGraph{
		Package: "test",
		Hierarchy: &types.ErrorHierarchy{
			RootErrors: []*types.ErrorNode{
				{
					Name: "ErrRoot",
					Kind: types.ErrorKindSentinel,
					Children: []*types.ErrorNode{
						{
							Name:    "ErrWrapped",
							Message: "wrapped error message",
							Kind:    types.ErrorKindWrap,
						},
					},
				},
			},
		},
	}

	viz := NewDOTVisualizer(graph)
	output := viz.GenerateDOT()

	assert.Contains(t, output, "digraph ErrorHierarchy")
	assert.Contains(t, output, "node0")
	assert.Contains(t, output, "node1")
	assert.Contains(t, output, "node0 -> node1")
}

func TestDOTVisualizer_GenerateMermaid_WithHierarchy(t *testing.T) {
	graph := &types.ErrorGraph{
		Package: "test",
		Hierarchy: &types.ErrorHierarchy{
			RootErrors: []*types.ErrorNode{
				{
					Name: "ErrRoot",
					Kind: types.ErrorKindSentinel,
					Children: []*types.ErrorNode{
						{
							Name:    "ErrWrapped",
							Message: "wrapped",
							Kind:    types.ErrorKindErrorf,
						},
						{
							Name: "ErrCustom",
							Kind: types.ErrorKindCustom,
						},
					},
				},
			},
		},
	}

	viz := NewDOTVisualizer(graph)
	output := viz.GenerateMermaid()

	assert.Contains(t, output, "```mermaid")
	assert.Contains(t, output, "graph TD")
	assert.Contains(t, output, "ErrRoot")
	assert.Contains(t, output, "ErrWrapped")
	assert.Contains(t, output, "ErrCustom")
	assert.Contains(t, output, "ErrRoot --> ErrWrapped")
	assert.Contains(t, output, ":::sentinel")
	assert.Contains(t, output, ":::wrapped")
	assert.Contains(t, output, ":::custom")
}

func TestDOTVisualizer_GetNodeColor(t *testing.T) {
	viz := NewDOTVisualizer(nil)

	tests := []struct {
		kind     types.ErrorKind
		expected string
	}{
		{types.ErrorKindSentinel, colorGreenLightBg},
		{types.ErrorKindErrorf, colorBlueLightBg},
		{types.ErrorKindCustom, colorOrangeLightBg},
		{types.ErrorKindWrap, colorPurpleLightBg},
		{types.ErrorKind("unknown"), "#FAFAFA"},
	}

	for _, tc := range tests {
		result := viz.getNodeColor(tc.kind)
		assert.Equal(t, tc.expected, result, "color for kind %s", tc.kind)
	}
}

func TestDOTVisualizer_FormatNodeLabel(t *testing.T) {
	viz := NewDOTVisualizer(nil)

	// Sentinel without message
	node := &types.ErrorNode{
		Name: "ErrSentinel",
		Kind: types.ErrorKindSentinel,
	}
	label := viz.formatNodeLabel(node)
	assert.Contains(t, label, "ErrSentinel")

	// Non-sentinel with message
	node = &types.ErrorNode{
		Name:    "ErrWithMessage",
		Message: "something went wrong",
		Kind:    types.ErrorKindErrorf,
	}
	label = viz.formatNodeLabel(node)
	assert.Contains(t, label, "ErrWithMessage")
	assert.Contains(t, label, "something went wrong")
}

func TestDOTVisualizer_EscapeString(t *testing.T) {
	viz := NewDOTVisualizer(nil)

	tests := []struct {
		input    string
		expected string
	}{
		{"simple", "simple"},
		{"with\"quote", "with\\\"quote"},
		{"with\nnewline", "with\\nnewline"},
		{"both\"and\n", "both\\\"and\\n"},
	}

	for _, tc := range tests {
		result := viz.escapeString(tc.input)
		assert.Equal(t, tc.expected, result)
	}
}

func TestDOTVisualizer_GetMermaidStyle(t *testing.T) {
	viz := NewDOTVisualizer(nil)

	tests := []struct {
		kind     types.ErrorKind
		expected string
	}{
		{types.ErrorKindSentinel, ":::sentinel"},
		{types.ErrorKindErrorf, ":::wrapped"},
		{types.ErrorKindCustom, ":::custom"},
		{types.ErrorKindNew, ":::sentinel"},
		{types.ErrorKindWrap, ":::wrapped"},
		{types.ErrorKind("unknown"), ""},
	}

	for _, tc := range tests {
		result := viz.getMermaidStyle(tc.kind)
		assert.Equal(t, tc.expected, result)
	}
}

// ============================================================================
// JSON Visualizer Tests
// ============================================================================

func TestJSONVisualizer_GenerateMetrics(t *testing.T) {
	graph := &types.ErrorGraph{
		Package: "test",
		Metrics: types.ErrorMetrics{
			TotalErrors:  10,
			ErrorReturns: 5,
			ErrorWraps:   3,
		},
	}

	viz := NewJSONVisualizer(graph)
	output := viz.GenerateMetrics()

	assert.Contains(t, output, `"totalErrors"`)
	assert.Contains(t, output, `"errorReturns"`)
	assert.Contains(t, output, `"errorWraps"`)
}

func TestJSONVisualizer_GenerateMetrics_NilGraph(t *testing.T) {
	viz := NewJSONVisualizer(nil)
	output := viz.GenerateMetrics()

	assert.Contains(t, output, `"error"`)
	assert.Contains(t, output, "nil")
}

func TestJSONVisualizer_GenerateViolations(t *testing.T) {
	graph := &types.ErrorGraph{
		Package: "test",
	}

	violations := testViolationsPair(" error")

	viz := NewJSONVisualizer(graph)
	output := viz.GenerateViolations(violations)

	assert.Contains(t, output, `"count"`)
	assert.Contains(t, output, `"violations"`)
	assert.Contains(t, output, `"count": 2`)
}

func TestJSONVisualizer_GenerateViolations_NilGraph(t *testing.T) {
	viz := NewJSONVisualizer(nil)
	output := viz.GenerateViolations(nil)

	assert.Contains(t, output, `"error"`)
	assert.Contains(t, output, "nil")
}

func TestJSONVisualizer_GenerateSummary(t *testing.T) {
	graph := &types.ErrorGraph{
		Package: "github.com/example/pkg",
		Metrics: types.ErrorMetrics{
			TotalErrors:  10,
			ErrorReturns: 5,
		},
	}

	violations := []types.ErrorViolation{
		{Type: types.ErrorTypeUnwrapped, Severity: types.SeverityHigh, Message: "test"},
	}

	viz := NewJSONVisualizer(graph)
	output := viz.GenerateSummary(violations)

	assert.Contains(t, output, `"package"`)
	assert.Contains(t, output, `"violationCount"`)
	assert.Contains(t, output, `"metrics"`)
	assert.Contains(t, output, `"totalErrors"`)
}

func TestJSONVisualizer_GenerateSummary_NilGraph(t *testing.T) {
	viz := NewJSONVisualizer(nil)
	output := viz.GenerateSummary(nil)

	assert.Contains(t, output, `"error"`)
	assert.Contains(t, output, "nil")
}

// ============================================================================
// HTML Generator Tests
// ============================================================================

func TestHTMLGenerator_GenerateMetrics(t *testing.T) {
	graph := &types.ErrorGraph{
		Package: "test",
		Metrics: types.ErrorMetrics{
			TotalErrors:    10,
			ErrorReturns:   5,
			ErrorWraps:     3,
			SilentSwallows: 1,
			PanicsOnErrors: 1,
			IgnoredErrors:  0,
			WrapDepth:      3,
			MostCommonErrors: map[string]uint{
				"connection failed": 5,
				"timeout":           3,
			},
		},
	}

	viz := NewHTMLGenerator(graph)
	output := viz.GenerateMetrics()

	assert.Contains(t, output, "<h2>Error Metrics</h2>")
	assert.Contains(t, output, "Total Errors Found:")
	assert.Contains(t, output, "<strong>10</strong>")
	assert.Contains(t, output, "connection failed")
	assert.Contains(t, output, "timeout")
}

func TestHTMLGenerator_GenerateMetrics_NilGraph(t *testing.T) {
	viz := NewHTMLGenerator(nil)
	output := viz.GenerateMetrics()

	assert.Contains(t, output, "Error: graph is nil")
}

func TestHTMLGenerator_GenerateViolations(t *testing.T) {
	graph := newTestGraphWithSingleErrorInfo()

	violations := []types.ErrorViolation{
		makeViolationWithSuggestion("test.go", 10, types.ErrorTypeUnwrapped, "unwrapped error", "use %w"),
	}

	viz := NewHTMLGenerator(graph)
	output := viz.GenerateViolations(violations)

	assert.Contains(t, output, "<!doctype html>")
	assert.Contains(t, output, "unwrapped error")
}

func TestHTMLGenerator_GenerateViolations_NilGraph(t *testing.T) {
	viz := NewHTMLGenerator(nil)
	output := viz.GenerateViolations(nil)

	assert.Contains(t, output, "Error: graph is nil")
}

func TestHTMLGenerator_GenerateSummary(t *testing.T) {
	graph := &types.ErrorGraph{
		Package: "test",
		Metrics: types.ErrorMetrics{
			TotalErrors: 10,
		},
	}

	violations := testViolations("1")

	viz := NewHTMLGenerator(graph)
	output := viz.GenerateSummary(violations)

	assert.Contains(t, output, "<h2>Summary</h2>")
	assert.Contains(t, output, "Total Violations:")
	assert.Contains(t, output, "CRITICAL")
	assert.Contains(t, output, "ERROR")
	assert.Contains(t, output, "WARNING")
}

func TestHTMLGenerator_GenerateSummary_EmptyViolations(t *testing.T) {
	graph := &types.ErrorGraph{
		Package: "test",
	}

	viz := NewHTMLGenerator(graph)
	output := viz.GenerateSummary(nil)

	assert.Contains(t, output, "No violations found")
}

func TestHTMLGenerator_GenerateSummary_NilGraph(t *testing.T) {
	viz := NewHTMLGenerator(nil)
	output := viz.GenerateSummary(nil)

	assert.Contains(t, output, "Error: graph is nil")
}

func TestHTMLGenerator_CalculateStats(t *testing.T) {
	viz := NewHTMLGenerator(&types.ErrorGraph{})

	violations := []types.ErrorViolation{
		{
			Type:     types.ErrorTypeUnwrapped,
			Severity: types.SeverityHigh,
			Position: token.Position{Line: 30},
		},
		{
			Type:     types.ErrorTypeUnwrapped,
			Severity: types.SeverityHigh,
			Position: token.Position{Line: 10},
		},
		{
			Type:     types.ErrorTypeReturn,
			Severity: types.SeverityMedium,
			Position: token.Position{Line: 20},
		},
	}

	stats := viz.calculateStats(violations)

	assert.Equal(t, 3, stats.TotalViolations)
	assert.Len(t, stats.BySeverity[types.SeverityHigh], 2)
	assert.Len(t, stats.BySeverity[types.SeverityMedium], 1)
	assert.Len(t, stats.ByType[types.ErrorTypeUnwrapped], 2)
	assert.Len(t, stats.ByType[types.ErrorTypeReturn], 1)

	// Verify sorting by line number
	highViolations := stats.BySeverity[types.SeverityHigh]
	assert.Equal(t, 10, highViolations[0].Position.Line)
	assert.Equal(t, 30, highViolations[1].Position.Line)
}

// ============================================================================
// Tree Metrics Tests
// ============================================================================

func TestTreeVisualizer_GenerateSummaryStats(t *testing.T) {
	graph := &types.ErrorGraph{
		Package: "test",
		Metrics: types.ErrorMetrics{
			TotalErrors:  15,
			ErrorReturns: 10,
			ErrorWraps:   5,
			WrapDepth:    3,
		},
	}

	violations := testViolations("")

	viz := NewTreeVisualizer(graph)
	output := viz.GenerateSummaryStats(violations)

	assert.Contains(t, output, "Analysis Summary")
	assert.Contains(t, output, "Total Errors Found: 15")
	assert.Contains(t, output, "Total Violations: 4")
	assert.Contains(t, output, "CRITICAL: 2")
	assert.Contains(t, output, "ERROR: 1")
	assert.Contains(t, output, "WARNING: 1")
}

func TestTreeVisualizer_GenerateSummaryStats_NilGraph(t *testing.T) {
	viz := NewTreeVisualizer(nil)
	output := viz.GenerateSummaryStats(nil)

	assert.Contains(t, output, "Error: graph is nil")
}

// ============================================================================
// Tree Violations Tests
// ============================================================================

func TestTreeVisualizer_GenerateSummary_WithViolations(t *testing.T) {
	graph := newTestGraphWithErrors()

	violations := testViolationsPair("")

	viz := NewTreeVisualizer(graph)
	output := viz.GenerateSummary(violations)

	assert.Contains(t, output, "ERRAUDIT ANALYSIS REPORT")
	assert.Contains(t, output, "Total Violations: 2")
	assert.Contains(t, output, "CRITICAL: 1")
	assert.Contains(t, output, "ERROR: 1")
}

// ============================================================================
// Tree Formatters Tests
// ============================================================================

func TestTreeVisualizer_GenerateErrorHierarchy_WithHierarchy(t *testing.T) {
	graph := newTestGraphWithHierarchy("ErrRoot", "ErrChild")

	viz := NewTreeVisualizer(graph)
	output := viz.GenerateErrorHierarchy()

	assert.True(
		t,
		strings.Contains(output, "Error Hierarchy Tree") || strings.Contains(output, "ErrRoot"),
	)
}

func TestHTMLGenerator_XSSPrevention(t *testing.T) {
	graph := newTestGraphWithSingleErrorInfo()

	violations := []types.ErrorViolation{
		makeViolationWithSuggestion(
			"test<>.go",
			10,
			types.ErrorTypeUnwrapped,
			"error with <script>alert('xss')</script> injection",
			"fix <b>bold</b> & 'quotes' \"double\"",
		),
	}

	viz := NewHTMLGenerator(graph)
	output := viz.GenerateHTML(violations)

	assert.NotContains(t, output, "<script>alert")
	assert.NotContains(t, output, "<b>bold</b>")
	assert.Contains(t, output, "&lt;script&gt;")
	assert.Contains(t, output, "test&lt;&gt;.go")
}
